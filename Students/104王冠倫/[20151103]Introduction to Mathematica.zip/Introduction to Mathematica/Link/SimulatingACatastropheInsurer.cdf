(* Content-type: application/vnd.wolfram.cdf.text *)

(*** Wolfram CDF File ***)
(* http://www.wolfram.com/cdf *)

(* CreatedBy='Mathematica 8.0' *)

(*CacheID: 234*)
(* Internal cache information:
NotebookFileLineBreakTest
NotebookFileLineBreakTest
NotebookDataPosition[       150,          7]
NotebookDataLength[    282278,       4469]
NotebookOptionsPosition[    254715,       3874]
NotebookOutlinePosition[    280982,       4435]
CellTagsIndexPosition[    280869,       4429]
WindowTitle->Simulating a Catastrophe Insurer
WindowFrame->Normal*)

(* Beginning of Notebook Content *)
Notebook[{
Cell[BoxData[
 ButtonBox[
  GraphicsBox[RasterBox[CompressedData["
1:eJztvXmUXldxL8pazzeKUCRHkqVWz3O3utWTutWjWq1u9dz9SdbgSZ7AI1OY
59EGMxgMGI9AgACBJIwmcBNCwnBvgm2mvPduCATWevfmvgD5864L5P3Neaf2
WFW79vlOt2RJtrfXqnW+s3ftGn5Vu2r7bEtuvfXlp2/9P57znOd05fS133vO
cy7Ln0/Mdf6vROebOhIlSpToKaaLXecSJUqUKFGiRBeIfmfoYtuRKNHTjX73
RNo/iRKVod8V0MW2LVGii0VF+2Ize2Wj8hIleibQed2X//dCZ5bowtP/lehZ
QRc7zxI9/fZ5efldF92/RIkSJUqUKFGiRIkSJUqUKFGiRIkSJXqq6b+v7k90
3qm7Oq0kSoSoTM4kelrR/3MOBHXkf5Si7kSJEiVKlChRokSJEiVKlChRokSJ
EiV6RtP/XO3+X4kSJbr49K+JnjH0PwT67yvFhHn/FT1jdLHzNVGiRIkSJUp0
weh3hi62HYkSPd3od/8z7Z9EicrQ7wroYtuWKNHFoqJ9sZm9slF5iRI9E+i8
7svfXjueFdF/IPot+x3QNYgicsrwRuevidEY4f0Pgar5dj5JxnKsgIpjsPF1
fK5Id5HcsQ3q36yeajI2iudm9Z+LndViWH6fPTtpomBcz/1/ZGwSzV0sKlcD
fnONp1/ntUoizOPXTlTNjXPNu0JSdTWk/8ht/A+hBv+HIcVn90VERqJEiRIl
SpQoUaJEiRIlSpQoUaJEiRKVpYHWjpzas/782Z8/B1o89TNSfNK4mQNZg0pe
hxvra2nLicvJ+dpynrYOp1/pa7Xy7LgmZVdOg3adWQPvQ+2d+ViXIsXbAtTm
qK8Vnq1ZX3O7ov7mDiUf+PoUtetncxv63W5+txs+64eVp2Uqf5oRGd5+w9OH
7AC92rZ280Rygb/Vyx4AwnrUnMamr7UD4dkWkpFl3weUnW1Er/W93/nncbDr
Qf+Ak2vwaDY8bq3FBGxsNfHz9hFb4beKpVnb2k5s7oMYtWI79XPA+dlqCGEP
fBZ7I1fpA6ybje5mn1fq6XLMY03tMDa2ej/7Wk0ssZ2t7QH1tbS7ddp3u97k
hOWzv838AIqL09nSYXJV+9DX0mH2hd9Dfr3XO9DsZeI95eLd6vMa70ntN35H
a9z+bvd7kuWTrR9eVoeJuZGF4tNnawmpJ23GZpQfsMebWrOBnPraOrOe1s6s
t7lTxb+3tSE70NqYHWhrVtTX1qpjY0jnI8SrRVOrnTO/Wz2PptbsgJrT8/i3
loHlm3clB8vW7wdatc4DLV7WAXg2NyvqRc9exaefvW4NsqGFPrUs4NXvfl2r
0WlssjqRTLe+hY5rm1udTCv3AFmjZfbmYx3tjVl3S2PO02zmmlWuduXUmcep
N6f+Rohbi6kReN+2+jrFahatOW2+VqA89LUF5xSu+TquA1i+zQlbB6E2NHf4
mu1qeIep076eBzU+RoQX2d3cLo+3oHesNzZP+OjeJWudng5qW2Ar9xX700HX
OV86sgAnQlhnRHegs0OwLyKXjwcyMU7CWoJHh8zX3BHOcz1FPsfsxX4HceC2
cX6GO8ZMwGNvTUO2Z29ONY3qCe9qjDwbydhey7e3Uf/eS8f3GJnUFpZzzcym
Zo4jyl0pD4hfHQw7LkeIvYQjty+Qw/0pkhfLhw5mhxQvwQ++17keHFcxj9uz
ECtmO9m7PN8ErMUawuqOVK9idROfF4vsD/Kc7SmOO6+7ol1CzvF9zOsQwV94
kjM890GIL9/nQV3voHJ5DyL285wR/A4w43VCqkOxePB1PHcku7m9fB9JOdAR
kcfjjtdJfEKOi/uJ68J5zH7z2sb/PU6SFeSOhDmX0R7KlOqqVIN4TZT6cLDf
NX9bQ6uidkNtDW1Ze2OrG7dzbY1tlKcBvxu+RjPeqH97uS2eGvUz2Eu5bdBr
XN+yvSjoWw1h30I9jvQy1LdsX9tj+xtei8YUv+mNzp69drzB91Ono5HqqQlp
j/HD8e6V5pBfe708i4PGpNHZsRfxUX2Ngc0coz17G0NMCTb03ODisLfR21Qj
6OZnjb0hLt4ndgaJ+ELjgnBBeUJ9oHHfw+Rh392Y09+IbGP4CfnH7d5j7OU2
ybnUyOQ3hj7ifWDjI9nAYoDPfVYOwVTcT2bNXuqzlZH6Vupbl1LfEvWJ519u
D7eR+UrkS7km2VAQW3wW5TnH5/leCGyO5TLXX4JaGF48j/g43//8/B/UByFf
uZ+8VgQxY5gH+Aj5EeSjZK+wV2L7XopJrDZwuXw8kMnyRYyBkOvE9o5wnusR
bNPnNTjX+bNdW2OrObu1krOdf7axcx2mNrSuLZxvbDXnPgGPFuYnj0U0Vh67
y3bty/7Trprssp3wzGlnjXrHBHOXwW87Z3ndGPq9087798uUjBo0ptd73Ugf
WkPsQLIvszbsZON4jKyp8fZjwrKJbXbOy7xMydhHbcVrEJ+Xvc/PYZt3eUwc
Ng7/mB/7GIYhTpcFviDZ6Onx20f4Ltu1j2Jgbdm1j+piuHsZNq4UH/4uxoE/
XS5S22luorGdnv8yZpfPWR5zn6eXIX8szjRvPQaXobWXReQRP5h/OIccvru8
DThXsf7L3HqbU/uIveEe2udyjNgu5pPfV56Hx2yfk+t928cwxXbsYz4weW49
9R/HCq/1+clyk+cW9oPkiBCHYL/6d4pXJO/RPqF738fX+7BX0669euwPYV6/
w7i19zKEz2XCPg32ALZT2ktYRrB/6B4I/EX4XYbyPYZLaAeyPagvFuN9gZ1h
HfW/L8OxjeafnBeXYX94rUXj3keWP7ymWV5sC+5/LKeCceuTe/K9wHKO1zIp
7iz2l+3ka/aFfgh16j+x/cb1kHq0C8fS+LET1x+cx7xO4ncpHgyvCB+Nj7xn
vM1UNjlTsJwn9RHn1S62H3GOobjiHA9qHMklCQ/WD3Av5nUN28kx2kX1pHMf
50/nvnTuozHC8tO5L537gnwsfe5Dsney2O30efVsP/elvsXkBTER4pz6FrE3
9S0qP/Wt1LeCfEx9i9UbtidQPtL6IvctuY763+l7RSznuQ60D8iafaEf6XsF
8nFf4OPT6XuF36t2L/HzmYThPqLv93bX5rQv25LT7+3ST/UbxnfVmnHNY3k1
fy15wlrFZ9cQuXT9Fml8l7fBrXNraqm+XbWOj89bmW79Ls+DdXn/+Npaxp/L
2oXX7SO6uZ1+jMrAGHvckN9Y7i60dpe302PHfHR83qYt2M/dzH7mw+8xmTY2
W/Bah7u3i+gnPqKcsDhb25yM2sBuh4eYAzSWzl62lvuJY7GF2LiP+cRyBOne
wtZTHjlnCL/dGyjnwvwSfMX5tmufEE8ao2DfRWhLsCcQbrt8HfB7WsrLfSaW
sRwI7SV7Ldg7PGZ8r1CMtmB72d73dUXKnXAv/h6zy+0jJH8LqSthPpI6tguv
zWss1Fn1jp477TgmxLO7xsveReuFsw35QfOc44VjGub6FsbnxpEOtweEXkDy
AuMQ2CDHItxT2A5e5zBvrbC/UV3AvgZ+s3zZ5d+37KJ+hLWI1VZTs7bwMVRb
pVzfEmAR2fsk31g8RRJsdBiw34F8oa5hfMjewv0ijFuAM89N3m9jtmA8CB+v
P8hW0l94PcByad/Yspva5PYxz9lI/4z1ELx+Czlnof0m5TnKS44b7/NbmE20
Ltp+QTFI5z4hD62v6dyH9pS3K537aNzDdXzv4ljy/BJ8Tec+kptBTJ4W5z4p
X/gcjwHfd8+2cx/HCu8dinnqWzymvK7g/YvzndqR+paQn6lvpb61O/Wt0B5O
tR5zsu+ebX2L4pO+Vwg5I+FbZKPDgP0O5At1LX2vCHM20j9jPQSvf6q/V7h9
HmDDc1qIhdH1+1fUadrDnpxgfE8tmq8tXLeVr3XP2nAcj11RhXcP1lGrbULr
tlh5AX+trCdCWyV7YtgE/gh47EEyyZy2a4vzRaA98bmtnE9aj/DYavRv5b4Q
HPn6feypdW3dg36L2NY6PRhP/7veYRPEG9ticm9rgY9b91DbojhI2EXiujUa
TxaTPYJM4X0rtyu6dyIxlX7jp+g3wxzp9DmJ1+4TZKBxw7cF+8xjs4fjK8UL
8ezheSzsNSZjq2RbmT0u1ZGSe1vjVcvWc33M192GrI3576270XiM7NpqubyH
4VyQA1Vr0R5MOg5bRcxqKX8E12o1MpBN+ksJWdVqNHrfSmperVzf8VwkvlvN
fLAejcl1no2XwYlhFa9HLE8LbCN1Xqo7ezxWkpxoPZHyAssJ9rMgS/JBWLeV
68djG80ZbntOWyLxidpk5zlmEh+uuc5m0yeDHhzBKCI3GqciTNK5L24/zuWi
dZs+9xm7C7EvYWeJ+JY793GqZU8mA/dDtu78nfuKc3hrQT2rGuPzcu6T82Zr
TB6WWbh3In5J/bbA7+rnPh7rSA4Yvi3s3BSeD2oL8SV5IdXLgj4R4lx+Xz/1
576Izah2FvXTarkh2iXoKMz7WC3ag+kSOPdxns3glPpW6lupbyGbUt8Kcjv1
rbjNqW+FuAf5m75XxHxJ3yvoXPpesTE8ZX5ak7ai9+furc+pwTztb03byHs9
eq8X1knvEmFZIXGdso6Y3nDNNvaU14dz2wQ/t4k6/Tuf34awfO7eHOs9+fie
ugLKdaDf8Nxm6LlsnPLXF8vei3gcHjb2dZREXfVVxuqoHU5uvZcp6XI8BqM9
1jaE2V4sn/q6LWpXvcHG84W80to6Yvc2h1Odeec4USx47Krp24bW0xjLcYjn
AdeD/ce60LvzI4YlliPFmT5l++M4b2P2b6sqp5rvPOdxDsap2p6u/hvnBPaX
+r4V0R/dPJnTVNbZ26b+fea5pi9sZTEq2tfb9oSxiOWQGzc5XVzfimu65dnm
6ltMBiZprMHsr7j+4tjwca7H+7ktylcvrMF2cayK+pusn2MWzz+qn/sQsyNc
Xy22/l3uwXTtNlGXbHfxXsM+UJu2BZiFvDQ28XEf7zCuNG9pr+fx3sZkUxnV
crIIg5jtZdeH4+ViIdWvdO7jc+f/3Fdub/AYhjkR5kyxTznV8JwLa0txnlXL
GaneV8sVAffg3BfL7XiMqI94X8fqfDyPw3pQjE+8HhTVNSl3yuyZ2N7m/vMa
Ktsq48PrHK8B1eyP48x74Laqcqr5Xm2NTOd+7ov5G9uTsRrVwKhIBq4L1XNI
OsNc2ue+ItxkDOXaFvNr8/mU+pasP/Wt1LfK7ZnY3ub+Y118L0u2xHKFx5k+
U9/i/larv7xGFdV62e5nbt8qE5sYng1MRvpeEcYlfa/gfeSZ9b1C0hfuixBr
v/YPahqzP9jXmG3fZ57mXVENeq8R3vex3zUNfoyM+7Ht+FnD5OwL+USKrBHn
aqjO7ZwH2xDzzWIkyOb4Ub4GTTWM8hhsZ+/w3GYIj29j9AcQwxo0htYHT0Pb
9/rndm6L468P1lt7iA1ct+BH/F3r2I70KHs4Tua3tXW7lbWX2SbZEMGU8Fa1
k9poaTvi8zjWk/Xb9vqnw6tIlzAX5Ab3xflTvzm5eym/xXcb0sPz0f1mcYjJ
Btv42m0YJ44LztW9DaL/nuqNDibHxonjofKr3tho96edQ3XNjsdqDOjN57cb
CuxEv7W/9SZGvg8D/fm9lewfPnF19q9fuzmbn+3X96xqb9Cnw49jLlKYC9sR
ERvtfov6yWq0UEur1WPST3idl+qoVI95D4rUdaqzAb03BPzbS9vQIPA2oD7S
kHFfRful3mZ8wv2oyC7ek/2zweSjYIegU+zX1eJbE85tr4mMS3qFuWhe1aAY
ur3LfbZ8DR7rWL5Wyc+orxyzGtnmELOGUDfLOfF3ydyJxjd6bmkI1vFzVzr3
FeEnYBPBT+QTbOS1gsdmu5XDaDveCzG7I/m7neslmDVE1/P9FY1bUS21+VEj
7KdI3ou5IuTddkZR2aXtDPOe11+y1yM1rGwNkvzhmMg1SupNJeRKODM9Qa0o
ygVRdlhzgt4r6ZJizPOZYy5hFcw3ONlBDatpLHnuw32/IKdqQv6NxAdjEMv9
cB83iPIKzzpVxi7auc/5nPpWYb4V1X2MUayec2yL7JPiXxPGJvWt1LfIvovE
LPWtCFbBfOpbT5u+xXVGbJTzKH2viOkU87NafIVanb5XyP5fct8rBF8K44D8
uLy2OduR0+V1TdmOOnjq9x21Tf43jNfqOftU82Zuh3uCDL9OyaxF8+bdzdei
Zx16Wl6sF81r24weN250K3lNRh9da9fYdTuQHZcjvZfXItnIFrxmB5K3o45i
o/Rz2teUbbfPHHs93pCTjs/lMGZitcPs9e3mucPsgx2OB/2uxb8bjbxQtyP1
rvVrfjvu123fp+e07AZ3RgUCW3bYd7u/jF6rYzvx2cxzGwBj8355Pq8xa1Rj
l9f68R213jaNm6/L3l+DibE5GDeYKl9qGxxmNg7bjf9Wl8ekyWPiYkfHNZYN
zk+rj8TP2qB4mhxZHDBezl8nr9G973Cyfcx3IJ4daA2OzXbsB/EZ+4Zzz2Bl
412D9Nl47/M2EvtqG6nPTi4eRzpqqR/OZjfW5Ox3+Dq8cRytfRjbRp1bZv7y
fSa/bG7ZXHO8NudYLtR6vssxL4mXtQ+Nob2zw+4f5D/cZX30bSv5eL0er0EY
231m+H3+NHrf7b6ytqJ9vB3FGu8954f5fbmt2eapa3QTrZG4/uF6jOqlr8vN
pn76+r0Dk+0BtsfU+vp9udFteXa4et3k63fQc1DPqvO1n/cBbreT43Q1o37S
lO3g9hv7rL2XIzttPyQ9DNvnMEZrsd2s35C+hnHDvQ7h42TF+hXr434MY0Ux
wNi7OLE+h3OD9sGmyDg+F7D+XtuE/Pd54GMf+nA5savJYyngu8ONMT0ohtQv
li+47+P+j3LeY8bk1DLbhRz2c+gM5faXnBdu/9VRu3A+O78w8VgQ/9K575zO
fWzfER9rUT0z8v4Q711UR7F/l+PfOO583wo1jsa8ya9lscIx97WY5jzhqWX+
1zKcSFzo/OUBjnSP+3g1IczRXiaxbCKxCveN7UXeHpzjWBfNtch+I/sBx7uJ
2ujqA8s7Vh9I/gh9dkcdwwmvZ3WB1DorC+9bYQ2tAz7udj/x+JI4orz1e7sp
sM/zoDMUqSkoZ2pR7rEa4/FhvvD8cn3Dn238PuD53oRiifZfLfMR41/r9fD6
hs8CtFeEMd+B8Q0wQ3aT/OFrmohf+BzG9eNef0me+3BN4fWrFuPmsU99K/Wt
1LdwrtG9nvoWzefUt5qJPalvoRijvNpQ33I+NAW+hT2H1qP0vYLFq47iResz
xopikL5XsHxB9Yn0rUvxe4WNrdB7SL3j+wDl2K6G1mxnfUu2s8GQ+g1jrfrZ
gN7tWL0eV2sJtfjfTiZdE/K2UBn1wtqcdrlxQRdZS+d3xfxh63bVMznEFjzW
Qp9OJuCBMMzpDxU162edPvuppyX+nsclfDayJ+dv8nJq6fxOQ4GuekxN4W8i
qwnpaUTvjcxWq0+Q5343UTzM750Yp+DZ4m0KMGuqjklAdq7J2Nzk5CqsnI1N
FKc65APzW8I+jHMTfa9FscF6q/nFcahtZvY0UYrFAOeBtZ344OO8k8gssLG2
GfFirBkWHI+oPwWYcj3muTPIb5NDdT6ndrqY+vxSezZfu8v+JqTHfT7q/PV5
i/CtxXh6O+2dEaa/eO9xRfau7XJ3l4bxbqR5ymrFTikX65pYznp/dxosoC6q
2ghjDc2oluPaK9TooI6jsXqhthI+qSdIeqV1Qq+pR73BvbcwedyfiJ31kt5W
hkukfwR9r8gv2ycMbz23NdJzne1CX471qsDeiB6MJ7J/F9dN9MbkFOmV47wr
tg7Fk/BwjIO4x/IBYyXkQ+CvPUNQ27Atu8jZycxh/np0BonlN8eHxJ37x3ns
OaxaPFBOOzvTue/8nfsimPBYBvszkrsF+yWoBWw/7MI5Wl9NpxQ/plfEv4Xp
i8WoRZCF95Hku5y38n6JYCLFg9QTHx/ZDp6/vJ7I2MtraZ5G612RX9F48njx
Gs9jKdgeiW/Y+yI21rf6f/chWDMsomcH7k8BpmKd4zUp1kN4jnj/Y3s4GK+P
1Nto/xXeybpIbHieBuMClkQOxWAXeu5CPJfWuS/1rdS3BJ9iMUt9qzgvU98q
tjH1rdS3ovFqzcr3LWmdgJ1Zn75XtBbkXUEN5nOsx6bvFS0CDk+H7xUx+SVi
YnJyd2NbdkVTe07+uRuRfs/HG9vpswmv0zyWH3j0E8kxevRaT1iWW+9ktpGx
3U5Pe2ifW298aLR2tBvdns/aJfntdDVS/6xPnqc9uwLZ4/SA7AZYn+dDTrtz
vHebXNqtvhdrgm/H9vu4/Vau3t23dERqrCWbW60osvP2W7SXp2sOvGu9+JkT
xLvB2qRpF6LdJsd2GxlKR/48de312anrbiB27bL6kU9Wr7arFcmlOjUeZrxR
26SwUpi1uXHbu3a7f4dpNhh6m70tdFzb0OyefYPd2cr8way5s8PYjW23NrY6
//Fv/8zH670PPJ7qt4tjS65vKOvP9XrbMEbNQRw8LtQ2Xbd0fEEm+EFyxsa8
HsehmdhL49xKfTI5stPYNTXZp/S0dBis6hDGxhZnn80B5qO7/6lrQZho2Ydz
crnr1rcw25sZNlTnTqOruasjW1kYyg5P9ZFYuRg1tpjcavP5ZXLN5p6ea/N8
Cp82t2Y3WdNCfztc/b8XWf1gF8Sf7pkm/axryj733uOKYGynGm9yOMP7YRMH
h1Md3WsWK7C3f2h/ru9g1prnd2yP+/3W5qnR1kpUyxp9Ld3N6yquiayWy7U4
/92I17SRmkx7AB3bLc5bG2N1mMm3/qEeckVA3n5iVyNds9uMEd+EniD7IPSQ
xjbWm7gM60vYn1w/bMSyeGxYvFivt/30Ct7rXA+kMsjT6UXxcHkUkUcwbs84
Xhh/3p89fmHvd364fMM9nPqOzyOux9tzSmM71Yl4dpMYeDkeE2oDz0Nqrz2j
hOcLGluUbwRvFl/sCzpH7Q7s4rmdzn3n7dzHc4T4Le9Z4k8j9X23ZAvZFyhm
jWGdDn0Q7AiwFGoK8Veqc0hGo7UlVgNoX/DxoHVI573Jucb2jMfb5S/pAcLe
Y7kT4BbNR17vuK7Qd88n1G+EB96nvJ6EexTXNrYHcG40SnZIcW6nPgmxJ/nS
SP0g+xTtdVpzhF5H7GNxEuqeZJeVSbHANU/qfaxO4vmgXto6GubQFYHtcl2K
zYf9gPJc0cRtYfucxIGu4XVWrqNWjid/1kP74yKf+1LfSn0r9a3Ut8I4p75F
62fqW5dS3+J60/eKcK+KNTp9r6Bxe5Z+r8C2455H90hYG/Bzb0tHTp3uWaN+
d6KxDjcWzDV3mKeds/wdwVqqB1NsLr6mRpQh8XHdnC+2xuqg62uiOs3vHI89
ze05mWeTpbbszNmbsiz7XfaOd9+bx7HFUwNQa3Zs9biaf+CRR+mdT32rWvO/
f/2/1TwQ/NZyWo2cVkUw9v/+278pnjNnbzTjbUhvmx5ralXzmu8m9U72T86z
J6cHHn3U6bT0wCMfVs+3G/17jB9//93vKrK2WCJ6VO62Olz+/ruPqzUWI6C9
7nf+bPTj8P8Skuhz7zuRveq2I1lrV4fDdI/FJMdveqov++6fXEPWwPu1V456
PHJaWxxWc+uLBw1GHgvQAWTxtM+1nBfWrKk1Wndrd0f2gdctyvog1vm6PYpa
1RzYvqexjdjyqttm1JyN7XX5WtDPff/Y3avG7zYjV6+/4+yk81nbxvxQmOo8
wP7Aun/63PUM3+PZXz98Wq9rQDmbP6cP92Vfz+e0HzNOlvXL5UHO/6pbjxDZ
8NvztJgYHDQxGA6w9jHQ8YW1PK4g8+4/OmZyrM3l1V7ze68ba89efdtRtWav
yzlPe9EaTK82ccGy7dPmS2t3Zx7/pTD+J0bp/Vr+BGyBrmhoVmTnb79uMvtv
QRxOKLy1/35/QV5xHD5295qy4woTY7CvbX9X9rG3r2lZ951Q9Qn8tjVrb06u
5jV3CvWzQ6iDaK45rIVyLS/qAbjuSjXY66e9qBONS7WZ2oh1eDtDG2qkdc1a
dwwbuZeGPYu8N3eg/snxlX2xGFBbOtF6jNNm+m3MP459KKtGHKO2aZ9p3ih7
Ue4FedaMzyESRliH7FONO7NUO4dIZ4fY2aMoXgU4N/Nc53upWD7HoQZh4/ND
ym8BF+F8lM59fD/G8kLOHblG8D3fyeKNsS2RQyzu8bwpwr9anZJrsM8zwb8g
r4rwYjnJ8Khp8fm8l2PWLNkq5UssH4Wa0SxhUZTLMdx9rH2c8J6X8jK+J0mO
Nku2hzWBxitWG4v2B/rdzPVUo1BWvDbLdUnKzRrBNylW1Gdqm3SGCM4PzdX2
npBXwXlCim9EX5RXii19j9Wa8CzRoXpgWLc7L4FzX+pb5fclxST1LQnzEL/U
t+I+S7H2cfI8qW8V5EBBbqa+Fb4/M/pWJ/sd5k76XpG+V0h7qbi2PHu+V8Sw
cbWsWbATjdW2dXtq78qfXXTMjrd3mznz21I+X+fGhLVt3WitHevK12AZSG6b
l+vG27qFp9XNeNu7Qz3q2WX86KI62mW5IS7cNqO7Hels7cz2AbWZZ6uvVffc
+151n/PffvzjbG9Tax6DNve9fG9jW3bPu9F8ox6raWx14/e8571ZV/9BRfe8
5143ButrcrrqBn1P9tCjH8muzn939Q/r79Q5Kd5cP3yr3gffq3O6xvADb435
hq33pf6mDbLtOtAJ9i6uHVf2Yd3aj3Zzj/W4eq9paXd0taTH1IS/f/xxRfB7
X2tO8MzzUhFgZ/HL+eH7+wffsJRVlkeyytJItp7T2SvHsg++fsndYQwP95pv
89qug/k7jMNdy8x0v8L94Eiv+p4P4+093Qo7WLO+OKLkVJaGtZ2K2tTz8/ed
UITHwHewwd672Hha2XeenVLvwyM92cfN/cHM9KDDCwjG4D5lr8FcU1v26tv1
fQm8t+/vVvaDfqsHbADfv/7IaTVn72LgOTM9oLHKcQH7Onu6nD/Wj30tKA7N
Ok5gm113UOHYqp4fNHcysE7lrc3Z3AaFbW4DYDc8fEDbb/3KfbBxsP7APVD7
/i5Fduw1tx0xMWhzMYCn88ngYm2HMfARdL/9pcfUbxgDnO68/rAbtzlWo/Yh
yiuTY6+5Xd9j1bTq+rrPPN27GXN52YrWAH7NPo/1U2Ps4p/bUpPbBTlp749m
Dg+4vb3X3ivCnZK5N95j7ixVHHLcYW2NwmVY4az8t/dPCC+I2fDIAaX/7Mlx
pf8FoN/YBnv+429fV+NnT41ns0eGXK2qbe3Kn13qvRbXZEN1pi7W4VqI+0S7
qa2u/tI6T/pFW+QZ/O4Sekak9uP6G+tfUTm4D1k/8zGhD9WRum94kb0LlZOK
xo7OZd0HR53ssZlj2Znrb8q6h0adjIXKlQ4bGAceLAfbA/8dwP6hUacbZIMO
i5XiN/Z0Dx1S/73A2NFjxFbQp3Rg+QgvWGN5wJ5aZ+dJZ5te53GDNYrXxAp0
gn7ba7Vdmnf/QWvXnMKgrl3Pdx885OzQmGhMQefYzBzBdzx/Vzz2zNHerfSD
XJj3+g1GDlMtf7/hHVNyTjL89O8wFlcaXEeR7i5nr8XZ7g14937zeHbnPhzT
PiPddfzM1E5/W9keC3amCvZPl5HZRdYH+Z7OfZHawHEJ4xLUnQg+ZJ7UtRhW
tL64GoxrsWBHneGpE+Lt6zjHrZvoiNqD4yTOdwW6CmPbztcw2VKeMx/CXOgq
8AXbgfGgOsk7t4fnIelTsu66dpR7PJdE6vJ71+0vipuLr8OC4Sj0bbIX2pk/
QZ6yXJX2MPO7jmOEc0Baa2uUs0vIoyLsi3I20CXFFGGF9RJ/fF6SPSXVA26j
4ed7NbCD7yuSO1hnDAuBGG9dINufY4K9xOJ2Mc59qW+lvsXrSOpbHI/Ut1Lf
Qjypb4n5k75XYL1dLj5hbnvbeezqSOyEekdiwPcty2e+h4OcwrZG5lkcw/3G
YyX1SlYHXa/F2KFcae8m79yOOo65w5L2kTpio1SrqN11kr28vwSxEPzE5wi+
h4J6xGtxGLun4nsFxZbncFHd8PIaOno0dQLt108yhsbVc3/I2ylQbFxax/VL
/NF3PF40x+3b7/V2lNETk+2pPpdZ39Gd1dve7WpmZ/YPjz/u/kxT9+CwukvY
Z+6V9jW1Z1/7q7/28wPDbg7+fBXMqfcWT5/58z9Xc/q7fEf2znvfp9bWtnYE
BOPvfO/70Fhnds2Nz1Pj8FTfsNV3bPPM5f2DuWOy8rX+tmx8ZlbLu/e9yB59
JwVrsA6t52at54abc7lIj8EEqK4VcrYTnWu7POV8MA/f6197x6y3VcnSuuC7
PMzf//pl9b6vWdt8/xuW1Lf7zt7uAL/O3v16fYuWcWJF3wnA0+kwWHz+visV
WV67zq45vjSi9A2P9Om7mduPOlysLY//yTW5PWBfu5HRbnw6GsQLxmDOvnfl
tvo4dDjZ158aV3yzM0N+7e10LY6F80PFoEPHweBodTodCC+w3d5/WTuOLxvf
8yfwW10w5zHQsh7/5DXqHkWvbXe5D3iAbC5Tx6Cd+KBtP+HGLSbcz3e8bF7F
vM70EppL/gm5BLpU7rWZPIOne++iMvAaMm+wzHWPHOoPYmp9AwwgH3EOunvF
Zl8LHNYkXztUvlpZNv9IPNG+6OrrcXsMbKvLx+3+sf5AjarPe4GuWZrK1rmg
Lkr1M+ghG6nXTJ7YK6TeFNEt2sH6kCQ36gPV+bFPfjr7xje/pZ6/+c1vs6vz
mgpzr3zdm9T4Bx58OHvy+z/IekfGlDz4bWUB7wcefMi9q7mcp3d4LPvJv/ws
+8ADeq2SmY9ffYPAnz/vftd7si98+TE1Bzpf+fo3qfHbXvQS9X51Xoe5bqBv
/J22G2z85a9+ZWyHdX+k5qwvet1+5YOy60Fr181qHN6tjbJdDxO7QOfyiVNq
7cTsQgb/KHzyOeAHsviCDGsnyNBx0TaBXOBx+h2mDzsfsc02Rhw/ha1btx/F
Yn+2fPyUWofXKJz/zvqzP7fx3dRGkx8Yb23jze7swWMBpDHpUZhADpTK4Vhe
S+c6cY+kc9/G9ZaJRQQPrL9aDKLxKGNTzL4CW7m9GCOFncW7hA0dRTJj+CMb
o9hFancR1tzmwt5kfJV4i/RLeR7k+AZiF9Mr5nVRvGP2ST17k/ZxndXqQ7U6
EYxttu5E8qSoNpZ532gsNxTnKrxSjGLnl9JYXSLnvtS35PHUt4ptTX3L+yrx
pr5VTmfqW+cQ5yq8z+S+9TT6XlGMS0+op9p+6eiR7XLjJXEjOJeoo9H44XrP
bdtgPQ34Ir25Wg50FOT1ZkjsrzE9HM8YvpEa1lGUWxGbSu9V3t/L9Ge2h/Pf
zd0Hzhs1ieO9m14vy7tQVM1uNt/VmzUp6skaO4FM/OGusL1L3eX857/+unre
+ZKXZnWtHZ5aOsz8X7t5+FY9eXRO4O9U9IJ8DOYmjx7L6ts6s3e9V99jwXf1
evVNXj+BYBzm69u6FIE91930fDV+3c3PV++atK3AA7b+0z//2MmoN3rrzL2Y
ktfqddg7Ka3DjoMefV8G+uqJnu6c/4nsH554Ims050zArNHkMoxhgu/wr7tz
DtnapeRZnz70hmV1f4Ht/ZtHzqhxi1k9JmQjPK9c0X8OBp5qDMn+wvuvVGTf
LV25csisOaRkvOjGafW+v68nf+9AOjqze14+r+4yvE5/N8flvs7cl3AZnG48
PaH4jh0dcn74tV3OD4uX9QPH2sbbrutWttN4f+G+KxVh7LjvmFSswK+cd9Tc
7dx4asKtt7G44ZS2f3S0X5RZ1ybFAOui+IAv97x8QeVBQ0d3kEOa9Pjr81wC
XcBnee1vTHYN/HZrTP5S6spe7OLfi+Jp4v8yE3+UgxZXu7e7D+g8f+ENh8l+
l3IWdAAv6Gxg+4rbBU/gff2ds85/2GdNeZ0CajS1ayO1ejP1uSm6rleQWcaW
3sjvjcqJ2Siv5fb/9F9+5n5/8bGvZNfmtQ7Wfu8HPxTX4/Frct77H3rEybVz
8Pe2vvoNb1a/Dx9byv72m99Sv0H2/Q8+Isqy1D864cZBtrbH8zdFbNe8zzO/
Hw7Wxe3qFfUU2YUJZAJuWq7GDfNxfFdPngl0YP3XIkzt+yc+9aciBliGX9cb
8aE3u+MlL1N2VsuBajaG8rXOT3zq00o+YAvzgBnMbWyv8bztFfP2fNGz+txX
Go9zwbL8uvODXczHMtj0luQN7Y3Zvtlafu6x3oysjft97nZtNGdD/gux58rm
aHVb4n3/fGD61OXb+fKlDD+Xe/5i/tSd+1LfOj95tDm/Ut8qH//Ut86HXalv
nc9Yp751rvEpG/en9/eKjcdEllUaz65zi125mlO9VmzU12LejdXNc6UyGJTL
0/NFof84hzei73zY1tbbn7XnBM9WQ229A+rd0wB7RqinYM6sbQ3G+wK57SXk
tgvrYjrjtsnrW3skOwYK/WvdD+v68ueBrGV/b9YC8e3qyWl/dv3zblV3OS98
6cuyf/vFv2Wf/YvPZQ3tnYrgm/RZc6e0euJk9utf/zqf/ws1d9bcAZ01d02N
ljq61Jidg/d3v+8+9a6/U1OCcZiH79dNnZquf94tahyeTeabdnMnntfy/+rr
X1c6MHl5Xe5+4LtPPJ7TE0pfU2e3ktGcP60ceFrZTV2agB+oubtH5X5rTi15
zQPsWmwPAwzzefgO/4YXzOm1Srb9Fq99fPFNRxRPb/8B7Xe7vid64I0r2cnV
0ZzGslNro/r3mqbx8QGDSXf+Pqb4T62POfubjPwvvv9KRfbd6rRr4NmI7jkc
9u0+BnRO343ou4U5J7PJ2EJ42z0/6LnpzKSafyfc13z++uwbj5whscZrm2AM
xfSL7z+pSMegx2EJdGDggJL3N4+eyXVMOYxOroyq+0DwX8Xb5B/Mad9HtR5E
/s4E8eW46/WdJm+6EH6j2r9ViifGysYA64FYAy/E/g253xBrWP/OVy6anNL3
9DafWlzN7clz6Zji1XvUUKehHBf3jub9mv2ELI6QnzCPcyeIi4qn9t/7pHEF
jCx2Omdxvo6pp81vyFOfr3RfNTH7gPT+Oeb2msIjr1Wt+/t03VK1K1ZTB8Tx
sJbjWlutNpehgbwGDwiyq9fwcn0q3tdaC+Rzv7//wx863g89/Gh2Nq/38P7L
X/27egf60lf+MnvBS1/O+PsVL8xruQNuzsnpQTp6Bgh/m+MfyGYWl5UOeP+7
b307q5y+mspxtv5IybR9Hmz6k09/RvHBWs07EKyDOxUsz2LwfTP+QD5+veXv
0fYCz9HFFdEujOVPf/Yz9Vtj9Irsnnvfp2yy+q0ObhfGEY8TjHr8OksQFxtX
KRbtFtsf/BDZOhDEBZ8PYrbAeLtgexuKNSfA6bVveovCCrAZGp/K5PNHbK8K
cz1h3qdzH9vXmzj3wZ6kPlGcid9ITqutqZLsoD5Vt704NnL9tvLaC/XhuYGC
94I4VqH2AEeEQU/IizFtZe98X+oeIuVBMY54b/AeFORyD4uj9Jv0xD5qJ/c9
4A9zsb2nP56XPQW9uWzN4LLFvVhCtvO/L863gT0qyu+R4hKrZUUy+P4t8rUI
Y4Enlh/IPlnegCyjNMX3fXGu2bELfe5LfasoR8QcS32rCqapb4m5nPpWXHbq
W/GcYPalvuX1Ph2+V5yTLURufN+ItbFUX5ZrR9jnBwpj19pDZfBcbO/Fdczj
FMSvKpZCPyzVlzC/lNPl64D9vtDWE+MfEPpLnNrJ+pJnKQmXDX2v6C/sC5iP
5roe7+wbzGkI0WBI/UOMR+ItMx6Rb8f77RONkTUxGZyXyTPvHZK8fkkHGwM5
lkRbBrKOA7n8A7qO6V59QN1ptXYfyO697wPqLmfg0Fj2Z5/7nLrLajL3DECP
fvSj6v6qqaNL3evo+S53B3TDzbeoexu4F7J0g7mHgid8p773vverd8XX1ZO1
5GOaetQ4zLeo8V71Z8dueP5tev3zb81t7FF3SGCrfvYo3he//BXZ47k99u87
xKTl7TcyexQfkH23BPKtHnhvNfdVQI8/+aQifVY4oHDT2PUp/Bzt139f3xtf
eIzYqO3sVXLPrOu/Y+/M+pjBSt99FdEbX3DMYeLXjzuZinIdX/zASUV+3Ooc
Q2v2K3nw7v33+IRzPcgGc69g5HLe/sH+7BuPntH/H7DPX69s+eQ9FcUHc1gm
X2txAvpSvg6IxFvlqPZp6dghJRd0cKzgvqXZ3HVCvp02eJ3OMWgh+YbuTHJe
j9GYmnN3RZ371Vo8h3mbWR75GOh3sNXa+cQnr1VzD75pNXvp846qfFHUg+mA
f+Y+Qy7BWp1PB1Be9aK9APj0OnrjC+fZGsrrZfa4PRSLC/hn7xUtJhaPIrL5
eWZd/1m2M5UJZMuB0HZ4z/3V+2de+Q4YtPf4Xt4BlNeuDqHGdgV1saAO9+M5
qX6zmm35cX/p92s7iIxYP5B0cPvQez/WPyT0hCJbZb3/8rOfu/cv/+VXsxtv
uU29f/Pb33E8n/zTz5rxIXWXNDJ1RMl80cteoeasjVYW/HnX17/5ber37NKq
kgvzIMPydzjdQ9mDj3xYyeJ+w7i1x8vneOrfnteuu93JApu1Xffldr01sMvr
H8xGJqcdvx5/ZTR2IEPh1K/xAppdWlO6tZ8hvrDG2WTiAnpuANv7MUY8VkPE
F/sb7IU5FYvPfNbJVHr76XrwRftPc8zjOmhsXAtsB5s8RkeI/XbtiauuNTYd
UXIs1vKZB59zhLOMeLaR3tO5b1PnvsBerq+objEb+ofo7/6Y3yy+yLYOETNP
HWXjR2pdEeZFsY2tYz5H/eTjMRyknC6aL7N2kO3LAv5IDhTajn3ul/iq5E21
/VQG//6IbUVY91dby/OozL7R1EX2TlG8ByP6i+rURmrTRvOlTDxwbZD2T1xn
l6Crq5+vYTKD3I3EgeBJxy/OuY/Li+mtgnvqW6lvVd2LsdjG1jGfU9+qYvMG
9mthLLjdRfUlglfqW5uMB64N0v6J63x29a0YRpIdJfIvyDmv93x8ryiXM2zP
9Usyi9aGPsl7ZKP5Xi3Pq/m8kb1SYGeQO2WwpPHscDks2Vsyh/q9zK6gxpXF
rWxOsnysinNEXvC9okRekjWhf/sHh3M6qJ8DiAZjdJD+Hjho1hwM10myBiQ5
gg6Qh+1y4+iZU7f53T0gyTwY2juI7Cz0M/S1e5DZ4eTkcwNDijTGA1knfBfu
1f8d1uNPPpH9809+krV192Zveuvb1L3OzPyi++7/43/+5+yvvv43+e/u7N77
7nPzx0+dUb9vvOUW/W28qyeX0aPk3HSLvh86cebq/P1A9t7367sy9Z0aqNtQ
/hvGYR5+t/f05nQgu/kWfY8Fz/b9fflYn7a3p0/Nu+d+TW37ezXlur28Xqfv
8SeeVPdYeq1Zl+u6+VajJ3+2GbkdPfrb+RNPPqmoE+5Tc7wUdgc8fpY6Dui/
m+5NL5o3dlnb7LM3u6oyqXiuOj5pbOpV9xtveuExZXOrsR3o8NSw4r3l2mm1
ti238+oT+l4Ans7//frew97/WF3t5i7kquPmLiF/wvubzD0H9t/iAbb/+PM3
EHycT/stv+f1cnqzh968lv1TvnZlYVT7YWOM1rQpXb3UBuOD9+OU86PD3F9A
fno+b0cbirn1X+FnxqzvV1UmHK4275RfcGeS/16ZHyUYaZ5eg5+OGfDgd3g6
nHo0js4Gg+sTn7o2+9sPX5UNDg+4nFB5daAvzyeaPy6f1Hi/yqc3G4w1JqeM
fP0E26cPj7g90ZE/O3N684sWDLY+h+0TcPRxQ3vH/IY8dPE3GHuf9N3T4amD
xv9xt9f0HdoBdT8Hc8rf/H16asTk8BFnY4e1t7fPUL97B17wGXzvVKTPfEDd
/UOmfqF6N8Bq78BBP0bm9bN74GDYPwZo3aXyI/0Eyw5qNB8X+gOv0a4PCf0p
1qMkGhD6lRn79Gf/LPvWt7+Tffozf5b99re/zW6+7Q6l/yWveFX2re98R89/
57/oHpXTD370j9ljX/1a9tCHP5L97Oc/V7+B57G//KqSAT1tdHpGzQEP8N98
6x1qLciGcc3/NcUP4yevPqv4gP+xr35V8c+vrhtdXzU2DSv7YC3QTfkY8MNv
qwd45lcrzkZYB33Pzo1OH6V2Gbn2/aFH9RN8J3Y9+hFkh8+lN771ruzd73u/
+w2ybbzU75wX5r/17f+i7IR7LhuvmL3gO8Zo9PCMWg82KN8Bs0EvQ47F1xAf
zXuLM8gEm2Fc2ZjHGNaoWBsff4Pw/sGPfqTyhGDE9hLwAcbgwxuUbHTm4ecb
t/fCfdId5GrRfiuzD9K5Lzj3Id5uwe5uws98M9QtxpbjwH4jP7qDnED2DeCa
y9azuAU4YruxHyIf7wsHkQ/IxiAnYnW+SmxITxJ40Hh3LL8BG4I7taWb24X3
mvEtwN7xF+T4APsd2ycOOxsf5BOOG48Pk+1zkPVvbkNRn5V84jJ538d7QIp3
2X0Y2FWAubS/uf1oL3UTX4X1OW8P9y9WQ0itYj5H685BH0t2num2dQfvLzFf
sD6p7g3TeZZfsZ5yUc59qW8Jfqa+RdanvpX6VnTvp75leVPfuoB962n2vSKK
P6vp4b9XSjFEeznWlyW/GNZ0L8h1uXuQ2hucFQzFxrkvgX+BzTj/CuoF6SUH
yXpS/4rswjUS9zqpLsTyS8orvo+lmAzaenuQ1habIzwX2V7ye5/HUN6jcl4h
PYX9Vsqf4ezAwUOahg/536VpJPKbyutV76PheqazN6pHWLthu0eE9xEmZwTJ
G0XPkUI9vUMjinpyPHsstvBtGP4bhL4BdY/z0Y9/XH1nHhmfVO/ve/8Hsvbu
3uzowpK7F4I7C3u/9Oa33aW+1//6N7/OPvqxfG3vAf+tOieQB3Od6rv9gex9
H/igWqfuhHr7HME3bKUvn1dj8A0753nebXeo8bfcdXfWdWBAU58h87uzz/Bb
MjK1vPu9rgP6TuoXv/iFHuvrd3rectfbjZ63K1uxnl/88hfZ3/zt3+ZYDSq8
fC7nv/sNhooG1Hf4t7x4IV/X7+zVOgaUnmtO6DuQa05MGUz6soffsqbuOjoQ
HkAvf77+O95mjhzSMnKZ11w5pcZefssc87lf3ZkAeQz0uJWztjiudMIT3m+7
9ojjsQR2fOpdJ8ydipYNvGCjvsfzBGNw52Hx/fIHTymyvgaE8LZ3LVZWl7nL
gSfIeOJT16EYDJKYOxusPIPjl/J1X1L6+9yYx3vSY2JsUHcmL5534+DLva9e
DuyGMe9nv4qdisHz55wsKxfwV/j1Ih25r50oH7rVncyAyR1DNqcgv/rNnU3+
fMtLFlxOwW94vtkQ6IK5V+S54LHqVzwwfjTPG4Vdv5nr1/rXl/Td3m3Xzfg9
ZTB18T9g7mzzp49rn4s16NZY9RG8ISdUDvb2K5kgG2L58FvXvR2c0Ljy9SWL
yne1v+CsO3jQ1Sxbw8QaOMxrJ6/HQm3F9RL/HorU92Grp0StH8Z6RwUebo8g
h9dzaUzqIQGf1nXmuutzOps98pGPZs+/4wVufmn9uJrDctR7LuP5d9yZTRyd
02Nnrw/4gEDWxMycwwl+L+YylypYrrYB5oAfdFqfiD3DWrfls37AmOMx8dHr
XhjYHNg1rHs76JyYOab4ltaO+77J7Rqm+WXtgffx/OlsN5hQHM+SeP3wR//o
3rG9E0YOxUjbLMaC+DNiYnmDnL/INmxrNNZnz3q8TaxIjA6ycw/ZN1XyuCjP
ic2jkfEyOV9N77P33Be3aTSCcwQrXiuHuX0xXZavSt0U5URyR9Rv3odwrBA2
QzEdVXTZ8WiuIh1FPUjCsQgHm5PDjAqxi+FVsBcIX5X4cBoqEVsJN77/RAp5
Azyq5k9krmrNsvwlfCqyg+eew8mQ0KODOEblx2I6QmVLOgqp2rkpgqN0Zoqc
QwpjZXEX5y+Rc1/qW3FsU98ScCnSn/pW6lvV8InFKcaf+lbqW0//7xXxOBbU
V4xTqf6ife0tm3PVerykcyjUV8iP66jlH7K/BbuGhfwyFNSpol4l4lXC3mrk
cr3grLQR2cHeCTF5Sr5XbMZexDMwMqb+vjtF5ne//W3eBw+FPME69z5OKR/v
V/PjaN04Wzvux0bQGJY5Iui0tuW8g8SO8bi9WMYhbDN/9/YPYhucLd7e/mHw
cTTry/HsM+fN3sER9d9E3HrnC9Q9zstf9Zqsu09/1/7JT36Sff0b31B/xgPu
kWB+fsl8u+7R90Sf+/wXct6+7I8//nH1fsvtd2T71bf6AfX7N7/5dfbHn/hE
tr9fj73/gx9SfPvhW76iAUcw/v4P3q9+7wfqH8pl3KnG4S5pcW096+mH/4Zj
KLvrHe/Ifw9l49Mz2ZPf+1525tqz7g4A6P33az10fEjxaj0fcrxjh49kP/np
T6meXAfgctc77lHjd93zzuzA4HDWp84/w56GhtWZqDd/9g7qP6fy1j9aNOu9
XmvD2ZPTigeeai7387qTh933e8CpJx+vrExmT37quuzL9592du4f8Othbvbo
qJab4/jKW4+5v9PtrUoOyB7KDo0NZ3/34asVP8bHjjkZ+Risg/V3nD2qdGka
cnKdzQNg34S623n0LRWlH2wGv2EMbLf6QTbIBTuUPDXudWHfIJ6A2ZfvP+X8
sDieWJnKjudy4fcjb13PXnnbMS9P4WoxXFAY2nyz2MJT55Rfg7EC3e99zYr3
s0/bCb/Bp/e9ZtXZTmIwM6r9zMnGAJ427hC/v/vI1dno+IjLqbGJ0extL13W
Z2nIn4P62Tdk8knd1+h8Akw9Tvn6vkHiw6fffULZdwjkG/ze+kdLas2fvvvK
XO8hNQb677j+qLYh5wObwP652TFlE5DVhflAB8QDyGJicwX0upzICfLGYWp8
BTmvvE3/+S+IWc+gvpsCex7LsbExtaT3z1LWm/P0Dtl9ltervPf05f2gP+/t
UMOCuulq4zirw+Okbg6idYOSDFvjR2htJXX/EJeb13XSg8apbl7rg77Ce9OY
kxddE/QGRiPjmdwv9O9HP/qx7NYXvDDSG6VeymWxnhfwcnvHZbkjuo+/9e53
ZFefvYnJGvdYjEiYmnXX3+h41W+xR/KeH+I4iMYHAxlCDsTyguH1o3/8P008
x9V/p/GKV78291mwQczlSL+P4R+sk84sFN9i4vKlvKLjgzbOI2x9kT58VnEx
lnIrnfs2eu6jv1Esgr3G83vcrfU65L3j9mnEl0FnK5Lh5vgaIadHIpiNhPLC
GjSeiT5HcWdrwW4xd6vkc0GtCfVxjKVaw9bwnONYCfk2aOptyFd2n1s5Fhcc
e5x7wtpY3yrAZlDMff97sLQ8KUe4/BBT3BPCmjIe8VUYI3w8twpibP2M9nxW
h2K9SsilQVRH+vmaWP0cQfVXlCv5qam/ar+RcrBajvCeIdlxvs99Qh4QG1Lf
ErFKfYv6lvqWjFXqWywWIU/qW6lvbbxvhXF5unyvkPsuzneOcSxmUm9mutH6
2PcKsfaU+F7BeUX7eG5EavFT9b3C723Pm75XSGNC3Ynllhk/ODZpaII+x+3v
iXB+fFJYh9/9uiHy7mmYvQ8RPcLvcT82HMxLNCmQ4AvhxbIlf8DO0Mah0XFF
g6qOjebY6u/CcKf1wQceUPc1E9NHs94BfS/xsU98Qo3Bnx35/Be/qO549vf1
6/uAnOBOCMaAd/zwjLsjgjshey/05Pe/l00cOZodGDyovst/4EP6fql3YCh/
13SbuUPDBOtgze13vlC9f+FLX1LP733/+9kvf/lL9fvue96ZTc3MqjF4/+m/
/DRf9311dwbvH/+TT2YHhg6a+4IR9RvkwnpL8A68sObqszdQPb/Ser745S8r
nAaARhjZb+vwPHhIfYe/S91RDDud4Iel608fUTw35E89NqyerzLf+p/89HXq
+z78huf45KiS0zek79BuOHPEzdknrIHfj76tkl25OqXuF7AceL9ybQphMZy/
T7t1X0Ey7nvtmtLTZ+5V4DeMw70HyIEnkB0bnzxkfB3OJibHlCw7Z/VrTJaM
/oNk3NINZ2ac3sfM3Y+6a8nt+sqHzjhsYP59r10lWFnb4ffYxCGXa28z9zmY
YExjrv/OxrvUu44NYP0Yst/6aePQp+wfVrErioHGQ/OeJDifcTIBy5uuOopy
6ZAmm0vD+q4Zcgn4cQ65u6789/ys/rN1r759wdyF+TUffttxpQf0whPGFuYm
FYYn1w4XxH/Y00EdDyCXzyanwVeOFcTmAF6vZIxk971uzcUMx1PHfVg9eayA
T+MyqmtW3gdU/RrlNZrVwPFYnQ3r8bBYX4vG/NxQVL5Qz8eldVJvKu5T8X4h
9SbJLm0L3M9fd+PNVWyojkGR7cOiXNyXY7jx2MSwCW38s7/4nOl9ct8sjnNx
T/X44R6r/RzC68apPLDJ/p6ZX8i+81//Psf/nYJu7rOUZ7JNPPbymiLsEN84
twHHM5YDm8FZOrOUybvJdO6L5Kh07ovaXE1WgGPR2mo1pFrMi3QVYVMNS0ln
lVwMckuWPxToqbY36PuwqKM47+WeE8OqzL4rWROiOeyfcv+pjkMs14tt2RjP
EJFdvC84L93P0jOCX1BHq/ldBb9x2fYh0Z7QL7oG8Uhyx6V9EounvM/oXuF5
MhH8jtnqeamOi3Xu45T6VgznSUG2nCupb8VskfZKRF7qWxEfYj6Ftan6Gsnm
WMzK4VnEk/oW9xHxpL4ViYeM5dP5e0Xct1jOFNU12faL8b3C53RRLYmtL5PH
Exv+XhH3NcztZ+f3iqJ857lL+Q9NHM4OTSLi74qmQh5MeEzx5jQxZd6n3fwI
5uG/ka4RQQ/8v9idzAlu5xS1fWJK9oXb7WzE/OHvESYf7BvBtuVyhidMfOFb
sLvXGsu+9wN9b9N/0Hx7hjukF+g7JLhLgnueL3zxS+hb+sHsgx/Sd18rlePq
e3f/0Eh27fU3Zvc/+EB2/wMPZtfecKO55zmkngMHD+Xjeg38+Yp+oIMj2dTR
ueyOF77I3RnBb5AzkM9Nz85ld77oRfnzWLZ24srsHe96V/ahBx/Kzt50s7oz
Hjw0qujsjTdlH3roITUHPOvHT6q7OnVfZ3jg99kbb8zO3nBTNjg8mr3mdW9Q
/PCcnjum76pyHlgLMh4weobgHtVg5facxe9QPma/sY/o/8fS3S9b0f6O2Luv
Eef/a+7Qf+Zl8diUubcY0ZTPLS5MZa+5c1Gtv/mq2dzeQ4rAfv0tfzQ7fHhC
3X8cPjyeLeX8b895gf9UZVrrMgQ8MPeim+azqXyNlqUxsFjA8+arZ7O7X76S
vTbXu7Q45eeRTrAFbAPdwGflDuY+AY5KNpJ5+vgRxaP5jql1isfYdqpyJPvI
XccVDjflsoHAxgFj3+l8HngA05uvnsventv3ulyvlqN1gO/WFu3/EY2xwn1E
YQsY3/3SFROT5ezGHJPF+SkXl5vsO/gwPOrwAf3Wfvjt/DRPHYNZFYNFEwPN
O61lDB8iuTdgcH77y1ZzX1azm6+ZUzmDa7ir4zA+OqZyDvwE38B+yA/tn94z
joYPkZwD+wAb0AeYq1jkOu/OdS8vHDb/7cG4izHYAna99s4ltc7nh/3vPHQ8
nW8joy6WIlZoPRD4oSj3aXnxsIoj2PPim+ezw9MT2p6cD36DzeDLR+46oew6
c+Ko2mfDQOP6XD4yntfdvIaNmPo5Molr7xSt2VLtRTTCay+vt7hn4N4wKckX
ZEk9g8uc9Dp9P/H1fiSQN0VrP/GV67P24nVTbPyw02Expfbl71OYF+E4McX4
pyhmga9TAkbM5wlkg/J/iq51/RnHE81JseFy0TyNJ+/PDHcbE9Jz0RjSSezA
/Vo6U+DzgHhWYVhL78oGfE6Y8nw8ZpM+5u7cIJ6TQoyD/GV8o/jMEZzPfE77
vRee2Uawf+ncx9Zv/NyHYxzuHZQjZD97v0ei+0LAlu8BkiMUuxHuf5DXdM/J
tVOohVw/33dIjsMK28niNIL3jK3VrhYJ+1KMFcPHYR7B0e4T7A/by36foDxE
+nGNl+rzCMFmiumxPKwmkdyI5DGLndgLJryN1EfMJ+UlzymOG8+DKdrngz3G
8Cf7dcrrmaB6Rgr5D6MaNxXV53iwv+IzzF+rn+gQ6iGtxdMeU3E/4xof1oGg
vwvnjbD2sdgE+rlMQQ4/D10S577Ut6J2p77l85XnDrFdiDfWL+x7nGupb6W+
FcSJYJv6Vpi/3D4ui+P6TOtbUt7EcEnfK+R9xjBP3ysiuR/B3tmA6zHatzxm
uN5MXhrfK3D9D9aTOkRzZvzwEU3TR/zvGE0jqsa7GYrJfar0bdQOgcamph1B
7EZNXsH/B2t2flHdIX35sceyoUOj6j5Gf6s+5P5sEjxf87rXq+/o+nv+oezO
F71YjcOdD6xR9z2WRi2NE3rgoYfUmoOIV3/rHlXjcHfk5KB1w0Bj4/pbtvqe
bWhMpmFDsfGQxj2NYx2T2SEg9+8nnPQ8fGcfGdP/L6Z3vHyV+W2wyH366N0n
FA/HZZj4OE5sq2r/OLOfrY9hoX2cLMSxGLNN4pz7CRgBDoHP49YfGoOYnVgm
wdDg+rxr9P8bDJ4B1iyvzhuNC5ggP1TOVMmnESPD4kT3iqfpaZ9zsRwi+2Uc
xZyTxFsqByaRrkkmYzJCsnzw5Z5XrJF9B7Vq1PScscO6hl20mnteaObcavzF
6G3n3Oc24POm+C9Rmr4QvpSQfzHz5ULpSee+RBcY1zH1xPvvwtStsXPOg0us
vkb37Tn2ygvtw8XG8YLG/ALmPcf2ksd6A3amvpXoAuOa+tZ5xD71raeYUt96
2uCfvlc8vSl9rzgvNBYZnzpyVNPMUf8bv894mjzCxsz75IwgQ/o9E9HDx5je
QF/M5jJUzUYsP7YWYzI9k/PPqOdEjueEwhW+CR/O3vDmN6s7pHe95z3um/KI
+eb/zW9+0/1df7PH5tV9zDC6D1D3X195LDs0PqG/OxsanchpHJH6Hj2ZPfTw
I2qN59ffs+EJ4w8+/HB2aEzPkfWTU4rA3rHJ3G74po1o1D5hfsq/e/JrRtm8
/p3LnjBkeMbzJ2A0PmUIcJs22MF+sOOTh41dU+47PNxHjExMGj81XXNS/3mT
P347/H+L9J2F8mvCk7MD+8RsFX2cmKJkx6dCjMamGEWwdHiy36PCmgBXrhfZ
Bn6+85XrCgvnt8XAypjycsaRTEm+k8uwBLr1Ov33NcLT5eFkyKtwx3o4NlPI
F+6/s2varR1lvCqXwBe4S85zasLUNb8XUT7Z+AJOr9B/Hx++73H3P/nzHjO/
vjyD9pnHNMgDwXbym/OxMZd/kwJGQs5ov/0duo3nqMAL9oIvkBtjZh3QhNl3
qoZB/copWpuFOmxr5aTtAbHaat4ni+p1rP/E6jHXNYN4S/QYbAvuX5NIDvmt
eGdFO8R+hO3h+th7ke/iu9SDBYwm+W+hT8d6XTRWPI4zrP/zuVifnRF0R+RW
7cdFMSF2zIrrA5wkDHi+SGeBmL0xvGdCOyaZTMknnkuxs1HAH5Er2prOfYWY
RLGL1MhYbklzUbxK+hTU4phPji+sa5NMVojNLNEXrTUFuYL5gnoj1PTJQvxn
Zb+F+HJb4z4WYx7siwjusZoyGfNdwrVMngp6nQyh1kR7V9GYNF4tX2eEnGR2
8LWu3854H2K9RKq71fYTyQXek6rEMMYr9nWeqzOhPpIHku6If/yMEt1HZfM4
ZncEv6fq3Jf6VhW7qsWvAJModtX2SCQXU9+K50fqWxG9VSj1rbh9qW8V+3Yx
+1ZhnkfwTd8r5LH0vQKez67vFYWY4T0j7A/4++WOHJ3Tz5ymj5qnGbe/7Tx+
V7xH/Rr8e5qtmz5KZRwJZM7mz9lQz1FPWA62geuI2oB8xfZzn6YRL8bkyCzF
Ss/NZodzms5xPWzzw9xp/elnP6PukE5ddbX5pjwV3Dv9y89+pt7HJibdd3+4
C/hZPv6rf/+V/j6d0wTc+6jv9PYbdE5TmmD84UcfVfLGDT++T/nWt7+d/fa3
v8ne+Ja3ZM+75VYnB2gSnuYOCe7jpo7M0Oc0fcc0Ze7v7D3eVC7HkpU5YX5P
gvzpI2j9EbUe8Dpsnwa/w0fo3SDYCN/hP/aOk9lt1y8ouv3sQvayW5bysSvV
3D9/4cbs+Oos8W3C3GtMonsy7gO2f9LYPul8mHb2Wzl2fnKaYTCtf08hzPj8
5DTVO8XGptC4JYK9fTd2Tbp7CG/j7TcsZe9+dUWPHT4S8E3ma7E+HtcpYrOP
H9UznZ1Ym8ve9apKdmJ9juZSTl978OrsTS9ZI3ZNTjMi/mDfTQ5JNkmEcD+M
6tthUnMRP2CR75l3vUrf992W5xHQrWfn1fOlKqdOqrkPvemE3k/EP2O/ygW2
X6ZDLEVbzfOBN1+pCOedJZ+HLFcRuTw5wvKaxyy39V15TtyR54a16zDC6/CM
qWFHZ4N66WviLK27Qm0N1gn1+gir5a5uH2W1t8rT1/nZQL6ty2IfiNR7seeQ
Oi/0i6PCk/lwhM+xHhX4zynmO+qVQe+265DN3H7sg8KQ9TiOBe+vhbGO9Ohq
a6WeT+IgnS+OynqDuLGeH66fpeM2r47KeX9EwJLgLGEi4HKE28T3C889fNbi
TzbGzzgEE7yW4Z/OfSXOfRJWJBdnqVwhpyXsY3uC7+/AHx4jjlOslkTGOX8s
rgSjCJY0dqjHHJ0VdeJ8l/Y1xjeUX7w+VquoDbOET6r5vLaQWs/mef3jNuOY
HjkqYO/eZwlOQY1me4Xub9rbpX0Sy0Weg5xHysUo7sw+4juzK5rTTM8RPibo
xb0Q12nApWgP8vqGa3CwF7g9zK6g5khxiNRwUg+dDVXOZEIeiPtU2l9u/MKd
+1LfCvFMfYvhIeEo4JX6lhBjjIGQI3w+9a14Tqa+JdgpYPps6FtBrglPj2f6
XkFqB483y/P0vSKyp55B3yvkPkn9F/s7sv/osXmRZo8toPcF9WeG4rzxObu+
aN1shDccl+XEZFa3q5ysQj/mjimaAVL4HtPnnJx+/vOfZ//+77/S39WP+Dse
uEt4/q23q3unRx79sPo+ru4X0Hfsz3z2s2r+qmuvc9+cLU2j3/b90Y98RPG7
u5Qj+vs2PM9cc2327e98R83/8Ec/CmToXJl1T0VztH8ov2b5GO6Rs46m2W9M
R0z/BZpRdMw8JZlzyk4guFeQ6GsPXa3ubRYXj7q7DOvf9Iyg29pqfFJ6kb3Y
fr5Wnx1mA38D2xle4jy3p4iwjKiNpoZh/x3fnJ9nco8I/oexM3XSvrPc4/kI
cXnPa47T2M9G4lCVwvwitrM8Vbk0R3NqZm7O+wM2Hj2q7CvKqVfctuLu07xv
swhXbtNcAa6Sr3PZf37oGkXTUb/D/cL34QzG4CjPjzkaA7YHHVaGoI65uj9f
vsbPxn7Pb6zWzqIa6+Q4GfHaf251fkHsFdSnBWZj9b4m2TQrrPFj1XvbhvpS
gKnXIfnKe7Gkw58JJDwEHOeLYhPaLOET2hLDaUGIGT+3LBD/JF83kktFOUPs
FXDgvsZ8L5vvxftzI7mVzn0b2V84dvKe4TLLx2Jz+Ub1FK9ZCPMuqNlF9oY+
l8G/ONd1neH9gPsU0xGXXS6vY3jpXsZrTBz32LzPB6kPFNtTbd+EazfWV0Rf
5uO2lNonG8onqWdFeCNni8Lzx/xm60OYg+X8kfagsOeCmEk+CfkyL+upVu/l
vLw0zn3VsIjLSX0r9a3qvsfyI/Wt1LcIpb6V+lbpeCM56XtFCX/T94r0vaLc
muI897+PLSxugJayOfN7rgqvND8n/MbPamu4LdV4NmOjxFPENze/4Gh23u8X
/W3YfGuGuw5+94C+/x8hdw7ofsTckeDv8UcJHTM0R/lmqV5JnpVhv2HbfcKJ
144YT9F8lAxmsxhDLNfeERpf5O/94X3SDMKmrA+4hpb1KzZfbVyyp8yacN7b
OuNywd+ruvcCDMrgQmoMl43vcYXxsH8U699sLuF9OIfyKvDD3TfP0fsisw8V
oVyj+yWOqdRryu6huIyF0jGL5g/Lh9j+s1SmD6h6uBjW8DK1s0yNLytXWlck
Pya3bE87lx6yEXm8T27Gvmp9K2bfxnpwOZ4i+zerb3N+L20Kk7LjsbhtxrdY
TKTzUqn4LJ4LvuncV5ZXqk1FMat6vtyAvRvNr3PVu9l9Gqvf5zteG9NRPa82
m3dFsS6zJpyP2yrVoHOp6XKdWQp4iuSX8ftcan6ZPAh/L0XXbw6TjedfXIbc
pzYTx9gaTmWxfSrPfaKs1Lc2htcG45n6VnlKfWtja8L51Lc2mgfh79S3LrW+
VVZuWZylWrsRfRvFdTM8MR9iObZROWXtO5caUW3ufOXy5v1+9n2vKGOvxLOw
tIxoST8Xl9h4AS3y9UuRcb4W61pi/Hx9EcVsLfJhyT8DX5fCtYuSPP0+n6+f
z2ukfmrS2KLv6vDNeA59P56bJ3dRs8cwoW/z7vs8fy4o+Za0DkzHDM0jmceM
vHnFM2vWaBk0J7wvi5oWzPvCEvHT+n0Mjy1gDDAtsLWyLL7W3295P2YJnsco
Xsc0TsSv+YVQz0KBD8ZvYv+8xYavD30PfVokcrW+xYznTfC+wOdxjvG4LRA7
yRj5vYBiwWMtxWEhIpPm4DGWk0X6i+Mv2USxC3GPreF7Eu3LOZo7R9nd56x5
+j3I98qC3ytSLsRsxfYgXKmM4rjIeYXlFuPv9zi1Ua6Hkbop1ezC2i3U1cjc
fLRfcBlLEdlL7Aky5fFyfcP4ivyal3gXuQ2CrFJ9zds5X7UPlcW+hI+BjDLn
gCJMy+Ad0nxgB8eTx30zZwCJZ6P80nrJTuRPNP6y7vlCPr5nC2wrPI+lc99G
z31V/ZP8WeR6yuZvgU+LiKJ7xPps8qkqxiw2Ab85+5aKW7WcKjvP86tErIJ6
HK6fD3TF4ifldzE+Un+aF+NdZHc1vKrtO6lHFvdKnC9xmWwfR22slsNFNkVi
UhTfahTkyUawZ/ylem2VfCkVt6K8kmwvKwfHumTdlGp2VTyKYl+lhqa+RfFP
fasKTqlvifpS36KyUt+qEp8q+ZL6lntP3yu8nel7hYTnRvtmGfs3wy+tj9XX
5YvwvSIWVyk2VO7SympOK9ly/lzOn0vquWrG7e8VRKtkDX73YytofT62zHkp
uTXLbG7Z2rQS2LaM1i0TH7A9q8SeZSJnBdlmiftBfcFzywiTxeXlbCnHcymX
tbgE7ysoFuYbsflmvGAIf2+GOU9LZo3nXwQSYrioyMwtLInr6R2A1mFlLaL8
UT4sr2gf0BPGlR42vmTmPJ8ZXzJrgnksI1wXyAY5DsNF941+nt/H2HsR820e
cHD+OZ+WnV6sa2lJto36T+0N55dDuUwv1iGtW0J4Of4lPLdM7JBk23jofND1
YonPLy0j+1hMl7xNNGYhHjh3lJ2Lyyg/l9x7aCfFgdq0QjFeCvMwnp907dIy
j5+x29qJ9prKm+BezuaS4UP1ktti4yP7gPEs4ENjPt5SLPweW+IYkDjT3FW/
F5cJH9ah+IL6v0LqMK7BtlZjfl6Lad3kY2jdcji2JNR6LlPqS76OU5lF/Yn2
HCNnWeht4K/1eTnscU7W8krQc1SsmJ1h/+P44R5D55e5XufLCpMj+L7M9UpY
c/krTvbySgz7cD3lp/bz2HJfPc7eN7nfr2Q87ssMv2Xmg8+VVeQXi8myPxtI
5wieM9L5gOqXcJVwW2H7Ap+FwpzB5yMec+ksRm1O575zOfctYR+5DwxzYuMy
s4X4gDBc5rhiWTZPZJ+x3TxGUp5IeUj3C9+vzM9laqeEY5ijguzlMJZh7qIa
b21cpjlL85r6sbwcl8/rH6+1dJ8yuUxvmI90ndinSD1aIXZIsnH9DOuNr3G0
JlG8w/oR1nUeV4sjwXx5NWInz11sE6tly2EexvOTrl1e4fHD9QTvt3gf8/tO
qvE8DjEf5Loi9W4uT46F32NSrZN7+4pbQ+sH2z9BbvOz0YU893FZ0t7HcUh9
K/UtqS6kvpX6VpgrGMfUt1LfOn99K6z1QWyEmPF/b43V7tA3lpvpewWTv5Kl
7xU8LuG+5D0nrMNh3KR6RvcFrV3hurBW4LhJNVPCisdiZW09W11dy1bXLK2r
54qhVYkM/4p95ms8P12/YviJPPu+aoj95vx4zOrD9qxwu9awfeuUb5X6tcLs
x36srFIfVo2N3L7l1dV8fFU9MS0tr5C42ae9p1iy90fmPoDmt+dfMfKtDv17
zemB3/xMsLTM9wuWuWrw9raurBhaXTXz+h37huO0GsQEEbKX2rxKY7rG8gjz
OVv0/vT3NPbbu38uWvwMH44BxWnV5xjWTfJk3ftgaxiyh+RXsDfWxRzzvOsk
f/A+WEW48lzENvMcc7SC5lws1wj+y0JcloVxu1ZatwwyV2RenEvLK1SP4llB
7/lvWnfoHrV4aN/XI/kSwcvwL1t7kX2knwX3Tcvkjsf9e2NOdn8sE7/RGN4H
1v6VEGeC90rxGPaT109avzD+a4ZCW2N2cCy5bFL3V4V4ReKi98N6IBPXUYxZ
UEtQfwnsWQ3jTmv8OrHZ1y60B9k+DHxbDeW7cd6jVteZzSGOK6sCDkwm/x3G
3/aqdXkdwpvXDz4e8KyiWDnM1mlcV2kd8+NhD+XY8pjyOirlOO41q0xekDuo
jsfOLitMVrCXVhl+OJcwBgiXwF6+X9coHz0v+ZrF7Qzn16n9axIWjC/IDySP
5Hs69+EejX2InfuCPYRyhs87vHj/F+qphL8fo5gHPkXk+RixOPN9HGBO4xSd
L7Q5xIL2iTDH/G+5rhKbWD2mdZLmfrCP2bnP+Sf0BMkHsnY1nMM5dS7nPqm2
4nqF5fEaKNkkxmyV4kDjtx6PDcqloMetrdPYsZob1DGLPetlpO7E8CL2rAf2
BbWK137s8yolXmukWrCySv2TddO10hi2L7Apmg/+rCXVRdEOhmW0BgkxK4rL
Zs99qW95eyQ53s7Ut1LfSn1LwjuMX+pbJD9T34rGJX2vkP2hdlKZ/HcY//S9
AseK5I5Q86L1RchnXEep7KfX9wrJ/iDfWDxXGc5r65VsfX09p0r+e90RHlt3
4/a94sbUs4LnsIwKkbcWzGGdFaSvQvR5ezx5mRX39GvM74psC/cz8LFSQXo4
PhXCu17Rc7YOakz9GWON1RNfE1cd2fsV9W7WrCFZa072uhvH5901p4vqw3JW
14HWkU3reszqqYS4kPhV1on/6xxrEquKw9Fi5GRX4rFYMziuEb9szUI4rVEM
+RzF3ttkYxXGlecOHVsPcFlnuWpzphLwrwW+hnnq10m8FWJjFDvk9yrKF2Vr
xftK92Ql0EX3JtNZobm4ynNzfd3Pofxcr4T+hTr4vse1JoyJj6mfWw9km98m
1/HeWUH70ObPqskznFe0rltMWc6z+udyo4L4KhRruj/DWqvrKscH5WOF78Ww
vq6T/W5rwBqypYIwxPoqDvd1xCfnsucL4mdxqWAseO55/WR9xfvp9geSsW5r
UgXVImR/2Ae8T3wv2v0R7k+af+vCWFj/cD+qOPvDmkn3ttTfwt5G6yiPFY6F
3D+5bl4bpHoY1nm7jvTtShyX8PwQ9k9bP3m+4bG1YI7nk5SvtC6E9T/MZx83
X2NCv0Ks1tdxLGyc+NoifMI8prFdR3264n7T2kHzD9cTnn/p3Hfu5z5eR2Ix
lfY53+O8d9A4ytiEe5710oqv675OIjmXyLkvGhOCeYXZEeHjOfsMPvfJfUuq
7TxOvOYVn/toT2O5GfRdmzuhfxfy3If7Eo+zVK9iZ6noHtzEuY/yVohuX1c5
PigfS577iI8VXAdQzbjEzn2pb8m2SPs99a0Ql9S3whimvoXrUupbfu+EfqS+
5etM+l4R9t1YP5B6QpCL6XuFsHelfKV1Iaz/YT77uPkaE/oVYrW+jmNh48TX
FuET5jGN7Trq0xX3Wz7vSbka5vea3UdE3npWOV7J6Tih43ascjx8VhAv/23e
j6tnJeThvBXQFY7BWpBxPMcn0Kl4C2Rz/TGqFMxXzHwRj5F/nGHj95rPp4r9
jQnt1UqF5p/nQU8rl6xn/BW2FuV1pbIu8K1HY3s8hh/hgecJeR7FEuMlxq1C
11H/cd1e8/tnjZ6JOB6AeWH8Y/ZK+Ub4KjTmxB9h31RQjhDc8O9KdD7AjdtI
9hy3tyLYGMbmeLCuxH5xcVpXczZm9Ldgl1RHYL9HYhOMV4S5wLdQXrinUE9Y
w3VZyCeUh3JuC/Epk3tSDhbkXaVSKeApsc8K9txxFOPjZfaFzTspZqQ+V9uH
IYZSLhx3NTmSq7Ga4myga48H9S4iI5qzVbAQ9ii24fhxhBP7HbWB5TjBpyje
FTQf1O8qeSLFC9st+cp7p1QzeWyL+gjHuay9Yn5E9lCQwxFZONaVKmclglUF
EcKsStzL1U/kV7Q38binc190X23i3BfYFu19nu94UX8+zuTi9dVqUQXXGckX
ppfUhIt37qN8FWpvLPfEHCxB1fpbwJfOfdzn0B/Pc6mc+/h60mdj+chqUgw/
cV2Z3JNysCDvni3nvmqYpL5VFNPUtwr32PHUt1Lf0jJS3xLWlck9KQcL8u7Z
0rfS94oCv1COE3yK4l1B80H9rpInUrzS94pL/ntF1Zou7mt/pjl96lR2KqfT
iPi7Gzsdjms67flOnxZ5JJmnC2WGfKJdp+NzgY4CXTH/TmHbT0f4sc+n/fjJ
UyezUycNnTKE3k+eLJg/ecq9x7A6hXRJMk5iWUwXiV2JGFB8ThM/8VxxnnAs
5VxxvOCD8eckx6sKxXKP5AnyoShHivJO8uGU5D8ey/Mluseq7Zdqec5z1MYr
sAHlbiSPq8WyeL8Vx1aMd1HeFGBq/RTtRe8n2d47eZLvuRjJtgQx2gBWsViD
7FNV8SuBrYrraSpfyvEYriT+p5HMTeTDKW8H8a1wn5wO4ivhJa2PxqcoZnYN
XxvLJxGH0K+g3rDY0TyQ8S3V24rGeH+K8Qq+nWLxi8mJ90ih1hkcXH4hvSLu
RFe8lp0qxF3IE+ZfWYrVqWjOnBLqqmCfs+W0vC6699z6SG5BDIRzWTr3PTXn
vlM8N9l79AwSxF+2/5Qgs7Dvi3Iu3XMfxvBUtRhXs13Kw3Tue1ad+3DunYrx
i3RatCWd+8rSZs59qW+lvpX6lpiHqW+lvpX6VjSP0veKgnwScUjfK8Iemb5X
XOjvFdE6ejrso6dOYRw8TUzPJEqU6FlIk5eADYkSJUqUKFGiRImeekrnvkSJ
EiVK9HSi1LcSJUqU6JlPG631W3bXXhi6ojb7fUV1m6c9nraKVL9JMnKRrufW
NKnnZn0tot8voC3oGaULFDMcL643jCX3MRbH4jwIcRLmCuwoWi/bUeBL1Fe+
Pp6zYcyr5XkJnoJcf+5eoAZCW/cyPsKD9gCRXyfsi03k6gXM10SJEiV6ttNz
tu9+yuhi+5YoUaJEiZ559FT2rUSJEm2eLnZtSJQoUaJEiST6/wFtJUc4
    "], {{0, 0}, {1714, 38}}, {0, 255},
    ColorFunction->RGBColor],
   ImageSize->{1714, 38},
   PlotRange->{{0, 1714}, {0, 38}}],
  Alignment->Left,
  BaseStyle->{"Hyperlink", "DemonstrationHeader"},
  ButtonData->{
    URL["http://demonstrations.wolfram.com"], None},
  ButtonNote->"http://demonstrations.wolfram.com"]], "DemonstrationHeader"],

Cell["Simulating a Catastrophe Insurer", "DemoTitle"],

Cell[BoxData[
 TagBox[
  StyleBox[
   DynamicModuleBox[{$CellContext`amortizationPeriod$$ = 
    10, $CellContext`assetInterestRate$$ = 0.02, $CellContext`assets$$ = 
    0, $CellContext`debtInterestRate$$ = 0.05, $CellContext`liabilities$$ = 
    0, $CellContext`lossAmplificationFactor$$ = 1, $CellContext`lossCap$$ = 
    1, $CellContext`netpremiums$$ = 0.27, $CellContext`samples$$ = 
    10, $CellContext`view$$ = "histories", $CellContext`years$$ = 20, 
    Typeset`show$$ = True, Typeset`bookmarkList$$ = {}, 
    Typeset`bookmarkMode$$ = "Menu", Typeset`animator$$, Typeset`animvar$$ = 
    1, Typeset`name$$ = "\"untitled\"", Typeset`specs$$ = {{{
       Hold[$CellContext`lossAmplificationFactor$$], 1, 
       "loss amplification factor"}, 0.1, 2, 0.1}, {{
       Hold[$CellContext`assetInterestRate$$], 0.02, "asset return rate"}, 0, 
      0.2, 0.005}, {{
       Hold[$CellContext`years$$], 20, "length of simulation in years"}, 10, 
      100, 10}, {{
       Hold[$CellContext`samples$$], 10, "sample runs"}, 5, 50, 5}, {{
       Hold[$CellContext`assets$$], 0, "initial assets"}, 0, 2, 0.1}, {{
       Hold[$CellContext`liabilities$$], 0, "initial liabilities"}, 0, 2, 
      0.1}, {{
       Hold[$CellContext`debtInterestRate$$], 0.05, "debt interest rate"}, 
      0.005, 0.2, 0.005}, {{
       Hold[$CellContext`amortizationPeriod$$], 10, 
       "debt amortization period"}, 1, 30, 1}, {{
       Hold[$CellContext`netpremiums$$], 0.27, "net annual premiums"}, 0, 0.6,
       0.01}, {{
       Hold[$CellContext`lossCap$$], 1, "limitation on losses"}, 0, 20}, {
      Hold[
       Grid[{{
          Manipulate`Place[1], 
          Manipulate`Place[2]}, {
          Manipulate`Place[3], 
          Manipulate`Place[4]}, {
          Manipulate`Place[5], 
          Manipulate`Place[6]}, {
          Manipulate`Place[7], 
          Manipulate`Place[8]}, {
          Manipulate`Place[9], 
          Manipulate`Place[10]}}]], Manipulate`Dump`ThisIsNotAControl}, {{
       Hold[$CellContext`view$$], "histories"}, {
      "histories", "terminal histogram", "lowest position histogram"}}}, 
    Typeset`size$$ = {590., {147., 153.}}, Typeset`update$$ = 0, 
    Typeset`initDone$$, Typeset`skipInitDone$$ = 
    False, $CellContext`lossAmplificationFactor$24425$$ = 
    0, $CellContext`assetInterestRate$24426$$ = 
    0, $CellContext`years$24427$$ = 0, $CellContext`samples$24428$$ = 
    0, $CellContext`assets$24429$$ = 0, $CellContext`liabilities$24430$$ = 
    0, $CellContext`debtInterestRate$24431$$ = 
    0, $CellContext`amortizationPeriod$24432$$ = 
    0, $CellContext`netpremiums$24433$$ = 0, $CellContext`lossCap$24434$$ = 
    0}, 
    DynamicBox[Manipulate`ManipulateBoxes[
     2, StandardForm, 
      "Variables" :> {$CellContext`amortizationPeriod$$ = 
        10, $CellContext`assetInterestRate$$ = 0.02, $CellContext`assets$$ = 
        0, $CellContext`debtInterestRate$$ = 0.05, $CellContext`liabilities$$ = 
        0, $CellContext`lossAmplificationFactor$$ = 1, $CellContext`lossCap$$ = 
        1, $CellContext`netpremiums$$ = 0.27, $CellContext`samples$$ = 
        10, $CellContext`view$$ = "histories", $CellContext`years$$ = 20}, 
      "ControllerVariables" :> {
        Hold[$CellContext`lossAmplificationFactor$$, \
$CellContext`lossAmplificationFactor$24425$$, 0], 
        Hold[$CellContext`assetInterestRate$$, \
$CellContext`assetInterestRate$24426$$, 0], 
        Hold[$CellContext`years$$, $CellContext`years$24427$$, 0], 
        Hold[$CellContext`samples$$, $CellContext`samples$24428$$, 0], 
        Hold[$CellContext`assets$$, $CellContext`assets$24429$$, 0], 
        Hold[$CellContext`liabilities$$, $CellContext`liabilities$24430$$, 0], 
        Hold[$CellContext`debtInterestRate$$, \
$CellContext`debtInterestRate$24431$$, 0], 
        Hold[$CellContext`amortizationPeriod$$, \
$CellContext`amortizationPeriod$24432$$, 0], 
        Hold[$CellContext`netpremiums$$, $CellContext`netpremiums$24433$$, 0], 
        Hold[$CellContext`lossCap$$, $CellContext`lossCap$24434$$, 0]}, 
      "OtherVariables" :> {
       Typeset`show$$, Typeset`bookmarkList$$, Typeset`bookmarkMode$$, 
        Typeset`animator$$, Typeset`animvar$$, Typeset`name$$, 
        Typeset`specs$$, Typeset`size$$, Typeset`update$$, Typeset`initDone$$,
         Typeset`skipInitDone$$}, "Body" :> (SeedRandom[60909]; Dynamic[
         With[{$CellContext`x$ = 
           RandomChoice[$CellContext`yearProbs, {$CellContext`samples$$, \
$CellContext`years$$}]}, 
          Dynamic[
           With[{$CellContext`\[Rho]$ = Reap[
               $CellContext`simulation[$CellContext`lossAmplificationFactor$$ \
$CellContext`x$, {$CellContext`assets$$, $CellContext`liabilities$$}, \
$CellContext`assetInterestRate$$, $CellContext`debtInterestRate$$, \
$CellContext`amortizationPeriod$$, 0, 0, $CellContext`netpremiums$$, 
                "cap" -> (Max[#, -$CellContext`lossCap$$]& )]]}, 
            Switch[$CellContext`view$$, "histories", 
             ListLinePlot[
              Map[(Part[#, 1] - Part[#, 2]& )[
                Part[#, 2]]& , 
               Part[$CellContext`\[Rho]$, 1], {2}], Axes -> False, Frame -> 
              True, FrameLabel -> {"time", "insurer net worth"}, 
              ImageSize -> {590, 300}, PlotStyle -> 
              If[$CellContext`samples$$ <= 20, 
                Thickness[0.004], 
                Thickness[0.002]], ImagePadding -> {{60, 10}, {50, 10}}, 
              AspectRatio -> 1/2, BaseStyle -> (FontSize -> 14)], 
             "terminal histogram", 
             With[{$CellContext`histogramdata = Map[Part[#, 1] - Part[#, 2]& , 
                 Map[Part[#, -1, -1]& , 
                  Part[$CellContext`\[Rho]$, 1]]]}, 
              
              Histogram[$CellContext`histogramdata, 
               FrameLabel -> {"terminal net worth", "frequency"}, Axes -> 
               False, Frame -> True, ImagePadding -> {{60, 10}, {50, 10}}, 
               AspectRatio -> 1/2, BaseStyle -> (FontSize -> 14), 
               PlotRange -> {{
                  Min[-10, 
                   Min[$CellContext`histogramdata]], 
                  Max[10, 
                   Max[$CellContext`histogramdata]]}, Automatic}, 
               ImageSize -> {590, 300}]], "lowest position histogram", 
             With[{$CellContext`histogramdata = Map[$CellContext`worstcase, 
                 Part[$CellContext`\[Rho]$, 1]]}, 
              
              Histogram[$CellContext`histogramdata, 
               FrameLabel -> {"lowest net worth", "frequency"}, Axes -> False,
                Frame -> True, ImagePadding -> {{60, 10}, {50, 10}}, 
               AspectRatio -> 1/2, BaseStyle -> (FontSize -> 14), 
               PlotRange -> {{
                  Min[-10, 
                   Min[$CellContext`histogramdata]], 
                  Max[10, 
                   Max[$CellContext`histogramdata]]}, Automatic}, 
               ImageSize -> {590, 300}]]]]]]]), 
      "Specifications" :> {{{$CellContext`lossAmplificationFactor$$, 1, 
          "loss amplification factor"}, 0.1, 2, 0.1, Appearance -> "Labeled", 
         ImageSize -> Small, ControlPlacement -> 
         1}, {{$CellContext`assetInterestRate$$, 0.02, "asset return rate"}, 
         0, 0.2, 0.005, Appearance -> "Labeled", ImageSize -> Small, 
         ControlPlacement -> 
         2}, {{$CellContext`years$$, 20, "length of simulation in years"}, 10,
          100, 10, Appearance -> "Labeled", ImageSize -> Small, 
         ControlPlacement -> 3}, {{$CellContext`samples$$, 10, "sample runs"},
          5, 50, 5, Appearance -> "Labeled", ImageSize -> Small, 
         ControlPlacement -> 
         4}, {{$CellContext`assets$$, 0, "initial assets"}, 0, 2, 0.1, 
         Appearance -> "Labeled", ImageSize -> Small, ControlPlacement -> 
         5}, {{$CellContext`liabilities$$, 0, "initial liabilities"}, 0, 2, 
         0.1, Appearance -> "Labeled", ImageSize -> Small, ControlPlacement -> 
         6}, {{$CellContext`debtInterestRate$$, 0.05, "debt interest rate"}, 
         0.005, 0.2, 0.005, Appearance -> "Labeled", ImageSize -> Small, 
         ControlPlacement -> 
         7}, {{$CellContext`amortizationPeriod$$, 10, 
          "debt amortization period"}, 1, 30, 1, Appearance -> "Labeled", 
         ImageSize -> Small, ControlPlacement -> 
         8}, {{$CellContext`netpremiums$$, 0.27, "net annual premiums"}, 0, 
         0.6, 0.01, Appearance -> "Labeled", ImageSize -> Small, 
         ControlPlacement -> 
         9}, {{$CellContext`lossCap$$, 1, "limitation on losses"}, 0, 20, 
         Appearance -> "Labeled", ImageSize -> Small, ControlPlacement -> 10}, 
        Grid[{{
           Manipulate`Place[1], 
           Manipulate`Place[2]}, {
           Manipulate`Place[3], 
           Manipulate`Place[4]}, {
           Manipulate`Place[5], 
           Manipulate`Place[6]}, {
           Manipulate`Place[7], 
           Manipulate`Place[8]}, {
           Manipulate`Place[9], 
           Manipulate`Place[10]}}], {{$CellContext`view$$, "histories"}, {
         "histories", "terminal histogram", "lowest position histogram"}}}, 
      "Options" :> {
       ControlPlacement -> Top, AutorunSequencing -> {1, 3, 5, 7}}, 
      "DefaultOptions" :> {ControllerLinking -> True}],
     ImageSizeCache->{635., {243., 248.}},
     SingleEvaluation->True],
    Deinitialization:>None,
    DynamicModuleValues:>{},
    Initialization:>(({$CellContext`yearProbs = {
         16.426131400000003`, 14.932075320000001`, 13.549557412, 
          12.567523047000002`, 12.526003508, 12.478529076000001`, 
          12.221252545, 12.182781817, 11.932251455000001`, 11.092291423, 
          10.911553608, 10.844337103, 10.587533384, 10.011079681, 
          9.916498115000001, 9.781691679000001, 9.553680318000001, 
          9.308779631, 9.048634768000001, 9.05571127, 8.739863569, 
          8.621733934, 8.557224152, 8.504544961, 7.891515181000001, 
          7.8831183010000005`, 7.7319829780000005`, 7.679341916, 
          7.616457068000001, 7.4956045630000006`, 7.442257296, 7.274566218, 
          9.570276571, 6.945400617000001, 6.89890497, 6.816827890000001, 
          6.711107419, 6.607407781, 6.390972522, 6.2027398620000005`, 
          6.059239024, 6.054051601, 6.0497521800000005`, 6.029510684000001, 
          6.863229885000001, 5.988101905000001, 5.827287512000001, 
          5.864510652000001, 5.695238004, 5.690834838000001, 5.686454997, 
          5.608857792, 5.592576495, 5.552029727000001, 5.548060841000001, 
          5.5163423400000005`, 5.498623472, 5.40735816, 5.209393576, 
          6.1485465800000005`, 7.117741602000001, 5.090884889000001, 
          5.165489084000001, 5.6104424790000005`, 4.961545269, 4.893777653, 
          5.01078283, 4.854614837000001, 4.978560532, 4.808532305, 
          5.122115888000001, 4.746664837, 5.650342109, 4.605065741000001, 
          5.882890173000001, 4.522688417, 4.589842079, 4.388237915, 
          4.356991808, 4.369910703, 5.686832545000001, 4.2876825080000005`, 
          5.897912474, 4.250560790000001, 4.23310417, 4.199795654, 4.18391958,
           4.151514756, 4.15106144, 4.135003612, 4.1210117330000005`, 
          4.046623433000001, 4.297414998000001, 4.036276394000001, 
          4.013737559, 4.081668797, 3.967782108, 4.009505274, 3.955525343, 
          3.923680199, 5.9328645380000005`, 4.442517198, 3.8724898110000003`, 
          3.804127121, 3.7841350510000002`, 3.8046968440000004`, 
          3.7605468880000004`, 3.8427630450000003`, 3.7177781850000002`, 
          3.711141442, 3.6819670450000004`, 3.7649681480000003`, 
          3.6303737770000004`, 3.5818369850000003`, 4.180624826, 
          3.5559124310000003`, 3.5300866280000003`, 3.4996931960000004`, 
          3.475107404, 4.328662974, 3.376965069, 3.3755247550000003`, 
          3.3433635600000002`, 3.3476200720000002`, 3.349625247, 4.523742051, 
          3.313213199, 3.530808668, 4.350150188000001, 3.4518053820000003`, 
          3.2627826690000004`, 3.249208152, 3.248352311, 3.247896223, 
          3.717167755, 3.256179543, 4.349782080000001, 3.207884607, 
          3.124716996, 3.1154761090000003`, 3.103596549, 3.1718666360000003`, 
          3.0867774860000003`, 3.0859598160000004`, 3.079769542, 
          3.2218370870000004`, 3.2327488570000003`, 3.0587822210000004`, 
          3.032388789, 3.890786818, 3.004379934, 4.759445575, 4.209793827, 
          2.9775745110000003`, 2.9432363930000003`, 2.931689413, 2.995840874, 
          3.071454323, 2.895849767, 3.398727769, 2.844049525, 2.84193776, 
          3.07317317, 2.798425108, 2.795813035, 2.790865558, 
          3.8954226390000004`, 2.7529898040000003`, 2.7443338440000002`, 
          3.380196885, 3.2482864740000004`, 2.7243669930000003`, 2.722958611, 
          2.686138782, 2.68549021, 2.672654758, 3.042070841, 2.610933161, 
          2.5995355780000002`, 2.5915680890000004`, 2.5824576, 3.140871111, 
          2.705635082, 2.549903292, 2.897121351, 2.4708552960000003`, 
          2.4770235670000003`, 2.494739292, 2.4394930780000004`, 2.436119543, 
          3.3101837670000003`, 2.43095358, 3.3056169210000004`, 
          2.4111649820000003`, 2.5757414020000002`, 3.2771938730000003`, 
          2.383650176, 2.985126176, 2.438729929, 2.3666946340000004`, 
          2.791710165, 2.350166341, 3.317167706, 2.3454866830000003`, 
          2.335455664, 2.3353437880000003`, 2.4668986740000003`, 2.330258187, 
          2.3302144780000003`, 2.324768075, 2.3205857400000003`, 2.297592788, 
          2.2863354090000003`, 2.2590444350000003`, 2.223043084, 
          2.2179302290000003`, 2.217054031, 2.200928352, 2.243138922, 
          2.174233333, 2.1663115370000003`, 2.3314877050000002`, 2.152209049, 
          2.149310627, 2.274050495, 2.129264278, 2.1145338060000003`, 
          2.105689663, 2.207743386, 2.090155528, 2.0822712020000003`, 
          2.0720011190000003`, 2.0654947050000003`, 2.0647722390000003`, 
          2.060576411, 2.052058985, 2.1295508140000003`, 2.098857293, 
          2.358300706, 2.6842726750000003`, 2.0364108450000002`, 2.001660202, 
          2.0003197210000003`, 1.9946870890000001`, 3.3230315040000002`, 
          1.9825037620000001`, 1.969888338, 1.939478837, 1.999897465, 
          1.938005133, 1.93635738, 1.9287675890000002`, 1.9167809240000002`, 
          1.911144444, 1.9276223190000001`, 1.902933358, 2.0186851210000003`, 
          1.8924003800000002`, 1.9344489560000002`, 1.886977657, 2.096857113, 
          2.5759140680000003`, 1.8579165000000002`, 1.856610182, 2.113860582, 
          1.8477280390000002`, 1.8451016050000002`, 1.827441534, 
          1.8253997670000002`, 1.8252104290000002`, 1.8065055110000001`, 
          1.825156095, 1.797764157, 1.9518792390000002`, 1.784671587, 
          1.869767407, 1.774794159, 1.7736943420000002`, 1.773141327, 
          1.7653095740000002`, 1.7648623410000002`, 1.968191435, 
          1.7557101350000002`, 1.753055303, 1.752836491, 1.7466564340000001`, 
          1.7982490130000002`, 1.742195181, 1.798103433, 1.872683807, 
          1.766511536, 2.1421206290000003`, 1.7250799010000002`, 1.724652636, 
          2.3475952120000003`, 1.709097426, 1.82644657, 1.7047314800000002`, 
          1.9985142720000002`, 1.701102321, 3.2113574010000003`, 
          1.7559278690000002`, 1.676388245, 2.02451216, 1.670614606, 
          1.6694875530000002`, 1.684653124, 1.636752605, 1.8230624480000002`, 
          1.6299626960000002`, 1.6270052570000002`, 1.615642381, 
          1.6100532230000002`, 1.6091365850000001`, 1.6030629280000002`, 
          4.412063938, 1.599568225, 1.919557898, 1.5944412490000002`, 
          1.5900792990000001`, 2.536121758, 1.6282263600000002`, 1.751640576, 
          1.5779151850000002`, 2.357254316, 1.567640433, 1.567523436, 
          1.5673415670000002`, 1.567029741, 1.5640547150000002`, 
          1.5625418610000001`, 1.567159312, 1.561171872, 1.5568495830000002`, 
          1.554877386, 1.554542831, 1.5536987400000002`, 2.90587324, 
          1.770016209, 1.563111767, 1.815302584, 1.53590344, 
          1.5293677890000001`, 1.5305746230000001`, 1.526822235, 
          1.5107264290000002`, 1.5084296700000002`, 1.505435684, 
          1.5025074250000001`, 1.492064199, 2.509627793, 1.476627807, 
          2.068243562, 1.4688718390000002`, 1.46606096, 1.458293179, 
          1.4576155720000001`, 1.457137103, 1.4559789680000002`, 1.45319875, 
          1.4511879490000001`, 2.654945852, 1.4383161560000002`, 1.940191779, 
          1.4312191840000001`, 1.5503371860000001`, 1.687622814, 
          1.4270217710000002`, 1.723914455, 1.4147576800000001`, 
          1.4216609720000002`, 1.409836418, 1.407718725, 1.4025634340000002`, 
          1.398263571, 1.4328771370000002`, 1.654903406, 1.376922277, 
          1.375502311, 1.577258336, 1.359312134, 1.351633531, 1.349937433, 
          1.349926266, 1.349230984, 1.5000875200000001`, 1.3472168450000002`, 
          1.346786832, 1.351760386, 1.339309506, 1.337240339, 1.332622277, 
          1.331285693, 1.3242672850000001`, 1.3237920140000001`, 
          2.3804921510000003`, 2.008611494, 1.313234875, 1.312997785, 
          1.309175341, 1.303022936, 1.3021489130000001`, 1.290367596, 
          1.42937201, 1.276462516, 1.273074787, 1.2687163460000002`, 
          1.8446046600000001`, 1.896671661, 1.2615704790000002`, 1.258195194, 
          1.253888273, 1.464736818, 1.2392414980000002`, 1.2349675800000002`, 
          1.507991555, 1.520909939, 1.225397305, 1.2230545030000002`, 
          1.560311111, 1.213866994, 1.226875616, 1.212997059, 1.211269396, 
          1.2072281360000001`, 1.8256864330000002`, 1.199153603, 
          1.1918662530000002`, 1.555319485, 1.190079114, 1.3150607460000001`, 
          1.1873625190000001`, 1.186990381, 1.2811534210000002`, 1.185233942, 
          1.184590858, 1.181790259, 1.18112122, 1.380422822, 1.400449222, 
          1.1745973410000001`, 1.2484258860000002`, 1.167343234, 1.166414207, 
          1.1658205830000001`, 1.2362792690000002`, 1.1640711590000001`, 
          1.162198043, 1.821450631, 1.148446998, 1.147253434, 1.153640437, 
          1.721464217, 1.95966346, 1.137239857, 1.1346505960000002`, 
          1.129822026, 2.079741844, 1.1274498860000002`, 1.4005129520000001`, 
          2.148486782, 1.124949755, 1.121662941, 1.193710725, 1.121403238, 
          1.192408871, 1.1252563020000002`, 1.117636082, 1.116514822, 
          1.1250927290000001`, 1.114255135, 1.1140645630000001`, 
          1.1100489960000002`, 1.107647529, 1.1072836590000001`, 1.146655835, 
          1.103617015, 1.1465122620000001`, 1.099664331, 1.0946637670000001`, 
          1.0821598190000001`, 1.743584065, 1.3269189620000001`, 
          1.0768497510000001`, 1.075716047, 1.071865617, 1.067127482, 
          1.065240012, 1.06378904, 1.06323631, 1.096733918, 1.07991535, 
          1.058078824, 1.0576822810000002`, 1.049486233, 1.1333706460000001`, 
          1.048655288, 1.0484548070000002`, 1.048405869, 1.0474850450000002`, 
          1.1024083630000001`, 1.042447998, 1.0401697840000002`, 1.03862455, 
          1.264274943, 1.039606011, 1.035919504, 1.9332934060000002`, 
          1.025231699, 1.0263503820000002`, 1.0211973, 1.016144168, 
          1.014947151, 1.013843751, 1.2092358300000001`, 1.007569903, 
          1.0358210780000001`, 1.0034456920000001`, 1.0021841790000001`, 
          1.000526902, 0.999715133, 0.9963601860000001, 0.9963297560000001, 
          1.1667535820000001`, 1.8791777420000002`, 0.9940604780000001, 
          0.984217816, 0.9793055730000001, 0.979064432, 1.67934701, 
          0.980314199, 0.972196421, 0.9693748440000001, 0.969247206, 
          0.96885823, 1.3560749840000001`, 1.175104877, 0.97865535, 
          0.961302638, 0.960179847, 0.959036992, 0.9532436310000001, 
          0.952878101, 1.0029607090000001`, 0.9444722720000001, 0.942452861, 
          1.3124845360000001`, 1.705617127, 0.9330429530000001, 1.269387577, 
          0.9284672860000001, 0.9282906310000001, 0.9271923590000001, 
          1.007021471, 0.924623649, 0.9829002910000001, 1.1923583100000001`, 
          0.922121116, 0.922084251, 1.4431537890000001`, 0.9181196170000001, 
          0.9150850460000001, 0.9147654340000001, 0.9083181100000001, 
          0.915007458, 0.9398521860000001, 0.9050047080000001, 
          0.9048443110000001, 1.479823989, 1.021325269, 0.8963761240000001, 
          0.896087442, 0.892795738, 0.8905808230000001, 0.8860391590000001, 
          0.8827944040000001, 1.917978135, 0.899647336, 1.256802503, 
          0.8795564990000001, 0.8765687040000001, 0.8769131130000001, 
          0.8714339860000001, 0.99230728, 0.864978098, 0.863267647, 
          1.68848101, 0.8603611640000001, 0.8599325400000001, 0.859612546, 
          0.859196633, 0.8566514070000001, 0.856222769, 0.853763256, 
          0.8515831700000001, 0.8515337420000001, 0.850904828, 0.899266234, 
          0.84987153, 0.847965713, 0.8592580910000001, 0.839153209, 
          0.8365720280000001, 0.833847116, 0.8329474290000001, 0.832481149, 
          0.914861648, 0.831304146, 0.8263716360000001, 0.8261070250000001, 
          1.380352178, 0.821908305, 0.9070501310000001, 0.935268477, 
          0.815132417, 1.0184110130000001`, 0.811158813, 0.8665279950000001, 
          0.807618091, 1.514519608, 0.859480015, 0.8046044950000001, 
          0.7969083490000001, 0.976300397, 0.7953162460000001, 
          0.7946697650000001, 0.7934738650000001, 0.7930760200000001, 
          0.791093669, 0.790957298, 0.78973468, 0.7864493330000001, 
          0.7856509810000001, 0.785462195, 0.7844020140000001, 
          0.7817528220000001, 1.179249446, 0.775530335, 0.7669129760000001, 
          1.035778839, 0.7662133160000001, 0.7877529870000001, 0.764020158, 
          0.762529713, 0.76243739, 0.759433291, 0.7586687830000001, 
          0.754864379, 0.754772811, 0.753830015, 0.7506249580000001, 
          0.765781763, 0.7473282720000001, 1.266038523, 0.744658166, 
          0.744567159, 0.820832428, 0.744299185, 0.743352082, 
          0.7522610460000001, 0.738620895, 0.7367654800000001, 
          0.7367503360000001, 0.7353219480000001, 0.7333172490000001, 
          0.733305984, 0.7932354920000001, 0.7314103670000001, 
          0.7282257830000001, 0.7271148420000001, 0.7260701620000001, 
          0.766436666, 1.072458492, 0.963187267, 0.7219455370000001, 
          1.434187397, 0.7195555130000001, 1.460996028, 0.718749486, 
          0.718750077, 0.8906869770000001, 0.717778604, 0.716872178, 
          0.9889814010000001, 0.716487305, 0.7668689790000001, 0.712982572, 
          0.7126801110000001, 0.712261056, 0.739338524, 0.960631263, 
          0.711028322, 0.7106943130000001, 1.6509804730000002`, 
          0.7067435270000001, 0.705455555, 0.704456423, 1.3315268770000002`, 
          0.716963592, 0.7036779240000001, 0.7032292290000001, 
          0.7017158130000001, 0.8322549890000001, 0.7710705120000001, 
          0.699510521, 0.697055839, 0.74382859, 0.696147613, 0.695629375, 
          0.695565192, 0.6953492250000001, 0.69504957, 0.7779781090000001, 
          0.691256187, 0.816694629, 0.778325707, 0.686920324, 0.684509107, 
          0.6844848410000001, 0.683880351, 0.68352215, 0.683263975, 
          0.6816723680000001, 0.685282347, 0.679922323, 0.678906525, 
          0.678362707, 0.6774177050000001, 0.6761813790000001, 0.676001127, 
          0.673327285, 0.991964516, 0.6695203670000001, 1.010162099, 
          0.669196911, 0.66858328, 0.6679839830000001, 0.667174162, 
          0.66327228, 0.6631787560000001, 0.6623662720000001, 1.11417677, 
          0.6595719050000001, 0.68244317, 0.6572641100000001, 
          0.6550091650000001, 0.654335208, 0.654127965, 0.653632842, 
          0.8441434090000001, 0.6545911280000001, 0.821229788, 0.65092918, 
          0.648957823, 0.647430187, 0.6461494080000001, 0.677810851, 
          0.6438775560000001, 0.6437413350000001, 0.8527319250000001, 
          0.637843743, 0.637695662, 0.636017983, 0.828779173, 0.634805662, 
          0.6346881940000001, 0.6337983110000001, 1.2174574470000001`, 
          0.9254829590000001, 0.7067574130000001, 0.6312768320000001, 
          0.6309180050000001, 0.630656776, 0.6279450710000001, 0.627628728, 
          0.6269162070000001, 1.061243157, 0.625784067, 0.710756956, 
          0.623772757, 0.6590100790000001, 0.748148443, 0.619274957, 
          0.798123993, 0.7343743540000001, 0.6181599590000001, 
          1.0548844510000002`, 0.615709453, 0.717280013, 0.647998354, 
          0.682500855, 0.612256342, 0.678800049, 0.6106228850000001, 
          0.7543074580000001, 0.607725586, 0.606532158, 1.08916731, 
          0.605822728, 0.908848894, 0.602303993, 0.6001826610000001, 
          0.598355659, 0.597933586, 0.5978983880000001, 0.5973534, 
          0.597242621, 0.625073878, 0.594916958, 0.7098195930000001, 
          0.887605611, 0.5910228270000001, 0.590543106, 0.5898006640000001, 
          0.5891158790000001, 0.582425835, 0.9344181530000001, 
          0.5809785080000001, 0.5805730680000001, 0.6225846820000001, 
          0.579435664, 0.827830112, 0.575653776, 0.799073652, 0.574373397, 
          0.57430768, 0.8321232700000001, 0.5723100720000001, 
          0.5749585100000001, 0.571647259, 0.5715834200000001, 
          0.6501116520000001, 0.639984642, 0.619513712, 0.56451374, 
          0.563694522, 0.630178525, 0.562622937, 0.562214781, 0.560957625, 
          0.5594071890000001, 0.559099486, 0.642390572, 0.926064289, 
          0.55766074, 0.557183708, 0.5623415070000001, 0.563437367, 
          0.7209434170000001, 0.8044142240000001, 0.639646532, 
          0.5541076890000001, 0.552748066, 0.552700241, 0.552640309, 
          0.552355846, 0.552339589, 0.5511047010000001, 0.554597797, 
          0.550726146, 0.549812186, 0.5487003570000001, 0.5617690270000001, 
          0.546557625, 0.545126874, 0.5449657090000001, 0.5432617740000001, 
          0.542501815, 0.823690024, 1.087644899, 0.539108994, 
          0.5386872180000001, 0.538589575, 0.5382821710000001, 0.537123653, 
          1.032551283, 0.536292204, 0.866308351, 0.5684067780000001, 
          0.534601203, 0.533707518, 0.572197374, 0.757163806, 0.876110331, 
          0.5303988390000001, 0.529206355, 0.6172125810000001, 0.534777452, 
          0.5269209, 0.526254797, 0.5262301690000001, 0.525993256, 
          0.630028537, 0.5252708660000001, 0.524415484, 0.524227927, 
          0.523686037, 0.528788506, 0.5214038510000001, 0.520707052, 
          0.520513325, 0.520349185, 0.5194254100000001, 0.875591122, 
          0.5190033460000001, 0.51846148, 0.51820192, 0.96959211, 
          0.5613666810000001, 0.5165680850000001, 0.515970761, 
          0.5158933880000001, 0.514081097, 0.513604787, 0.884341302, 
          1.2736888910000002`, 0.5117857170000001, 0.562446112, 0.509846686, 
          0.508823475, 0.775369021, 0.506805805, 0.6868703580000001, 
          0.5050199790000001, 0.6661177540000001, 0.504035208, 0.503544501, 
          0.548884279, 0.512024699, 0.501266479, 0.993270686, 0.499882714, 
          0.49981450200000005`, 0.49967796500000006`, 0.498881923, 
          0.777421519, 0.49761046400000003`, 0.5329518520000001, 
          0.6914930530000001, 0.49601729800000005`, 0.495185637, 0.49423461, 
          0.92959254, 0.49384465200000005`, 0.829181864, 0.49239742100000006`,
           0.5017790560000001, 0.507293281, 0.487946814, 0.48788409400000005`,
           0.486829296, 0.5504457850000001, 0.48523317400000004`, 0.484924149,
           0.484723463, 0.48315186200000004`, 0.792564139, 0.489571662, 
          0.5243599830000001, 0.480668808, 0.48066426100000004`, 
          0.48022380600000003`, 0.48005074000000003`, 0.47997422900000003`, 
          0.47937970500000004`, 0.47880767700000004`, 0.477925447, 
          0.475797827, 0.47530741000000004`, 0.674135763, 
          0.47239605900000003`, 0.468461852, 0.468087409, 
          0.46704803600000006`, 0.466250504, 0.518086637, 0.794636081, 
          0.465736101, 0.464298076, 0.871703714, 0.651438921, 0.602787768, 
          0.465411807, 0.461617891, 0.46062932300000003`, 
          0.45964943500000005`, 0.458186794, 0.45775816900000005`, 
          0.45663935200000005`, 0.456544072, 0.9127526460000001, 0.54700683, 
          0.453796884, 0.45796001900000005`, 0.453465987, 
          0.45325699500000005`, 0.45248358600000005`, 0.451814325, 0.45046856,
           0.450205114, 0.45017335700000005`, 0.713082626, 0.449742754, 
          1.0905804000000001`, 0.878930736, 0.447346511, 0.446924478, 
          0.44686722100000004`, 0.469150783, 0.44373188100000005`, 
          0.442739044, 0.44212725500000005`, 0.6274193530000001, 0.441195869, 
          0.440729927, 0.7202023270000001, 0.437537742, 0.437365824, 
          0.43724070600000003`, 0.638122529, 0.437076732, 1.136347943, 
          0.43488587300000003`, 0.434748057, 0.46419511300000005`, 
          0.433853303, 0.451793062, 0.433710627, 0.433445664, 0.432632783, 
          0.432436647, 0.431647039, 0.431267644, 0.431044015, 
          0.43063378500000005`, 0.430163775, 0.564302678, 0.429394859, 
          0.49848107, 0.577732448, 0.42908427000000005`, 0.428978085, 
          0.428685615, 0.42854770400000003`, 0.42639752200000003`, 
          0.42639424800000003`, 0.428340323, 0.42592979400000003`, 
          0.42419881600000003`, 0.423729367, 0.42278687200000004`, 
          0.422758581, 0.549050664, 0.42135691700000005`, 
          0.42045112700000004`, 0.420315274, 0.41940013000000004`, 
          0.418545902, 0.679311831, 0.6451268440000001, 0.485719612, 
          0.7398878520000001, 0.416593841, 0.41634399000000005`, 0.415996413, 
          0.41535811300000003`, 0.41769930600000005`, 0.522500469, 
          0.41935535100000004`, 0.41383001900000005`, 0.41371714000000004`, 
          0.41243579900000005`, 0.412020563, 0.494470642, 0.409438428, 
          0.409339153, 0.408406818, 0.40802424200000004`, 0.40795353, 
          0.40790166, 0.406817547, 0.406582527, 0.405461448, 
          0.7500756890000001, 0.5944482480000001, 0.40303740600000004`, 
          0.40298094700000003`, 0.402910013, 0.399885835, 0.399682729, 
          0.39967865700000005`, 0.399375441, 0.39881989700000003`, 
          0.972669027, 0.39869914, 0.397104815, 0.890503106, 0.416328415, 
          0.39610871400000003`, 0.395815642, 0.409011636, 0.395420086, 
          0.45404903100000005`, 0.429831772, 0.39303307000000004`, 
          0.392653848, 0.39264042600000004`, 0.45669266100000006`, 
          0.41908319600000005`, 0.790593544, 0.5807620680000001, 0.39015831, 
          0.38934796200000005`, 0.46160949700000004`, 0.38783377500000005`, 
          0.387526629, 0.387329572, 0.387322447, 0.386736858, 
          0.38669994700000004`, 0.385726396, 0.38483756500000005`, 
          0.384799636, 0.38451360100000004`, 0.38337737400000005`, 
          0.425416401, 0.39848446400000004`, 0.925421593, 0.37940052, 
          0.379259887, 0.37888491700000004`, 0.37841109, 0.378399091, 
          0.37810511300000005`, 0.449053018, 0.426334229, 0.376039938, 
          0.375850667, 0.374914837, 0.37389358300000003`, 
          0.37384285100000003`, 0.373304907, 0.373228337, 0.549157356, 
          0.372214943, 0.463353693, 0.37202966200000004`, 0.371699271, 
          0.390271105, 0.390850403, 0.37029115500000004`, 
          0.36897407000000004`, 0.36680896900000004`, 0.36652975200000004`, 
          0.36539371600000004`, 0.364586258, 0.364256163, 0.363802348, 
          0.363541006, 0.36339161200000003`, 0.418241597, 
          0.36216800800000004`, 0.36198062200000003`, 0.36158679600000004`, 
          0.45267479400000005`, 0.706368757, 0.35810476100000005`, 
          0.357871575, 0.35757723300000005`, 0.35734987700000004`, 
          0.512866155, 0.357057976, 0.356134614, 0.537855151, 0.355272511, 
          0.439300662, 0.35393140900000003`, 0.35392426800000004`, 
          0.353646987, 0.37350681, 0.35336188300000004`, 0.357912339, 
          0.466171755, 0.527010918, 0.35069127, 0.35554700300000003`, 
          0.35042728300000003`, 0.38597875400000003`, 0.36501007700000004`, 
          0.35327676900000005`, 0.348095156, 0.375698737, 
          0.34679225900000005`, 0.34601189200000004`, 0.44065675000000004`, 
          0.349822012, 0.343884575, 0.343340492, 0.342846364, 0.342729228, 
          0.342474785, 0.34931899800000005`, 0.34167941700000004`, 
          0.517474526, 0.34089164800000005`, 0.588403917, 0.340247224, 
          0.40267385, 0.37889284300000003`, 0.33727925200000003`, 0.541748982,
           0.337069734, 0.33599209100000005`, 0.335917841, 0.334984598, 
          0.334944958, 0.334867216, 0.333976131, 0.33390038, 
          0.33356457500000003`, 0.3430012, 0.332236907, 0.387918272, 
          0.331161252, 0.331130144, 0.343881423, 0.330645811, 0.330408034, 
          0.330230953, 0.32960149800000005`, 0.32906223500000004`, 
          0.328622156, 0.328262261, 0.327448605, 0.32686724500000003`, 
          0.325850285, 0.501550446, 0.33490399200000004`, 0.325171832, 
          0.46590428300000003`, 0.35525909, 0.324450416, 0.43954020600000004`,
           0.322471658, 0.32241595100000003`, 0.32113204, 0.418892818, 
          0.319837873, 0.383005971, 0.31871923300000005`, 
          0.31826365500000003`, 0.31813888900000004`, 0.32064603, 0.317650515,
           0.32022380500000003`, 0.49354306600000003`, 0.316272799, 
          0.32496766800000004`, 0.31617015000000004`, 0.315287003, 
          0.315235027, 0.31515770200000004`, 0.314422973, 0.314345274, 
          0.31376257900000004`, 0.31340275, 0.31324782900000003`, 0.313189156,
           0.343400095, 0.347611486, 0.311109427, 0.49590802, 
          0.37044128600000004`, 0.32101908, 0.378643597, 0.30900681700000004`,
           0.308992096, 0.308395611, 0.308338296, 0.329995338, 
          0.30804336000000004`, 0.30770476, 0.306847637, 0.306630091, 
          0.306079213, 0.305713367, 0.305494468, 0.44287835400000003`, 
          0.30543087, 0.305350736, 0.30527946100000003`, 0.304899142, 
          0.30457586400000003`, 0.304354028, 0.30413444300000003`, 
          0.30413352400000004`, 0.30504707400000003`, 0.302926435, 
          0.302730683, 0.302647903, 0.3019372, 0.30137688700000004`, 
          0.30101821, 0.300251203, 0.299834149, 0.29952304300000004`, 
          0.29879318200000005`, 0.298174203, 0.297312611, 
          0.29726623500000005`, 0.296985529, 0.29689675000000004`, 
          0.296540682, 0.29577628100000003`, 0.295301405, 0.295864073, 
          0.295188914, 0.29509654700000004`, 0.323659283, 0.294171258, 
          0.293713016, 0.5063198400000001, 0.292757215, 0.366582864, 
          0.525464677, 0.291579672, 0.291053349, 0.29058293500000004`, 
          0.697987914, 0.411544569, 0.28905821800000003`, 0.289062354, 
          0.288681371, 0.28845452, 0.391346161, 0.288422711, 0.287421313, 
          0.28690885600000005`, 0.28680044000000005`, 0.28545136800000004`, 
          0.531296721, 0.30184182000000004`, 0.284034163, 0.343517108, 
          0.447163336, 0.673399374, 0.281693564, 0.514977145, 
          0.48127179600000003`, 0.320784936, 0.27969704500000003`, 
          0.46727192100000003`, 0.295083759, 0.278397465, 
          0.41678692300000003`, 0.31737450700000003`, 0.277672207, 
          0.369438804, 0.277224943, 0.27706429800000004`, 
          0.27690478700000004`, 0.276386778, 0.2812236, 0.27629320300000004`, 
          0.276290452, 0.276688651, 0.27596397, 0.30546268200000004`, 
          0.49505365500000004`, 0.275436728, 0.558076384, 
          0.49352922200000005`, 0.274450597, 0.274218781, 0.516323561, 
          0.27373745800000004`, 0.27343612500000003`, 0.49394929000000004`, 
          0.309622516, 0.272423774, 0.370258695, 0.271811583, 0.271360792, 
          0.271037183, 0.270477255, 0.314960913, 0.26982706300000003`, 
          0.288073157, 0.47229418100000004`, 0.26899480200000003`, 
          0.526064615, 0.46929185300000004`, 0.26754895, 0.267304834, 
          0.267076877, 0.26675207300000003`, 0.266104473, 0.265608385, 
          0.26495240600000003`, 0.398120525, 0.263749934, 
          0.26364728400000004`, 0.263542105, 0.27679380600000003`, 
          0.263020805, 0.262938991, 0.5016939450000001, 0.49836002500000004`, 
          0.443615919, 0.261970223, 0.6406931260000001, 0.26163121100000003`, 
          0.260846648, 0.317077394, 0.261545552, 0.25973524600000003`, 
          0.259085347, 0.346009705, 0.258640931, 0.258042418, 0.257972548, 
          0.270331763, 0.37465385300000004`, 0.46668661100000003`, 
          0.256764359, 0.256356568, 0.256251512, 0.256025063, 0.255516149, 
          0.255484629, 0.25545679200000004`, 0.274321827, 
          0.33384488500000004`, 0.445622151, 0.253902613, 0.253693002, 
          0.25337098, 0.253254831, 0.252852428, 0.25215755, 0.250619046, 
          0.250298586, 0.36034525700000003`, 0.343353939, 
          0.24914374400000003`, 0.249104811, 0.248378373, 
          0.24834739700000003`, 0.42742770900000004`, 0.24603476200000002`, 
          0.24588303200000003`, 0.24567350100000002`, 0.24552542100000002`, 
          0.24548166100000002`, 0.24522833500000002`, 0.252589498, 
          0.245095008, 0.31671535300000003`, 0.244545963, 0.244262431, 
          0.24419645, 0.24414538600000002`, 0.3683382, 0.242837869, 
          0.24162820100000001`, 0.2888719, 0.241249497, 0.247375743, 
          0.240364512, 0.23989816700000002`, 0.23955799100000003`, 
          0.47450988400000005`, 0.23802277800000002`, 0.237921554, 0.23783201,
           0.237536242, 0.237427823, 0.344353465, 0.29123287600000003`, 
          0.236781066, 0.236114506, 0.236048474, 0.274091972, 0.235482148, 
          0.23540069500000002`, 0.23540000100000003`, 0.23451943, 0.234113796,
           0.233982655, 0.23387196200000002`, 0.233712048, 0.233452133, 
          0.232805633, 0.251645346, 0.35505171700000004`, 
          0.23225906000000002`, 0.23223979300000003`, 0.23219577800000002`, 
          0.23189119800000002`, 0.231687409, 0.231267576, 
          0.23637845600000001`, 0.335743165, 0.30252058200000004`, 
          0.229923292, 0.24396714700000002`, 0.22876220500000002`, 
          0.22814784600000002`, 0.22812189900000002`, 0.22721043200000002`, 
          0.227170423, 0.22641965300000003`, 0.22621274500000002`, 
          0.226170281, 0.22566512900000002`, 0.22564174, 0.292682131, 
          0.225088702, 0.273831999, 0.456406423, 0.223689998, 0.232153393, 
          0.22269688, 0.225011767, 0.222558197, 0.235646283, 
          0.22187020600000001`, 0.23209992200000001`, 0.296834303, 
          0.221289896, 0.22075555700000002`, 0.382619399, 0.279618195, 
          0.219807895, 0.219249662, 0.28358139000000004`, 
          0.21917223800000002`, 0.304944408, 0.218962331, 0.448442712, 
          0.21789986500000003`, 0.217673898, 0.21757725300000003`, 
          0.222463727, 0.21711300300000003`, 0.21688385300000002`, 
          0.216634824, 0.27782180700000003`, 0.216482221, 
          0.21646577500000003`, 0.216228508, 0.39616024000000005`, 
          0.257887123, 0.215232257, 0.21521572500000002`, 
          0.28494444900000004`, 0.21516321300000002`, 0.21482373000000002`, 
          0.224896686, 0.214122993, 0.21409723300000003`, 0.214029972, 
          0.21362119000000002`, 0.21361280800000002`, 0.21333516400000002`, 
          0.279606291, 0.21256946000000002`, 0.212064144, 
          0.34890648900000004`, 0.21112543800000003`, 0.276284497, 
          0.21087683200000001`, 0.210444981, 0.209969855, 0.209912484, 
          0.304663099, 0.294738204, 0.24316036500000002`, 0.207057394, 
          0.27477916, 0.20612402100000002`, 0.205884591, 0.205850275, 
          0.205529445, 0.20489067900000002`, 0.20584053300000002`, 
          0.203704781, 0.20294045800000002`, 0.202899883, 0.20289945, 
          0.202769409, 0.20254449800000002`, 0.202419548, 0.343255727, 
          0.275709466, 0.202166538, 0.20189873500000002`, 0.208162851, 
          0.224574447, 0.20148817900000002`, 0.20109478700000002`, 
          0.200595338, 0.200357897, 0.200340018, 0.20027507300000003`, 
          0.199839491, 0.19983921500000001`, 0.19955657300000001`, 
          0.239701777, 0.199370928, 0.19910575400000002`, 
          0.19933049700000002`, 0.20120131400000002`, 0.19750213600000002`, 
          0.197406842, 0.29596636200000004`, 0.19663017600000002`, 
          0.196364474, 0.196244453, 0.195755217, 0.195693322, 0.195533327, 
          0.19485226600000002`, 0.194777115, 0.19464150900000002`, 
          0.193979439, 0.19392151400000002`, 0.29936833300000004`, 0.19376644,
           0.19364935800000002`, 0.198713737, 0.19323975200000001`, 
          0.193234117, 0.19262599300000002`, 0.19226490000000002`, 
          0.19213954400000002`, 0.19058238200000002`, 0.19007921600000002`, 
          0.189469765, 0.189056685, 0.189006841, 0.292388915, 0.188571498, 
          0.188043063, 0.22564412900000003`, 0.186605987, 0.234033655, 
          0.186452382, 0.18612513, 0.239334485, 0.185693508, 0.185663512, 
          0.18559656400000002`, 0.18524263800000002`, 0.33917237100000003`, 
          0.184938774, 0.18476930900000002`, 0.18476909000000002`, 
          0.25242885000000004`, 0.18454788900000002`, 0.18405099, 0.184016843,
           0.18377795700000002`, 0.18372744500000002`, 0.21266082500000003`, 
          0.18326477500000002`, 0.183113364, 0.182986482, 0.182273223, 
          0.182216918, 0.182257957, 0.18220580700000003`, 0.181907119, 
          0.181633773, 0.181628175, 0.181521559, 0.181385081, 0.449633526, 
          0.18004973300000002`, 0.18004460600000002`, 0.179270286, 
          0.17915313100000002`, 0.182161298, 0.17916938200000002`, 
          0.17840161400000001`, 0.213300695, 0.17810230700000002`, 
          0.177813041, 0.28804498100000003`, 0.33341728000000004`, 
          0.21534873000000002`, 0.177423037, 0.17719683600000002`, 
          0.176262475, 0.17595617800000002`, 0.17593688000000002`, 
          0.175670015, 0.175363655, 0.174969792, 0.17439764200000002`, 
          0.26298887000000004`, 0.17426386800000002`, 0.17421271400000002`, 
          0.17417221800000002`, 0.174022737, 0.173008342, 0.35256196, 
          0.17275262200000002`, 0.172058904, 0.172041256, 
          0.17190175300000002`, 0.171872831, 0.17166903700000002`, 
          0.17146113300000002`, 0.171236081, 0.17082618900000002`, 
          0.170587243, 0.21280377900000003`, 0.170249947, 0.271576651, 
          0.21907199100000002`, 0.16987575100000002`, 0.16940386100000002`, 
          0.170961357, 0.169296424, 0.16893159800000002`, 
          0.16824934400000002`, 0.167680785, 0.216171212, 0.167308966, 
          0.167264824, 0.1670839, 0.16699365600000002`, 0.16674418200000002`, 
          0.183556625, 0.16652080500000002`, 0.325433707, 0.166372283, 
          0.16588160100000002`, 0.165839029, 0.16541323000000002`, 
          0.165286243, 0.16512453900000001`, 0.16500187800000002`, 
          0.164902495, 0.164670599, 0.16457964700000002`, 0.164454432, 
          0.164116448, 0.16974535400000001`, 0.16397930300000002`, 
          0.163401516, 0.163371503, 0.16322630300000002`, 
          0.16287199200000002`, 0.162773717, 0.162377068, 0.16208837, 
          0.16192676, 0.16162363500000002`, 0.16158154800000002`, 
          0.16155306500000002`, 0.16842711400000002`, 0.161297255, 
          0.16105508300000002`, 0.16092910800000002`, 0.160870444, 
          0.27631472100000004`, 0.16052470500000002`, 0.160499199, 
          0.160402129, 0.160199306, 0.16001483500000002`, 0.159998636, 
          0.15958582500000001`, 0.159236188, 0.15921561, 0.158908672, 
          0.158868384, 0.158658669, 0.158528054, 0.15823731300000002`, 
          0.158206019, 0.161382616, 0.15796421900000002`, 
          0.15778688500000002`, 0.16134906000000002`, 0.156373004, 
          0.156262651, 0.156237007, 0.156014582, 0.155730283, 0.167296203, 
          0.15470075800000002`, 0.154689616, 0.154583848, 0.154536386, 
          0.154531843, 0.154240224, 0.15418483200000002`, 0.153778313, 
          0.15823921900000001`, 0.153586107, 0.15349817200000002`, 
          0.153482741, 0.153415923, 0.153324173, 0.15283611700000002`, 
          0.152671457, 0.155740957, 0.152128178, 0.151323693, 
          0.15115234500000002`, 0.15106134100000002`, 0.15101735800000002`, 
          0.151002898, 0.15263046900000002`, 0.15072389900000002`, 
          0.150515543, 0.150388998, 0.150050442, 0.149937274, 0.148534104, 
          0.148175295, 0.148150311, 0.196177853, 0.147988626, 0.152723455, 
          0.14748661000000002`, 0.230540987, 0.14703088, 0.14681491500000002`,
           0.146760272, 0.146714816, 0.14670227800000002`, 0.146644777, 
          0.182661824, 0.146263901, 0.146204583, 0.145916198, 0.219250199, 
          0.145605788, 0.14551234100000002`, 0.26953827, 0.145250183, 
          0.154110667, 0.273182083, 0.144686869, 0.18738959800000002`, 
          0.144191489, 0.143775716, 0.143682686, 0.143181469, 0.143167598, 
          0.14285688600000002`, 0.142824125, 0.142660732, 
          0.22809817400000001`, 0.268235634, 0.142244063, 
          0.14222135900000002`, 0.142047602, 0.166626622, 0.141766257, 
          0.141298093, 0.21157107300000003`, 0.140855228, 0.140658625, 
          0.258874949, 0.14037595900000002`, 0.171049004, 0.163161111, 
          0.139625609, 0.139336382, 0.139296272, 0.19812121100000002`, 
          0.139624725, 0.138729022, 0.13867962, 0.13852045300000002`, 
          0.138495832, 0.138381254, 0.13830884100000002`, 0.13796507, 
          0.137760248, 0.13747715000000002`, 0.137378461, 0.137250283, 
          0.137242354, 0.13722515000000002`, 0.137162654, 0.137153733, 
          0.137029949, 0.136458762, 0.136314121, 0.135900872, 0.135830952, 
          0.135352794, 0.13530277400000001`, 0.135238727, 0.135232125, 
          0.134939883, 0.134806581, 0.134710089, 0.14990825600000002`, 
          0.13458586, 0.184435869, 0.13444799400000002`, 0.134276887, 
          0.13419039800000002`, 0.13397793, 0.139714729, 0.133618173, 
          0.133378354, 0.133309375, 0.133119905, 0.132974057, 0.132675249, 
          0.132542454, 0.13386140300000002`, 0.18625133900000002`, 
          0.13226005400000002`, 0.13216888000000002`, 0.132075636, 
          0.188823877, 0.131984083, 0.131958944, 0.1560032, 
          0.13157005400000002`, 0.13137499700000002`, 0.131289957, 
          0.131261399, 0.131087276, 0.13091022800000002`, 0.150640311, 
          0.130579135, 0.130539298, 0.130489625, 0.14168941300000001`, 
          0.17495771100000002`, 0.19490617200000002`, 0.129610894, 
          0.129123917, 0.128698464, 0.128545208, 0.128353393, 0.128230897, 
          0.138687435, 0.127974844, 0.162284014, 0.12777548800000002`, 
          0.127699995, 0.127407711, 0.12738157, 0.127156467, 0.126972166, 
          0.126957346, 0.17982219300000002`, 0.126789811, 
          0.22301103100000003`, 0.126606876, 0.12632484100000002`, 
          0.126138725, 0.127768171, 0.125858927, 0.12528355600000002`, 
          0.124989443, 0.124902312, 0.12476711600000001`, 0.12444958, 
          0.124397036, 0.124142366, 0.124121958, 0.12404848600000001`, 
          0.12399019600000001`, 0.123894764, 0.12389279900000001`, 
          0.123878071, 0.12322071200000001`, 0.122826708, 
          0.13759321700000002`, 0.12227802200000001`, 0.12226610800000001`, 
          0.13985017500000002`, 0.12210037100000001`, 0.12186798, 
          0.12170162300000001`, 0.12168160400000001`, 0.14898540500000002`, 
          0.12765410700000002`, 0.120643754, 0.120600092, 0.120352781, 
          0.12025387200000001`, 0.12833307100000002`, 0.11987522800000001`, 
          0.119784045, 0.11941195900000001`, 0.11925780100000001`, 
          0.11909062000000001`, 0.11887472600000001`, 0.11887428600000001`, 
          0.118826231, 0.11838691600000001`, 0.11826502100000001`, 
          0.117895551, 0.11718982600000001`, 0.11690220100000001`, 
          0.116820846, 0.11680936900000001`, 0.116749746, 
          0.11670509200000001`, 0.116468018, 0.11613329900000001`, 
          0.116073748, 0.11604574100000001`, 0.11597668900000001`, 
          0.13164609800000002`, 0.115724117, 0.128427722, 0.229378823, 
          0.115017884, 0.122471619, 0.114920214, 0.11476508, 
          0.11468151900000001`, 0.114383548, 0.114365825, 0.114156056, 
          0.18709946500000002`, 0.113922693, 0.113905221, 0.113705568, 
          0.11364647300000001`, 0.113635842, 0.24241856900000003`, 
          0.11343277400000001`, 0.11330097900000001`, 0.11355786600000001`, 
          0.112962009, 0.11863663, 0.112787097, 0.144714181, 0.120668301, 
          0.11267710500000001`, 0.11258324300000001`, 0.112556711, 
          0.11246513000000001`, 0.11244483400000001`, 0.18750296500000002`, 
          0.11184316000000001`, 0.111643764, 0.191137996, 0.20138654, 
          0.14194869000000002`, 0.110942835, 0.11086902700000001`, 
          0.110815124, 0.110804025, 0.110669126, 0.110612635, 
          0.11055308700000001`, 0.110491005, 0.110353323, 0.124041516, 
          0.110163677, 0.110115925, 0.10994279200000001`, 0.109892554, 
          0.1287633, 0.133956457, 0.126040585, 0.109374281, 0.109374172, 
          0.109243537, 0.10920229000000001`, 0.10911645900000001`, 
          0.109023987, 0.108929124, 0.10875817400000001`, 
          0.10875545900000001`, 0.125221666, 0.10870889500000001`, 
          0.15960264600000001`, 0.10817899, 0.170440166, 0.215099338, 
          0.10778359200000001`, 0.177471019, 0.106812048, 0.10676459, 
          0.106703696, 0.106622143, 0.10645309700000001`, 0.10627422, 
          0.106062605, 0.187336562, 0.105888045, 0.105864841, 0.105652518, 
          0.105438052, 0.10524343200000001`, 0.20576708700000002`, 
          0.10493980400000001`, 0.104850016, 0.106510773, 
          0.10435574600000001`, 0.10429103, 0.10410556600000001`, 
          0.10406211000000001`, 0.103542542, 0.10343023800000001`, 
          0.10339608800000001`, 0.19781741500000002`, 0.10330770700000001`, 
          0.103233981, 0.103018566, 0.102969036, 0.102898733, 
          0.10255665100000001`, 0.158239197, 0.10223218, 0.118383993, 
          0.102019433, 0.10173106400000001`, 0.129009339, 
          0.10153393000000001`, 0.10141908100000001`, 0.10141093000000001`, 
          0.101276957, 0.101199859, 0.104293363, 0.100722505, 
          0.10051497000000001`, 0.100398315, 0.100184254, 0.100000183, 
          0.099816232, 0.125422961, 0.09949782500000001, 0.099401153, 
          0.099278322, 0.098793687, 0.09878342300000001, 0.09872380900000001, 
          0.09871368100000001, 0.098214327, 0.09818046700000001, 0.098128356, 
          0.098117969, 0.09806584900000001, 0.097892432, 0.097439853, 
          0.09719209300000001, 0.096927542, 0.09691518, 0.096824147, 
          0.09670453000000001, 0.09668041200000001, 0.09660119, 
          0.09638405100000001, 0.09637422100000001, 0.09636665000000001, 
          0.214001456, 0.096095264, 0.158573439, 0.15945306, 0.095767482, 
          0.186969133, 0.095438937, 0.095378922, 0.095174878, 0.094980301, 
          0.14100864100000002`, 0.09471631000000001, 0.094662836, 0.094597702,
           0.093779315, 0.09370297500000001, 0.093597675, 0.094646115, 
          0.13378546400000002`, 0.09347053300000001, 0.093331391, 
          0.11162063800000001`, 0.093233562, 0.093211579, 0.093046604, 
          0.11145542700000001`, 0.092951589, 0.117361925, 0.09279041, 
          0.092757528, 0.11931609300000001`, 0.09269777700000001, 0.092444231,
           0.092174509, 0.092167565, 0.09209908600000001, 0.09208232000000001,
           0.09205447500000001, 0.09196429, 0.09174697700000001, 
          0.09158941400000001, 0.09156077300000001, 0.091538637, 0.091108295, 
          0.090945576, 0.09078192700000001, 0.090763726, 0.090724993, 
          0.09028783900000001, 0.089862415, 0.089639252, 0.089612906, 
          0.09293445600000001, 0.089463947, 0.089259797, 0.089225629, 
          0.08913696800000001, 0.089119529, 0.089105745, 0.095687039, 
          0.08900287200000001, 0.088748695, 0.088651909, 0.088627272, 
          0.08809076, 0.119666617, 0.08793381700000001, 0.087921491, 
          0.08753951, 0.08741278400000001, 0.087409229, 0.14812862200000002`, 
          0.087193461, 0.16707089700000002`, 0.08671928200000001, 
          0.08664714300000001, 0.08717073700000001, 0.086318747, 
          0.08626180800000001, 0.086233183, 0.086225416, 0.086211198, 
          0.08609881700000001, 0.08602889200000001, 0.086028801, 0.086009656, 
          0.08596935400000001, 0.085958697, 0.08590536600000001, 0.085860882, 
          0.12082956600000001`, 0.08569873800000001, 0.172469007, 
          0.08552680400000001, 0.08683363300000001, 0.085129911, 0.089070651, 
          0.08510753500000001, 0.137619923, 0.08502183, 0.08492827600000001, 
          0.104335628, 0.08484860200000001, 0.08483576100000001, 0.084637316, 
          0.084388658, 0.167699338, 0.11646687300000001`, 0.08394069600000001,
           0.083536502, 0.083360734, 0.08345833000000001, 0.08317186, 
          0.08313208100000001, 0.083057875, 0.08300183900000001, 0.082976783, 
          0.082808874, 0.082671563, 0.082572932, 0.10236824900000001`, 
          0.082361426, 0.08202561, 0.08201433600000001, 0.081861499, 
          0.11973809, 0.081800459, 0.081783505, 0.08174870000000001, 
          0.081644347, 0.08146905800000001, 0.081239604, 0.08118491500000001, 
          0.08085619000000001, 0.090696174, 0.08082077, 0.080706207, 
          0.08066255800000001, 0.079994651, 0.07992101900000001, 0.079767762, 
          0.079703303, 0.079580754, 0.07955345700000001, 0.079492293, 
          0.079275858, 0.079271098, 0.07924972300000001, 0.080881359, 
          0.07898384500000001, 0.078978932, 0.078810698, 0.078548475, 
          0.07847612600000001, 0.078364471, 0.07836259200000001, 
          0.07811293400000001, 0.07809403300000001, 0.078188014, 0.078064983, 
          0.09311532500000001, 0.077922643, 0.07789878600000001, 
          0.07770342100000001, 0.07743193400000001, 0.07738824200000001, 
          0.077367691, 0.07720995500000001, 0.07718269500000001, 0.127017065, 
          0.077163021, 0.077114737, 0.076889202, 0.076863558, 0.076843504, 
          0.076695911, 0.076621388, 0.076495877, 0.076480027, 0.076432439, 
          0.081971207, 0.076326049, 0.09675836800000001, 0.09116439100000001, 
          0.07596781400000001, 0.137548278, 0.075676559, 0.07528979300000001, 
          0.14446635200000002`, 0.07481977100000001, 0.074738895, 0.074651891,
           0.125927815, 0.074421844, 0.07526916, 0.07417557500000001, 
          0.07366709, 0.14237106600000002`, 0.07362660600000001, 0.096531503, 
          0.07693878600000001, 0.10715060100000001`, 0.072724174, 0.072722862,
           0.072508083, 0.07241689, 0.072313027, 0.072078294, 0.071932125, 
          0.07168814500000001, 0.071600959, 0.071441716, 0.088807991, 
          0.071054042, 0.10799844700000001`, 0.126037488, 0.070169306, 
          0.070115325, 0.07005114400000001, 0.069902615, 0.069868236, 
          0.069734499, 0.069694121, 0.069585108, 0.069275453, 0.068866885, 
          0.068853332, 0.06880649400000001, 0.068742103, 0.12559035300000002`,
           0.068557645, 0.06831662100000001, 0.06828651200000001, 0.068277207,
           0.06826070000000001, 0.107241847, 0.068170757, 
          0.10182163000000001`, 0.067806883, 0.067711773, 0.067500116, 
          0.067433293, 0.06736272, 0.067043804, 0.066839174, 
          0.06683507100000001, 0.066792954, 0.066530977, 0.06643924600000001, 
          0.076934731, 0.06630605, 0.06630388200000001, 0.06627234700000001, 
          0.066250505, 0.066182221, 0.066148201, 0.066091308, 
          0.06607613400000001, 0.065814574, 0.07957456900000001, 0.065653426, 
          0.065609868, 0.065606591, 0.06555406300000001, 0.065353619, 
          0.067711545, 0.065146534, 0.09965660000000001, 0.065128319, 
          0.108704611, 0.064921486, 0.064727819, 0.107869619, 0.064556342, 
          0.064317072, 0.06428821800000001, 0.06425676200000001, 0.063865138, 
          0.063819924, 0.085015226, 0.064117643, 0.06334861700000001, 
          0.06318992100000001, 0.06312089, 0.063074106, 0.062918587, 
          0.062815801, 0.062658974, 0.062592465, 0.062586347, 
          0.06239880800000001, 0.062371390000000006`, 0.062310721000000006`, 
          0.06227475700000001, 0.06222288, 0.062195077, 0.062061248000000006`,
           0.062036988, 0.061927358, 0.06146254, 0.061338787000000006`, 
          0.061328725, 0.061162863000000005`, 0.061080315, 0.060912842, 
          0.060903360000000004`, 0.060836816, 0.06256157400000001, 
          0.06390422300000001, 0.060551459, 0.076029161, 0.07644265900000001, 
          0.060442046000000006`, 0.06044097700000001, 0.060395053000000004`, 
          0.060391407, 0.05992477, 0.059821678, 0.059753636000000006`, 
          0.05968806, 0.05950238, 0.059264299000000006`, 0.05921701, 
          0.059101615, 0.058874437, 0.058796987, 0.058738369000000006`, 
          0.058714744000000006`, 0.058713535000000004`, 0.058694866000000005`,
           0.05847001, 0.058264508000000007`, 0.058161699000000004`, 
          0.058114081000000005`, 0.058111779, 0.058073493000000004`, 
          0.057899159000000006`, 0.060197056000000006`, 0.057551869000000005`,
           0.057545339, 0.05744699700000001, 0.057338704000000004`, 
          0.08538654300000001, 0.056981216, 0.056864335, 
          0.056823789000000006`, 0.056750095, 0.08718708600000001, 
          0.056655598, 0.056630994000000004`, 0.08865726, 0.09737860400000001,
           0.056172049, 0.055873319000000005`, 0.055437714000000006`, 
          0.055330819, 0.055218823, 0.055074464000000004`, 0.05499097, 
          0.054968453, 0.054896292000000006`, 0.054252049000000004`, 
          0.054232027, 0.054119955000000004`, 0.05411702, 0.054069785, 
          0.053796290000000004`, 0.053762120000000004`, 0.080398858, 
          0.05353613, 0.101855082, 0.053475607, 0.053430375, 
          0.053374498000000006`, 0.09460536100000001, 0.053352319, 
          0.053332597, 0.05326231100000001, 0.053052407, 0.053349341, 
          0.0845129, 0.052571668, 0.053688118, 0.052421757000000006`, 
          0.05240235, 0.052248299000000005`, 0.052244848, 0.052169988, 
          0.052151890000000006`, 0.05194125300000001, 0.051937315000000005`, 
          0.051883175000000004`, 0.051857125000000004`, 0.062007852, 
          0.051738829, 0.051682382000000006`, 0.051451046, 0.051211456, 
          0.051203853, 0.051100444, 0.050795907, 0.050768757000000005`, 
          0.05072643, 0.050720304, 0.050709596, 0.05067176, 
          0.050671586000000005`, 0.050621441, 0.06360032, 
          0.050506219000000005`, 0.050363887, 0.050327032, 
          0.09124768200000001, 0.04980492, 0.078604669, 0.049649925000000004`,
           0.049543565000000005`, 0.049242346000000006`, 
          0.049179927000000005`, 0.049098444000000005`, 0.049059289000000006`,
           0.048854266, 0.09099522600000001, 0.048791422, 0.04872395, 
          0.048320125000000005`, 0.048207845000000006`, 0.048164502000000005`,
           0.048115655, 0.048047143, 0.047979797000000005`, 0.047684982, 
          0.047660899, 0.072009632, 0.047652517000000005`, 0.047644164, 
          0.047571253, 0.047496043, 0.047453867000000004`, 
          0.049495990000000004`, 0.047240341000000005`, 0.047105709, 
          0.047097815, 0.047093228, 0.046731979, 0.046717319, 0.046641119, 
          0.046555752000000006`, 0.046465064, 0.046312521, 0.047536795, 
          0.045858397, 0.045634166000000004`, 0.045630799, 0.045413736, 
          0.045371578, 0.045235591000000006`, 0.044918538, 0.044845502, 
          0.044814299, 0.047384593, 0.051971078000000004`, 0.044730906, 
          0.044623627000000006`, 0.044605668, 0.044462894, 0.044091267, 
          0.043992621, 0.045544115, 0.043797019, 0.04379446, 
          0.043658049000000004`, 0.043642318, 0.043614955000000004`, 
          0.043600585000000004`, 0.043542773, 0.043353952, 0.043165382, 
          0.043101814, 0.043096198, 0.043043399, 0.042963908, 
          0.042906160000000006`, 0.042877207, 0.042714757000000006`, 
          0.042691645, 0.042668708, 0.04263766, 0.042633858000000004`, 
          0.042537462000000005`, 0.055723065, 0.042504739, 0.042447756, 
          0.042337296, 0.042322042000000004`, 0.042247722, 
          0.042142369000000006`, 0.045170172, 0.041798222, 0.080912934, 
          0.041758539000000004`, 0.04147905, 0.041449475, 0.041358639, 
          0.045527281, 0.041189781, 0.041021115000000004`, 0.041013214, 
          0.040886942, 0.040731577000000005`, 0.040512372000000005`, 
          0.040386996, 0.040276657, 0.040273402, 0.040258207000000004`, 
          0.040203796, 0.04399852, 0.040067702000000004`, 0.0399587, 
          0.039717354, 0.039701696, 0.039659074, 0.039461891000000006`, 
          0.039309130000000005`, 0.039224116, 0.039071748, 0.039066925, 
          0.03881113, 0.0386994, 0.038665893, 0.03862564, 
          0.038607956000000006`, 0.038606665000000005`, 0.038561624, 
          0.03842429, 0.038368059, 0.038286692000000004`, 
          0.038222938000000005`, 0.038221062, 0.038148107, 0.037883711, 
          0.067572176, 0.037742540000000005`, 0.037599717000000005`, 
          0.037566041, 0.037498224000000004`, 0.043448262, 
          0.037366022000000006`, 0.037669453000000006`, 0.0372737, 
          0.057724829000000005`, 0.036910751000000006`, 0.036831089000000004`,
           0.036744285, 0.036596710000000005`, 0.036570695, 0.036547369, 
          0.036434868, 0.036355503000000004`, 0.03624974, 
          0.036201581000000004`, 0.061890947, 0.041021865000000005`, 
          0.03568786, 0.035674939, 0.035586027, 0.035567789, 
          0.035403249000000005`, 0.035386755, 0.035359938, 0.035328354, 
          0.035258415, 0.035243878, 0.035190247, 0.035188245, 
          0.035171533000000005`, 0.035136912, 0.034991178000000005`, 
          0.034762211, 0.034758966, 0.034646359, 0.034627256, 0.03456225, 
          0.034434578, 0.034346375000000005`, 0.034168762000000005`, 
          0.034126349, 0.034069678, 0.034068192000000004`, 0.034062349, 
          0.033965403000000005`, 0.033943914000000006`, 0.033803865, 
          0.033722746000000005`, 0.033694413, 0.033623926000000005`, 
          0.050975559000000004`, 0.033100145000000004`, 0.040931184, 
          0.032981526000000004`, 0.032845585000000004`, 0.045234887, 
          0.032663429, 0.032609699, 0.032413635, 0.032329952, 0.045755555, 
          0.032247452, 0.03223791, 0.032230336000000005`, 
          0.032213464000000004`, 0.032145110000000005`, 0.032144992000000004`,
           0.032143089, 0.032114991, 0.032102526, 0.033123483, 0.032077067, 
          0.032055732, 0.033669358, 0.031939555, 0.031818324, 0.03176207, 
          0.031761021, 0.03172659, 0.031624923, 0.031548613, 
          0.031516957000000005`, 0.031282643, 0.030889391000000002`, 
          0.030824471000000003`, 0.030779184, 0.030731099, 
          0.030670104000000004`, 0.04688801, 0.030371184000000002`, 
          0.030360078000000002`, 0.030325404, 0.030258591, 0.03006315, 
          0.030034649000000004`, 0.029986941000000003`, 0.029951254000000004`,
           0.029864685000000002`, 0.029812979000000003`, 
          0.029722828000000003`, 0.029710265000000003`, 0.029698036, 
          0.029437839, 0.036356257, 0.029323328000000003`, 
          0.050612064000000005`, 0.029036463000000002`, 0.029016410000000003`,
           0.028891749, 0.028812734000000003`, 0.037003256000000005`, 
          0.02874418, 0.028708110000000002`, 0.040194766, 0.028662333, 
          0.028319147000000003`, 0.028307322000000003`, 0.028302615000000003`,
           0.028299565000000002`, 0.028247668, 0.033421884, 
          0.028153387000000002`, 0.054510285000000006`, 0.028120522000000002`,
           0.028074270000000002`, 0.028062107000000003`, 
          0.027957759000000002`, 0.027933431, 0.027831909000000002`, 
          0.030478113, 0.027948151, 0.027505151000000002`, 
          0.027430338000000002`, 0.027370742, 0.027337119, 0.032698867, 
          0.027269194, 0.027152401000000003`, 0.027096743000000003`, 
          0.027056503000000003`, 0.026932151, 0.03607193, 0.026756944, 
          0.026754468, 0.026664029000000002`, 0.026620294000000003`, 
          0.026430832, 0.026336347000000003`, 0.026313495000000003`, 
          0.026196615000000003`, 0.026164159000000003`, 0.026139025000000003`,
           0.041766937000000004`, 0.026049187, 0.025818326000000003`, 
          0.025793624, 0.025786994, 0.025769665, 0.025730684, 
          0.025718663000000003`, 0.034826445000000004`, 0.025585077, 
          0.041104485, 0.025502176, 0.025341563, 0.025306873, 0.025275189, 
          0.025160699, 0.025147691000000003`, 0.02492476, 0.025256638, 
          0.024801055000000002`, 0.024784359000000002`, 0.024695757000000002`,
           0.024662942, 0.024662814, 0.030242654, 0.024635732, 0.024618869, 
          0.024506999, 0.024410213, 0.024306165, 0.024266235, 0.024207743, 
          0.024171380000000003`, 0.024159381, 0.024011365, 0.023919927, 
          0.023846438, 0.023744194000000003`, 0.023693336000000002`, 
          0.023626911, 0.023569423000000003`, 0.023556617000000002`, 
          0.023509038000000003`, 0.06346544600000001, 0.023102027, 
          0.023034998, 0.035821192, 0.022953903, 0.022885589, 0.022869612, 
          0.022855539, 0.022842531000000003`, 0.026359135000000002`, 
          0.022792331000000002`, 0.022784629, 0.022733435, 0.02271507, 
          0.024637210000000003`, 0.022652783000000003`, 0.022608042000000002`,
           0.024859507000000003`, 0.02255599, 0.022545100000000002`, 
          0.022506363, 0.022502298, 0.022479573000000003`, 0.028689616, 
          0.022361645000000003`, 0.022319593000000002`, 0.022296206000000002`,
           0.022267710000000003`, 0.022230892000000002`, 0.039505242, 
          0.022157663, 0.022011429000000002`, 0.021905466000000002`, 
          0.021772085, 0.021764936000000002`, 0.021754468000000002`, 
          0.021691707, 0.035488822, 0.021629022, 0.021576582, 0.021440738, 
          0.021414164000000003`, 0.021409202000000002`, 0.021353592, 
          0.021260497, 0.023456567, 0.021170508, 0.021044638, 0.020947394, 
          0.020863386, 0.020723096, 0.020637289, 0.020487341000000003`, 
          0.020466658000000002`, 0.026241499, 0.020364430000000003`, 
          0.020273987, 0.020246415, 0.020232748000000002`, 0.020133772, 
          0.020078832, 0.020053885, 0.01997057, 0.019954801, 
          0.019862109000000003`, 0.019827266, 0.0198266, 0.026024496, 
          0.019937454, 0.019542956, 0.019530060000000002`, 
          0.021959120000000002`, 0.019402371, 0.019278523000000002`, 
          0.019138381000000003`, 0.019106475, 0.019067081, 0.019034058, 
          0.032952746000000005`, 0.018971603, 0.018911176000000002`, 
          0.018898376, 0.018753376000000002`, 0.018713510000000003`, 
          0.01870749, 0.018679463, 0.018652171000000002`, 
          0.018633160000000003`, 0.018611861, 0.018596748, 
          0.018520289000000002`, 0.018412577, 0.018391309, 0.01837869, 
          0.018377125, 0.018351534000000003`, 0.018334839000000002`, 
          0.018307846000000003`, 0.019408058000000002`, 0.036159547, 
          0.018127885, 0.018120266, 0.018115910000000002`, 0.017966336, 
          0.017923424, 0.017863406000000002`, 0.020393630000000003`, 
          0.017771914, 0.017728951, 0.030158343, 0.017694445, 0.017668711, 
          0.017665879000000002`, 0.017553275, 0.017521428000000002`, 
          0.01751582, 0.017501642, 0.017485615, 0.017478936, 0.017409796, 
          0.017402541, 0.017366087000000002`, 0.021523679, 0.01734638, 
          0.017326169000000002`, 0.017273327, 0.021448269000000002`, 
          0.017204145, 0.017161182, 0.016946179000000002`, 0.016925114, 
          0.033320862, 0.016861959000000003`, 0.016854862, 0.016845819, 
          0.016809546, 0.016749609000000002`, 0.016626403, 0.016836534, 
          0.016583831, 0.016514501, 0.016466295000000002`, 0.016392177, 
          0.016378449, 0.016373723, 0.016307258, 0.01631241, 0.016250961, 
          0.016244599000000002`, 0.016216414000000002`, 0.016213452, 
          0.016210843000000003`, 0.016204845000000002`, 0.01613452, 
          0.016537211, 0.016056163000000002`, 0.015848977, 0.01580705, 
          0.015804069, 0.015770471, 0.015743774000000002`, 0.01573607, 
          0.015693020000000002`, 0.015421642000000001`, 0.015359988000000002`,
           0.015327024000000002`, 0.015279979, 0.015276683000000001`, 
          0.015231129000000001`, 0.015122032, 0.015082615, 0.019669473, 
          0.014977059000000001`, 0.014968175, 0.014932968000000001`, 
          0.014927211000000001`, 0.014867464, 0.014851284000000001`, 
          0.014841636, 0.014831100000000002`, 0.014759702000000001`, 
          0.014759515, 0.014617989000000001`, 0.014609189000000002`, 
          0.014496448, 0.014448204000000001`, 0.014333548000000002`, 
          0.014295141, 0.025195499000000003`, 0.014185022, 
          0.014171237000000001`, 0.013931601, 0.013814638, 0.013813808, 
          0.013807523, 0.013755330000000001`, 0.013745653, 0.013573016, 
          0.013400159, 0.013373104, 0.013326202, 0.013316203, 0.013239531, 
          0.013135435, 0.01313501, 0.013054718000000002`, 
          0.013038635000000002`, 0.012915171000000001`, 0.012914793, 
          0.012879972, 0.01270912, 0.012692918000000001`, 
          0.012685038000000001`, 0.021711704000000002`, 0.012543695, 
          0.012520548000000001`, 0.012447280000000002`, 0.012445565, 
          0.012391013000000001`, 0.012362772000000001`, 0.012356334, 
          0.012318692000000001`, 0.012257979, 0.015446742000000001`, 
          0.012046992000000001`, 0.012142743000000001`, 0.0118764, 
          0.011876174000000001`, 0.011713178000000001`, 0.011686891000000001`,
           0.011676420000000002`, 0.01164125, 0.021116646000000003`, 
          0.01157152, 0.011515894, 0.011508838, 0.011462908, 0.011455969, 
          0.011286288, 0.011216666, 0.011305379, 0.011192967, 0.011189793, 
          0.011100434000000001`, 0.011003571, 0.011000457, 0.010991528, 
          0.010933557, 0.010886318, 0.010867513, 0.010853082, 0.010795733, 
          0.010542886000000001`, 0.010476303000000001`, 0.010450286000000001`,
           0.010353252, 0.010342543000000001`, 0.010331517, 0.010250415, 
          0.010168011000000001`, 0.010152941, 0.010107027000000001`, 
          0.010103348, 0.010092132, 0.018197484, 0.019691826000000003`, 
          0.009930735000000001, 0.009882031000000001, 0.009869637, 
          0.009869306000000001, 0.009816565000000001, 0.009742033, 
          0.009678477000000001, 0.009664848, 0.009653562000000001, 
          0.009632318, 0.009586538, 0.009564318, 0.009539102, 
          0.009529959000000001, 0.00950255, 0.009490659, 0.009419363, 
          0.009302562, 0.009117988, 0.009000779, 0.008976695, 
          0.008972662000000001, 0.008951727000000001, 0.008945336, 0.00892837,
           0.008884933000000001, 0.008805635000000001, 0.008801652, 
          0.008754669000000001, 0.008713179, 0.008687682, 0.008682502, 
          0.008667240000000001, 0.008684567, 0.010550917, 0.008523434, 
          0.00843605, 0.008260335, 0.008185299, 0.008180323, 0.008166804, 
          0.00816492, 0.008143571, 0.0081245, 0.01021586, 0.008071699, 
          0.007997774000000001, 0.007949804000000001, 0.007940353, 
          0.007935187, 0.0079337, 0.007838531000000001, 
          0.0078068270000000006`, 0.009330907000000001, 
          0.0077078630000000006`, 0.007701165, 0.007612835, 
          0.007444648000000001, 0.007344721, 0.007319613000000001, 
          0.007279771000000001, 0.007271434, 0.007162479, 0.007140907, 
          0.007138872, 0.007087155, 0.007059262, 0.00704933, 
          0.007037977000000001, 0.0070277460000000005`, 0.007014715, 
          0.0070101040000000005`, 0.007005308, 0.0070048490000000005`, 
          0.00698116, 0.0069615530000000005`, 0.006941628, 0.00690168, 
          0.006806886000000001, 0.006734197000000001, 0.006721176000000001, 
          0.00668193, 0.006631943, 0.006601755000000001, 0.006558798, 
          0.006507309, 0.006439782000000001, 0.006429375, 0.006397573, 
          0.009378092000000001, 0.006229005, 0.0062052010000000005`, 
          0.006178363, 0.006102907, 0.0060403110000000005`, 
          0.006025892000000001, 0.006016317, 0.005941329, 0.005879388, 
          0.005875040000000001, 0.005864185, 0.005798621, 0.005746465, 
          0.0057173350000000005`, 0.005693699, 0.005668659, 
          0.005611359000000001, 0.005609413000000001, 0.005602076, 
          0.005536167000000001, 0.005529112, 0.005513489000000001, 
          0.005444581, 0.005440813, 0.005409934, 0.00903316, 0.005364647, 
          0.005359629, 0.005351758000000001, 0.005320924, 0.005301956, 
          0.0052613830000000006`, 0.005242977, 0.005195502, 0.005189456, 
          0.0051873810000000005`, 0.005119598, 0.005097939, 
          0.005082911000000001, 0.0050170020000000004`, 0.005007662, 
          0.004967478, 0.004938214000000001, 0.004881531000000001, 
          0.004821108, 0.004747903, 0.004714971, 0.0046681560000000006`, 
          0.004610531, 0.004565588000000001, 0.004528016, 
          0.004512746000000001, 0.004449606, 0.005935246000000001, 
          0.004435804000000001, 0.004388423000000001, 0.00438601, 0.004372993,
           0.00435289, 0.004337403, 0.004335507000000001, 0.004331871, 
          0.004328823, 0.004285737, 0.004213196000000001, 0.00421136, 
          0.005589454000000001, 0.0041613530000000004`, 0.004123204, 
          0.004091759, 0.004011019, 0.003998864, 0.003963157, 
          0.0039029330000000004`, 0.0038488880000000004`, 0.00384371, 
          0.0038168050000000004`, 0.0038110310000000003`, 
          0.0037893700000000002`, 0.0037599290000000004`, 
          0.0037557920000000004`, 0.003737507, 0.0037188160000000002`, 
          0.003705906, 0.003686626, 0.00367218, 0.0036673210000000003`, 
          0.003660149, 0.0036597400000000003`, 0.003655769, 0.00364452, 
          0.0036360900000000002`, 0.0036248260000000003`, 
          0.0036106610000000003`, 0.005182319, 0.003524412, 0.003524108, 
          0.0034395230000000003`, 0.0034182780000000003`, 
          0.0034061290000000004`, 0.0033774990000000004`, 0.00331925, 
          0.003301201, 0.0032980440000000004`, 0.0032377630000000003`, 
          0.0032325400000000003`, 0.0032252110000000004`, 0.003188396, 
          0.0031669600000000003`, 0.003146114, 0.003140378, 
          0.0031311050000000003`, 0.003131013, 0.003127205, 
          0.0031215260000000003`, 0.003112038, 0.0031032620000000003`, 
          0.003101435, 0.0030867890000000004`, 0.0030864350000000002`, 
          0.0030776590000000004`, 0.003072118, 0.002956387, 0.002940793, 
          0.002917579, 0.002902429, 0.0028919220000000003`, 0.002886736, 
          0.0028379100000000003`, 0.002809015, 0.0027983070000000003`, 
          0.0027868370000000003`, 0.002752383, 0.0027431810000000004`, 
          0.002709697, 0.00270335, 0.002686599, 0.002656719, 
          0.0026295660000000003`, 0.00394549, 0.0025961450000000002`, 
          0.002581332, 0.00254857, 0.0025017100000000003`, 
          0.0024351810000000002`, 0.0024246700000000003`, 0.004594112, 
          0.0024079740000000002`, 0.002404775, 0.0023929420000000003`, 
          0.0023708120000000004`, 0.0023569420000000003`, 
          0.0023559460000000003`, 0.0023478880000000002`, 0.002324093, 
          0.002315918, 0.0022897300000000002`, 0.002285866, 
          0.0022766830000000003`, 0.0022750030000000003`, 
          0.0022660220000000003`, 0.002265736, 0.002247088, 0.002226327, 
          0.002195551, 0.002173551, 0.0021427150000000003`, 0.002130242, 
          0.002104164, 0.003981941, 0.002102891, 0.0020590450000000002`, 
          0.002037531, 0.002028338, 0.0020151360000000003`, 0.001988017, 
          0.001979008, 0.001963701, 0.0019428280000000002`, 
          0.0019239160000000001`, 0.0018889890000000002`, 
          0.0018866960000000002`, 0.0018659520000000001`, 0.001860632, 
          0.0018600620000000002`, 0.001794662, 0.001759436, 
          0.0017419690000000001`, 0.001722194, 0.001660643, 0.00162816, 
          0.001622809, 0.001610995, 0.001576806, 0.001554285, 0.001502021, 
          0.001490694, 0.001481237, 0.0014794040000000001`, 0.001476265, 
          0.001458412, 0.0014350860000000001`, 0.0014337780000000001`, 
          0.001421664, 0.0014013320000000001`, 0.001391796, 
          0.0013791740000000002`, 0.001371091, 0.001363075, 0.001358465, 
          0.0013473320000000001`, 0.001333716, 0.0012917500000000001`, 
          0.001271343, 0.001250489, 0.001240081, 0.001211073, 0.001210612, 
          0.0012023840000000001`, 0.001194044, 0.00119202, 0.001191907, 
          0.0011508450000000002`, 0.0010559360000000002`, 0.001021123, 
          0.0009983560000000002, 0.0009876470000000001, 0.000983404, 
          0.000963719, 0.000959539, 0.00092371, 0.0009121810000000001, 
          0.000905305, 0.0008943330000000001, 0.0008911730000000001, 
          0.000872252, 0.0008259430000000001, 0.000818004, 0.000809873, 
          0.000807717, 0.000803779, 0.0007527860000000001, 
          0.0006923760000000001, 0.0006703340000000001, 0.0006667040000000001,
           0.000611014, 0.0005954070000000001, 0.0005762780000000001, 
          0.000554481, 0.000542023, 0.0005346320000000001, 0.00053374, 
          0.000530999, 0.000529784, 0.000503545, 0.000502123, 0.00047443, 
          0.000473169, 0.000469961, 0.00045079900000000005`, 0.000446645, 
          0.00041455100000000004`, 0.00039972600000000004`, 0.000397097, 
          0.00039277, 0.000606644, 0.000385535, 0.000382733, 
          0.00038222200000000004`, 0.00035640600000000003`, 
          0.00034590200000000004`, 0.000356829, 0.00033660200000000003`, 
          0.00033206200000000005`, 0.000317276, 0.000316756, 0.000295086, 
          0.000287566, 0.000281817, 0.00027676400000000004`, 0.000273377, 
          0.000267046, 0.00026689600000000003`, 0.000262912, 
          0.00023348700000000002`, 0.000230608, 0.000200638, 0.000200411, 
          0.00019832700000000001`, 0.00018173, 0.000181048, 0.000174942, 
          0.00016728, 0.00016007600000000002`, 0.000146142, 0.000144029, 
          0.000142609, 0.000142432, 0.00014223100000000001`, 0.000133771, 
          0.00011576200000000001`, 0.00011428600000000001`, 
          0.00010911900000000001`, 0.000103097, 0.000102232, 
          0.00010222000000000001`, 0.00010180700000000001`, 
          0.00009995200000000001, 0.000094139, 0.00009285700000000001, 
          0.000092514, 0.00008118200000000001, 0.000078656, 0.000066219, 
          0.000061043, 0.000059622000000000006`, 0.000056126000000000004`, 
          0.00005499, 0.000054343000000000005`, 0.000053880000000000006`, 
          0.000050882000000000005`, 0.000047426, 0.000041549000000000005`, 
          0.000040178, 0.000039072, 0.000035199, 0.000032031, 
          0.000031471000000000004`, 0.000030726000000000004`, 0.000019811, 
          0.000019738, 0.000018848, 0.000018335, 0.000017247000000000003`, 
          0.000016674, 0.000016548, 0.000015755, 0.000015654, 0.000015173, 
          0.000013809000000000001`, 0.000013706, 0.000013581000000000001`, 
          0.000013342, 9.91*^-6, 8.439*^-6, 8.036*^-6, 8.028*^-6, 6.301*^-6, 
          5.796*^-6, 5.296000000000001*^-6, 5.0920000000000005`*^-6, 3.8*^-6, 
          3.4550000000000004`*^-6, 3.221*^-6, 2.999*^-6, 2.674*^-6, 
          2.3550000000000003`*^-6, 1.9930000000000002`*^-6, 
          1.9820000000000003`*^-6, 1.57*^-6, 1.433*^-6, 
          1.2140000000000002`*^-6, 8.36*^-7, 7.16*^-7, 5.33*^-7, 4.64*^-7, 
          4.5800000000000005`*^-7, 4.42*^-7, 3.9800000000000004`*^-7, 
          3.6200000000000004`*^-7, 3.6000000000000005`*^-7, 3.56*^-7, 
          3.4500000000000003`*^-7, 3.42*^-7, 2.5900000000000003`*^-7, 
          2.42*^-7, 2.39*^-7, 2.3500000000000003`*^-7, 
          2.0000000000000002`*^-7, 1.9200000000000003`*^-7, 1.52*^-7, 
          1.05*^-7, 8.400000000000001*^-8, 7.800000000000001*^-8, 
          4.4000000000000004`*^-8, 3.0000000000000004`*^-8, 2.7*^-8, 2.7*^-8, 
          2.6*^-8, 2.6*^-8, 2.6*^-8, 2.5000000000000002`*^-8, 
          2.5000000000000002`*^-8, 2.1000000000000003`*^-8, 2.*^-8, 1.9*^-8, 
          1.3*^-8, 0., 0., 0., 0., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
          0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
           0, 0}, $CellContext`simulation[
          PatternTest[
           Pattern[$CellContext`eventsTable, 
            Blank[]], MatrixQ], 
          Pattern[$CellContext`initialCondition, 
           Blank[]], 
          Pattern[$CellContext`rassets, 
           Blank[]], 
          Pattern[$CellContext`rdebt, 
           Blank[]], 
          Pattern[$CellContext`\[Tau], 
           Blank[]], 
          Pattern[$CellContext`reinsurancePremium, 
           Blank[]], 
          Pattern[$CellContext`reinsuranceLimit, 
           Blank[]], 
          Pattern[$CellContext`netpremiums, 
           Blank[]], 
          Pattern[$CellContext`opts, 
           BlankNullSequence[]]] := MapIndexed[
          Function[{$CellContext`annualLosses, $CellContext`year}, 
           Thread[{
             Range[0, 
              Length[$CellContext`annualLosses]], 
             FoldList[
             With[{$CellContext`cashflow = $CellContext`netpremiums - \
$CellContext`reinsurancePremium - Max[0, #2 - $CellContext`reinsuranceLimit]}, 
               $CellContext`newBalanceSheet[#, $CellContext`cashflow, \
$CellContext`rassets, $CellContext`rdebt, $CellContext`\[Tau], 
                
                Part[$CellContext`year, 
                 1], $CellContext`opts]]& , $CellContext`initialCondition, \
$CellContext`annualLosses]}]], $CellContext`eventsTable], \
$CellContext`newBalanceSheet[{
           Pattern[$CellContext`assets, 
            Blank[]], 
           Pattern[$CellContext`liabilities, 
            Blank[]]}, 
          Pattern[$CellContext`operatingcashflow, 
           Blank[]], 
          Pattern[$CellContext`rassets, 
           Blank[]], 
          Pattern[$CellContext`rdebt, 
           Blank[]], 
          Pattern[$CellContext`\[Tau], 
           Blank[]], 
          Pattern[$CellContext`sim, 
           Blank[]], 
          Pattern[$CellContext`opts, 
           BlankNullSequence[Rule]]] := 
        Module[{$CellContext`debtService, $CellContext`cashflow, \
$CellContext`newBorrowings, $CellContext`f, \
$CellContext`twiaMemberAssessment, $CellContext`coastalSurcharge, \
$CellContext`unfunded}, $CellContext`f = ReplaceAll[
             ReplaceAll["cap", {$CellContext`opts}], {
             "cap" -> (
               Max[#, -1]& )}]; $CellContext`debtService = \
$CellContext`amortizePercent[$CellContext`rdebt, $CellContext`\[Tau]] \
$CellContext`liabilities; 
          Sow[{$CellContext`sim, $CellContext`operatingcashflow, 
             $CellContext`f[$CellContext`operatingcashflow], \
$CellContext`debtService}]; $CellContext`cashflow = \
$CellContext`f[$CellContext`operatingcashflow] - $CellContext`debtService; \
$CellContext`newBorrowings = 
           If[$CellContext`assets + $CellContext`cashflow > 0, 
             0, -($CellContext`assets + $CellContext`cashflow)]; {(
              1 + $CellContext`rassets) $CellContext`assets + \
$CellContext`cashflow + $CellContext`newBorrowings, \
$CellContext`newDebtPercent[$CellContext`rdebt, $CellContext`\[Tau]] \
$CellContext`liabilities + $CellContext`newBorrowings}], \
$CellContext`amortizePercent[
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`\[Tau], 
           Blank[]]] := $CellContext`r (1 + 
          1/(-1 + (
             1 + $CellContext`r)^$CellContext`\[Tau])), \
$CellContext`newDebtPercent[
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`\[Tau], 
           
           Blank[]]] := (-1 - $CellContext`r + (
            1 + $CellContext`r)^$CellContext`\[Tau])/(-1 + (
           1 + $CellContext`r)^$CellContext`\[Tau]), 
        Attributes[PlotRange] = {ReadProtected}, $CellContext`worstcase[
          Pattern[$CellContext`history, 
           Blank[List]]] := Min[
          Map[Part[#, 1] - Part[#, 2]& , 
           Map[Last, $CellContext`history]]]}; Typeset`initDone$$ = True); 
     ReleaseHold[
       HoldComplete[{$CellContext`yearProbs = {
           16.426131400000003`, 14.932075320000001`, 13.549557412, 
            12.567523047000002`, 12.526003508, 12.478529076000001`, 
            12.221252545, 12.182781817, 11.932251455000001`, 11.092291423, 
            10.911553608, 10.844337103, 10.587533384, 10.011079681, 
            9.916498115000001, 9.781691679000001, 9.553680318000001, 
            9.308779631, 9.048634768000001, 9.05571127, 8.739863569, 
            8.621733934, 8.557224152, 8.504544961, 7.891515181000001, 
            7.8831183010000005`, 7.7319829780000005`, 7.679341916, 
            7.616457068000001, 7.4956045630000006`, 7.442257296, 7.274566218, 
            9.570276571, 6.945400617000001, 6.89890497, 6.816827890000001, 
            6.711107419, 6.607407781, 6.390972522, 6.2027398620000005`, 
            6.059239024, 6.054051601, 6.0497521800000005`, 6.029510684000001, 
            6.863229885000001, 5.988101905000001, 5.827287512000001, 
            5.864510652000001, 5.695238004, 5.690834838000001, 5.686454997, 
            5.608857792, 5.592576495, 5.552029727000001, 5.548060841000001, 
            5.5163423400000005`, 5.498623472, 5.40735816, 5.209393576, 
            6.1485465800000005`, 7.117741602000001, 5.090884889000001, 
            5.165489084000001, 5.6104424790000005`, 4.961545269, 4.893777653, 
            5.01078283, 4.854614837000001, 4.978560532, 4.808532305, 
            5.122115888000001, 4.746664837, 5.650342109, 4.605065741000001, 
            5.882890173000001, 4.522688417, 4.589842079, 4.388237915, 
            4.356991808, 4.369910703, 5.686832545000001, 4.2876825080000005`, 
            5.897912474, 4.250560790000001, 4.23310417, 4.199795654, 
            4.18391958, 4.151514756, 4.15106144, 4.135003612, 
            4.1210117330000005`, 4.046623433000001, 4.297414998000001, 
            4.036276394000001, 4.013737559, 4.081668797, 3.967782108, 
            4.009505274, 3.955525343, 3.923680199, 5.9328645380000005`, 
            4.442517198, 3.8724898110000003`, 3.804127121, 
            3.7841350510000002`, 3.8046968440000004`, 3.7605468880000004`, 
            3.8427630450000003`, 3.7177781850000002`, 3.711141442, 
            3.6819670450000004`, 3.7649681480000003`, 3.6303737770000004`, 
            3.5818369850000003`, 4.180624826, 3.5559124310000003`, 
            3.5300866280000003`, 3.4996931960000004`, 3.475107404, 
            4.328662974, 3.376965069, 3.3755247550000003`, 
            3.3433635600000002`, 3.3476200720000002`, 3.349625247, 
            4.523742051, 3.313213199, 3.530808668, 4.350150188000001, 
            3.4518053820000003`, 3.2627826690000004`, 3.249208152, 
            3.248352311, 3.247896223, 3.717167755, 3.256179543, 
            4.349782080000001, 3.207884607, 3.124716996, 3.1154761090000003`, 
            3.103596549, 3.1718666360000003`, 3.0867774860000003`, 
            3.0859598160000004`, 3.079769542, 3.2218370870000004`, 
            3.2327488570000003`, 3.0587822210000004`, 3.032388789, 
            3.890786818, 3.004379934, 4.759445575, 4.209793827, 
            2.9775745110000003`, 2.9432363930000003`, 2.931689413, 
            2.995840874, 3.071454323, 2.895849767, 3.398727769, 2.844049525, 
            2.84193776, 3.07317317, 2.798425108, 2.795813035, 2.790865558, 
            3.8954226390000004`, 2.7529898040000003`, 2.7443338440000002`, 
            3.380196885, 3.2482864740000004`, 2.7243669930000003`, 
            2.722958611, 2.686138782, 2.68549021, 2.672654758, 3.042070841, 
            2.610933161, 2.5995355780000002`, 2.5915680890000004`, 2.5824576, 
            3.140871111, 2.705635082, 2.549903292, 2.897121351, 
            2.4708552960000003`, 2.4770235670000003`, 2.494739292, 
            2.4394930780000004`, 2.436119543, 3.3101837670000003`, 2.43095358,
             3.3056169210000004`, 2.4111649820000003`, 2.5757414020000002`, 
            3.2771938730000003`, 2.383650176, 2.985126176, 2.438729929, 
            2.3666946340000004`, 2.791710165, 2.350166341, 3.317167706, 
            2.3454866830000003`, 2.335455664, 2.3353437880000003`, 
            2.4668986740000003`, 2.330258187, 2.3302144780000003`, 
            2.324768075, 2.3205857400000003`, 2.297592788, 
            2.2863354090000003`, 2.2590444350000003`, 2.223043084, 
            2.2179302290000003`, 2.217054031, 2.200928352, 2.243138922, 
            2.174233333, 2.1663115370000003`, 2.3314877050000002`, 
            2.152209049, 2.149310627, 2.274050495, 2.129264278, 
            2.1145338060000003`, 2.105689663, 2.207743386, 2.090155528, 
            2.0822712020000003`, 2.0720011190000003`, 2.0654947050000003`, 
            2.0647722390000003`, 2.060576411, 2.052058985, 
            2.1295508140000003`, 2.098857293, 2.358300706, 
            2.6842726750000003`, 2.0364108450000002`, 2.001660202, 
            2.0003197210000003`, 1.9946870890000001`, 3.3230315040000002`, 
            1.9825037620000001`, 1.969888338, 1.939478837, 1.999897465, 
            1.938005133, 1.93635738, 1.9287675890000002`, 1.9167809240000002`,
             1.911144444, 1.9276223190000001`, 1.902933358, 
            2.0186851210000003`, 1.8924003800000002`, 1.9344489560000002`, 
            1.886977657, 2.096857113, 2.5759140680000003`, 
            1.8579165000000002`, 1.856610182, 2.113860582, 
            1.8477280390000002`, 1.8451016050000002`, 1.827441534, 
            1.8253997670000002`, 1.8252104290000002`, 1.8065055110000001`, 
            1.825156095, 1.797764157, 1.9518792390000002`, 1.784671587, 
            1.869767407, 1.774794159, 1.7736943420000002`, 1.773141327, 
            1.7653095740000002`, 1.7648623410000002`, 1.968191435, 
            1.7557101350000002`, 1.753055303, 1.752836491, 
            1.7466564340000001`, 1.7982490130000002`, 1.742195181, 
            1.798103433, 1.872683807, 1.766511536, 2.1421206290000003`, 
            1.7250799010000002`, 1.724652636, 2.3475952120000003`, 
            1.709097426, 1.82644657, 1.7047314800000002`, 1.9985142720000002`,
             1.701102321, 3.2113574010000003`, 1.7559278690000002`, 
            1.676388245, 2.02451216, 1.670614606, 1.6694875530000002`, 
            1.684653124, 1.636752605, 1.8230624480000002`, 
            1.6299626960000002`, 1.6270052570000002`, 1.615642381, 
            1.6100532230000002`, 1.6091365850000001`, 1.6030629280000002`, 
            4.412063938, 1.599568225, 1.919557898, 1.5944412490000002`, 
            1.5900792990000001`, 2.536121758, 1.6282263600000002`, 
            1.751640576, 1.5779151850000002`, 2.357254316, 1.567640433, 
            1.567523436, 1.5673415670000002`, 1.567029741, 
            1.5640547150000002`, 1.5625418610000001`, 1.567159312, 
            1.561171872, 1.5568495830000002`, 1.554877386, 1.554542831, 
            1.5536987400000002`, 2.90587324, 1.770016209, 1.563111767, 
            1.815302584, 1.53590344, 1.5293677890000001`, 1.5305746230000001`,
             1.526822235, 1.5107264290000002`, 1.5084296700000002`, 
            1.505435684, 1.5025074250000001`, 1.492064199, 2.509627793, 
            1.476627807, 2.068243562, 1.4688718390000002`, 1.46606096, 
            1.458293179, 1.4576155720000001`, 1.457137103, 
            1.4559789680000002`, 1.45319875, 1.4511879490000001`, 2.654945852,
             1.4383161560000002`, 1.940191779, 1.4312191840000001`, 
            1.5503371860000001`, 1.687622814, 1.4270217710000002`, 
            1.723914455, 1.4147576800000001`, 1.4216609720000002`, 
            1.409836418, 1.407718725, 1.4025634340000002`, 1.398263571, 
            1.4328771370000002`, 1.654903406, 1.376922277, 1.375502311, 
            1.577258336, 1.359312134, 1.351633531, 1.349937433, 1.349926266, 
            1.349230984, 1.5000875200000001`, 1.3472168450000002`, 
            1.346786832, 1.351760386, 1.339309506, 1.337240339, 1.332622277, 
            1.331285693, 1.3242672850000001`, 1.3237920140000001`, 
            2.3804921510000003`, 2.008611494, 1.313234875, 1.312997785, 
            1.309175341, 1.303022936, 1.3021489130000001`, 1.290367596, 
            1.42937201, 1.276462516, 1.273074787, 1.2687163460000002`, 
            1.8446046600000001`, 1.896671661, 1.2615704790000002`, 
            1.258195194, 1.253888273, 1.464736818, 1.2392414980000002`, 
            1.2349675800000002`, 1.507991555, 1.520909939, 1.225397305, 
            1.2230545030000002`, 1.560311111, 1.213866994, 1.226875616, 
            1.212997059, 1.211269396, 1.2072281360000001`, 
            1.8256864330000002`, 1.199153603, 1.1918662530000002`, 
            1.555319485, 1.190079114, 1.3150607460000001`, 
            1.1873625190000001`, 1.186990381, 1.2811534210000002`, 
            1.185233942, 1.184590858, 1.181790259, 1.18112122, 1.380422822, 
            1.400449222, 1.1745973410000001`, 1.2484258860000002`, 
            1.167343234, 1.166414207, 1.1658205830000001`, 
            1.2362792690000002`, 1.1640711590000001`, 1.162198043, 
            1.821450631, 1.148446998, 1.147253434, 1.153640437, 1.721464217, 
            1.95966346, 1.137239857, 1.1346505960000002`, 1.129822026, 
            2.079741844, 1.1274498860000002`, 1.4005129520000001`, 
            2.148486782, 1.124949755, 1.121662941, 1.193710725, 1.121403238, 
            1.192408871, 1.1252563020000002`, 1.117636082, 1.116514822, 
            1.1250927290000001`, 1.114255135, 1.1140645630000001`, 
            1.1100489960000002`, 1.107647529, 1.1072836590000001`, 
            1.146655835, 1.103617015, 1.1465122620000001`, 1.099664331, 
            1.0946637670000001`, 1.0821598190000001`, 1.743584065, 
            1.3269189620000001`, 1.0768497510000001`, 1.075716047, 
            1.071865617, 1.067127482, 1.065240012, 1.06378904, 1.06323631, 
            1.096733918, 1.07991535, 1.058078824, 1.0576822810000002`, 
            1.049486233, 1.1333706460000001`, 1.048655288, 
            1.0484548070000002`, 1.048405869, 1.0474850450000002`, 
            1.1024083630000001`, 1.042447998, 1.0401697840000002`, 1.03862455,
             1.264274943, 1.039606011, 1.035919504, 1.9332934060000002`, 
            1.025231699, 1.0263503820000002`, 1.0211973, 1.016144168, 
            1.014947151, 1.013843751, 1.2092358300000001`, 1.007569903, 
            1.0358210780000001`, 1.0034456920000001`, 1.0021841790000001`, 
            1.000526902, 0.999715133, 0.9963601860000001, 0.9963297560000001, 
            1.1667535820000001`, 1.8791777420000002`, 0.9940604780000001, 
            0.984217816, 0.9793055730000001, 0.979064432, 1.67934701, 
            0.980314199, 0.972196421, 0.9693748440000001, 0.969247206, 
            0.96885823, 1.3560749840000001`, 1.175104877, 0.97865535, 
            0.961302638, 0.960179847, 0.959036992, 0.9532436310000001, 
            0.952878101, 1.0029607090000001`, 0.9444722720000001, 0.942452861,
             1.3124845360000001`, 1.705617127, 0.9330429530000001, 
            1.269387577, 0.9284672860000001, 0.9282906310000001, 
            0.9271923590000001, 1.007021471, 0.924623649, 0.9829002910000001, 
            1.1923583100000001`, 0.922121116, 0.922084251, 
            1.4431537890000001`, 0.9181196170000001, 0.9150850460000001, 
            0.9147654340000001, 0.9083181100000001, 0.915007458, 
            0.9398521860000001, 0.9050047080000001, 0.9048443110000001, 
            1.479823989, 1.021325269, 0.8963761240000001, 0.896087442, 
            0.892795738, 0.8905808230000001, 0.8860391590000001, 
            0.8827944040000001, 1.917978135, 0.899647336, 1.256802503, 
            0.8795564990000001, 0.8765687040000001, 0.8769131130000001, 
            0.8714339860000001, 0.99230728, 0.864978098, 0.863267647, 
            1.68848101, 0.8603611640000001, 0.8599325400000001, 0.859612546, 
            0.859196633, 0.8566514070000001, 0.856222769, 0.853763256, 
            0.8515831700000001, 0.8515337420000001, 0.850904828, 0.899266234, 
            0.84987153, 0.847965713, 0.8592580910000001, 0.839153209, 
            0.8365720280000001, 0.833847116, 0.8329474290000001, 0.832481149, 
            0.914861648, 0.831304146, 0.8263716360000001, 0.8261070250000001, 
            1.380352178, 0.821908305, 0.9070501310000001, 0.935268477, 
            0.815132417, 1.0184110130000001`, 0.811158813, 0.8665279950000001,
             0.807618091, 1.514519608, 0.859480015, 0.8046044950000001, 
            0.7969083490000001, 0.976300397, 0.7953162460000001, 
            0.7946697650000001, 0.7934738650000001, 0.7930760200000001, 
            0.791093669, 0.790957298, 0.78973468, 0.7864493330000001, 
            0.7856509810000001, 0.785462195, 0.7844020140000001, 
            0.7817528220000001, 1.179249446, 0.775530335, 0.7669129760000001, 
            1.035778839, 0.7662133160000001, 0.7877529870000001, 0.764020158, 
            0.762529713, 0.76243739, 0.759433291, 0.7586687830000001, 
            0.754864379, 0.754772811, 0.753830015, 0.7506249580000001, 
            0.765781763, 0.7473282720000001, 1.266038523, 0.744658166, 
            0.744567159, 0.820832428, 0.744299185, 0.743352082, 
            0.7522610460000001, 0.738620895, 0.7367654800000001, 
            0.7367503360000001, 0.7353219480000001, 0.7333172490000001, 
            0.733305984, 0.7932354920000001, 0.7314103670000001, 
            0.7282257830000001, 0.7271148420000001, 0.7260701620000001, 
            0.766436666, 1.072458492, 0.963187267, 0.7219455370000001, 
            1.434187397, 0.7195555130000001, 1.460996028, 0.718749486, 
            0.718750077, 0.8906869770000001, 0.717778604, 0.716872178, 
            0.9889814010000001, 0.716487305, 0.7668689790000001, 0.712982572, 
            0.7126801110000001, 0.712261056, 0.739338524, 0.960631263, 
            0.711028322, 0.7106943130000001, 1.6509804730000002`, 
            0.7067435270000001, 0.705455555, 0.704456423, 1.3315268770000002`,
             0.716963592, 0.7036779240000001, 0.7032292290000001, 
            0.7017158130000001, 0.8322549890000001, 0.7710705120000001, 
            0.699510521, 0.697055839, 0.74382859, 0.696147613, 0.695629375, 
            0.695565192, 0.6953492250000001, 0.69504957, 0.7779781090000001, 
            0.691256187, 0.816694629, 0.778325707, 0.686920324, 0.684509107, 
            0.6844848410000001, 0.683880351, 0.68352215, 0.683263975, 
            0.6816723680000001, 0.685282347, 0.679922323, 0.678906525, 
            0.678362707, 0.6774177050000001, 0.6761813790000001, 0.676001127, 
            0.673327285, 0.991964516, 0.6695203670000001, 1.010162099, 
            0.669196911, 0.66858328, 0.6679839830000001, 0.667174162, 
            0.66327228, 0.6631787560000001, 0.6623662720000001, 1.11417677, 
            0.6595719050000001, 0.68244317, 0.6572641100000001, 
            0.6550091650000001, 0.654335208, 0.654127965, 0.653632842, 
            0.8441434090000001, 0.6545911280000001, 0.821229788, 0.65092918, 
            0.648957823, 0.647430187, 0.6461494080000001, 0.677810851, 
            0.6438775560000001, 0.6437413350000001, 0.8527319250000001, 
            0.637843743, 0.637695662, 0.636017983, 0.828779173, 0.634805662, 
            0.6346881940000001, 0.6337983110000001, 1.2174574470000001`, 
            0.9254829590000001, 0.7067574130000001, 0.6312768320000001, 
            0.6309180050000001, 0.630656776, 0.6279450710000001, 0.627628728, 
            0.6269162070000001, 1.061243157, 0.625784067, 0.710756956, 
            0.623772757, 0.6590100790000001, 0.748148443, 0.619274957, 
            0.798123993, 0.7343743540000001, 0.6181599590000001, 
            1.0548844510000002`, 0.615709453, 0.717280013, 0.647998354, 
            0.682500855, 0.612256342, 0.678800049, 0.6106228850000001, 
            0.7543074580000001, 0.607725586, 0.606532158, 1.08916731, 
            0.605822728, 0.908848894, 0.602303993, 0.6001826610000001, 
            0.598355659, 0.597933586, 0.5978983880000001, 0.5973534, 
            0.597242621, 0.625073878, 0.594916958, 0.7098195930000001, 
            0.887605611, 0.5910228270000001, 0.590543106, 0.5898006640000001, 
            0.5891158790000001, 0.582425835, 0.9344181530000001, 
            0.5809785080000001, 0.5805730680000001, 0.6225846820000001, 
            0.579435664, 0.827830112, 0.575653776, 0.799073652, 0.574373397, 
            0.57430768, 0.8321232700000001, 0.5723100720000001, 
            0.5749585100000001, 0.571647259, 0.5715834200000001, 
            0.6501116520000001, 0.639984642, 0.619513712, 0.56451374, 
            0.563694522, 0.630178525, 0.562622937, 0.562214781, 0.560957625, 
            0.5594071890000001, 0.559099486, 0.642390572, 0.926064289, 
            0.55766074, 0.557183708, 0.5623415070000001, 0.563437367, 
            0.7209434170000001, 0.8044142240000001, 0.639646532, 
            0.5541076890000001, 0.552748066, 0.552700241, 0.552640309, 
            0.552355846, 0.552339589, 0.5511047010000001, 0.554597797, 
            0.550726146, 0.549812186, 0.5487003570000001, 0.5617690270000001, 
            0.546557625, 0.545126874, 0.5449657090000001, 0.5432617740000001, 
            0.542501815, 0.823690024, 1.087644899, 0.539108994, 
            0.5386872180000001, 0.538589575, 0.5382821710000001, 0.537123653, 
            1.032551283, 0.536292204, 0.866308351, 0.5684067780000001, 
            0.534601203, 0.533707518, 0.572197374, 0.757163806, 0.876110331, 
            0.5303988390000001, 0.529206355, 0.6172125810000001, 0.534777452, 
            0.5269209, 0.526254797, 0.5262301690000001, 0.525993256, 
            0.630028537, 0.5252708660000001, 0.524415484, 0.524227927, 
            0.523686037, 0.528788506, 0.5214038510000001, 0.520707052, 
            0.520513325, 0.520349185, 0.5194254100000001, 0.875591122, 
            0.5190033460000001, 0.51846148, 0.51820192, 0.96959211, 
            0.5613666810000001, 0.5165680850000001, 0.515970761, 
            0.5158933880000001, 0.514081097, 0.513604787, 0.884341302, 
            1.2736888910000002`, 0.5117857170000001, 0.562446112, 0.509846686,
             0.508823475, 0.775369021, 0.506805805, 0.6868703580000001, 
            0.5050199790000001, 0.6661177540000001, 0.504035208, 0.503544501, 
            0.548884279, 0.512024699, 0.501266479, 0.993270686, 0.499882714, 
            0.49981450200000005`, 0.49967796500000006`, 0.498881923, 
            0.777421519, 0.49761046400000003`, 0.5329518520000001, 
            0.6914930530000001, 0.49601729800000005`, 0.495185637, 0.49423461,
             0.92959254, 0.49384465200000005`, 0.829181864, 
            0.49239742100000006`, 0.5017790560000001, 0.507293281, 
            0.487946814, 0.48788409400000005`, 0.486829296, 
            0.5504457850000001, 0.48523317400000004`, 0.484924149, 
            0.484723463, 0.48315186200000004`, 0.792564139, 0.489571662, 
            0.5243599830000001, 0.480668808, 0.48066426100000004`, 
            0.48022380600000003`, 0.48005074000000003`, 0.47997422900000003`, 
            0.47937970500000004`, 0.47880767700000004`, 0.477925447, 
            0.475797827, 0.47530741000000004`, 0.674135763, 
            0.47239605900000003`, 0.468461852, 0.468087409, 
            0.46704803600000006`, 0.466250504, 0.518086637, 0.794636081, 
            0.465736101, 0.464298076, 0.871703714, 0.651438921, 0.602787768, 
            0.465411807, 0.461617891, 0.46062932300000003`, 
            0.45964943500000005`, 0.458186794, 0.45775816900000005`, 
            0.45663935200000005`, 0.456544072, 0.9127526460000001, 0.54700683,
             0.453796884, 0.45796001900000005`, 0.453465987, 
            0.45325699500000005`, 0.45248358600000005`, 0.451814325, 
            0.45046856, 0.450205114, 0.45017335700000005`, 0.713082626, 
            0.449742754, 1.0905804000000001`, 0.878930736, 0.447346511, 
            0.446924478, 0.44686722100000004`, 0.469150783, 
            0.44373188100000005`, 0.442739044, 0.44212725500000005`, 
            0.6274193530000001, 0.441195869, 0.440729927, 0.7202023270000001, 
            0.437537742, 0.437365824, 0.43724070600000003`, 0.638122529, 
            0.437076732, 1.136347943, 0.43488587300000003`, 0.434748057, 
            0.46419511300000005`, 0.433853303, 0.451793062, 0.433710627, 
            0.433445664, 0.432632783, 0.432436647, 0.431647039, 0.431267644, 
            0.431044015, 0.43063378500000005`, 0.430163775, 0.564302678, 
            0.429394859, 0.49848107, 0.577732448, 0.42908427000000005`, 
            0.428978085, 0.428685615, 0.42854770400000003`, 
            0.42639752200000003`, 0.42639424800000003`, 0.428340323, 
            0.42592979400000003`, 0.42419881600000003`, 0.423729367, 
            0.42278687200000004`, 0.422758581, 0.549050664, 
            0.42135691700000005`, 0.42045112700000004`, 0.420315274, 
            0.41940013000000004`, 0.418545902, 0.679311831, 
            0.6451268440000001, 0.485719612, 0.7398878520000001, 0.416593841, 
            0.41634399000000005`, 0.415996413, 0.41535811300000003`, 
            0.41769930600000005`, 0.522500469, 0.41935535100000004`, 
            0.41383001900000005`, 0.41371714000000004`, 0.41243579900000005`, 
            0.412020563, 0.494470642, 0.409438428, 0.409339153, 0.408406818, 
            0.40802424200000004`, 0.40795353, 0.40790166, 0.406817547, 
            0.406582527, 0.405461448, 0.7500756890000001, 0.5944482480000001, 
            0.40303740600000004`, 0.40298094700000003`, 0.402910013, 
            0.399885835, 0.399682729, 0.39967865700000005`, 0.399375441, 
            0.39881989700000003`, 0.972669027, 0.39869914, 0.397104815, 
            0.890503106, 0.416328415, 0.39610871400000003`, 0.395815642, 
            0.409011636, 0.395420086, 0.45404903100000005`, 0.429831772, 
            0.39303307000000004`, 0.392653848, 0.39264042600000004`, 
            0.45669266100000006`, 0.41908319600000005`, 0.790593544, 
            0.5807620680000001, 0.39015831, 0.38934796200000005`, 
            0.46160949700000004`, 0.38783377500000005`, 0.387526629, 
            0.387329572, 0.387322447, 0.386736858, 0.38669994700000004`, 
            0.385726396, 0.38483756500000005`, 0.384799636, 
            0.38451360100000004`, 0.38337737400000005`, 0.425416401, 
            0.39848446400000004`, 0.925421593, 0.37940052, 0.379259887, 
            0.37888491700000004`, 0.37841109, 0.378399091, 
            0.37810511300000005`, 0.449053018, 0.426334229, 0.376039938, 
            0.375850667, 0.374914837, 0.37389358300000003`, 
            0.37384285100000003`, 0.373304907, 0.373228337, 0.549157356, 
            0.372214943, 0.463353693, 0.37202966200000004`, 0.371699271, 
            0.390271105, 0.390850403, 0.37029115500000004`, 
            0.36897407000000004`, 0.36680896900000004`, 0.36652975200000004`, 
            0.36539371600000004`, 0.364586258, 0.364256163, 0.363802348, 
            0.363541006, 0.36339161200000003`, 0.418241597, 
            0.36216800800000004`, 0.36198062200000003`, 0.36158679600000004`, 
            0.45267479400000005`, 0.706368757, 0.35810476100000005`, 
            0.357871575, 0.35757723300000005`, 0.35734987700000004`, 
            0.512866155, 0.357057976, 0.356134614, 0.537855151, 0.355272511, 
            0.439300662, 0.35393140900000003`, 0.35392426800000004`, 
            0.353646987, 0.37350681, 0.35336188300000004`, 0.357912339, 
            0.466171755, 0.527010918, 0.35069127, 0.35554700300000003`, 
            0.35042728300000003`, 0.38597875400000003`, 0.36501007700000004`, 
            0.35327676900000005`, 0.348095156, 0.375698737, 
            0.34679225900000005`, 0.34601189200000004`, 0.44065675000000004`, 
            0.349822012, 0.343884575, 0.343340492, 0.342846364, 0.342729228, 
            0.342474785, 0.34931899800000005`, 0.34167941700000004`, 
            0.517474526, 0.34089164800000005`, 0.588403917, 0.340247224, 
            0.40267385, 0.37889284300000003`, 0.33727925200000003`, 
            0.541748982, 0.337069734, 0.33599209100000005`, 0.335917841, 
            0.334984598, 0.334944958, 0.334867216, 0.333976131, 0.33390038, 
            0.33356457500000003`, 0.3430012, 0.332236907, 0.387918272, 
            0.331161252, 0.331130144, 0.343881423, 0.330645811, 0.330408034, 
            0.330230953, 0.32960149800000005`, 0.32906223500000004`, 
            0.328622156, 0.328262261, 0.327448605, 0.32686724500000003`, 
            0.325850285, 0.501550446, 0.33490399200000004`, 0.325171832, 
            0.46590428300000003`, 0.35525909, 0.324450416, 
            0.43954020600000004`, 0.322471658, 0.32241595100000003`, 
            0.32113204, 0.418892818, 0.319837873, 0.383005971, 
            0.31871923300000005`, 0.31826365500000003`, 0.31813888900000004`, 
            0.32064603, 0.317650515, 0.32022380500000003`, 
            0.49354306600000003`, 0.316272799, 0.32496766800000004`, 
            0.31617015000000004`, 0.315287003, 0.315235027, 
            0.31515770200000004`, 0.314422973, 0.314345274, 
            0.31376257900000004`, 0.31340275, 0.31324782900000003`, 
            0.313189156, 0.343400095, 0.347611486, 0.311109427, 0.49590802, 
            0.37044128600000004`, 0.32101908, 0.378643597, 
            0.30900681700000004`, 0.308992096, 0.308395611, 0.308338296, 
            0.329995338, 0.30804336000000004`, 0.30770476, 0.306847637, 
            0.306630091, 0.306079213, 0.305713367, 0.305494468, 
            0.44287835400000003`, 0.30543087, 0.305350736, 
            0.30527946100000003`, 0.304899142, 0.30457586400000003`, 
            0.304354028, 0.30413444300000003`, 0.30413352400000004`, 
            0.30504707400000003`, 0.302926435, 0.302730683, 0.302647903, 
            0.3019372, 0.30137688700000004`, 0.30101821, 0.300251203, 
            0.299834149, 0.29952304300000004`, 0.29879318200000005`, 
            0.298174203, 0.297312611, 0.29726623500000005`, 0.296985529, 
            0.29689675000000004`, 0.296540682, 0.29577628100000003`, 
            0.295301405, 0.295864073, 0.295188914, 0.29509654700000004`, 
            0.323659283, 0.294171258, 0.293713016, 0.5063198400000001, 
            0.292757215, 0.366582864, 0.525464677, 0.291579672, 0.291053349, 
            0.29058293500000004`, 0.697987914, 0.411544569, 
            0.28905821800000003`, 0.289062354, 0.288681371, 0.28845452, 
            0.391346161, 0.288422711, 0.287421313, 0.28690885600000005`, 
            0.28680044000000005`, 0.28545136800000004`, 0.531296721, 
            0.30184182000000004`, 0.284034163, 0.343517108, 0.447163336, 
            0.673399374, 0.281693564, 0.514977145, 0.48127179600000003`, 
            0.320784936, 0.27969704500000003`, 0.46727192100000003`, 
            0.295083759, 0.278397465, 0.41678692300000003`, 
            0.31737450700000003`, 0.277672207, 0.369438804, 0.277224943, 
            0.27706429800000004`, 0.27690478700000004`, 0.276386778, 
            0.2812236, 0.27629320300000004`, 0.276290452, 0.276688651, 
            0.27596397, 0.30546268200000004`, 0.49505365500000004`, 
            0.275436728, 0.558076384, 0.49352922200000005`, 0.274450597, 
            0.274218781, 0.516323561, 0.27373745800000004`, 
            0.27343612500000003`, 0.49394929000000004`, 0.309622516, 
            0.272423774, 0.370258695, 0.271811583, 0.271360792, 0.271037183, 
            0.270477255, 0.314960913, 0.26982706300000003`, 0.288073157, 
            0.47229418100000004`, 0.26899480200000003`, 0.526064615, 
            0.46929185300000004`, 0.26754895, 0.267304834, 0.267076877, 
            0.26675207300000003`, 0.266104473, 0.265608385, 
            0.26495240600000003`, 0.398120525, 0.263749934, 
            0.26364728400000004`, 0.263542105, 0.27679380600000003`, 
            0.263020805, 0.262938991, 0.5016939450000001, 
            0.49836002500000004`, 0.443615919, 0.261970223, 
            0.6406931260000001, 0.26163121100000003`, 0.260846648, 
            0.317077394, 0.261545552, 0.25973524600000003`, 0.259085347, 
            0.346009705, 0.258640931, 0.258042418, 0.257972548, 0.270331763, 
            0.37465385300000004`, 0.46668661100000003`, 0.256764359, 
            0.256356568, 0.256251512, 0.256025063, 0.255516149, 0.255484629, 
            0.25545679200000004`, 0.274321827, 0.33384488500000004`, 
            0.445622151, 0.253902613, 0.253693002, 0.25337098, 0.253254831, 
            0.252852428, 0.25215755, 0.250619046, 0.250298586, 
            0.36034525700000003`, 0.343353939, 0.24914374400000003`, 
            0.249104811, 0.248378373, 0.24834739700000003`, 
            0.42742770900000004`, 0.24603476200000002`, 0.24588303200000003`, 
            0.24567350100000002`, 0.24552542100000002`, 0.24548166100000002`, 
            0.24522833500000002`, 0.252589498, 0.245095008, 
            0.31671535300000003`, 0.244545963, 0.244262431, 0.24419645, 
            0.24414538600000002`, 0.3683382, 0.242837869, 
            0.24162820100000001`, 0.2888719, 0.241249497, 0.247375743, 
            0.240364512, 0.23989816700000002`, 0.23955799100000003`, 
            0.47450988400000005`, 0.23802277800000002`, 0.237921554, 
            0.23783201, 0.237536242, 0.237427823, 0.344353465, 
            0.29123287600000003`, 0.236781066, 0.236114506, 0.236048474, 
            0.274091972, 0.235482148, 0.23540069500000002`, 
            0.23540000100000003`, 0.23451943, 0.234113796, 0.233982655, 
            0.23387196200000002`, 0.233712048, 0.233452133, 0.232805633, 
            0.251645346, 0.35505171700000004`, 0.23225906000000002`, 
            0.23223979300000003`, 0.23219577800000002`, 0.23189119800000002`, 
            0.231687409, 0.231267576, 0.23637845600000001`, 0.335743165, 
            0.30252058200000004`, 0.229923292, 0.24396714700000002`, 
            0.22876220500000002`, 0.22814784600000002`, 0.22812189900000002`, 
            0.22721043200000002`, 0.227170423, 0.22641965300000003`, 
            0.22621274500000002`, 0.226170281, 0.22566512900000002`, 
            0.22564174, 0.292682131, 0.225088702, 0.273831999, 0.456406423, 
            0.223689998, 0.232153393, 0.22269688, 0.225011767, 0.222558197, 
            0.235646283, 0.22187020600000001`, 0.23209992200000001`, 
            0.296834303, 0.221289896, 0.22075555700000002`, 0.382619399, 
            0.279618195, 0.219807895, 0.219249662, 0.28358139000000004`, 
            0.21917223800000002`, 0.304944408, 0.218962331, 0.448442712, 
            0.21789986500000003`, 0.217673898, 0.21757725300000003`, 
            0.222463727, 0.21711300300000003`, 0.21688385300000002`, 
            0.216634824, 0.27782180700000003`, 0.216482221, 
            0.21646577500000003`, 0.216228508, 0.39616024000000005`, 
            0.257887123, 0.215232257, 0.21521572500000002`, 
            0.28494444900000004`, 0.21516321300000002`, 0.21482373000000002`, 
            0.224896686, 0.214122993, 0.21409723300000003`, 0.214029972, 
            0.21362119000000002`, 0.21361280800000002`, 0.21333516400000002`, 
            0.279606291, 0.21256946000000002`, 0.212064144, 
            0.34890648900000004`, 0.21112543800000003`, 0.276284497, 
            0.21087683200000001`, 0.210444981, 0.209969855, 0.209912484, 
            0.304663099, 0.294738204, 0.24316036500000002`, 0.207057394, 
            0.27477916, 0.20612402100000002`, 0.205884591, 0.205850275, 
            0.205529445, 0.20489067900000002`, 0.20584053300000002`, 
            0.203704781, 0.20294045800000002`, 0.202899883, 0.20289945, 
            0.202769409, 0.20254449800000002`, 0.202419548, 0.343255727, 
            0.275709466, 0.202166538, 0.20189873500000002`, 0.208162851, 
            0.224574447, 0.20148817900000002`, 0.20109478700000002`, 
            0.200595338, 0.200357897, 0.200340018, 0.20027507300000003`, 
            0.199839491, 0.19983921500000001`, 0.19955657300000001`, 
            0.239701777, 0.199370928, 0.19910575400000002`, 
            0.19933049700000002`, 0.20120131400000002`, 0.19750213600000002`, 
            0.197406842, 0.29596636200000004`, 0.19663017600000002`, 
            0.196364474, 0.196244453, 0.195755217, 0.195693322, 0.195533327, 
            0.19485226600000002`, 0.194777115, 0.19464150900000002`, 
            0.193979439, 0.19392151400000002`, 0.29936833300000004`, 
            0.19376644, 0.19364935800000002`, 0.198713737, 
            0.19323975200000001`, 0.193234117, 0.19262599300000002`, 
            0.19226490000000002`, 0.19213954400000002`, 0.19058238200000002`, 
            0.19007921600000002`, 0.189469765, 0.189056685, 0.189006841, 
            0.292388915, 0.188571498, 0.188043063, 0.22564412900000003`, 
            0.186605987, 0.234033655, 0.186452382, 0.18612513, 0.239334485, 
            0.185693508, 0.185663512, 0.18559656400000002`, 
            0.18524263800000002`, 0.33917237100000003`, 0.184938774, 
            0.18476930900000002`, 0.18476909000000002`, 0.25242885000000004`, 
            0.18454788900000002`, 0.18405099, 0.184016843, 
            0.18377795700000002`, 0.18372744500000002`, 0.21266082500000003`, 
            0.18326477500000002`, 0.183113364, 0.182986482, 0.182273223, 
            0.182216918, 0.182257957, 0.18220580700000003`, 0.181907119, 
            0.181633773, 0.181628175, 0.181521559, 0.181385081, 0.449633526, 
            0.18004973300000002`, 0.18004460600000002`, 0.179270286, 
            0.17915313100000002`, 0.182161298, 0.17916938200000002`, 
            0.17840161400000001`, 0.213300695, 0.17810230700000002`, 
            0.177813041, 0.28804498100000003`, 0.33341728000000004`, 
            0.21534873000000002`, 0.177423037, 0.17719683600000002`, 
            0.176262475, 0.17595617800000002`, 0.17593688000000002`, 
            0.175670015, 0.175363655, 0.174969792, 0.17439764200000002`, 
            0.26298887000000004`, 0.17426386800000002`, 0.17421271400000002`, 
            0.17417221800000002`, 0.174022737, 0.173008342, 0.35256196, 
            0.17275262200000002`, 0.172058904, 0.172041256, 
            0.17190175300000002`, 0.171872831, 0.17166903700000002`, 
            0.17146113300000002`, 0.171236081, 0.17082618900000002`, 
            0.170587243, 0.21280377900000003`, 0.170249947, 0.271576651, 
            0.21907199100000002`, 0.16987575100000002`, 0.16940386100000002`, 
            0.170961357, 0.169296424, 0.16893159800000002`, 
            0.16824934400000002`, 0.167680785, 0.216171212, 0.167308966, 
            0.167264824, 0.1670839, 0.16699365600000002`, 
            0.16674418200000002`, 0.183556625, 0.16652080500000002`, 
            0.325433707, 0.166372283, 0.16588160100000002`, 0.165839029, 
            0.16541323000000002`, 0.165286243, 0.16512453900000001`, 
            0.16500187800000002`, 0.164902495, 0.164670599, 
            0.16457964700000002`, 0.164454432, 0.164116448, 
            0.16974535400000001`, 0.16397930300000002`, 0.163401516, 
            0.163371503, 0.16322630300000002`, 0.16287199200000002`, 
            0.162773717, 0.162377068, 0.16208837, 0.16192676, 
            0.16162363500000002`, 0.16158154800000002`, 0.16155306500000002`, 
            0.16842711400000002`, 0.161297255, 0.16105508300000002`, 
            0.16092910800000002`, 0.160870444, 0.27631472100000004`, 
            0.16052470500000002`, 0.160499199, 0.160402129, 0.160199306, 
            0.16001483500000002`, 0.159998636, 0.15958582500000001`, 
            0.159236188, 0.15921561, 0.158908672, 0.158868384, 0.158658669, 
            0.158528054, 0.15823731300000002`, 0.158206019, 0.161382616, 
            0.15796421900000002`, 0.15778688500000002`, 0.16134906000000002`, 
            0.156373004, 0.156262651, 0.156237007, 0.156014582, 0.155730283, 
            0.167296203, 0.15470075800000002`, 0.154689616, 0.154583848, 
            0.154536386, 0.154531843, 0.154240224, 0.15418483200000002`, 
            0.153778313, 0.15823921900000001`, 0.153586107, 
            0.15349817200000002`, 0.153482741, 0.153415923, 0.153324173, 
            0.15283611700000002`, 0.152671457, 0.155740957, 0.152128178, 
            0.151323693, 0.15115234500000002`, 0.15106134100000002`, 
            0.15101735800000002`, 0.151002898, 0.15263046900000002`, 
            0.15072389900000002`, 0.150515543, 0.150388998, 0.150050442, 
            0.149937274, 0.148534104, 0.148175295, 0.148150311, 0.196177853, 
            0.147988626, 0.152723455, 0.14748661000000002`, 0.230540987, 
            0.14703088, 0.14681491500000002`, 0.146760272, 0.146714816, 
            0.14670227800000002`, 0.146644777, 0.182661824, 0.146263901, 
            0.146204583, 0.145916198, 0.219250199, 0.145605788, 
            0.14551234100000002`, 0.26953827, 0.145250183, 0.154110667, 
            0.273182083, 0.144686869, 0.18738959800000002`, 0.144191489, 
            0.143775716, 0.143682686, 0.143181469, 0.143167598, 
            0.14285688600000002`, 0.142824125, 0.142660732, 
            0.22809817400000001`, 0.268235634, 0.142244063, 
            0.14222135900000002`, 0.142047602, 0.166626622, 0.141766257, 
            0.141298093, 0.21157107300000003`, 0.140855228, 0.140658625, 
            0.258874949, 0.14037595900000002`, 0.171049004, 0.163161111, 
            0.139625609, 0.139336382, 0.139296272, 0.19812121100000002`, 
            0.139624725, 0.138729022, 0.13867962, 0.13852045300000002`, 
            0.138495832, 0.138381254, 0.13830884100000002`, 0.13796507, 
            0.137760248, 0.13747715000000002`, 0.137378461, 0.137250283, 
            0.137242354, 0.13722515000000002`, 0.137162654, 0.137153733, 
            0.137029949, 0.136458762, 0.136314121, 0.135900872, 0.135830952, 
            0.135352794, 0.13530277400000001`, 0.135238727, 0.135232125, 
            0.134939883, 0.134806581, 0.134710089, 0.14990825600000002`, 
            0.13458586, 0.184435869, 0.13444799400000002`, 0.134276887, 
            0.13419039800000002`, 0.13397793, 0.139714729, 0.133618173, 
            0.133378354, 0.133309375, 0.133119905, 0.132974057, 0.132675249, 
            0.132542454, 0.13386140300000002`, 0.18625133900000002`, 
            0.13226005400000002`, 0.13216888000000002`, 0.132075636, 
            0.188823877, 0.131984083, 0.131958944, 0.1560032, 
            0.13157005400000002`, 0.13137499700000002`, 0.131289957, 
            0.131261399, 0.131087276, 0.13091022800000002`, 0.150640311, 
            0.130579135, 0.130539298, 0.130489625, 0.14168941300000001`, 
            0.17495771100000002`, 0.19490617200000002`, 0.129610894, 
            0.129123917, 0.128698464, 0.128545208, 0.128353393, 0.128230897, 
            0.138687435, 0.127974844, 0.162284014, 0.12777548800000002`, 
            0.127699995, 0.127407711, 0.12738157, 0.127156467, 0.126972166, 
            0.126957346, 0.17982219300000002`, 0.126789811, 
            0.22301103100000003`, 0.126606876, 0.12632484100000002`, 
            0.126138725, 0.127768171, 0.125858927, 0.12528355600000002`, 
            0.124989443, 0.124902312, 0.12476711600000001`, 0.12444958, 
            0.124397036, 0.124142366, 0.124121958, 0.12404848600000001`, 
            0.12399019600000001`, 0.123894764, 0.12389279900000001`, 
            0.123878071, 0.12322071200000001`, 0.122826708, 
            0.13759321700000002`, 0.12227802200000001`, 0.12226610800000001`, 
            0.13985017500000002`, 0.12210037100000001`, 0.12186798, 
            0.12170162300000001`, 0.12168160400000001`, 0.14898540500000002`, 
            0.12765410700000002`, 0.120643754, 0.120600092, 0.120352781, 
            0.12025387200000001`, 0.12833307100000002`, 0.11987522800000001`, 
            0.119784045, 0.11941195900000001`, 0.11925780100000001`, 
            0.11909062000000001`, 0.11887472600000001`, 0.11887428600000001`, 
            0.118826231, 0.11838691600000001`, 0.11826502100000001`, 
            0.117895551, 0.11718982600000001`, 0.11690220100000001`, 
            0.116820846, 0.11680936900000001`, 0.116749746, 
            0.11670509200000001`, 0.116468018, 0.11613329900000001`, 
            0.116073748, 0.11604574100000001`, 0.11597668900000001`, 
            0.13164609800000002`, 0.115724117, 0.128427722, 0.229378823, 
            0.115017884, 0.122471619, 0.114920214, 0.11476508, 
            0.11468151900000001`, 0.114383548, 0.114365825, 0.114156056, 
            0.18709946500000002`, 0.113922693, 0.113905221, 0.113705568, 
            0.11364647300000001`, 0.113635842, 0.24241856900000003`, 
            0.11343277400000001`, 0.11330097900000001`, 0.11355786600000001`, 
            0.112962009, 0.11863663, 0.112787097, 0.144714181, 0.120668301, 
            0.11267710500000001`, 0.11258324300000001`, 0.112556711, 
            0.11246513000000001`, 0.11244483400000001`, 0.18750296500000002`, 
            0.11184316000000001`, 0.111643764, 0.191137996, 0.20138654, 
            0.14194869000000002`, 0.110942835, 0.11086902700000001`, 
            0.110815124, 0.110804025, 0.110669126, 0.110612635, 
            0.11055308700000001`, 0.110491005, 0.110353323, 0.124041516, 
            0.110163677, 0.110115925, 0.10994279200000001`, 0.109892554, 
            0.1287633, 0.133956457, 0.126040585, 0.109374281, 0.109374172, 
            0.109243537, 0.10920229000000001`, 0.10911645900000001`, 
            0.109023987, 0.108929124, 0.10875817400000001`, 
            0.10875545900000001`, 0.125221666, 0.10870889500000001`, 
            0.15960264600000001`, 0.10817899, 0.170440166, 0.215099338, 
            0.10778359200000001`, 0.177471019, 0.106812048, 0.10676459, 
            0.106703696, 0.106622143, 0.10645309700000001`, 0.10627422, 
            0.106062605, 0.187336562, 0.105888045, 0.105864841, 0.105652518, 
            0.105438052, 0.10524343200000001`, 0.20576708700000002`, 
            0.10493980400000001`, 0.104850016, 0.106510773, 
            0.10435574600000001`, 0.10429103, 0.10410556600000001`, 
            0.10406211000000001`, 0.103542542, 0.10343023800000001`, 
            0.10339608800000001`, 0.19781741500000002`, 0.10330770700000001`, 
            0.103233981, 0.103018566, 0.102969036, 0.102898733, 
            0.10255665100000001`, 0.158239197, 0.10223218, 0.118383993, 
            0.102019433, 0.10173106400000001`, 0.129009339, 
            0.10153393000000001`, 0.10141908100000001`, 0.10141093000000001`, 
            0.101276957, 0.101199859, 0.104293363, 0.100722505, 
            0.10051497000000001`, 0.100398315, 0.100184254, 0.100000183, 
            0.099816232, 0.125422961, 0.09949782500000001, 0.099401153, 
            0.099278322, 0.098793687, 0.09878342300000001, 
            0.09872380900000001, 0.09871368100000001, 0.098214327, 
            0.09818046700000001, 0.098128356, 0.098117969, 
            0.09806584900000001, 0.097892432, 0.097439853, 
            0.09719209300000001, 0.096927542, 0.09691518, 0.096824147, 
            0.09670453000000001, 0.09668041200000001, 0.09660119, 
            0.09638405100000001, 0.09637422100000001, 0.09636665000000001, 
            0.214001456, 0.096095264, 0.158573439, 0.15945306, 0.095767482, 
            0.186969133, 0.095438937, 0.095378922, 0.095174878, 0.094980301, 
            0.14100864100000002`, 0.09471631000000001, 0.094662836, 
            0.094597702, 0.093779315, 0.09370297500000001, 0.093597675, 
            0.094646115, 0.13378546400000002`, 0.09347053300000001, 
            0.093331391, 0.11162063800000001`, 0.093233562, 0.093211579, 
            0.093046604, 0.11145542700000001`, 0.092951589, 0.117361925, 
            0.09279041, 0.092757528, 0.11931609300000001`, 
            0.09269777700000001, 0.092444231, 0.092174509, 0.092167565, 
            0.09209908600000001, 0.09208232000000001, 0.09205447500000001, 
            0.09196429, 0.09174697700000001, 0.09158941400000001, 
            0.09156077300000001, 0.091538637, 0.091108295, 0.090945576, 
            0.09078192700000001, 0.090763726, 0.090724993, 
            0.09028783900000001, 0.089862415, 0.089639252, 0.089612906, 
            0.09293445600000001, 0.089463947, 0.089259797, 0.089225629, 
            0.08913696800000001, 0.089119529, 0.089105745, 0.095687039, 
            0.08900287200000001, 0.088748695, 0.088651909, 0.088627272, 
            0.08809076, 0.119666617, 0.08793381700000001, 0.087921491, 
            0.08753951, 0.08741278400000001, 0.087409229, 
            0.14812862200000002`, 0.087193461, 0.16707089700000002`, 
            0.08671928200000001, 0.08664714300000001, 0.08717073700000001, 
            0.086318747, 0.08626180800000001, 0.086233183, 0.086225416, 
            0.086211198, 0.08609881700000001, 0.08602889200000001, 
            0.086028801, 0.086009656, 0.08596935400000001, 0.085958697, 
            0.08590536600000001, 0.085860882, 0.12082956600000001`, 
            0.08569873800000001, 0.172469007, 0.08552680400000001, 
            0.08683363300000001, 0.085129911, 0.089070651, 
            0.08510753500000001, 0.137619923, 0.08502183, 0.08492827600000001,
             0.104335628, 0.08484860200000001, 0.08483576100000001, 
            0.084637316, 0.084388658, 0.167699338, 0.11646687300000001`, 
            0.08394069600000001, 0.083536502, 0.083360734, 
            0.08345833000000001, 0.08317186, 0.08313208100000001, 0.083057875,
             0.08300183900000001, 0.082976783, 0.082808874, 0.082671563, 
            0.082572932, 0.10236824900000001`, 0.082361426, 0.08202561, 
            0.08201433600000001, 0.081861499, 0.11973809, 0.081800459, 
            0.081783505, 0.08174870000000001, 0.081644347, 
            0.08146905800000001, 0.081239604, 0.08118491500000001, 
            0.08085619000000001, 0.090696174, 0.08082077, 0.080706207, 
            0.08066255800000001, 0.079994651, 0.07992101900000001, 
            0.079767762, 0.079703303, 0.079580754, 0.07955345700000001, 
            0.079492293, 0.079275858, 0.079271098, 0.07924972300000001, 
            0.080881359, 0.07898384500000001, 0.078978932, 0.078810698, 
            0.078548475, 0.07847612600000001, 0.078364471, 
            0.07836259200000001, 0.07811293400000001, 0.07809403300000001, 
            0.078188014, 0.078064983, 0.09311532500000001, 0.077922643, 
            0.07789878600000001, 0.07770342100000001, 0.07743193400000001, 
            0.07738824200000001, 0.077367691, 0.07720995500000001, 
            0.07718269500000001, 0.127017065, 0.077163021, 0.077114737, 
            0.076889202, 0.076863558, 0.076843504, 0.076695911, 0.076621388, 
            0.076495877, 0.076480027, 0.076432439, 0.081971207, 0.076326049, 
            0.09675836800000001, 0.09116439100000001, 0.07596781400000001, 
            0.137548278, 0.075676559, 0.07528979300000001, 
            0.14446635200000002`, 0.07481977100000001, 0.074738895, 
            0.074651891, 0.125927815, 0.074421844, 0.07526916, 
            0.07417557500000001, 0.07366709, 0.14237106600000002`, 
            0.07362660600000001, 0.096531503, 0.07693878600000001, 
            0.10715060100000001`, 0.072724174, 0.072722862, 0.072508083, 
            0.07241689, 0.072313027, 0.072078294, 0.071932125, 
            0.07168814500000001, 0.071600959, 0.071441716, 0.088807991, 
            0.071054042, 0.10799844700000001`, 0.126037488, 0.070169306, 
            0.070115325, 0.07005114400000001, 0.069902615, 0.069868236, 
            0.069734499, 0.069694121, 0.069585108, 0.069275453, 0.068866885, 
            0.068853332, 0.06880649400000001, 0.068742103, 
            0.12559035300000002`, 0.068557645, 0.06831662100000001, 
            0.06828651200000001, 0.068277207, 0.06826070000000001, 
            0.107241847, 0.068170757, 0.10182163000000001`, 0.067806883, 
            0.067711773, 0.067500116, 0.067433293, 0.06736272, 0.067043804, 
            0.066839174, 0.06683507100000001, 0.066792954, 0.066530977, 
            0.06643924600000001, 0.076934731, 0.06630605, 0.06630388200000001,
             0.06627234700000001, 0.066250505, 0.066182221, 0.066148201, 
            0.066091308, 0.06607613400000001, 0.065814574, 
            0.07957456900000001, 0.065653426, 0.065609868, 0.065606591, 
            0.06555406300000001, 0.065353619, 0.067711545, 0.065146534, 
            0.09965660000000001, 0.065128319, 0.108704611, 0.064921486, 
            0.064727819, 0.107869619, 0.064556342, 0.064317072, 
            0.06428821800000001, 0.06425676200000001, 0.063865138, 
            0.063819924, 0.085015226, 0.064117643, 0.06334861700000001, 
            0.06318992100000001, 0.06312089, 0.063074106, 0.062918587, 
            0.062815801, 0.062658974, 0.062592465, 0.062586347, 
            0.06239880800000001, 0.062371390000000006`, 0.062310721000000006`,
             0.06227475700000001, 0.06222288, 0.062195077, 
            0.062061248000000006`, 0.062036988, 0.061927358, 0.06146254, 
            0.061338787000000006`, 0.061328725, 0.061162863000000005`, 
            0.061080315, 0.060912842, 0.060903360000000004`, 0.060836816, 
            0.06256157400000001, 0.06390422300000001, 0.060551459, 
            0.076029161, 0.07644265900000001, 0.060442046000000006`, 
            0.06044097700000001, 0.060395053000000004`, 0.060391407, 
            0.05992477, 0.059821678, 0.059753636000000006`, 0.05968806, 
            0.05950238, 0.059264299000000006`, 0.05921701, 0.059101615, 
            0.058874437, 0.058796987, 0.058738369000000006`, 
            0.058714744000000006`, 0.058713535000000004`, 
            0.058694866000000005`, 0.05847001, 0.058264508000000007`, 
            0.058161699000000004`, 0.058114081000000005`, 0.058111779, 
            0.058073493000000004`, 0.057899159000000006`, 
            0.060197056000000006`, 0.057551869000000005`, 0.057545339, 
            0.05744699700000001, 0.057338704000000004`, 0.08538654300000001, 
            0.056981216, 0.056864335, 0.056823789000000006`, 0.056750095, 
            0.08718708600000001, 0.056655598, 0.056630994000000004`, 
            0.08865726, 0.09737860400000001, 0.056172049, 
            0.055873319000000005`, 0.055437714000000006`, 0.055330819, 
            0.055218823, 0.055074464000000004`, 0.05499097, 0.054968453, 
            0.054896292000000006`, 0.054252049000000004`, 0.054232027, 
            0.054119955000000004`, 0.05411702, 0.054069785, 
            0.053796290000000004`, 0.053762120000000004`, 0.080398858, 
            0.05353613, 0.101855082, 0.053475607, 0.053430375, 
            0.053374498000000006`, 0.09460536100000001, 0.053352319, 
            0.053332597, 0.05326231100000001, 0.053052407, 0.053349341, 
            0.0845129, 0.052571668, 0.053688118, 0.052421757000000006`, 
            0.05240235, 0.052248299000000005`, 0.052244848, 0.052169988, 
            0.052151890000000006`, 0.05194125300000001, 0.051937315000000005`,
             0.051883175000000004`, 0.051857125000000004`, 0.062007852, 
            0.051738829, 0.051682382000000006`, 0.051451046, 0.051211456, 
            0.051203853, 0.051100444, 0.050795907, 0.050768757000000005`, 
            0.05072643, 0.050720304, 0.050709596, 0.05067176, 
            0.050671586000000005`, 0.050621441, 0.06360032, 
            0.050506219000000005`, 0.050363887, 0.050327032, 
            0.09124768200000001, 0.04980492, 0.078604669, 
            0.049649925000000004`, 0.049543565000000005`, 
            0.049242346000000006`, 0.049179927000000005`, 
            0.049098444000000005`, 0.049059289000000006`, 0.048854266, 
            0.09099522600000001, 0.048791422, 0.04872395, 
            0.048320125000000005`, 0.048207845000000006`, 
            0.048164502000000005`, 0.048115655, 0.048047143, 
            0.047979797000000005`, 0.047684982, 0.047660899, 0.072009632, 
            0.047652517000000005`, 0.047644164, 0.047571253, 0.047496043, 
            0.047453867000000004`, 0.049495990000000004`, 
            0.047240341000000005`, 0.047105709, 0.047097815, 0.047093228, 
            0.046731979, 0.046717319, 0.046641119, 0.046555752000000006`, 
            0.046465064, 0.046312521, 0.047536795, 0.045858397, 
            0.045634166000000004`, 0.045630799, 0.045413736, 0.045371578, 
            0.045235591000000006`, 0.044918538, 0.044845502, 0.044814299, 
            0.047384593, 0.051971078000000004`, 0.044730906, 
            0.044623627000000006`, 0.044605668, 0.044462894, 0.044091267, 
            0.043992621, 0.045544115, 0.043797019, 0.04379446, 
            0.043658049000000004`, 0.043642318, 0.043614955000000004`, 
            0.043600585000000004`, 0.043542773, 0.043353952, 0.043165382, 
            0.043101814, 0.043096198, 0.043043399, 0.042963908, 
            0.042906160000000006`, 0.042877207, 0.042714757000000006`, 
            0.042691645, 0.042668708, 0.04263766, 0.042633858000000004`, 
            0.042537462000000005`, 0.055723065, 0.042504739, 0.042447756, 
            0.042337296, 0.042322042000000004`, 0.042247722, 
            0.042142369000000006`, 0.045170172, 0.041798222, 0.080912934, 
            0.041758539000000004`, 0.04147905, 0.041449475, 0.041358639, 
            0.045527281, 0.041189781, 0.041021115000000004`, 0.041013214, 
            0.040886942, 0.040731577000000005`, 0.040512372000000005`, 
            0.040386996, 0.040276657, 0.040273402, 0.040258207000000004`, 
            0.040203796, 0.04399852, 0.040067702000000004`, 0.0399587, 
            0.039717354, 0.039701696, 0.039659074, 0.039461891000000006`, 
            0.039309130000000005`, 0.039224116, 0.039071748, 0.039066925, 
            0.03881113, 0.0386994, 0.038665893, 0.03862564, 
            0.038607956000000006`, 0.038606665000000005`, 0.038561624, 
            0.03842429, 0.038368059, 0.038286692000000004`, 
            0.038222938000000005`, 0.038221062, 0.038148107, 0.037883711, 
            0.067572176, 0.037742540000000005`, 0.037599717000000005`, 
            0.037566041, 0.037498224000000004`, 0.043448262, 
            0.037366022000000006`, 0.037669453000000006`, 0.0372737, 
            0.057724829000000005`, 0.036910751000000006`, 
            0.036831089000000004`, 0.036744285, 0.036596710000000005`, 
            0.036570695, 0.036547369, 0.036434868, 0.036355503000000004`, 
            0.03624974, 0.036201581000000004`, 0.061890947, 
            0.041021865000000005`, 0.03568786, 0.035674939, 0.035586027, 
            0.035567789, 0.035403249000000005`, 0.035386755, 0.035359938, 
            0.035328354, 0.035258415, 0.035243878, 0.035190247, 0.035188245, 
            0.035171533000000005`, 0.035136912, 0.034991178000000005`, 
            0.034762211, 0.034758966, 0.034646359, 0.034627256, 0.03456225, 
            0.034434578, 0.034346375000000005`, 0.034168762000000005`, 
            0.034126349, 0.034069678, 0.034068192000000004`, 0.034062349, 
            0.033965403000000005`, 0.033943914000000006`, 0.033803865, 
            0.033722746000000005`, 0.033694413, 0.033623926000000005`, 
            0.050975559000000004`, 0.033100145000000004`, 0.040931184, 
            0.032981526000000004`, 0.032845585000000004`, 0.045234887, 
            0.032663429, 0.032609699, 0.032413635, 0.032329952, 0.045755555, 
            0.032247452, 0.03223791, 0.032230336000000005`, 
            0.032213464000000004`, 0.032145110000000005`, 
            0.032144992000000004`, 0.032143089, 0.032114991, 0.032102526, 
            0.033123483, 0.032077067, 0.032055732, 0.033669358, 0.031939555, 
            0.031818324, 0.03176207, 0.031761021, 0.03172659, 0.031624923, 
            0.031548613, 0.031516957000000005`, 0.031282643, 
            0.030889391000000002`, 0.030824471000000003`, 0.030779184, 
            0.030731099, 0.030670104000000004`, 0.04688801, 
            0.030371184000000002`, 0.030360078000000002`, 0.030325404, 
            0.030258591, 0.03006315, 0.030034649000000004`, 
            0.029986941000000003`, 0.029951254000000004`, 
            0.029864685000000002`, 0.029812979000000003`, 
            0.029722828000000003`, 0.029710265000000003`, 0.029698036, 
            0.029437839, 0.036356257, 0.029323328000000003`, 
            0.050612064000000005`, 0.029036463000000002`, 
            0.029016410000000003`, 0.028891749, 0.028812734000000003`, 
            0.037003256000000005`, 0.02874418, 0.028708110000000002`, 
            0.040194766, 0.028662333, 0.028319147000000003`, 
            0.028307322000000003`, 0.028302615000000003`, 
            0.028299565000000002`, 0.028247668, 0.033421884, 
            0.028153387000000002`, 0.054510285000000006`, 
            0.028120522000000002`, 0.028074270000000002`, 
            0.028062107000000003`, 0.027957759000000002`, 0.027933431, 
            0.027831909000000002`, 0.030478113, 0.027948151, 
            0.027505151000000002`, 0.027430338000000002`, 0.027370742, 
            0.027337119, 0.032698867, 0.027269194, 0.027152401000000003`, 
            0.027096743000000003`, 0.027056503000000003`, 0.026932151, 
            0.03607193, 0.026756944, 0.026754468, 0.026664029000000002`, 
            0.026620294000000003`, 0.026430832, 0.026336347000000003`, 
            0.026313495000000003`, 0.026196615000000003`, 
            0.026164159000000003`, 0.026139025000000003`, 
            0.041766937000000004`, 0.026049187, 0.025818326000000003`, 
            0.025793624, 0.025786994, 0.025769665, 0.025730684, 
            0.025718663000000003`, 0.034826445000000004`, 0.025585077, 
            0.041104485, 0.025502176, 0.025341563, 0.025306873, 0.025275189, 
            0.025160699, 0.025147691000000003`, 0.02492476, 0.025256638, 
            0.024801055000000002`, 0.024784359000000002`, 
            0.024695757000000002`, 0.024662942, 0.024662814, 0.030242654, 
            0.024635732, 0.024618869, 0.024506999, 0.024410213, 0.024306165, 
            0.024266235, 0.024207743, 0.024171380000000003`, 0.024159381, 
            0.024011365, 0.023919927, 0.023846438, 0.023744194000000003`, 
            0.023693336000000002`, 0.023626911, 0.023569423000000003`, 
            0.023556617000000002`, 0.023509038000000003`, 0.06346544600000001,
             0.023102027, 0.023034998, 0.035821192, 0.022953903, 0.022885589, 
            0.022869612, 0.022855539, 0.022842531000000003`, 
            0.026359135000000002`, 0.022792331000000002`, 0.022784629, 
            0.022733435, 0.02271507, 0.024637210000000003`, 
            0.022652783000000003`, 0.022608042000000002`, 
            0.024859507000000003`, 0.02255599, 0.022545100000000002`, 
            0.022506363, 0.022502298, 0.022479573000000003`, 0.028689616, 
            0.022361645000000003`, 0.022319593000000002`, 
            0.022296206000000002`, 0.022267710000000003`, 
            0.022230892000000002`, 0.039505242, 0.022157663, 
            0.022011429000000002`, 0.021905466000000002`, 0.021772085, 
            0.021764936000000002`, 0.021754468000000002`, 0.021691707, 
            0.035488822, 0.021629022, 0.021576582, 0.021440738, 
            0.021414164000000003`, 0.021409202000000002`, 0.021353592, 
            0.021260497, 0.023456567, 0.021170508, 0.021044638, 0.020947394, 
            0.020863386, 0.020723096, 0.020637289, 0.020487341000000003`, 
            0.020466658000000002`, 0.026241499, 0.020364430000000003`, 
            0.020273987, 0.020246415, 0.020232748000000002`, 0.020133772, 
            0.020078832, 0.020053885, 0.01997057, 0.019954801, 
            0.019862109000000003`, 0.019827266, 0.0198266, 0.026024496, 
            0.019937454, 0.019542956, 0.019530060000000002`, 
            0.021959120000000002`, 0.019402371, 0.019278523000000002`, 
            0.019138381000000003`, 0.019106475, 0.019067081, 0.019034058, 
            0.032952746000000005`, 0.018971603, 0.018911176000000002`, 
            0.018898376, 0.018753376000000002`, 0.018713510000000003`, 
            0.01870749, 0.018679463, 0.018652171000000002`, 
            0.018633160000000003`, 0.018611861, 0.018596748, 
            0.018520289000000002`, 0.018412577, 0.018391309, 0.01837869, 
            0.018377125, 0.018351534000000003`, 0.018334839000000002`, 
            0.018307846000000003`, 0.019408058000000002`, 0.036159547, 
            0.018127885, 0.018120266, 0.018115910000000002`, 0.017966336, 
            0.017923424, 0.017863406000000002`, 0.020393630000000003`, 
            0.017771914, 0.017728951, 0.030158343, 0.017694445, 0.017668711, 
            0.017665879000000002`, 0.017553275, 0.017521428000000002`, 
            0.01751582, 0.017501642, 0.017485615, 0.017478936, 0.017409796, 
            0.017402541, 0.017366087000000002`, 0.021523679, 0.01734638, 
            0.017326169000000002`, 0.017273327, 0.021448269000000002`, 
            0.017204145, 0.017161182, 0.016946179000000002`, 0.016925114, 
            0.033320862, 0.016861959000000003`, 0.016854862, 0.016845819, 
            0.016809546, 0.016749609000000002`, 0.016626403, 0.016836534, 
            0.016583831, 0.016514501, 0.016466295000000002`, 0.016392177, 
            0.016378449, 0.016373723, 0.016307258, 0.01631241, 0.016250961, 
            0.016244599000000002`, 0.016216414000000002`, 0.016213452, 
            0.016210843000000003`, 0.016204845000000002`, 0.01613452, 
            0.016537211, 0.016056163000000002`, 0.015848977, 0.01580705, 
            0.015804069, 0.015770471, 0.015743774000000002`, 0.01573607, 
            0.015693020000000002`, 0.015421642000000001`, 
            0.015359988000000002`, 0.015327024000000002`, 0.015279979, 
            0.015276683000000001`, 0.015231129000000001`, 0.015122032, 
            0.015082615, 0.019669473, 0.014977059000000001`, 0.014968175, 
            0.014932968000000001`, 0.014927211000000001`, 0.014867464, 
            0.014851284000000001`, 0.014841636, 0.014831100000000002`, 
            0.014759702000000001`, 0.014759515, 0.014617989000000001`, 
            0.014609189000000002`, 0.014496448, 0.014448204000000001`, 
            0.014333548000000002`, 0.014295141, 0.025195499000000003`, 
            0.014185022, 0.014171237000000001`, 0.013931601, 0.013814638, 
            0.013813808, 0.013807523, 0.013755330000000001`, 0.013745653, 
            0.013573016, 0.013400159, 0.013373104, 0.013326202, 0.013316203, 
            0.013239531, 0.013135435, 0.01313501, 0.013054718000000002`, 
            0.013038635000000002`, 0.012915171000000001`, 0.012914793, 
            0.012879972, 0.01270912, 0.012692918000000001`, 
            0.012685038000000001`, 0.021711704000000002`, 0.012543695, 
            0.012520548000000001`, 0.012447280000000002`, 0.012445565, 
            0.012391013000000001`, 0.012362772000000001`, 0.012356334, 
            0.012318692000000001`, 0.012257979, 0.015446742000000001`, 
            0.012046992000000001`, 0.012142743000000001`, 0.0118764, 
            0.011876174000000001`, 0.011713178000000001`, 
            0.011686891000000001`, 0.011676420000000002`, 0.01164125, 
            0.021116646000000003`, 0.01157152, 0.011515894, 0.011508838, 
            0.011462908, 0.011455969, 0.011286288, 0.011216666, 0.011305379, 
            0.011192967, 0.011189793, 0.011100434000000001`, 0.011003571, 
            0.011000457, 0.010991528, 0.010933557, 0.010886318, 0.010867513, 
            0.010853082, 0.010795733, 0.010542886000000001`, 
            0.010476303000000001`, 0.010450286000000001`, 0.010353252, 
            0.010342543000000001`, 0.010331517, 0.010250415, 
            0.010168011000000001`, 0.010152941, 0.010107027000000001`, 
            0.010103348, 0.010092132, 0.018197484, 0.019691826000000003`, 
            0.009930735000000001, 0.009882031000000001, 0.009869637, 
            0.009869306000000001, 0.009816565000000001, 0.009742033, 
            0.009678477000000001, 0.009664848, 0.009653562000000001, 
            0.009632318, 0.009586538, 0.009564318, 0.009539102, 
            0.009529959000000001, 0.00950255, 0.009490659, 0.009419363, 
            0.009302562, 0.009117988, 0.009000779, 0.008976695, 
            0.008972662000000001, 0.008951727000000001, 0.008945336, 
            0.00892837, 0.008884933000000001, 0.008805635000000001, 
            0.008801652, 0.008754669000000001, 0.008713179, 0.008687682, 
            0.008682502, 0.008667240000000001, 0.008684567, 0.010550917, 
            0.008523434, 0.00843605, 0.008260335, 0.008185299, 0.008180323, 
            0.008166804, 0.00816492, 0.008143571, 0.0081245, 0.01021586, 
            0.008071699, 0.007997774000000001, 0.007949804000000001, 
            0.007940353, 0.007935187, 0.0079337, 0.007838531000000001, 
            0.0078068270000000006`, 0.009330907000000001, 
            0.0077078630000000006`, 0.007701165, 0.007612835, 
            0.007444648000000001, 0.007344721, 0.007319613000000001, 
            0.007279771000000001, 0.007271434, 0.007162479, 0.007140907, 
            0.007138872, 0.007087155, 0.007059262, 0.00704933, 
            0.007037977000000001, 0.0070277460000000005`, 0.007014715, 
            0.0070101040000000005`, 0.007005308, 0.0070048490000000005`, 
            0.00698116, 0.0069615530000000005`, 0.006941628, 0.00690168, 
            0.006806886000000001, 0.006734197000000001, 0.006721176000000001, 
            0.00668193, 0.006631943, 0.006601755000000001, 0.006558798, 
            0.006507309, 0.006439782000000001, 0.006429375, 0.006397573, 
            0.009378092000000001, 0.006229005, 0.0062052010000000005`, 
            0.006178363, 0.006102907, 0.0060403110000000005`, 
            0.006025892000000001, 0.006016317, 0.005941329, 0.005879388, 
            0.005875040000000001, 0.005864185, 0.005798621, 0.005746465, 
            0.0057173350000000005`, 0.005693699, 0.005668659, 
            0.005611359000000001, 0.005609413000000001, 0.005602076, 
            0.005536167000000001, 0.005529112, 0.005513489000000001, 
            0.005444581, 0.005440813, 0.005409934, 0.00903316, 0.005364647, 
            0.005359629, 0.005351758000000001, 0.005320924, 0.005301956, 
            0.0052613830000000006`, 0.005242977, 0.005195502, 0.005189456, 
            0.0051873810000000005`, 0.005119598, 0.005097939, 
            0.005082911000000001, 0.0050170020000000004`, 0.005007662, 
            0.004967478, 0.004938214000000001, 0.004881531000000001, 
            0.004821108, 0.004747903, 0.004714971, 0.0046681560000000006`, 
            0.004610531, 0.004565588000000001, 0.004528016, 
            0.004512746000000001, 0.004449606, 0.005935246000000001, 
            0.004435804000000001, 0.004388423000000001, 0.00438601, 
            0.004372993, 0.00435289, 0.004337403, 0.004335507000000001, 
            0.004331871, 0.004328823, 0.004285737, 0.004213196000000001, 
            0.00421136, 0.005589454000000001, 0.0041613530000000004`, 
            0.004123204, 0.004091759, 0.004011019, 0.003998864, 0.003963157, 
            0.0039029330000000004`, 0.0038488880000000004`, 0.00384371, 
            0.0038168050000000004`, 0.0038110310000000003`, 
            0.0037893700000000002`, 0.0037599290000000004`, 
            0.0037557920000000004`, 0.003737507, 0.0037188160000000002`, 
            0.003705906, 0.003686626, 0.00367218, 0.0036673210000000003`, 
            0.003660149, 0.0036597400000000003`, 0.003655769, 0.00364452, 
            0.0036360900000000002`, 0.0036248260000000003`, 
            0.0036106610000000003`, 0.005182319, 0.003524412, 0.003524108, 
            0.0034395230000000003`, 0.0034182780000000003`, 
            0.0034061290000000004`, 0.0033774990000000004`, 0.00331925, 
            0.003301201, 0.0032980440000000004`, 0.0032377630000000003`, 
            0.0032325400000000003`, 0.0032252110000000004`, 0.003188396, 
            0.0031669600000000003`, 0.003146114, 0.003140378, 
            0.0031311050000000003`, 0.003131013, 0.003127205, 
            0.0031215260000000003`, 0.003112038, 0.0031032620000000003`, 
            0.003101435, 0.0030867890000000004`, 0.0030864350000000002`, 
            0.0030776590000000004`, 0.003072118, 0.002956387, 0.002940793, 
            0.002917579, 0.002902429, 0.0028919220000000003`, 0.002886736, 
            0.0028379100000000003`, 0.002809015, 0.0027983070000000003`, 
            0.0027868370000000003`, 0.002752383, 0.0027431810000000004`, 
            0.002709697, 0.00270335, 0.002686599, 0.002656719, 
            0.0026295660000000003`, 0.00394549, 0.0025961450000000002`, 
            0.002581332, 0.00254857, 0.0025017100000000003`, 
            0.0024351810000000002`, 0.0024246700000000003`, 0.004594112, 
            0.0024079740000000002`, 0.002404775, 0.0023929420000000003`, 
            0.0023708120000000004`, 0.0023569420000000003`, 
            0.0023559460000000003`, 0.0023478880000000002`, 0.002324093, 
            0.002315918, 0.0022897300000000002`, 0.002285866, 
            0.0022766830000000003`, 0.0022750030000000003`, 
            0.0022660220000000003`, 0.002265736, 0.002247088, 0.002226327, 
            0.002195551, 0.002173551, 0.0021427150000000003`, 0.002130242, 
            0.002104164, 0.003981941, 0.002102891, 0.0020590450000000002`, 
            0.002037531, 0.002028338, 0.0020151360000000003`, 0.001988017, 
            0.001979008, 0.001963701, 0.0019428280000000002`, 
            0.0019239160000000001`, 0.0018889890000000002`, 
            0.0018866960000000002`, 0.0018659520000000001`, 0.001860632, 
            0.0018600620000000002`, 0.001794662, 0.001759436, 
            0.0017419690000000001`, 0.001722194, 0.001660643, 0.00162816, 
            0.001622809, 0.001610995, 0.001576806, 0.001554285, 0.001502021, 
            0.001490694, 0.001481237, 0.0014794040000000001`, 0.001476265, 
            0.001458412, 0.0014350860000000001`, 0.0014337780000000001`, 
            0.001421664, 0.0014013320000000001`, 0.001391796, 
            0.0013791740000000002`, 0.001371091, 0.001363075, 0.001358465, 
            0.0013473320000000001`, 0.001333716, 0.0012917500000000001`, 
            0.001271343, 0.001250489, 0.001240081, 0.001211073, 0.001210612, 
            0.0012023840000000001`, 0.001194044, 0.00119202, 0.001191907, 
            0.0011508450000000002`, 0.0010559360000000002`, 0.001021123, 
            0.0009983560000000002, 0.0009876470000000001, 0.000983404, 
            0.000963719, 0.000959539, 0.00092371, 0.0009121810000000001, 
            0.000905305, 0.0008943330000000001, 0.0008911730000000001, 
            0.000872252, 0.0008259430000000001, 0.000818004, 0.000809873, 
            0.000807717, 0.000803779, 0.0007527860000000001, 
            0.0006923760000000001, 0.0006703340000000001, 
            0.0006667040000000001, 0.000611014, 0.0005954070000000001, 
            0.0005762780000000001, 0.000554481, 0.000542023, 
            0.0005346320000000001, 0.00053374, 0.000530999, 0.000529784, 
            0.000503545, 0.000502123, 0.00047443, 0.000473169, 0.000469961, 
            0.00045079900000000005`, 0.000446645, 0.00041455100000000004`, 
            0.00039972600000000004`, 0.000397097, 0.00039277, 0.000606644, 
            0.000385535, 0.000382733, 0.00038222200000000004`, 
            0.00035640600000000003`, 0.00034590200000000004`, 0.000356829, 
            0.00033660200000000003`, 0.00033206200000000005`, 0.000317276, 
            0.000316756, 0.000295086, 0.000287566, 0.000281817, 
            0.00027676400000000004`, 0.000273377, 0.000267046, 
            0.00026689600000000003`, 0.000262912, 0.00023348700000000002`, 
            0.000230608, 0.000200638, 0.000200411, 0.00019832700000000001`, 
            0.00018173, 0.000181048, 0.000174942, 0.00016728, 
            0.00016007600000000002`, 0.000146142, 0.000144029, 0.000142609, 
            0.000142432, 0.00014223100000000001`, 0.000133771, 
            0.00011576200000000001`, 0.00011428600000000001`, 
            0.00010911900000000001`, 0.000103097, 0.000102232, 
            0.00010222000000000001`, 0.00010180700000000001`, 
            0.00009995200000000001, 0.000094139, 0.00009285700000000001, 
            0.000092514, 0.00008118200000000001, 0.000078656, 0.000066219, 
            0.000061043, 0.000059622000000000006`, 0.000056126000000000004`, 
            0.00005499, 0.000054343000000000005`, 0.000053880000000000006`, 
            0.000050882000000000005`, 0.000047426, 0.000041549000000000005`, 
            0.000040178, 0.000039072, 0.000035199, 0.000032031, 
            0.000031471000000000004`, 0.000030726000000000004`, 0.000019811, 
            0.000019738, 0.000018848, 0.000018335, 0.000017247000000000003`, 
            0.000016674, 0.000016548, 0.000015755, 0.000015654, 0.000015173, 
            0.000013809000000000001`, 0.000013706, 0.000013581000000000001`, 
            0.000013342, 9.91*^-6, 8.439*^-6, 8.036*^-6, 8.028*^-6, 6.301*^-6,
             5.796*^-6, 5.296000000000001*^-6, 5.0920000000000005`*^-6, 
            3.8*^-6, 3.4550000000000004`*^-6, 3.221*^-6, 2.999*^-6, 2.674*^-6,
             2.3550000000000003`*^-6, 1.9930000000000002`*^-6, 
            1.9820000000000003`*^-6, 1.57*^-6, 1.433*^-6, 
            1.2140000000000002`*^-6, 8.36*^-7, 7.16*^-7, 5.33*^-7, 4.64*^-7, 
            4.5800000000000005`*^-7, 4.42*^-7, 3.9800000000000004`*^-7, 
            3.6200000000000004`*^-7, 3.6000000000000005`*^-7, 3.56*^-7, 
            3.4500000000000003`*^-7, 3.42*^-7, 2.5900000000000003`*^-7, 
            2.42*^-7, 2.39*^-7, 2.3500000000000003`*^-7, 
            2.0000000000000002`*^-7, 1.9200000000000003`*^-7, 1.52*^-7, 
            1.05*^-7, 8.400000000000001*^-8, 7.800000000000001*^-8, 
            4.4000000000000004`*^-8, 3.0000000000000004`*^-8, 2.7*^-8, 
            2.7*^-8, 2.6*^-8, 2.6*^-8, 2.6*^-8, 2.5000000000000002`*^-8, 
            2.5000000000000002`*^-8, 2.1000000000000003`*^-8, 2.*^-8, 1.9*^-8,
             1.3*^-8, 0., 0., 0., 0., 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
            0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}; 
         Null, $CellContext`amortizePercent[
           Pattern[$CellContext`r, 
            Blank[]], 
           Pattern[$CellContext`\[Tau], 
            Blank[]]] := $CellContext`r (1 + 
           1/(-1 + (
              1 + $CellContext`r)^$CellContext`\[Tau])), $CellContext`rsolve = 
          First[
            
            RSolve[{$CellContext`p[
               0] == $CellContext`debt, $CellContext`p[$CellContext`t + 
                1] == (1 + $CellContext`r) $CellContext`p[$CellContext`t] - \
$CellContext`k $CellContext`debt}, 
             $CellContext`p[$CellContext`t], $CellContext`t]]; 
         Null, $CellContext`krule = FullSimplify[
            First[
             Solve[
              ReplaceAll[
               ReplaceAll[
               0 == $CellContext`p[$CellContext`t], $CellContext`rsolve], \
$CellContext`t -> $CellContext`\[Tau]], $CellContext`k]]]; 
         Null, $CellContext`newDebtPercent[
           Pattern[$CellContext`r, 
            Blank[]], 
           Pattern[$CellContext`\[Tau], 
            
            Blank[]]] := (-1 - $CellContext`r + (
             1 + $CellContext`r)^$CellContext`\[Tau])/(-1 + (
            1 + $CellContext`r)^$CellContext`\[Tau]), \
$CellContext`newBalanceSheet[{
            Pattern[$CellContext`assets, 
             Blank[]], 
            Pattern[$CellContext`liabilities, 
             Blank[]]}, 
           Pattern[$CellContext`operatingcashflow, 
            Blank[]], 
           Pattern[$CellContext`rassets, 
            Blank[]], 
           Pattern[$CellContext`rdebt, 
            Blank[]], 
           Pattern[$CellContext`\[Tau], 
            Blank[]], 
           Pattern[$CellContext`sim, 
            Blank[]], 
           Pattern[$CellContext`opts, 
            BlankNullSequence[Rule]]] := 
         Module[{$CellContext`debtService, $CellContext`cashflow, \
$CellContext`newBorrowings, $CellContext`f, \
$CellContext`twiaMemberAssessment, $CellContext`coastalSurcharge, \
$CellContext`unfunded}, $CellContext`f = ReplaceAll[
              ReplaceAll["cap", {$CellContext`opts}], {
              "cap" -> (
                Max[#, -1]& )}]; $CellContext`debtService = \
$CellContext`amortizePercent[$CellContext`rdebt, $CellContext`\[Tau]] \
$CellContext`liabilities; 
           Sow[{$CellContext`sim, $CellContext`operatingcashflow, 
              $CellContext`f[$CellContext`operatingcashflow], \
$CellContext`debtService}]; $CellContext`cashflow = \
$CellContext`f[$CellContext`operatingcashflow] - $CellContext`debtService; \
$CellContext`newBorrowings = 
            If[$CellContext`assets + $CellContext`cashflow > 0, 
              0, -($CellContext`assets + $CellContext`cashflow)]; {(
               1 + $CellContext`rassets) $CellContext`assets + \
$CellContext`cashflow + $CellContext`newBorrowings, \
$CellContext`newDebtPercent[$CellContext`rdebt, $CellContext`\[Tau]] \
$CellContext`liabilities + $CellContext`newBorrowings}], \
$CellContext`simulation[
           PatternTest[
            Pattern[$CellContext`eventsTable, 
             Blank[]], MatrixQ], 
           Pattern[$CellContext`initialCondition, 
            Blank[]], 
           Pattern[$CellContext`rassets, 
            Blank[]], 
           Pattern[$CellContext`rdebt, 
            Blank[]], 
           Pattern[$CellContext`\[Tau], 
            Blank[]], 
           Pattern[$CellContext`reinsurancePremium, 
            Blank[]], 
           Pattern[$CellContext`reinsuranceLimit, 
            Blank[]], 
           Pattern[$CellContext`netpremiums, 
            Blank[]], 
           Pattern[$CellContext`opts, 
            BlankNullSequence[]]] := MapIndexed[
           Function[{$CellContext`annualLosses, $CellContext`year}, 
            Thread[{
              Range[0, 
               Length[$CellContext`annualLosses]], 
              FoldList[
              With[{$CellContext`cashflow = $CellContext`netpremiums - \
$CellContext`reinsurancePremium - Max[0, #2 - $CellContext`reinsuranceLimit]}, 
                $CellContext`newBalanceSheet[#, $CellContext`cashflow, \
$CellContext`rassets, $CellContext`rdebt, $CellContext`\[Tau], 
                 
                 Part[$CellContext`year, 
                  1], $CellContext`opts]]& , $CellContext`initialCondition, \
$CellContext`annualLosses]}]], $CellContext`eventsTable], \
$CellContext`worstcase[
           Pattern[$CellContext`history, 
            Blank[List]]] := Min[
           Map[Part[#, 1] - Part[#, 2]& , 
            Map[Last, $CellContext`history]]]}]]; Typeset`initDone$$ = True),
    SynchronousInitialization->True,
    UnsavedVariables:>{Typeset`initDone$$},
    UntrackedVariables:>{Typeset`size$$}], "Manipulate",
   Deployed->True,
   StripOnInput->False],
  Manipulate`InterpretManipulate[1]]], "Output",
 CellID->61136942],

Cell["\<\
This Demonstration simulates the financial history of a catastrophe insurer. \
You select a variety of parameters that affect that financial history and the \
Demonstration responds with a graphic showing the annual net worth of the \
insurer for each of a user-chosen number of sample runs. You can also choose \
to display a histogram showing the distribution of the net worth of the \
insurer either at the end of the simulations or at its lowest annual value.\
\>", "ManipulateCaption"],

Cell["\<\
You choose a number of parameters likely to affect the financial histories. \
You choose the number of years for which the Demonstration computes the \
annual covered losses suffered by the insurer as a result of catastrophes \
such as earthquakes, hurricanes, or tornadoes. You choose the number of \
sample runs of the system. You can choose to amplify (or reduce) the losses \
resulting from each event. You also determine the initial balance sheet of \
the insurer (assets and liabilities), the interest rate the insurer pays on \
debt, and the amortization period of debt. Finally, you affect the annual \
operating profits and losses of the insurer by determining its annual premium \
revenue net of overhead expenses, the return it makes on its assets, and any \
legal limitation on the amount of losses it needs to pay. \
\>", "ManipulateCaption",
 CellID->289930240],

Cell["THINGS TO TRY", "ManipulateCaption",
 CellFrame->{{0, 0}, {1, 0}},
 CellFrameColor->RGBColor[0.87, 0.87, 0.87],
 FontFamily->"Helvetica",
 FontSize->12,
 FontWeight->"Bold",
 FontColor->RGBColor[0.597406, 0, 0.0527047],
 CellTags->"ControlSuggestions"],

Cell[TextData[{
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Resize Images",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox["Resize Images",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   "\"Click inside an image to reveal its orange resize frame.\\nDrag any of \
the orange resize handles to resize the image.\"",
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]],
 StyleBox["\[NonBreakingSpace]\[FilledVerySmallSquare]\[NonBreakingSpace]",
  FontColor->RGBColor[0.928786, 0.43122, 0.104662]],
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Slider Zoom",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox["Slider Zoom",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   RowBox[{"\"Hold down the \"", 
     FrameBox[
     "Alt", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], 
     "\" key while moving a slider to make fine adjustments in the slider \
value.\\nHold \"", 
     FrameBox[
     "Ctrl", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" and/or \"", 
     FrameBox[
     "Shift", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" at the same time as \"", 
     FrameBox[
     "Alt", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" to make ever finer adjustments.\""}],
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]]
}], "ManipulateCaption",
 CellMargins->{{Inherited, Inherited}, {0, 0}},
 Deployed->True,
 FontFamily->"Verdana",
 CellTags->"ControlSuggestions"],

Cell["DETAILS", "DetailsSection"],

Cell["\<\
The data from which the event sets are calculated is based on the projected \
losses of the Texas Windstorm Insurance Association from hurricanes as of \
2007. \
\>", "DetailNotes",
 CellID->878929216],

Cell["\<\
Snapshot 1: the distribution of the terminal net worth of the insurer using \
the default settings\
\>", "DetailNotes",
 CellID->428675160],

Cell["\<\
Snapshot 2: the distribution of the lowest annual net worth of the insurer \
using the default settings\
\>", "DetailNotes",
 CellID->2083262082],

Cell["\<\
Snapshot 3: the financial history of the insurer if maximum losses are capped \
at 5 instead of the default value of 1\
\>", "DetailNotes",
 CellID->15133749],

Cell["\<\
Snapshot 4: the financial history of the insurer if it has to borrow at 8% \
instead of the default value of 5%\
\>", "DetailNotes",
 CellID->207401535],

Cell["\<\
Snapshot 5: the financial history of the insurer if losses are amplified by \
50%\
\>", "DetailNotes",
 CellID->1454747214],

Cell["\<\
Snapshot 6: the financial history of the insurer if premiums are increased by \
about 50% over their default value\
\>", "DetailNotes",
 CellID->744740783],

Cell["\<\
Snapshot 7: the financial history of the insurer using 50-year runs\
\>", "DetailNotes",
 CellID->1172592204],

Cell["\<\
Snapshot 8: the distribution of the lowest annual net worth of the insurer \
using 50-year runs\
\>", "DetailNotes",
 CellID->1494971580],

Cell[BoxData[
 ButtonBox[
  PaneSelectorBox[{False->Cell[BoxData[
    GraphicsBox[RasterBox[CompressedData["
1:eJztmjlPZFcQhZH8H5z7LzmYFGkSyAwZkEEGZEDEkrBEbAEgAjCLxS6xCbEP
Bnu8SAYaRoIEhPDnPqJcvm/p17THyJp3pGnVPbdu1bl1T7dGo/nm/Xffvv+q
qqrqa/78wJ+/4ufn56enp4eHh7u7u9vb25ubm0KhcFNEoQiCT0Wwa4wA88kh
WCYhKS39eKAtCUFCSUmW4AN/96T6sY30qa1gUCk6NdiUK8Q+ij9riFZOR5YZ
xu5yFsNgG8zzXMTV1dX5+fmHHDnKBLbBPHLR2dnZW8vJ8X8F5pGLbJkjRxbI
LfZpv0U5crwauYuEpaWlmZkZPt9ayN/Y39+fKeKthZSGXPRj+WhoaHjnwHJi
YsJ2mUBra2t1dTVbzc3NvI5tQZKsWLu+Znd3t+LZ2Vl2fZBSFlIyCIaHhwnI
hEdSTU0Ny46ODl/cgyLKEYitbFI7JOkIu6ps12HLKtNOaXV1dTYcApaQlOWs
dEbBlkkik0t5wYgRjwCrAK9H4dOrKtmRg/39/cr0j5gdctG5A+R5BiCyra3t
+xcQo5PAdhkgd5+cnCRG/8HBATzL6iKISdYDaUunenp6FMe6yMpyWZVlJkxA
cyZTw9cAdZCnJNDYoy7iOGfZ3dzcZMkn70KLlHbwkLwL+lGrL4U0+wloi7Mw
UrW1tUUsQxKwRQJzi87WzhIzHJacYnRaqiNLElCi7uJVWfniM3bkOpxCIQl2
hRQEJom6KCP8iwvIQwwBYvw8dUHNpK0IlsvLywMDA3omzSeoqev7IKksdShi
VqS+BmiBQHIgGHBWlvZQl5RbeN538TySKO6Ho++al8QQ7O4GGvk6wWzlBLus
hoPUgMc2sUOI7Wh12GVEfpgZIRddFMHyIjMaGxvp6JmVlRWUbG9vS1JsMgqn
pqZYjoyMcFNI+Spa04pEg6Ds4eGhfrEp3viCqMKoYIBaZHtGXSBTbqFXFgmj
dgHvY19BRTyCHOaDH6I64YN2vlHA2zJLR4HnYIwEdO/s7IzNSYJ3UVmIfRTd
SPPncY3XD6ZsBi/z6MfTDy2Li6JlFVOcUvoq2QD9NHxyFBznp4MjtJCrU9pl
dJHePRiat7rMH+REfRLs6q0F5JmLPM/FbQglO14UXcor8NXWcwTfrJKQi34q
H0jq7e0NSBTOzc0RyM8iEQa/uroK09LSAkOO/tqpBJLJUU34o6Mj4sHBQSWQ
7DOjZXd2duDVF2iAqmDVVCQqGFDBfsrwj9VJauevCaipduItn5saTzKl0Ikk
ekkSoJ0G4uELxqqVP+2yVDZe8qgPaUMo2VFqAWkMgSNJ3ZMgF/1cPuQizzAl
LsIn8ejoKHFtba0eqL29HZIlvJIhqaC4vQjVJJ80/SaInJ+fJ1ZmbFlVUEHx
6nJ8fMxS8+STU4FguwhYW1uLbiW1I0aVYj268WRaQTX1d1E7SWKLINqXpvAp
k9dlNSi7rB8CxyUjY0cYLMS4KIUtU1onQS76WD5Q1dfX55muri502nJ3d3do
aIgcRIpZWFg4OTlRDEmCZSpHJGmcGhsbs1MMJ6WsMD093VcE+UbSjjqQnIoK
FijujxCTmd7OX8TEG28aiHUWbVGpbFkRD8hA0sfItOmoCjZDX1kD9LdI71g5
KnER5l94gb4Iwbj+FQQuejWSXATPN1HPwWd9fT3LyttVAr6P/GjoeyRbRn2V
jsBFnxty0S/lo6mp6Z0Dw8dCr6hTEnJR5XUQzGyj/Pr6OuLtIqSdnp5W3q5C
IFX/mKZ/LRwfHy/3OBf5TNqikIt+/eKxsbGxuLi4t7f31kL+gcUiMib/Z54B
QevcRTkqh1z0W44cFcBc9HuOHK+Cuejq6kqmSsnMnZYjgFxh/2P28fHx/v6+
UChcXl7+EQf46+vrpN0cXyAwA4bBNpgHC/0JwypFcA==
      "], {{0, 0}, {194, 22}}, {0, 255},
      ColorFunction->RGBColor],
     ImageSize->{194, 22},
     PlotRange->{{0, 194}, {0, 22}}]]], True->Cell[BoxData[
    GraphicsBox[RasterBox[CompressedData["
1:eJztmjtPLEcQhZH8H5z7LzlwinQjiCwIIYQQyICMRwRkPCIQCRgIeCa8At6S
vetrW2aXlTYAhD/PEeW63TOzu4wxsj1HYlVdXV11qvrMLEJ88+n7bz991dXV
9TU/m/z8ab+8vDw/Pz8+PjabzUaj8fDwUK/XHxLUE2A0XmEeofHPwnPLQhBQ
pFBqLT+crELaCgaVw9OOZGVOvRR/1hBnbtlpyxmm7nIWwSAbxPOSoFarVSqV
H0uU6BDIBvFIRR/NpcS/G6WKShRHqaISxVGqSNjd3d3Y2ODzo4n8hYuLi40E
H02kNaSinzrHwMDAdw4sV1dXbffy8nJkZKS7u5utoaGhvb0928JJsGzt+pxT
U1OyNzc32fVGTlqcooGxuLiIQSR+KPX09LAcHx/3yT1IohgB29JmlYOSjrCr
zNYOW5aZcgrr6+uz4WCwxElazopnDLaMEpE05QlDRn4IWAb8uhQ+PauWFTk4
NzenSH+J7UMqqjjgrLQBSI6Ojv7wCmx4YtguA6T3tbU1bPhfXV3hZ9mdAJtg
XZC2dGp6elp2qoosLc0qLTNhApozkRq+BqiDXCWGxh6riOOcZff4+Jgln9wL
JXLK4cfJvcAftnooxNlPQFucxTMxMcHWyckJtgSJwRYBzC2erZ3FZjgsOcXo
tFRFlgTARNXlV2bFy99mRdrhFAwJsBZyEIgkVlGb8DcuQA8yGJDx81SDmslo
Apb7+/vcvq5J8wlyqn1vZKUlD0lMiuTXAM0QCA4IAykwcKpKThfe76t4P5RI
7oejZ81TYgjWu4FCPk8wWynBmtVwoBr4kU3qEFIrWh52GZEfZpuQiqoJWFbb
xuDgIBW95+DgACanp6eilBoszbBcWloaHh7GKV3FOS1JbARpr6+v9cYm+eAr
YoYxYQBbaHuPquDM6UK3LCcelQv83vYZlMQjiNHrOuaJPyjnCwV+W7ZTUeA6
GCMG1Xl5psZkwauoI6ReijrS/Llc8+uFKZnhl3j08vRDa0dFcVrZJCeVHiUb
oJ+GD47B8fn5eY5QQqrOKdeminTvwdC81CX+ICbWSbCruxagZyryfhq3IbSs
WE1Uyi3waOs6gierJd5DRdUv9QwxPd14EHw1uSD92qkAgjVwtayL407jV1Bq
Wk3Ars8GSAbLpiSpKiKDvcr0vWNbqeWquSqyeDo1v34DhCeUqGXKpJwG4pGv
Ij2Jpk/K6RmUX/TIj9OG0LKi2ALCGAJHsqpnQSr6uXNAcmZmxnvOzs5ohE/s
5eVl3Ut/f7+ebpws8SsYJxlk60tNOYnXs2Ontra2sBWZmlYZlFB+Vbm5uWGp
efLJqYCwNQKYf7yVVQ4bVrLJaY3gJ9ISqqjvReVEiS099XFR/DmTV7MalDXr
h8Bx0WizIh4kxLhINTk5mVM6C1LR584hFXkPBHp7e22JnBYWFog5PDyUZ3t7
+/b2VjZOAixSMXISxik6slMMJyetsL6+PpOAeHNSjjw4ORUTFkjuj2ATmV/O
N2LkzW8csHUWbjFVtiyJB86A0udo2lRUBpuhz6wB+i7yKxZHERWNjY1tvwKb
3oNx/S0IVPRmZKkIP0+iroNPnmKWxcsVAc8jLw09R5JlrKt8BCp6b0hFv3QO
vagNDB8JvSFPS+zs7JC/eB4Iz87Oxv6joyN9YQmE3d3dFS9XEFDVH9P018KV
lZVOj9PIO3GL8WYV/ceAlpDr+fn5RxP5AjsJPppFa5QqKlEcUtGvJUoUgKno
txIl3gRTUa1Wk6hyIkullQggVdh/zD49PTWbzXq9fn9//3sa8BOctVvifwjE
gGCQDeJBQn8AEYN5ZQ==
      "], {{0, 0}, {194, 22}}, {0, 255},
      ColorFunction->RGBColor],
     ImageSize->{194, 22},
     PlotRange->{{0, 194}, {0, 22}}]]]}, Dynamic[
    CurrentValue["MouseOver"]]],
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/versions/source.jsp?id=\
SimulatingACatastropheInsurer&version=0008"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/\
SimulatingACatastropheInsurer-source.nb"]], "DemoSourceNotebookSection",
 CellFrame->{{0, 0}, {1, 1}},
 ShowCellBracket->False,
 CellMargins->{{48, 48}, {28, 28}},
 CellGroupingRules->{"SectionGrouping", 25},
 CellFrameMargins->{{48, 48}, {6, 8}},
 CellFrameColor->RGBColor[0.87, 0.87, 0.87]],

Cell["PERMANENT CITATION", "CitationSection"],

Cell[TextData[{
 "\"",
 ButtonBox["Simulating a Catastrophe Insurer",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/"], 
    None},
  ButtonNote->
   "http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/"],
 "\"",
 " from ",
 ButtonBox["the Wolfram Demonstrations Project",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
 "\[ParagraphSeparator]\[NonBreakingSpace]",
 ButtonBox["http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/"], 
    None},
  ButtonNote->
   "http://demonstrations.wolfram.com/SimulatingACatastropheInsurer/"]
}], "Citations"],

Cell[TextData[{
 "Contributed by: ",
 ButtonBox["Seth J. Chandler",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/author.html?author=Seth+J.+\
Chandler"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/author.html?author=Seth+J.+Chandler"]
}], "Author",
 FontColor->GrayLevel[0.6]],

Cell[TextData[{
 "\[Copyright] ",
 StyleBox[ButtonBox["Wolfram Demonstrations Project & Contributors",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
  FontColor->GrayLevel[0.6]],
 "\[ThickSpace]\[ThickSpace]\[ThickSpace]|\[ThickSpace]\[ThickSpace]\
\[ThickSpace]",
 StyleBox[ButtonBox["Terms of Use",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/termsofuse.html"], None},
  ButtonNote->"http://demonstrations.wolfram.com/termsofuse.html"],
  FontColor->GrayLevel[0.6]]
}], "Text",
 CellFrame->{{0, 0}, {0, 0.5}},
 CellMargins->{{48, 48}, {20, 50}},
 CellFrameColor->GrayLevel[0.45098],
 FontFamily->"Verdana",
 FontSize->9,
 FontColor->GrayLevel[0.6],
 CellTags->"Copyright"]
},
Editable->False,
Saveable->False,
ScreenStyleEnvironment->"Working",
CellInsertionPointCell->None,
CellGrouping->Manual,
WindowSize->{750, 650},
WindowMargins->{{0, Automatic}, {Automatic, 0}},
WindowElements->{
 "StatusArea", "MemoryMonitor", "MagnificationPopUp", "VerticalScrollBar", 
  "MenuBar"},
WindowTitle->"Simulating a Catastrophe Insurer",
DockedCells->{},
CellContext->Notebook,
FrontEndVersion->"8.0 for Microsoft Windows (32-bit) (November 7, 2010)",
StyleDefinitions->Notebook[{
   Cell[
    CellGroupData[{
      Cell[
      "Demonstration Styles", "Title", 
       CellChangeTimes -> {
        3.3509184553711*^9, {3.36928902713192*^9, 3.36928902738193*^9}, {
         3.3754479092466917`*^9, 3.3754479095123196`*^9}, {
         3.375558447161495*^9, 3.375558447395873*^9}, {3.37572892702972*^9, 
         3.375728927639103*^9}}], 
      Cell[
       StyleData[StyleDefinitions -> "Default.nb"]], 
      Cell[
       CellGroupData[{
         Cell[
         "Style Environment Names", "Section", 
          CellChangeTimes -> {{3.369277974278112*^9, 3.369277974396138*^9}}], 
         Cell[
          StyleData[All, "Working"], ShowCellBracket -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Notebook Options", "Section", 
          CellChangeTimes -> {{3.374865264950812*^9, 3.374865265419568*^9}}], 
         Cell[
         "  The options defined for the style below will be used at the \
Notebook level.  ", "Text"], 
         Cell[
          StyleData["Notebook"], Editable -> True, 
          PageHeaders -> {{None, None, None}, {None, None, None}}, 
          PageFooters -> {{None, None, None}, {None, None, None}}, 
          PageHeaderLines -> {False, False}, 
          PageFooterLines -> {False, False}, 
          PrintingOptions -> {
           "FacingPages" -> False, "FirstPageFooter" -> False, 
            "RestPagesFooter" -> False}, CellFrameLabelMargins -> 6, 
          DefaultNewInlineCellStyle -> "InlineMath", DefaultInlineFormatType -> 
          "DefaultTextInlineFormatType", ShowStringCharacters -> True, 
          CacheGraphics -> False, StyleMenuListing -> None, 
          DemonstrationSite`Private`CreateCellID -> True, 
          DemonstrationSite`Private`TrackCellChangeTimes -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Input/Output", "Section", 
          CellChangeTimes -> {{3.3756313297791014`*^9, 
           3.3756313299509783`*^9}}], 
         Cell[
         "The cells in this section define styles used for input and output \
to the kernel.  Be careful when modifying, renaming, or removing these \
styles, because the front end associates special meanings with these style \
names.    ", "Text"], 
         Cell[
          StyleData["Input"], CellMargins -> {{48, 4}, {6, 4}}], 
         Cell[
          StyleData["Output"], CellMargins -> {{48, 4}, {6, 4}}], 
         Cell[
          StyleData["DemonstrationHeader"], Deletable -> False, 
          CellFrame -> {{0, 0}, {0, 0}}, ShowCellBracket -> False, 
          CellMargins -> {{0, 0}, {30, 0}}, 
          CellGroupingRules -> {"SectionGrouping", 20}, 
          CellHorizontalScrolling -> True, 
          CellFrameMargins -> {{0, 0}, {0, 0}}, CellFrameColor -> 
          RGBColor[0, 0, 0], StyleMenuListing -> None, Background -> 
          RGBColor[0, 0, 0]], 
         Cell[
          StyleData["ShowSource"], CellFrame -> {{0, 0}, {0, 1}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
          CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
          RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
          "Helvetica", FontSize -> 10, FontWeight -> "Bold", FontSlant -> 
          "Plain", FontColor -> RGBColor[1, 0.42, 0]]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Basic Styles", "Section", 
          CellChangeTimes -> {{3.34971724802035*^9, 3.34971724966638*^9}, {
           3.35091840608065*^9, 3.35091840781999*^9}, {3.35091845122987*^9, 
           3.35091845356607*^9}, {3.35686681885432*^9, 3.35686681945788*^9}, {
           3.375657418186455*^9, 3.375657418452083*^9}}], 
         Cell[
          StyleData["Hyperlink"], StyleMenuListing -> None, FontColor -> 
          GrayLevel[0]], 
         Cell[
          StyleData["SiteLink"], StyleMenuListing -> None, 
          ButtonStyleMenuListing -> Automatic, FontColor -> 
          GrayLevel[0.45098], 
          ButtonBoxOptions -> {
           Active -> True, Appearance -> {Automatic, None}, 
            ButtonFunction :> (FrontEndExecute[{
               NotebookLocate[#2]}]& ), ButtonNote -> ButtonData}], 
         Cell[
          StyleData["Link"], FontColor -> GrayLevel[0.45098]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoNotes"], CellFrame -> True, 
             CellMargins -> {{0, 0}, {0, 0}}, 
             CellFrameMargins -> {{48, 48}, {4, 4}}, CellFrameColor -> 
             GrayLevel[0.99], StyleMenuListing -> None, FontFamily -> 
             "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.45098], 
             DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
            Cell[
             StyleData["DemoNotes", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, FontSize -> 9]}, Open]], 
         Cell[
          StyleData["SnapshotsSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, ShowGroupOpener -> True, 
          CellMargins -> {{48, 48}, {10, 30}}, 
          PrivateCellOptions -> {"DefaultCellGroupOpen" -> False}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], DefaultNewCellStyle -> 
          "SnapshotCaption", StyleMenuListing -> None, FontFamily -> 
          "Verdana", FontSize -> 12, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "SnapshotCaption", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["SnapshotOutput"], ShowCellBracket -> False, 
             CellMargins -> {{48, 10}, {5, 7}}, Evaluatable -> True, 
             CellGroupingRules -> "InputGrouping", PageBreakWithin -> False, 
             GroupPageBreakWithin -> False, DefaultFormatType -> 
             DefaultInputFormatType, ShowAutoStyles -> True, 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, 
             AutoItalicWords -> {}, LanguageCategory -> "Mathematica", 
             FormatType -> InputForm, NumberMarks -> True, 
             LinebreakAdjustments -> {0.85, 2, 10, 0, 1}, CounterIncrements -> 
             "Input", MenuSortingValue -> 1500, MenuCommandKey -> "9", 
             DemonstrationSite`Private`StripStyleOnPaste -> True], 
            Cell[
             StyleData["SnapshotOuput", "Printout"], 
             CellMargins -> {{39, 0}, {4, 6}}, 
             LinebreakAdjustments -> {0.85, 2, 10, 1, 1}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoTitle"], Deletable -> False, ShowCellBracket -> 
             False, CellMargins -> {{48, 48}, {22, 10}}, 
             CellGroupingRules -> {"SectionGrouping", 20}, StyleMenuListing -> 
             None, FontFamily -> "Verdana", FontSize -> 20, FontWeight -> 
             "Bold", FontColor -> RGBColor[0.597406, 0, 0.0527047], 
             Background -> GrayLevel[1]], 
            Cell[
             StyleData["DemoName", "Printout"], 
             CellMargins -> {{24, 8}, {8, 27}}, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, FontSize -> 
             16]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DetailsSection"], CellFrame -> {{0, 0}, {1, 0}}, 
             ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
             CellGroupingRules -> {"SectionGrouping", 25}, 
             CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
             RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
             "Helvetica", FontSize -> 12, FontWeight -> "Bold", FontColor -> 
             RGBColor[0.597406, 0, 0.0527047]], 
            Cell[
             StyleData["DetailsSection", "Printout"], 
             CellMargins -> {{12, 0}, {0, 16}}, PageBreakBelow -> False, 
             FontSize -> 12]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoSection"], CellFrame -> {{0, 0}, {1, 0}}, 
             ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
             CellGroupingRules -> {"SectionGrouping", 30}, 
             CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
             RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
             "Helvetica", FontSize -> 12, FontWeight -> "Bold", FontColor -> 
             RGBColor[0.597406, 0, 0.0527047]], 
            Cell[
             StyleData["DemoSection", "Printout"], 
             CellMargins -> {{12, 0}, {0, 16}}, PageBreakBelow -> False, 
             FontSize -> 12]}, Open]], 
         Cell[
          StyleData["ManipulateSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12], 
         Cell[
          StyleData["ManipulateCaptionSection"], 
          CellFrame -> {{0, 0}, {0, 2}}, ShowCellBracket -> False, 
          CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], DefaultNewCellStyle -> 
          "ManipulateCaption", StyleMenuListing -> None, FontFamily -> 
          "Verdana", FontSize -> 12, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData["ManipulateCaption"], ShowCellBracket -> False, 
          CellMargins -> {{48, 48}, {10, 16}}, StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12, FontColor -> GrayLevel[0], 
          DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
         Cell[
          StyleData[
          "SeeAlsoSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, DefaultNewCellStyle -> "SeeAlso"], 
         Cell[
          StyleData["SeeAlso", StyleDefinitions -> StyleData["DemoNotes"]], 
          CellDingbat -> 
          Cell["\[FilledSmallSquare]", FontColor -> 
            RGBColor[0.928786, 0.43122, 0.104662]], ShowCellBracket -> False, 
          FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "RelatedLinksSection", StyleDefinitions -> 
           StyleData["DemoSection"]], ShowCellBracket -> False, 
          DefaultNewCellStyle -> "RelatedLinks"], 
         Cell[
          StyleData[
          "RelatedLinks", StyleDefinitions -> StyleData["DemoNotes"], 
           FontColor -> RGBColor[0.928786, 0.43122, 0.104662]], 
          ShowCellBracket -> False, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "CategoriesSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, DefaultNewCellStyle -> "Categories"], 
         Cell[
          StyleData["Categories", StyleDefinitions -> StyleData["DemoNotes"]],
           ShowCellBracket -> False], 
         Cell[
          StyleData[
          "AuthorSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {4, 18}}, 
          CellElementSpacings -> {"CellMinHeight" -> 3}, 
          CellFrameMargins -> {{48, 48}, {6, 3}}, DefaultNewCellStyle -> 
          "Author", FontSize -> 1, FontColor -> GrayLevel[1]], 
         Cell[
          StyleData[
          "Author", StyleDefinitions -> StyleData["DemoNotes"], FontColor -> 
           GrayLevel[0.64]], ShowCellBracket -> False], 
         Cell[
          StyleData[
          "DetailNotes", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False, FontColor -> GrayLevel[0]], 
         Cell[
          StyleData[
          "CitationSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 14}}, 
          DefaultNewCellStyle -> "Categories"], 
         Cell[
          StyleData["Citations", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False, ParagraphSpacing -> {0, 6}], 
         Cell[
          StyleData[
          "RevisionSection", StyleDefinitions -> StyleData["DemoSection"]], 
          DefaultNewCellStyle -> "RevisionNotes"], 
         Cell[
          StyleData[
          "RevisionNotes", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Specific Styles", "Section", 
          CellChangeTimes -> {{3.34971724802035*^9, 3.34971724966638*^9}, {
           3.35091840608065*^9, 3.35091840781999*^9}, {3.35091845122987*^9, 
           3.35091845356607*^9}, {3.36230868322317*^9, 3.36230868335672*^9}, {
           3.36928857618576*^9, 3.36928857640452*^9}, {3.3737586217185173`*^9,
            3.373758622077897*^9}}], 
         Cell[
          StyleData["InitializationSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12, FontColor -> 
          GrayLevel[0.45098]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["AnchorBar"], ShowCellBracket -> False, 
             CellMargins -> {{48, 44}, {3, 6}}, StyleMenuListing -> None, 
             FontFamily -> "Verdana", FontSize -> 9, FontColor -> 
             GrayLevel[0.5]], 
            Cell[
             StyleData["AnchorBar", "Presentation"], FontSize -> 18], 
            Cell[
             StyleData["AnchorBar", "SlideShow"], StyleMenuListing -> None], 
            Cell[
             StyleData["AnchorBar", "Printout"], FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["AnchorLink"], StyleMenuListing -> None, 
             ButtonStyleMenuListing -> Automatic, FontColor -> 
             RGBColor[0.5, 0.5, 0.5], 
             ButtonBoxOptions -> {
              Active -> True, ButtonFunction :> (FrontEndExecute[{
                  FrontEnd`NotebookLocate[#2]}]& ), ButtonNote -> 
               ButtonData}], 
            Cell[
             StyleData["AnchorLink", "Printout"], 
             FontVariations -> {"Underline" -> False}, FontColor -> 
             GrayLevel[0]]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["GamePadStatus"], ShowCellBracket -> False, 
             CellMargins -> {{48, 48}, {5, 5}}, StyleMenuListing -> None, 
             FontFamily -> "Verdana", FontSize -> 10], 
            Cell[
             StyleData["GamePadStatus", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoInstruction"], CellMargins -> {{48, 48}, {5, 5}}, 
             CellFrameLabelMargins -> 2, MenuSortingValue -> 800, 
             MenuCommandKey -> "8", StyleMenuListing -> None, FontFamily -> 
             "Verdana", FontSize -> 11, Background -> RGBColor[1, 0.85, 0.5], 
             DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
            Cell[
             StyleData["DemoInstruction", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, Hyphenation -> True, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, 
             LineSpacing -> {1., 2, 2.}, FontSize -> 9]}, Open]], 
         Cell[
          StyleData[
          "ImplementationSection", StyleDefinitions -> 
           StyleData["DemoSection"]], Deletable -> True, DefaultNewCellStyle -> 
          "ImplementationNotes"], 
         Cell[
          StyleData[
          "ImplementationNotes", StyleDefinitions -> StyleData["DemoNotes"]]], 
         Cell[
          StyleData[
          "StatusSection", StyleDefinitions -> StyleData["DemoSection"]], 
          DefaultNewCellStyle -> "StatusNotes"], 
         Cell[
          StyleData[
          "StatusNotes", StyleDefinitions -> StyleData["DemoNotes"]]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["SectionGloss"], StyleMenuListing -> None, FontSize -> 
             0.85 Inherited, FontWeight -> "Plain", FontColor -> 
             GrayLevel[0.6]], 
            Cell[
             StyleData["SectionGloss", "Printout"]]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineFormula"], 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, LanguageCategory -> 
             "Formula", AutoSpacing -> True, ScriptLevel -> 1, 
             AutoMultiplicationSymbol -> False, SingleLetterItalics -> False, 
             SpanMaxSize -> 1, StyleMenuListing -> None, FontFamily -> 
             "Courier", FontSize -> 1.05 Inherited, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             FractionBoxOptions -> {BaseStyle -> {SpanMaxSize -> Automatic}}, 
             GridBoxOptions -> {
              GridBoxItemSize -> {
                "Columns" -> {{Automatic}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{1.}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["InlineFormula", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineOutput"], CellHorizontalScrolling -> True, 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, LanguageCategory -> 
             None, AutoMultiplicationSymbol -> False, StyleMenuListing -> 
             None, FontFamily -> "Courier", FontSize -> 1.05 Inherited], 
            Cell[
             StyleData["InlineOutput", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineMath"], DefaultFormatType -> 
             "DefaultTextFormatType", DefaultInlineFormatType -> 
             "TraditionalForm", LanguageCategory -> "Formula", AutoSpacing -> 
             True, ScriptLevel -> 1, AutoMultiplicationSymbol -> False, 
             SingleLetterItalics -> True, SpanMaxSize -> DirectedInfinity[1], 
             StyleMenuListing -> None, FontFamily -> "Times", FontSize -> 
             1.05 Inherited, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             GridBoxOptions -> {
              GridBoxItemSize -> {
                "Columns" -> {{Automatic}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{1.}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["InlineMath", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["TableBase"], CellMargins -> {{48, 48}, {4, 4}}, 
             SpanMaxSize -> 1, StyleMenuListing -> None, FontFamily -> 
             "Courier", FontSize -> 11, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             GridBoxOptions -> {
              GridBoxAlignment -> {
                "Columns" -> {{Left}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{Baseline}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["TableBase", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}, FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "1ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.04], {
                    Scaled[0.966]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.126], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "1ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.078], {
                    Scaled[0.922]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "2ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.05], 
                   Scaled[0.41], {
                    Scaled[0.565]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.14], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "2ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.079], 
                   Scaled[0.363], {
                    Scaled[0.558]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "3ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.04], 
                   Scaled[0.266], 
                   Scaled[0.26], {
                    Scaled[0.44]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}}, 
                 "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.14], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "3ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.08], 
                   Scaled[0.25], 
                   Scaled[0.25], {
                    Scaled[0.42]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}}, 
                 "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["TableText"], Deletable -> False, StyleMenuListing -> 
             None, FontFamily -> "Verdana", FontSize -> 0.952 Inherited], 
            Cell[
             StyleData["TableText", "Printout"], 
             CellMargins -> {{24, 0}, {0, 8}}, Hyphenation -> True, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, 
             LineSpacing -> {1., 2, 2.}]}, Open]], 
         Cell[
          StyleData["Continuation"], FontColor -> GrayLevel[1]]}, Closed]]}, 
     Open]]}, Visible -> False, FrontEndVersion -> 
  "8.0 for Microsoft Windows (32-bit) (November 7, 2010)", StyleDefinitions -> 
  "Default.nb"]
]
(* End of Notebook Content *)

(* Internal cache information *)
(*CellTagsOutline
CellTagsIndex->{
 "ControlSuggestions"->{
  Cell[244158, 3607, 258, 7, 70, "ManipulateCaption",
   CellTags->"ControlSuggestions"],
  Cell[244419, 3616, 1925, 44, 70, "ManipulateCaption",
   CellTags->"ControlSuggestions"]},
 "Copyright"->{
  Cell[253893, 3849, 818, 23, 70, "Text",
   CellTags->"Copyright"]}
 }
*)
(*CellTagsIndex
CellTagsIndex->{
 {"ControlSuggestions", 280577, 4418},
 {"Copyright", 280776, 4423}
 }
*)
(*NotebookFileOutline
Notebook[{
Cell[596, 21, 34328, 567, 70, "DemonstrationHeader"],
Cell[34927, 590, 53, 0, 70, "DemoTitle"],
Cell[34983, 592, 207781, 2989, 70, "Output",
 CellID->61136942],
Cell[242767, 3583, 500, 7, 70, "ManipulateCaption"],
Cell[243270, 3592, 885, 13, 70, "ManipulateCaption",
 CellID->289930240],
Cell[244158, 3607, 258, 7, 70, "ManipulateCaption",
 CellTags->"ControlSuggestions"],
Cell[244419, 3616, 1925, 44, 70, "ManipulateCaption",
 CellTags->"ControlSuggestions"],
Cell[246347, 3662, 33, 0, 70, "DetailsSection"],
Cell[246383, 3664, 211, 5, 70, "DetailNotes",
 CellID->878929216],
Cell[246597, 3671, 149, 4, 70, "DetailNotes",
 CellID->428675160],
Cell[246749, 3677, 155, 4, 70, "DetailNotes",
 CellID->2083262082],
Cell[246907, 3683, 168, 4, 70, "DetailNotes",
 CellID->15133749],
Cell[247078, 3689, 162, 4, 70, "DetailNotes",
 CellID->207401535],
Cell[247243, 3695, 133, 4, 70, "DetailNotes",
 CellID->1454747214],
Cell[247379, 3701, 165, 4, 70, "DetailNotes",
 CellID->744740783],
Cell[247547, 3707, 119, 3, 70, "DetailNotes",
 CellID->1172592204],
Cell[247669, 3712, 147, 4, 70, "DetailNotes",
 CellID->1494971580],
Cell[247819, 3718, 4826, 89, 70, "DemoSourceNotebookSection",
 CellGroupingRules->{"SectionGrouping", 25}],
Cell[252648, 3809, 45, 0, 70, "CitationSection"],
Cell[252696, 3811, 858, 24, 70, "Citations"],
Cell[253557, 3837, 333, 10, 70, "Author"],
Cell[253893, 3849, 818, 23, 70, "Text",
 CellTags->"Copyright"]
}
]
*)

(* End of internal cache information *)

(* NotebookSignature ZRED9mwWIOXCsx7QZ5jqzUr9 *)
