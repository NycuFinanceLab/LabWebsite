(* Content-type: application/vnd.wolfram.cdf.text *)

(*** Wolfram CDF File ***)
(* http://www.wolfram.com/cdf *)

(* CreatedBy='Mathematica 8.0' *)

(*************************************************************************)
(*                                                                       *)
(*  The Mathematica License under which this file was created prohibits  *)
(*  restricting third parties in receipt of this file from republishing  *)
(*  or redistributing it by any means, including but not limited to      *)
(*  rights management or terms of use, without the express consent of    *)
(*  Wolfram Research, Inc.                                               *)
(*                                                                       *)
(*************************************************************************)

(*CacheID: 234*)
(* Internal cache information:
NotebookFileLineBreakTest
NotebookFileLineBreakTest
NotebookDataPosition[       835,         17]
NotebookDataLength[    216588,       3951]
NotebookOptionsPosition[    189667,       3366]
NotebookOutlinePosition[    215959,       3927]
CellTagsIndexPosition[    215846,       3921]
WindowTitle->Nonuniqueness of Option Pricing Under the Meixner Model
WindowFrame->Normal*)

(* Beginning of Notebook Content *)
Notebook[{
Cell[BoxData[
 ButtonBox[
  GraphicsBox[RasterBox[CompressedData["
1:eJztvXmUXldxL8pazzeKUCRHkqVWz3O3utWTutWjWq1u9dz9SdbgSZ7AI1OY
59EGMxgMGI9AgACBJIwmcBNCwnBvgm2mvPduCATWevfmvgD5864L5P3Neaf2
WFW79vlOt2RJtrfXqnW+s3ftGn5Vu2r7bEtuvfXlp2/9P57znOd05fS133vO
cy7Ln0/Mdf6vROebOhIlSpToKaaLXecSJUqUKFGiRBeIfmfoYtuRKNHTjX73
RNo/iRKVod8V0MW2LVGii0VF+2Ize2Wj8hIleibQed2X//dCZ5bowtP/lehZ
QRc7zxI9/fZ5efldF92/RIkSJUqUKFGiRIkSJUqUKFGiRIkSJXqq6b+v7k90
3qm7Oq0kSoSoTM4kelrR/3MOBHXkf5Si7kSJEiVKlChRokSJEiVKlChRokSJ
EiV6RtP/XO3+X4kSJbr49K+JnjH0PwT67yvFhHn/FT1jdLHzNVGiRIkSJUp0
weh3hi62HYkSPd3od/8z7Z9EicrQ7wroYtuWKNHFoqJ9sZm9slF5iRI9E+i8
7svfXjueFdF/IPot+x3QNYgicsrwRuevidEY4f0Pgar5dj5JxnKsgIpjsPF1
fK5Id5HcsQ3q36yeajI2iudm9Z+LndViWH6fPTtpomBcz/1/ZGwSzV0sKlcD
fnONp1/ntUoizOPXTlTNjXPNu0JSdTWk/8ht/A+hBv+HIcVn90VERqJEiRIl
SpQoUaJEiRIlSpQoUaJEiRKVpYHWjpzas/782Z8/B1o89TNSfNK4mQNZg0pe
hxvra2nLicvJ+dpynrYOp1/pa7Xy7LgmZVdOg3adWQPvQ+2d+ViXIsXbAtTm
qK8Vnq1ZX3O7ov7mDiUf+PoUtetncxv63W5+txs+64eVp2Uqf5oRGd5+w9OH
7AC92rZ280Rygb/Vyx4AwnrUnMamr7UD4dkWkpFl3weUnW1Er/W93/nncbDr
Qf+Ak2vwaDY8bq3FBGxsNfHz9hFb4beKpVnb2k5s7oMYtWI79XPA+dlqCGEP
fBZ7I1fpA6ybje5mn1fq6XLMY03tMDa2ej/7Wk0ssZ2t7QH1tbS7ddp3u97k
hOWzv838AIqL09nSYXJV+9DX0mH2hd9Dfr3XO9DsZeI95eLd6vMa70ntN35H
a9z+bvd7kuWTrR9eVoeJuZGF4tNnawmpJ23GZpQfsMebWrOBnPraOrOe1s6s
t7lTxb+3tSE70NqYHWhrVtTX1qpjY0jnI8SrRVOrnTO/Wz2PptbsgJrT8/i3
loHlm3clB8vW7wdatc4DLV7WAXg2NyvqRc9exaefvW4NsqGFPrUs4NXvfl2r
0WlssjqRTLe+hY5rm1udTCv3AFmjZfbmYx3tjVl3S2PO02zmmlWuduXUmcep
N6f+Rohbi6kReN+2+jrFahatOW2+VqA89LUF5xSu+TquA1i+zQlbB6E2NHf4
mu1qeIep076eBzU+RoQX2d3cLo+3oHesNzZP+OjeJWudng5qW2Ar9xX700HX
OV86sgAnQlhnRHegs0OwLyKXjwcyMU7CWoJHh8zX3BHOcz1FPsfsxX4HceC2
cX6GO8ZMwGNvTUO2Z29ONY3qCe9qjDwbydhey7e3Uf/eS8f3GJnUFpZzzcym
Zo4jyl0pD4hfHQw7LkeIvYQjty+Qw/0pkhfLhw5mhxQvwQ++17keHFcxj9uz
ECtmO9m7PN8ErMUawuqOVK9idROfF4vsD/Kc7SmOO6+7ol1CzvF9zOsQwV94
kjM890GIL9/nQV3voHJ5DyL285wR/A4w43VCqkOxePB1PHcku7m9fB9JOdAR
kcfjjtdJfEKOi/uJ68J5zH7z2sb/PU6SFeSOhDmX0R7KlOqqVIN4TZT6cLDf
NX9bQ6uidkNtDW1Ze2OrG7dzbY1tlKcBvxu+RjPeqH97uS2eGvUz2Eu5bdBr
XN+yvSjoWw1h30I9jvQy1LdsX9tj+xtei8YUv+mNzp69drzB91Ono5HqqQlp
j/HD8e6V5pBfe708i4PGpNHZsRfxUX2Ngc0coz17G0NMCTb03ODisLfR21Qj
6OZnjb0hLt4ndgaJ+ELjgnBBeUJ9oHHfw+Rh392Y09+IbGP4CfnH7d5j7OU2
ybnUyOQ3hj7ifWDjI9nAYoDPfVYOwVTcT2bNXuqzlZH6Vupbl1LfEvWJ519u
D7eR+UrkS7km2VAQW3wW5TnH5/leCGyO5TLXX4JaGF48j/g43//8/B/UByFf
uZ+8VgQxY5gH+Aj5EeSjZK+wV2L7XopJrDZwuXw8kMnyRYyBkOvE9o5wnusR
bNPnNTjX+bNdW2OrObu1krOdf7axcx2mNrSuLZxvbDXnPgGPFuYnj0U0Vh67
y3bty/7Trprssp3wzGlnjXrHBHOXwW87Z3ndGPq9087798uUjBo0ptd73Ugf
WkPsQLIvszbsZON4jKyp8fZjwrKJbXbOy7xMydhHbcVrEJ+Xvc/PYZt3eUwc
Ng7/mB/7GIYhTpcFviDZ6Onx20f4Ltu1j2Jgbdm1j+piuHsZNq4UH/4uxoE/
XS5S22luorGdnv8yZpfPWR5zn6eXIX8szjRvPQaXobWXReQRP5h/OIccvru8
DThXsf7L3HqbU/uIveEe2udyjNgu5pPfV56Hx2yfk+t928cwxXbsYz4weW49
9R/HCq/1+clyk+cW9oPkiBCHYL/6d4pXJO/RPqF738fX+7BX0669euwPYV6/
w7i19zKEz2XCPg32ALZT2ktYRrB/6B4I/EX4XYbyPYZLaAeyPagvFuN9gZ1h
HfW/L8OxjeafnBeXYX94rUXj3keWP7ymWV5sC+5/LKeCceuTe/K9wHKO1zIp
7iz2l+3ka/aFfgh16j+x/cb1kHq0C8fS+LET1x+cx7xO4ncpHgyvCB+Nj7xn
vM1UNjlTsJwn9RHn1S62H3GOobjiHA9qHMklCQ/WD3Av5nUN28kx2kX1pHMf
50/nvnTuozHC8tO5L537gnwsfe5Dsney2O30efVsP/elvsXkBTER4pz6FrE3
9S0qP/Wt1LeCfEx9i9UbtidQPtL6IvctuY763+l7RSznuQ60D8iafaEf6XsF
8nFf4OPT6XuF36t2L/HzmYThPqLv93bX5rQv25LT7+3ST/UbxnfVmnHNY3k1
fy15wlrFZ9cQuXT9Fml8l7fBrXNraqm+XbWOj89bmW79Ls+DdXn/+Npaxp/L
2oXX7SO6uZ1+jMrAGHvckN9Y7i60dpe302PHfHR83qYt2M/dzH7mw+8xmTY2
W/Bah7u3i+gnPqKcsDhb25yM2sBuh4eYAzSWzl62lvuJY7GF2LiP+cRyBOne
wtZTHjlnCL/dGyjnwvwSfMX5tmufEE8ao2DfRWhLsCcQbrt8HfB7WsrLfSaW
sRwI7SV7Ldg7PGZ8r1CMtmB72d73dUXKnXAv/h6zy+0jJH8LqSthPpI6tguv
zWss1Fn1jp477TgmxLO7xsveReuFsw35QfOc44VjGub6FsbnxpEOtweEXkDy
AuMQ2CDHItxT2A5e5zBvrbC/UV3AvgZ+s3zZ5d+37KJ+hLWI1VZTs7bwMVRb
pVzfEmAR2fsk31g8RRJsdBiw34F8oa5hfMjewv0ijFuAM89N3m9jtmA8CB+v
P8hW0l94PcByad/Yspva5PYxz9lI/4z1ELx+Czlnof0m5TnKS44b7/NbmE20
Ltp+QTFI5z4hD62v6dyH9pS3K537aNzDdXzv4ljy/BJ8Tec+kptBTJ4W5z4p
X/gcjwHfd8+2cx/HCu8dinnqWzymvK7g/YvzndqR+paQn6lvpb61O/Wt0B5O
tR5zsu+ebX2L4pO+Vwg5I+FbZKPDgP0O5At1LX2vCHM20j9jPQSvf6q/V7h9
HmDDc1qIhdH1+1fUadrDnpxgfE8tmq8tXLeVr3XP2nAcj11RhXcP1lGrbULr
tlh5AX+trCdCWyV7YtgE/gh47EEyyZy2a4vzRaA98bmtnE9aj/DYavRv5b4Q
HPn6feypdW3dg36L2NY6PRhP/7veYRPEG9ticm9rgY9b91DbojhI2EXiujUa
TxaTPYJM4X0rtyu6dyIxlX7jp+g3wxzp9DmJ1+4TZKBxw7cF+8xjs4fjK8UL
8ezheSzsNSZjq2RbmT0u1ZGSe1vjVcvWc33M192GrI3576270XiM7NpqubyH
4VyQA1Vr0R5MOg5bRcxqKX8E12o1MpBN+ksJWdVqNHrfSmperVzf8VwkvlvN
fLAejcl1no2XwYlhFa9HLE8LbCN1Xqo7ezxWkpxoPZHyAssJ9rMgS/JBWLeV
68djG80ZbntOWyLxidpk5zlmEh+uuc5m0yeDHhzBKCI3GqciTNK5L24/zuWi
dZs+9xm7C7EvYWeJ+JY793GqZU8mA/dDtu78nfuKc3hrQT2rGuPzcu6T82Zr
TB6WWbh3In5J/bbA7+rnPh7rSA4Yvi3s3BSeD2oL8SV5IdXLgj4R4lx+Xz/1
576Izah2FvXTarkh2iXoKMz7WC3ag+kSOPdxns3glPpW6lupbyGbUt8Kcjv1
rbjNqW+FuAf5m75XxHxJ3yvoXPpesTE8ZX5ak7ai9+furc+pwTztb03byHs9
eq8X1knvEmFZIXGdso6Y3nDNNvaU14dz2wQ/t4k6/Tuf34awfO7eHOs9+fie
ugLKdaDf8Nxm6LlsnPLXF8vei3gcHjb2dZREXfVVxuqoHU5uvZcp6XI8BqM9
1jaE2V4sn/q6LWpXvcHG84W80to6Yvc2h1Odeec4USx47Krp24bW0xjLcYjn
AdeD/ce60LvzI4YlliPFmT5l++M4b2P2b6sqp5rvPOdxDsap2p6u/hvnBPaX
+r4V0R/dPJnTVNbZ26b+fea5pi9sZTEq2tfb9oSxiOWQGzc5XVzfimu65dnm
6ltMBiZprMHsr7j+4tjwca7H+7ktylcvrMF2cayK+pusn2MWzz+qn/sQsyNc
Xy22/l3uwXTtNlGXbHfxXsM+UJu2BZiFvDQ28XEf7zCuNG9pr+fx3sZkUxnV
crIIg5jtZdeH4+ViIdWvdO7jc+f/3Fdub/AYhjkR5kyxTznV8JwLa0txnlXL
GaneV8sVAffg3BfL7XiMqI94X8fqfDyPw3pQjE+8HhTVNSl3yuyZ2N7m/vMa
Ktsq48PrHK8B1eyP48x74Laqcqr5Xm2NTOd+7ov5G9uTsRrVwKhIBq4L1XNI
OsNc2ue+ItxkDOXaFvNr8/mU+pasP/Wt1LfK7ZnY3ub+Y118L0u2xHKFx5k+
U9/i/larv7xGFdV62e5nbt8qE5sYng1MRvpeEcYlfa/gfeSZ9b1C0hfuixBr
v/YPahqzP9jXmG3fZ57mXVENeq8R3vex3zUNfoyM+7Ht+FnD5OwL+USKrBHn
aqjO7ZwH2xDzzWIkyOb4Ub4GTTWM8hhsZ+/w3GYIj29j9AcQwxo0htYHT0Pb
9/rndm6L468P1lt7iA1ct+BH/F3r2I70KHs4Tua3tXW7lbWX2SbZEMGU8Fa1
k9poaTvi8zjWk/Xb9vqnw6tIlzAX5Ab3xflTvzm5eym/xXcb0sPz0f1mcYjJ
Btv42m0YJ44LztW9DaL/nuqNDibHxonjofKr3tho96edQ3XNjsdqDOjN57cb
CuxEv7W/9SZGvg8D/fm9lewfPnF19q9fuzmbn+3X96xqb9Cnw49jLlKYC9sR
ERvtfov6yWq0UEur1WPST3idl+qoVI95D4rUdaqzAb03BPzbS9vQIPA2oD7S
kHFfRful3mZ8wv2oyC7ek/2zweSjYIegU+zX1eJbE85tr4mMS3qFuWhe1aAY
ur3LfbZ8DR7rWL5Wyc+orxyzGtnmELOGUDfLOfF3ydyJxjd6bmkI1vFzVzr3
FeEnYBPBT+QTbOS1gsdmu5XDaDveCzG7I/m7neslmDVE1/P9FY1bUS21+VEj
7KdI3ou5IuTddkZR2aXtDPOe11+y1yM1rGwNkvzhmMg1SupNJeRKODM9Qa0o
ygVRdlhzgt4r6ZJizPOZYy5hFcw3ONlBDatpLHnuw32/IKdqQv6NxAdjEMv9
cB83iPIKzzpVxi7auc/5nPpWYb4V1X2MUayec2yL7JPiXxPGJvWt1LfIvovE
LPWtCFbBfOpbT5u+xXVGbJTzKH2viOkU87NafIVanb5XyP5fct8rBF8K44D8
uLy2OduR0+V1TdmOOnjq9x21Tf43jNfqOftU82Zuh3uCDL9OyaxF8+bdzdei
Zx16Wl6sF81r24weN250K3lNRh9da9fYdTuQHZcjvZfXItnIFrxmB5K3o45i
o/Rz2teUbbfPHHs93pCTjs/lMGZitcPs9e3mucPsgx2OB/2uxb8bjbxQtyP1
rvVrfjvu123fp+e07AZ3RgUCW3bYd7u/jF6rYzvx2cxzGwBj8355Pq8xa1Rj
l9f68R213jaNm6/L3l+DibE5GDeYKl9qGxxmNg7bjf9Wl8ekyWPiYkfHNZYN
zk+rj8TP2qB4mhxZHDBezl8nr9G973Cyfcx3IJ4daA2OzXbsB/EZ+4Zzz2Bl
412D9Nl47/M2EvtqG6nPTi4eRzpqqR/OZjfW5Ox3+Dq8cRytfRjbRp1bZv7y
fSa/bG7ZXHO8NudYLtR6vssxL4mXtQ+Nob2zw+4f5D/cZX30bSv5eL0er0EY
231m+H3+NHrf7b6ytqJ9vB3FGu8954f5fbmt2eapa3QTrZG4/uF6jOqlr8vN
pn76+r0Dk+0BtsfU+vp9udFteXa4et3k63fQc1DPqvO1n/cBbreT43Q1o37S
lO3g9hv7rL2XIzttPyQ9DNvnMEZrsd2s35C+hnHDvQ7h42TF+hXr434MY0Ux
wNi7OLE+h3OD9sGmyDg+F7D+XtuE/Pd54GMf+nA5savJYyngu8ONMT0ohtQv
li+47+P+j3LeY8bk1DLbhRz2c+gM5faXnBdu/9VRu3A+O78w8VgQ/9K575zO
fWzfER9rUT0z8v4Q711UR7F/l+PfOO583wo1jsa8ya9lscIx97WY5jzhqWX+
1zKcSFzo/OUBjnSP+3g1IczRXiaxbCKxCveN7UXeHpzjWBfNtch+I/sBx7uJ
2ujqA8s7Vh9I/gh9dkcdwwmvZ3WB1DorC+9bYQ2tAz7udj/x+JI4orz1e7sp
sM/zoDMUqSkoZ2pR7rEa4/FhvvD8cn3Dn238PuD53oRiifZfLfMR41/r9fD6
hs8CtFeEMd+B8Q0wQ3aT/OFrmohf+BzG9eNef0me+3BN4fWrFuPmsU99K/Wt
1LdwrtG9nvoWzefUt5qJPalvoRijvNpQ33I+NAW+hT2H1qP0vYLFq47iResz
xopikL5XsHxB9Yn0rUvxe4WNrdB7SL3j+wDl2K6G1mxnfUu2s8GQ+g1jrfrZ
gN7tWL0eV2sJtfjfTiZdE/K2UBn1wtqcdrlxQRdZS+d3xfxh63bVMznEFjzW
Qp9OJuCBMMzpDxU162edPvuppyX+nsclfDayJ+dv8nJq6fxOQ4GuekxN4W8i
qwnpaUTvjcxWq0+Q5343UTzM750Yp+DZ4m0KMGuqjklAdq7J2Nzk5CqsnI1N
FKc65APzW8I+jHMTfa9FscF6q/nFcahtZvY0UYrFAOeBtZ344OO8k8gssLG2
GfFirBkWHI+oPwWYcj3muTPIb5NDdT6ndrqY+vxSezZfu8v+JqTHfT7q/PV5
i/CtxXh6O+2dEaa/eO9xRfau7XJ3l4bxbqR5ymrFTikX65pYznp/dxosoC6q
2ghjDc2oluPaK9TooI6jsXqhthI+qSdIeqV1Qq+pR73BvbcwedyfiJ31kt5W
hkukfwR9r8gv2ycMbz23NdJzne1CX471qsDeiB6MJ7J/F9dN9MbkFOmV47wr
tg7Fk/BwjIO4x/IBYyXkQ+CvPUNQ27Atu8jZycxh/np0BonlN8eHxJ37x3ns
OaxaPFBOOzvTue/8nfsimPBYBvszkrsF+yWoBWw/7MI5Wl9NpxQ/plfEv4Xp
i8WoRZCF95Hku5y38n6JYCLFg9QTHx/ZDp6/vJ7I2MtraZ5G612RX9F48njx
Gs9jKdgeiW/Y+yI21rf6f/chWDMsomcH7k8BpmKd4zUp1kN4jnj/Y3s4GK+P
1Nto/xXeybpIbHieBuMClkQOxWAXeu5CPJfWuS/1rdS3BJ9iMUt9qzgvU98q
tjH1rdS3ovFqzcr3LWmdgJ1Zn75XtBbkXUEN5nOsx6bvFS0CDk+H7xUx+SVi
YnJyd2NbdkVTe07+uRuRfs/HG9vpswmv0zyWH3j0E8kxevRaT1iWW+9ktpGx
3U5Pe2ifW298aLR2tBvdns/aJfntdDVS/6xPnqc9uwLZ4/SA7AZYn+dDTrtz
vHebXNqtvhdrgm/H9vu4/Vau3t23dERqrCWbW60osvP2W7SXp2sOvGu9+JkT
xLvB2qRpF6LdJsd2GxlKR/48de312anrbiB27bL6kU9Wr7arFcmlOjUeZrxR
26SwUpi1uXHbu3a7f4dpNhh6m70tdFzb0OyefYPd2cr8way5s8PYjW23NrY6
//Fv/8zH670PPJ7qt4tjS65vKOvP9XrbMEbNQRw8LtQ2Xbd0fEEm+EFyxsa8
HsehmdhL49xKfTI5stPYNTXZp/S0dBis6hDGxhZnn80B5qO7/6lrQZho2Ydz
crnr1rcw25sZNlTnTqOruasjW1kYyg5P9ZFYuRg1tpjcavP5ZXLN5p6ea/N8
Cp82t2Y3WdNCfztc/b8XWf1gF8Sf7pkm/axryj733uOKYGynGm9yOMP7YRMH
h1Md3WsWK7C3f2h/ru9g1prnd2yP+/3W5qnR1kpUyxp9Ld3N6yquiayWy7U4
/92I17SRmkx7AB3bLc5bG2N1mMm3/qEeckVA3n5iVyNds9uMEd+EniD7IPSQ
xjbWm7gM60vYn1w/bMSyeGxYvFivt/30Ct7rXA+kMsjT6UXxcHkUkUcwbs84
Xhh/3p89fmHvd364fMM9nPqOzyOux9tzSmM71Yl4dpMYeDkeE2oDz0Nqrz2j
hOcLGluUbwRvFl/sCzpH7Q7s4rmdzn3n7dzHc4T4Le9Z4k8j9X23ZAvZFyhm
jWGdDn0Q7AiwFGoK8Veqc0hGo7UlVgNoX/DxoHVI573Jucb2jMfb5S/pAcLe
Y7kT4BbNR17vuK7Qd88n1G+EB96nvJ6EexTXNrYHcG40SnZIcW6nPgmxJ/nS
SP0g+xTtdVpzhF5H7GNxEuqeZJeVSbHANU/qfaxO4vmgXto6GubQFYHtcl2K
zYf9gPJc0cRtYfucxIGu4XVWrqNWjid/1kP74yKf+1LfSn0r9a3Ut8I4p75F
62fqW5dS3+J60/eKcK+KNTp9r6Bxe5Z+r8C2455H90hYG/Bzb0tHTp3uWaN+
d6KxDjcWzDV3mKeds/wdwVqqB1NsLr6mRpQh8XHdnC+2xuqg62uiOs3vHI89
ze05mWeTpbbszNmbsiz7XfaOd9+bx7HFUwNQa3Zs9biaf+CRR+mdT32rWvO/
f/2/1TwQ/NZyWo2cVkUw9v/+278pnjNnbzTjbUhvmx5ralXzmu8m9U72T86z
J6cHHn3U6bT0wCMfVs+3G/17jB9//93vKrK2WCJ6VO62Olz+/ruPqzUWI6C9
7nf+bPTj8P8Skuhz7zuRveq2I1lrV4fDdI/FJMdveqov++6fXEPWwPu1V456
PHJaWxxWc+uLBw1GHgvQAWTxtM+1nBfWrKk1Wndrd0f2gdctyvog1vm6PYpa
1RzYvqexjdjyqttm1JyN7XX5WtDPff/Y3avG7zYjV6+/4+yk81nbxvxQmOo8
wP7Aun/63PUM3+PZXz98Wq9rQDmbP6cP92Vfz+e0HzNOlvXL5UHO/6pbjxDZ
8NvztJgYHDQxGA6w9jHQ8YW1PK4g8+4/OmZyrM3l1V7ze68ba89efdtRtWav
yzlPe9EaTK82ccGy7dPmS2t3Zx7/pTD+J0bp/Vr+BGyBrmhoVmTnb79uMvtv
QRxOKLy1/35/QV5xHD5295qy4woTY7CvbX9X9rG3r2lZ951Q9Qn8tjVrb06u
5jV3CvWzQ6iDaK45rIVyLS/qAbjuSjXY66e9qBONS7WZ2oh1eDtDG2qkdc1a
dwwbuZeGPYu8N3eg/snxlX2xGFBbOtF6jNNm+m3MP459KKtGHKO2aZ9p3ih7
Ue4FedaMzyESRliH7FONO7NUO4dIZ4fY2aMoXgU4N/Nc53upWD7HoQZh4/ND
ym8BF+F8lM59fD/G8kLOHblG8D3fyeKNsS2RQyzu8bwpwr9anZJrsM8zwb8g
r4rwYjnJ8Khp8fm8l2PWLNkq5UssH4Wa0SxhUZTLMdx9rH2c8J6X8jK+J0mO
Nku2hzWBxitWG4v2B/rdzPVUo1BWvDbLdUnKzRrBNylW1Gdqm3SGCM4PzdX2
npBXwXlCim9EX5RXii19j9Wa8CzRoXpgWLc7L4FzX+pb5fclxST1LQnzEL/U
t+I+S7H2cfI8qW8V5EBBbqa+Fb4/M/pWJ/sd5k76XpG+V0h7qbi2PHu+V8Sw
cbWsWbATjdW2dXtq78qfXXTMjrd3mznz21I+X+fGhLVt3WitHevK12AZSG6b
l+vG27qFp9XNeNu7Qz3q2WX86KI62mW5IS7cNqO7Hels7cz2AbWZZ6uvVffc
+151n/PffvzjbG9Tax6DNve9fG9jW3bPu9F8ox6raWx14/e8571ZV/9BRfe8
5143ButrcrrqBn1P9tCjH8muzn939Q/r79Q5Kd5cP3yr3gffq3O6xvADb435
hq33pf6mDbLtOtAJ9i6uHVf2Yd3aj3Zzj/W4eq9paXd0taTH1IS/f/xxRfB7
X2tO8MzzUhFgZ/HL+eH7+wffsJRVlkeyytJItp7T2SvHsg++fsndYQwP95pv
89qug/k7jMNdy8x0v8L94Eiv+p4P4+093Qo7WLO+OKLkVJaGtZ2K2tTz8/ed
UITHwHewwd672Hha2XeenVLvwyM92cfN/cHM9KDDCwjG4D5lr8FcU1v26tv1
fQm8t+/vVvaDfqsHbADfv/7IaTVn72LgOTM9oLHKcQH7Onu6nD/Wj30tKA7N
Ok5gm113UOHYqp4fNHcysE7lrc3Z3AaFbW4DYDc8fEDbb/3KfbBxsP7APVD7
/i5Fduw1tx0xMWhzMYCn88ngYm2HMfARdL/9pcfUbxgDnO68/rAbtzlWo/Yh
yiuTY6+5Xd9j1bTq+rrPPN27GXN52YrWAH7NPo/1U2Ps4p/bUpPbBTlp749m
Dg+4vb3X3ivCnZK5N95j7ixVHHLcYW2NwmVY4az8t/dPCC+I2fDIAaX/7Mlx
pf8FoN/YBnv+429fV+NnT41ns0eGXK2qbe3Kn13qvRbXZEN1pi7W4VqI+0S7
qa2u/tI6T/pFW+QZ/O4Sekak9uP6G+tfUTm4D1k/8zGhD9WRum94kb0LlZOK
xo7OZd0HR53ssZlj2Znrb8q6h0adjIXKlQ4bGAceLAfbA/8dwP6hUacbZIMO
i5XiN/Z0Dx1S/73A2NFjxFbQp3Rg+QgvWGN5wJ5aZ+dJZ5te53GDNYrXxAp0
gn7ba7Vdmnf/QWvXnMKgrl3Pdx885OzQmGhMQefYzBzBdzx/Vzz2zNHerfSD
XJj3+g1GDlMtf7/hHVNyTjL89O8wFlcaXEeR7i5nr8XZ7g14937zeHbnPhzT
PiPddfzM1E5/W9keC3amCvZPl5HZRdYH+Z7OfZHawHEJ4xLUnQg+ZJ7UtRhW
tL64GoxrsWBHneGpE+Lt6zjHrZvoiNqD4yTOdwW6CmPbztcw2VKeMx/CXOgq
8AXbgfGgOsk7t4fnIelTsu66dpR7PJdE6vJ71+0vipuLr8OC4Sj0bbIX2pk/
QZ6yXJX2MPO7jmOEc0Baa2uUs0vIoyLsi3I20CXFFGGF9RJ/fF6SPSXVA26j
4ed7NbCD7yuSO1hnDAuBGG9dINufY4K9xOJ2Mc59qW+lvsXrSOpbHI/Ut1Lf
Qjypb4n5k75XYL1dLj5hbnvbeezqSOyEekdiwPcty2e+h4OcwrZG5lkcw/3G
YyX1SlYHXa/F2KFcae8m79yOOo65w5L2kTpio1SrqN11kr28vwSxEPzE5wi+
h4J6xGtxGLun4nsFxZbncFHd8PIaOno0dQLt108yhsbVc3/I2ylQbFxax/VL
/NF3PF40x+3b7/V2lNETk+2pPpdZ39Gd1dve7WpmZ/YPjz/u/kxT9+CwukvY
Z+6V9jW1Z1/7q7/28wPDbg7+fBXMqfcWT5/58z9Xc/q7fEf2znvfp9bWtnYE
BOPvfO/70Fhnds2Nz1Pj8FTfsNV3bPPM5f2DuWOy8rX+tmx8ZlbLu/e9yB59
JwVrsA6t52at54abc7lIj8EEqK4VcrYTnWu7POV8MA/f6197x6y3VcnSuuC7
PMzf//pl9b6vWdt8/xuW1Lf7zt7uAL/O3v16fYuWcWJF3wnA0+kwWHz+visV
WV67zq45vjSi9A2P9Om7mduPOlysLY//yTW5PWBfu5HRbnw6GsQLxmDOvnfl
tvo4dDjZ158aV3yzM0N+7e10LY6F80PFoEPHweBodTodCC+w3d5/WTuOLxvf
8yfwW10w5zHQsh7/5DXqHkWvbXe5D3iAbC5Tx6Cd+KBtP+HGLSbcz3e8bF7F
vM70EppL/gm5BLpU7rWZPIOne++iMvAaMm+wzHWPHOoPYmp9AwwgH3EOunvF
Zl8LHNYkXztUvlpZNv9IPNG+6OrrcXsMbKvLx+3+sf5AjarPe4GuWZrK1rmg
Lkr1M+ghG6nXTJ7YK6TeFNEt2sH6kCQ36gPV+bFPfjr7xje/pZ6/+c1vs6vz
mgpzr3zdm9T4Bx58OHvy+z/IekfGlDz4bWUB7wcefMi9q7mcp3d4LPvJv/ws
+8ADeq2SmY9ffYPAnz/vftd7si98+TE1Bzpf+fo3qfHbXvQS9X51Xoe5bqBv
/J22G2z85a9+ZWyHdX+k5qwvet1+5YOy60Fr181qHN6tjbJdDxO7QOfyiVNq
7cTsQgb/KHzyOeAHsviCDGsnyNBx0TaBXOBx+h2mDzsfsc02Rhw/ha1btx/F
Yn+2fPyUWofXKJz/zvqzP7fx3dRGkx8Yb23jze7swWMBpDHpUZhADpTK4Vhe
S+c6cY+kc9/G9ZaJRQQPrL9aDKLxKGNTzL4CW7m9GCOFncW7hA0dRTJj+CMb
o9hFancR1tzmwt5kfJV4i/RLeR7k+AZiF9Mr5nVRvGP2ST17k/ZxndXqQ7U6
EYxttu5E8qSoNpZ532gsNxTnKrxSjGLnl9JYXSLnvtS35PHUt4ptTX3L+yrx
pr5VTmfqW+cQ5yq8z+S+9TT6XlGMS0+op9p+6eiR7XLjJXEjOJeoo9H44XrP
bdtgPQ34Ir25Wg50FOT1ZkjsrzE9HM8YvpEa1lGUWxGbSu9V3t/L9Ge2h/Pf
zd0Hzhs1ieO9m14vy7tQVM1uNt/VmzUp6skaO4FM/OGusL1L3eX857/+unre
+ZKXZnWtHZ5aOsz8X7t5+FY9eXRO4O9U9IJ8DOYmjx7L6ts6s3e9V99jwXf1
evVNXj+BYBzm69u6FIE91930fDV+3c3PV++atK3AA7b+0z//2MmoN3rrzL2Y
ktfqddg7Ka3DjoMefV8G+uqJnu6c/4nsH554Ims050zArNHkMoxhgu/wr7tz
DtnapeRZnz70hmV1f4Ht/ZtHzqhxi1k9JmQjPK9c0X8OBp5qDMn+wvuvVGTf
LV25csisOaRkvOjGafW+v68nf+9AOjqze14+r+4yvE5/N8flvs7cl3AZnG48
PaH4jh0dcn74tV3OD4uX9QPH2sbbrutWttN4f+G+KxVh7LjvmFSswK+cd9Tc
7dx4asKtt7G44ZS2f3S0X5RZ1ybFAOui+IAv97x8QeVBQ0d3kEOa9Pjr81wC
XcBnee1vTHYN/HZrTP5S6spe7OLfi+Jp4v8yE3+UgxZXu7e7D+g8f+ENh8l+
l3IWdAAv6Gxg+4rbBU/gff2ds85/2GdNeZ0CajS1ayO1ejP1uSm6rleQWcaW
3sjvjcqJ2Siv5fb/9F9+5n5/8bGvZNfmtQ7Wfu8HPxTX4/Frct77H3rEybVz
8Pe2vvoNb1a/Dx9byv72m99Sv0H2/Q8+Isqy1D864cZBtrbH8zdFbNe8zzO/
Hw7Wxe3qFfUU2YUJZAJuWq7GDfNxfFdPngl0YP3XIkzt+yc+9aciBliGX9cb
8aE3u+MlL1N2VsuBajaG8rXOT3zq00o+YAvzgBnMbWyv8bztFfP2fNGz+txX
Go9zwbL8uvODXczHMtj0luQN7Y3Zvtlafu6x3oysjft97nZtNGdD/gux58rm
aHVb4n3/fGD61OXb+fKlDD+Xe/5i/tSd+1LfOj95tDm/Ut8qH//Ut86HXalv
nc9Yp751rvEpG/en9/eKjcdEllUaz65zi125mlO9VmzU12LejdXNc6UyGJTL
0/NFof84hzei73zY1tbbn7XnBM9WQ229A+rd0wB7RqinYM6sbQ3G+wK57SXk
tgvrYjrjtsnrW3skOwYK/WvdD+v68ueBrGV/b9YC8e3qyWl/dv3zblV3OS98
6cuyf/vFv2Wf/YvPZQ3tnYrgm/RZc6e0euJk9utf/zqf/ws1d9bcAZ01d02N
ljq61Jidg/d3v+8+9a6/U1OCcZiH79dNnZquf94tahyeTeabdnMnntfy/+rr
X1c6MHl5Xe5+4LtPPJ7TE0pfU2e3ktGcP60ceFrZTV2agB+oubtH5X5rTi15
zQPsWmwPAwzzefgO/4YXzOm1Srb9Fq99fPFNRxRPb/8B7Xe7vid64I0r2cnV
0ZzGslNro/r3mqbx8QGDSXf+Pqb4T62POfubjPwvvv9KRfbd6rRr4NmI7jkc
9u0+BnRO343ou4U5J7PJ2EJ42z0/6LnpzKSafyfc13z++uwbj5whscZrm2AM
xfSL7z+pSMegx2EJdGDggJL3N4+eyXVMOYxOroyq+0DwX8Xb5B/Mad9HtR5E
/s4E8eW46/WdJm+6EH6j2r9ViifGysYA64FYAy/E/g253xBrWP/OVy6anNL3
9DafWlzN7clz6Zji1XvUUKehHBf3jub9mv2ELI6QnzCPcyeIi4qn9t/7pHEF
jCx2Omdxvo6pp81vyFOfr3RfNTH7gPT+Oeb2msIjr1Wt+/t03VK1K1ZTB8Tx
sJbjWlutNpehgbwGDwiyq9fwcn0q3tdaC+Rzv7//wx863g89/Gh2Nq/38P7L
X/27egf60lf+MnvBS1/O+PsVL8xruQNuzsnpQTp6Bgh/m+MfyGYWl5UOeP+7
b307q5y+mspxtv5IybR9Hmz6k09/RvHBWs07EKyDOxUsz2LwfTP+QD5+veXv
0fYCz9HFFdEujOVPf/Yz9Vtj9Irsnnvfp2yy+q0ObhfGEY8TjHr8OksQFxtX
KRbtFtsf/BDZOhDEBZ8PYrbAeLtgexuKNSfA6bVveovCCrAZGp/K5PNHbK8K
cz1h3qdzH9vXmzj3wZ6kPlGcid9ITqutqZLsoD5Vt704NnL9tvLaC/XhuYGC
94I4VqH2AEeEQU/IizFtZe98X+oeIuVBMY54b/AeFORyD4uj9Jv0xD5qJ/c9
4A9zsb2nP56XPQW9uWzN4LLFvVhCtvO/L863gT0qyu+R4hKrZUUy+P4t8rUI
Y4Enlh/IPlnegCyjNMX3fXGu2bELfe5LfasoR8QcS32rCqapb4m5nPpWXHbq
W/GcYPalvuX1Ph2+V5yTLURufN+ItbFUX5ZrR9jnBwpj19pDZfBcbO/Fdczj
FMSvKpZCPyzVlzC/lNPl64D9vtDWE+MfEPpLnNrJ+pJnKQmXDX2v6C/sC5iP
5roe7+wbzGkI0WBI/UOMR+ItMx6Rb8f77RONkTUxGZyXyTPvHZK8fkkHGwM5
lkRbBrKOA7n8A7qO6V59QN1ptXYfyO697wPqLmfg0Fj2Z5/7nLrLajL3DECP
fvSj6v6qqaNL3evo+S53B3TDzbeoexu4F7J0g7mHgid8p773vverd8XX1ZO1
5GOaetQ4zLeo8V71Z8dueP5tev3zb81t7FF3SGCrfvYo3he//BXZ47k99u87
xKTl7TcyexQfkH23BPKtHnhvNfdVQI8/+aQifVY4oHDT2PUp/Bzt139f3xtf
eIzYqO3sVXLPrOu/Y+/M+pjBSt99FdEbX3DMYeLXjzuZinIdX/zASUV+3Ooc
Q2v2K3nw7v33+IRzPcgGc69g5HLe/sH+7BuPntH/H7DPX69s+eQ9FcUHc1gm
X2txAvpSvg6IxFvlqPZp6dghJRd0cKzgvqXZ3HVCvp02eJ3OMWgh+YbuTHJe
j9GYmnN3RZ371Vo8h3mbWR75GOh3sNXa+cQnr1VzD75pNXvp846qfFHUg+mA
f+Y+Qy7BWp1PB1Be9aK9APj0OnrjC+fZGsrrZfa4PRSLC/hn7xUtJhaPIrL5
eWZd/1m2M5UJZMuB0HZ4z/3V+2de+Q4YtPf4Xt4BlNeuDqHGdgV1saAO9+M5
qX6zmm35cX/p92s7iIxYP5B0cPvQez/WPyT0hCJbZb3/8rOfu/cv/+VXsxtv
uU29f/Pb33E8n/zTz5rxIXWXNDJ1RMl80cteoeasjVYW/HnX17/5ber37NKq
kgvzIMPydzjdQ9mDj3xYyeJ+w7i1x8vneOrfnteuu93JApu1Xffldr01sMvr
H8xGJqcdvx5/ZTR2IEPh1K/xAppdWlO6tZ8hvrDG2WTiAnpuANv7MUY8VkPE
F/sb7IU5FYvPfNbJVHr76XrwRftPc8zjOmhsXAtsB5s8RkeI/XbtiauuNTYd
UXIs1vKZB59zhLOMeLaR3tO5b1PnvsBerq+objEb+ofo7/6Y3yy+yLYOETNP
HWXjR2pdEeZFsY2tYz5H/eTjMRyknC6aL7N2kO3LAv5IDhTajn3ul/iq5E21
/VQG//6IbUVY91dby/OozL7R1EX2TlG8ByP6i+rURmrTRvOlTDxwbZD2T1xn
l6Crq5+vYTKD3I3EgeBJxy/OuY/Li+mtgnvqW6lvVd2LsdjG1jGfU9+qYvMG
9mthLLjdRfUlglfqW5uMB64N0v6J63x29a0YRpIdJfIvyDmv93x8ryiXM2zP
9Usyi9aGPsl7ZKP5Xi3Pq/m8kb1SYGeQO2WwpPHscDks2Vsyh/q9zK6gxpXF
rWxOsnysinNEXvC9okRekjWhf/sHh3M6qJ8DiAZjdJD+Hjho1hwM10myBiQ5
gg6Qh+1y4+iZU7f53T0gyTwY2juI7Cz0M/S1e5DZ4eTkcwNDijTGA1knfBfu
1f8d1uNPPpH9809+krV192Zveuvb1L3OzPyi++7/43/+5+yvvv43+e/u7N77
7nPzx0+dUb9vvOUW/W28qyeX0aPk3HSLvh86cebq/P1A9t7367sy9Z0aqNtQ
/hvGYR5+t/f05nQgu/kWfY8Fz/b9fflYn7a3p0/Nu+d+TW37ezXlur28Xqfv
8SeeVPdYeq1Zl+u6+VajJ3+2GbkdPfrb+RNPPqmoE+5Tc7wUdgc8fpY6Dui/
m+5NL5o3dlnb7LM3u6oyqXiuOj5pbOpV9xtveuExZXOrsR3o8NSw4r3l2mm1
ti238+oT+l4Ans7//frew97/WF3t5i7kquPmLiF/wvubzD0H9t/iAbb/+PM3
EHycT/stv+f1cnqzh968lv1TvnZlYVT7YWOM1rQpXb3UBuOD9+OU86PD3F9A
fno+b0cbirn1X+FnxqzvV1UmHK4275RfcGeS/16ZHyUYaZ5eg5+OGfDgd3g6
nHo0js4Gg+sTn7o2+9sPX5UNDg+4nFB5daAvzyeaPy6f1Hi/yqc3G4w1JqeM
fP0E26cPj7g90ZE/O3N684sWDLY+h+0TcPRxQ3vH/IY8dPE3GHuf9N3T4amD
xv9xt9f0HdoBdT8Hc8rf/H16asTk8BFnY4e1t7fPUL97B17wGXzvVKTPfEDd
/UOmfqF6N8Bq78BBP0bm9bN74GDYPwZo3aXyI/0Eyw5qNB8X+gOv0a4PCf0p
1qMkGhD6lRn79Gf/LPvWt7+Tffozf5b99re/zW6+7Q6l/yWveFX2re98R89/
57/oHpXTD370j9ljX/1a9tCHP5L97Oc/V7+B57G//KqSAT1tdHpGzQEP8N98
6x1qLciGcc3/NcUP4yevPqv4gP+xr35V8c+vrhtdXzU2DSv7YC3QTfkY8MNv
qwd45lcrzkZYB33Pzo1OH6V2Gbn2/aFH9RN8J3Y9+hFkh8+lN771ruzd73u/
+w2ybbzU75wX5r/17f+i7IR7LhuvmL3gO8Zo9PCMWg82KN8Bs0EvQ47F1xAf
zXuLM8gEm2Fc2ZjHGNaoWBsff4Pw/sGPfqTyhGDE9hLwAcbgwxuUbHTm4ecb
t/fCfdId5GrRfiuzD9K5Lzj3Id5uwe5uws98M9QtxpbjwH4jP7qDnED2DeCa
y9azuAU4YruxHyIf7wsHkQ/IxiAnYnW+SmxITxJ40Hh3LL8BG4I7taWb24X3
mvEtwN7xF+T4APsd2ycOOxsf5BOOG48Pk+1zkPVvbkNRn5V84jJ538d7QIp3
2X0Y2FWAubS/uf1oL3UTX4X1OW8P9y9WQ0itYj5H685BH0t2num2dQfvLzFf
sD6p7g3TeZZfsZ5yUc59qW8Jfqa+RdanvpX6VnTvp75leVPfuoB962n2vSKK
P6vp4b9XSjFEeznWlyW/GNZ0L8h1uXuQ2hucFQzFxrkvgX+BzTj/CuoF6SUH
yXpS/4rswjUS9zqpLsTyS8orvo+lmAzaenuQ1habIzwX2V7ye5/HUN6jcl4h
PYX9Vsqf4ezAwUOahg/536VpJPKbyutV76PheqazN6pHWLthu0eE9xEmZwTJ
G0XPkUI9vUMjinpyPHsstvBtGP4bhL4BdY/z0Y9/XH1nHhmfVO/ve/8Hsvbu
3uzowpK7F4I7C3u/9Oa33aW+1//6N7/OPvqxfG3vAf+tOieQB3Od6rv9gex9
H/igWqfuhHr7HME3bKUvn1dj8A0753nebXeo8bfcdXfWdWBAU58h87uzz/Bb
MjK1vPu9rgP6TuoXv/iFHuvrd3rectfbjZ63K1uxnl/88hfZ3/zt3+ZYDSq8
fC7nv/sNhooG1Hf4t7x4IV/X7+zVOgaUnmtO6DuQa05MGUz6soffsqbuOjoQ
HkAvf77+O95mjhzSMnKZ11w5pcZefssc87lf3ZkAeQz0uJWztjiudMIT3m+7
9ojjsQR2fOpdJ8ydipYNvGCjvsfzBGNw52Hx/fIHTymyvgaE8LZ3LVZWl7nL
gSfIeOJT16EYDJKYOxusPIPjl/J1X1L6+9yYx3vSY2JsUHcmL5534+DLva9e
DuyGMe9nv4qdisHz55wsKxfwV/j1Ih25r50oH7rVncyAyR1DNqcgv/rNnU3+
fMtLFlxOwW94vtkQ6IK5V+S54LHqVzwwfjTPG4Vdv5nr1/rXl/Td3m3Xzfg9
ZTB18T9g7mzzp49rn4s16NZY9RG8ISdUDvb2K5kgG2L58FvXvR2c0Ljy9SWL
yne1v+CsO3jQ1Sxbw8QaOMxrJ6/HQm3F9RL/HorU92Grp0StH8Z6RwUebo8g
h9dzaUzqIQGf1nXmuutzOps98pGPZs+/4wVufmn9uJrDctR7LuP5d9yZTRyd
02Nnrw/4gEDWxMycwwl+L+YylypYrrYB5oAfdFqfiD3DWrfls37AmOMx8dHr
XhjYHNg1rHs76JyYOab4ltaO+77J7Rqm+WXtgffx/OlsN5hQHM+SeP3wR//o
3rG9E0YOxUjbLMaC+DNiYnmDnL/INmxrNNZnz3q8TaxIjA6ycw/ZN1XyuCjP
ic2jkfEyOV9N77P33Be3aTSCcwQrXiuHuX0xXZavSt0U5URyR9Rv3odwrBA2
QzEdVXTZ8WiuIh1FPUjCsQgHm5PDjAqxi+FVsBcIX5X4cBoqEVsJN77/RAp5
Azyq5k9krmrNsvwlfCqyg+eew8mQ0KODOEblx2I6QmVLOgqp2rkpgqN0Zoqc
QwpjZXEX5y+Rc1/qW3FsU98ScCnSn/pW6lvV8InFKcaf+lbqW0//7xXxOBbU
V4xTqf6ife0tm3PVerykcyjUV8iP66jlH7K/BbuGhfwyFNSpol4l4lXC3mrk
cr3grLQR2cHeCTF5Sr5XbMZexDMwMqb+vjtF5ne//W3eBw+FPME69z5OKR/v
V/PjaN04Wzvux0bQGJY5Iui0tuW8g8SO8bi9WMYhbDN/9/YPYhucLd7e/mHw
cTTry/HsM+fN3sER9d9E3HrnC9Q9zstf9Zqsu09/1/7JT36Sff0b31B/xgPu
kWB+fsl8u+7R90Sf+/wXct6+7I8//nH1fsvtd2T71bf6AfX7N7/5dfbHn/hE
tr9fj73/gx9SfPvhW76iAUcw/v4P3q9+7wfqH8pl3KnG4S5pcW096+mH/4Zj
KLvrHe/Ifw9l49Mz2ZPf+1525tqz7g4A6P33az10fEjxaj0fcrxjh49kP/np
T6meXAfgctc77lHjd93zzuzA4HDWp84/w56GhtWZqDd/9g7qP6fy1j9aNOu9
XmvD2ZPTigeeai7387qTh933e8CpJx+vrExmT37quuzL9592du4f8Othbvbo
qJab4/jKW4+5v9PtrUoOyB7KDo0NZ3/34asVP8bHjjkZ+Risg/V3nD2qdGka
cnKdzQNg34S623n0LRWlH2wGv2EMbLf6QTbIBTuUPDXudWHfIJ6A2ZfvP+X8
sDieWJnKjudy4fcjb13PXnnbMS9P4WoxXFAY2nyz2MJT55Rfg7EC3e99zYr3
s0/bCb/Bp/e9ZtXZTmIwM6r9zMnGAJ427hC/v/vI1dno+IjLqbGJ0extL13W
Z2nIn4P62Tdk8knd1+h8Akw9Tvn6vkHiw6fffULZdwjkG/ze+kdLas2fvvvK
XO8hNQb677j+qLYh5wObwP652TFlE5DVhflAB8QDyGJicwX0upzICfLGYWp8
BTmvvE3/+S+IWc+gvpsCex7LsbExtaT3z1LWm/P0Dtl9ltervPf05f2gP+/t
UMOCuulq4zirw+Okbg6idYOSDFvjR2htJXX/EJeb13XSg8apbl7rg77Ce9OY
kxddE/QGRiPjmdwv9O9HP/qx7NYXvDDSG6VeymWxnhfwcnvHZbkjuo+/9e53
ZFefvYnJGvdYjEiYmnXX3+h41W+xR/KeH+I4iMYHAxlCDsTyguH1o3/8P008
x9V/p/GKV78291mwQczlSL+P4R+sk84sFN9i4vKlvKLjgzbOI2x9kT58VnEx
lnIrnfs2eu6jv1Esgr3G83vcrfU65L3j9mnEl0FnK5Lh5vgaIadHIpiNhPLC
GjSeiT5HcWdrwW4xd6vkc0GtCfVxjKVaw9bwnONYCfk2aOptyFd2n1s5Fhcc
e5x7wtpY3yrAZlDMff97sLQ8KUe4/BBT3BPCmjIe8VUYI3w8twpibP2M9nxW
h2K9SsilQVRH+vmaWP0cQfVXlCv5qam/ar+RcrBajvCeIdlxvs99Qh4QG1Lf
ErFKfYv6lvqWjFXqWywWIU/qW6lvbbxvhXF5unyvkPsuzneOcSxmUm9mutH6
2PcKsfaU+F7BeUX7eG5EavFT9b3C723Pm75XSGNC3Ynllhk/ODZpaII+x+3v
iXB+fFJYh9/9uiHy7mmYvQ8RPcLvcT82HMxLNCmQ4AvhxbIlf8DO0Mah0XFF
g6qOjebY6u/CcKf1wQceUPc1E9NHs94BfS/xsU98Qo3Bnx35/Be/qO549vf1
6/uAnOBOCMaAd/zwjLsjgjshey/05Pe/l00cOZodGDyovst/4EP6fql3YCh/
13SbuUPDBOtgze13vlC9f+FLX1LP733/+9kvf/lL9fvue96ZTc3MqjF4/+m/
/DRf9311dwbvH/+TT2YHhg6a+4IR9RvkwnpL8A68sObqszdQPb/Ser745S8r
nAaARhjZb+vwPHhIfYe/S91RDDud4Iel608fUTw35E89NqyerzLf+p/89HXq
+z78huf45KiS0zek79BuOHPEzdknrIHfj76tkl25OqXuF7AceL9ybQphMZy/
T7t1X0Ey7nvtmtLTZ+5V4DeMw70HyIEnkB0bnzxkfB3OJibHlCw7Z/VrTJaM
/oNk3NINZ2ac3sfM3Y+6a8nt+sqHzjhsYP59r10lWFnb4ffYxCGXa28z9zmY
YExjrv/OxrvUu44NYP0Yst/6aePQp+wfVrErioHGQ/OeJDifcTIBy5uuOopy
6ZAmm0vD+q4Zcgn4cQ65u6789/ys/rN1r759wdyF+TUffttxpQf0whPGFuYm
FYYn1w4XxH/Y00EdDyCXzyanwVeOFcTmAF6vZIxk971uzcUMx1PHfVg9eayA
T+MyqmtW3gdU/RrlNZrVwPFYnQ3r8bBYX4vG/NxQVL5Qz8eldVJvKu5T8X4h
9SbJLm0L3M9fd+PNVWyojkGR7cOiXNyXY7jx2MSwCW38s7/4nOl9ct8sjnNx
T/X44R6r/RzC68apPLDJ/p6ZX8i+81//Psf/nYJu7rOUZ7JNPPbymiLsEN84
twHHM5YDm8FZOrOUybvJdO6L5Kh07ovaXE1WgGPR2mo1pFrMi3QVYVMNS0ln
lVwMckuWPxToqbY36PuwqKM47+WeE8OqzL4rWROiOeyfcv+pjkMs14tt2RjP
EJFdvC84L93P0jOCX1BHq/ldBb9x2fYh0Z7QL7oG8Uhyx6V9EounvM/oXuF5
MhH8jtnqeamOi3Xu45T6VgznSUG2nCupb8VskfZKRF7qWxEfYj6Ftan6Gsnm
WMzK4VnEk/oW9xHxpL4ViYeM5dP5e0Xct1jOFNU12faL8b3C53RRLYmtL5PH
Exv+XhH3NcztZ+f3iqJ857lL+Q9NHM4OTSLi74qmQh5MeEzx5jQxZd6n3fwI
5uG/ka4RQQ/8v9idzAlu5xS1fWJK9oXb7WzE/OHvESYf7BvBtuVyhidMfOFb
sLvXGsu+9wN9b9N/0Hx7hjukF+g7JLhLgnueL3zxS+hb+sHsgx/Sd18rlePq
e3f/0Eh27fU3Zvc/+EB2/wMPZtfecKO55zmkngMHD+Xjeg38+Yp+oIMj2dTR
ueyOF77I3RnBb5AzkM9Nz85ld77oRfnzWLZ24srsHe96V/ahBx/Kzt50s7oz
Hjw0qujsjTdlH3roITUHPOvHT6q7OnVfZ3jg99kbb8zO3nBTNjg8mr3mdW9Q
/PCcnjum76pyHlgLMh4weobgHtVg5facxe9QPma/sY/o/8fS3S9b0f6O2Luv
Eef/a+7Qf+Zl8diUubcY0ZTPLS5MZa+5c1Gtv/mq2dzeQ4rAfv0tfzQ7fHhC
3X8cPjyeLeX8b895gf9UZVrrMgQ8MPeim+azqXyNlqUxsFjA8+arZ7O7X76S
vTbXu7Q45eeRTrAFbAPdwGflDuY+AY5KNpJ5+vgRxaP5jql1isfYdqpyJPvI
XccVDjflsoHAxgFj3+l8HngA05uvnsventv3ulyvlqN1gO/WFu3/EY2xwn1E
YQsY3/3SFROT5ezGHJPF+SkXl5vsO/gwPOrwAf3Wfvjt/DRPHYNZFYNFEwPN
O61lDB8iuTdgcH77y1ZzX1azm6+ZUzmDa7ir4zA+OqZyDvwE38B+yA/tn94z
joYPkZwD+wAb0AeYq1jkOu/OdS8vHDb/7cG4izHYAna99s4ltc7nh/3vPHQ8
nW8joy6WIlZoPRD4oSj3aXnxsIoj2PPim+ezw9MT2p6cD36DzeDLR+46oew6
c+Ko2mfDQOP6XD4yntfdvIaNmPo5Molr7xSt2VLtRTTCay+vt7hn4N4wKckX
ZEk9g8uc9Dp9P/H1fiSQN0VrP/GV67P24nVTbPyw02Expfbl71OYF+E4McX4
pyhmga9TAkbM5wlkg/J/iq51/RnHE81JseFy0TyNJ+/PDHcbE9Jz0RjSSezA
/Vo6U+DzgHhWYVhL78oGfE6Y8nw8ZpM+5u7cIJ6TQoyD/GV8o/jMEZzPfE77
vRee2Uawf+ncx9Zv/NyHYxzuHZQjZD97v0ei+0LAlu8BkiMUuxHuf5DXdM/J
tVOohVw/33dIjsMK28niNIL3jK3VrhYJ+1KMFcPHYR7B0e4T7A/by36foDxE
+nGNl+rzCMFmiumxPKwmkdyI5DGLndgLJryN1EfMJ+UlzymOG8+DKdrngz3G
8Cf7dcrrmaB6Rgr5D6MaNxXV53iwv+IzzF+rn+gQ6iGtxdMeU3E/4xof1oGg
vwvnjbD2sdgE+rlMQQ4/D10S577Ut6J2p77l85XnDrFdiDfWL+x7nGupb6W+
FcSJYJv6Vpi/3D4ui+P6TOtbUt7EcEnfK+R9xjBP3ysiuR/B3tmA6zHatzxm
uN5MXhrfK3D9D9aTOkRzZvzwEU3TR/zvGE0jqsa7GYrJfar0bdQOgcamph1B
7EZNXsH/B2t2flHdIX35sceyoUOj6j5Gf6s+5P5sEjxf87rXq+/o+nv+oezO
F71YjcOdD6xR9z2WRi2NE3rgoYfUmoOIV3/rHlXjcHfk5KB1w0Bj4/pbtvqe
bWhMpmFDsfGQxj2NYx2T2SEg9+8nnPQ8fGcfGdP/L6Z3vHyV+W2wyH366N0n
FA/HZZj4OE5sq2r/OLOfrY9hoX2cLMSxGLNN4pz7CRgBDoHP49YfGoOYnVgm
wdDg+rxr9P8bDJ4B1iyvzhuNC5ggP1TOVMmnESPD4kT3iqfpaZ9zsRwi+2Uc
xZyTxFsqByaRrkkmYzJCsnzw5Z5XrJF9B7Vq1PScscO6hl20mnteaObcavzF
6G3n3Oc24POm+C9Rmr4QvpSQfzHz5ULpSee+RBcY1zH1xPvvwtStsXPOg0us
vkb37Tn2ygvtw8XG8YLG/ALmPcf2ksd6A3amvpXoAuOa+tZ5xD71raeYUt96
2uCfvlc8vSl9rzgvNBYZnzpyVNPMUf8bv894mjzCxsz75IwgQ/o9E9HDx5je
QF/M5jJUzUYsP7YWYzI9k/PPqOdEjueEwhW+CR/O3vDmN6s7pHe95z3um/KI
+eb/zW9+0/1df7PH5tV9zDC6D1D3X195LDs0PqG/OxsanchpHJH6Hj2ZPfTw
I2qN59ffs+EJ4w8+/HB2aEzPkfWTU4rA3rHJ3G74po1o1D5hfsq/e/JrRtm8
/p3LnjBkeMbzJ2A0PmUIcJs22MF+sOOTh41dU+47PNxHjExMGj81XXNS/3mT
P347/H+L9J2F8mvCk7MD+8RsFX2cmKJkx6dCjMamGEWwdHiy36PCmgBXrhfZ
Bn6+85XrCgvnt8XAypjycsaRTEm+k8uwBLr1Ov33NcLT5eFkyKtwx3o4NlPI
F+6/s2varR1lvCqXwBe4S85zasLUNb8XUT7Z+AJOr9B/Hx++73H3P/nzHjO/
vjyD9pnHNMgDwXbym/OxMZd/kwJGQs5ov/0duo3nqMAL9oIvkBtjZh3QhNl3
qoZB/copWpuFOmxr5aTtAbHaat4ni+p1rP/E6jHXNYN4S/QYbAvuX5NIDvmt
eGdFO8R+hO3h+th7ke/iu9SDBYwm+W+hT8d6XTRWPI4zrP/zuVifnRF0R+RW
7cdFMSF2zIrrA5wkDHi+SGeBmL0xvGdCOyaZTMknnkuxs1HAH5Er2prOfYWY
RLGL1MhYbklzUbxK+hTU4phPji+sa5NMVojNLNEXrTUFuYL5gnoj1PTJQvxn
Zb+F+HJb4z4WYx7siwjusZoyGfNdwrVMngp6nQyh1kR7V9GYNF4tX2eEnGR2
8LWu3854H2K9RKq71fYTyQXek6rEMMYr9nWeqzOhPpIHku6If/yMEt1HZfM4
ZncEv6fq3Jf6VhW7qsWvAJModtX2SCQXU9+K50fqWxG9VSj1rbh9qW8V+3Yx
+1ZhnkfwTd8r5LH0vQKez67vFYWY4T0j7A/4++WOHJ3Tz5ymj5qnGbe/7Tx+
V7xH/Rr8e5qtmz5KZRwJZM7mz9lQz1FPWA62geuI2oB8xfZzn6YRL8bkyCzF
Ss/NZodzms5xPWzzw9xp/elnP6PukE5ddbX5pjwV3Dv9y89+pt7HJibdd3+4
C/hZPv6rf/+V/j6d0wTc+6jv9PYbdE5TmmD84UcfVfLGDT++T/nWt7+d/fa3
v8ne+Ja3ZM+75VYnB2gSnuYOCe7jpo7M0Oc0fcc0Ze7v7D3eVC7HkpU5YX5P
gvzpI2j9EbUe8Dpsnwa/w0fo3SDYCN/hP/aOk9lt1y8ouv3sQvayW5bysSvV
3D9/4cbs+Oos8W3C3GtMonsy7gO2f9LYPul8mHb2Wzl2fnKaYTCtf08hzPj8
5DTVO8XGptC4JYK9fTd2Tbp7CG/j7TcsZe9+dUWPHT4S8E3ma7E+HtcpYrOP
H9UznZ1Ym8ve9apKdmJ9juZSTl978OrsTS9ZI3ZNTjMi/mDfTQ5JNkmEcD+M
6tthUnMRP2CR75l3vUrf992W5xHQrWfn1fOlKqdOqrkPvemE3k/EP2O/ygW2
X6ZDLEVbzfOBN1+pCOedJZ+HLFcRuTw5wvKaxyy39V15TtyR54a16zDC6/CM
qWFHZ4N66WviLK27Qm0N1gn1+gir5a5uH2W1t8rT1/nZQL6ty2IfiNR7seeQ
Oi/0i6PCk/lwhM+xHhX4zynmO+qVQe+265DN3H7sg8KQ9TiOBe+vhbGO9Ohq
a6WeT+IgnS+OynqDuLGeH66fpeM2r47KeX9EwJLgLGEi4HKE28T3C889fNbi
TzbGzzgEE7yW4Z/OfSXOfRJWJBdnqVwhpyXsY3uC7+/AHx4jjlOslkTGOX8s
rgSjCJY0dqjHHJ0VdeJ8l/Y1xjeUX7w+VquoDbOET6r5vLaQWs/mef3jNuOY
HjkqYO/eZwlOQY1me4Xub9rbpX0Sy0Weg5xHysUo7sw+4juzK5rTTM8RPibo
xb0Q12nApWgP8vqGa3CwF7g9zK6g5khxiNRwUg+dDVXOZEIeiPtU2l9u/MKd
+1LfCvFMfYvhIeEo4JX6lhBjjIGQI3w+9a14Tqa+JdgpYPps6FtBrglPj2f6
XkFqB483y/P0vSKyp55B3yvkPkn9F/s7sv/osXmRZo8toPcF9WeG4rzxObu+
aN1shDccl+XEZFa3q5ysQj/mjimaAVL4HtPnnJx+/vOfZ//+77/S39WP+Dse
uEt4/q23q3unRx79sPo+ru4X0Hfsz3z2s2r+qmuvc9+cLU2j3/b90Y98RPG7
u5Qj+vs2PM9cc2327e98R83/8Ec/CmToXJl1T0VztH8ov2b5GO6Rs46m2W9M
R0z/BZpRdMw8JZlzyk4guFeQ6GsPXa3ubRYXj7q7DOvf9Iyg29pqfFJ6kb3Y
fr5Wnx1mA38D2xle4jy3p4iwjKiNpoZh/x3fnJ9nco8I/oexM3XSvrPc4/kI
cXnPa47T2M9G4lCVwvwitrM8Vbk0R3NqZm7O+wM2Hj2q7CvKqVfctuLu07xv
swhXbtNcAa6Sr3PZf37oGkXTUb/D/cL34QzG4CjPjzkaA7YHHVaGoI65uj9f
vsbPxn7Pb6zWzqIa6+Q4GfHaf251fkHsFdSnBWZj9b4m2TQrrPFj1XvbhvpS
gKnXIfnKe7Gkw58JJDwEHOeLYhPaLOET2hLDaUGIGT+3LBD/JF83kktFOUPs
FXDgvsZ8L5vvxftzI7mVzn0b2V84dvKe4TLLx2Jz+Ub1FK9ZCPMuqNlF9oY+
l8G/ONd1neH9gPsU0xGXXS6vY3jpXsZrTBz32LzPB6kPFNtTbd+EazfWV0Rf
5uO2lNonG8onqWdFeCNni8Lzx/xm60OYg+X8kfagsOeCmEk+CfkyL+upVu/l
vLw0zn3VsIjLSX0r9a3qvsfyI/Wt1LcIpb6V+lbpeCM56XtFCX/T94r0vaLc
muI897+PLSxugJayOfN7rgqvND8n/MbPamu4LdV4NmOjxFPENze/4Gh23u8X
/W3YfGuGuw5+94C+/x8hdw7ofsTckeDv8UcJHTM0R/lmqV5JnpVhv2HbfcKJ
144YT9F8lAxmsxhDLNfeERpf5O/94X3SDMKmrA+4hpb1KzZfbVyyp8yacN7b
OuNywd+ruvcCDMrgQmoMl43vcYXxsH8U699sLuF9OIfyKvDD3TfP0fsisw8V
oVyj+yWOqdRryu6huIyF0jGL5g/Lh9j+s1SmD6h6uBjW8DK1s0yNLytXWlck
Pya3bE87lx6yEXm8T27Gvmp9K2bfxnpwOZ4i+zerb3N+L20Kk7LjsbhtxrdY
TKTzUqn4LJ4LvuncV5ZXqk1FMat6vtyAvRvNr3PVu9l9Gqvf5zteG9NRPa82
m3dFsS6zJpyP2yrVoHOp6XKdWQp4iuSX8ftcan6ZPAh/L0XXbw6TjedfXIbc
pzYTx9gaTmWxfSrPfaKs1Lc2htcG45n6VnlKfWtja8L51Lc2mgfh79S3LrW+
VVZuWZylWrsRfRvFdTM8MR9iObZROWXtO5caUW3ufOXy5v1+9n2vKGOvxLOw
tIxoST8Xl9h4AS3y9UuRcb4W61pi/Hx9EcVsLfJhyT8DX5fCtYuSPP0+n6+f
z2ukfmrS2KLv6vDNeA59P56bJ3dRs8cwoW/z7vs8fy4o+Za0DkzHDM0jmceM
vHnFM2vWaBk0J7wvi5oWzPvCEvHT+n0Mjy1gDDAtsLWyLL7W3295P2YJnsco
Xsc0TsSv+YVQz0KBD8ZvYv+8xYavD30PfVokcrW+xYznTfC+wOdxjvG4LRA7
yRj5vYBiwWMtxWEhIpPm4DGWk0X6i+Mv2USxC3GPreF7Eu3LOZo7R9nd56x5
+j3I98qC3ytSLsRsxfYgXKmM4rjIeYXlFuPv9zi1Ua6Hkbop1ezC2i3U1cjc
fLRfcBlLEdlL7Aky5fFyfcP4ivyal3gXuQ2CrFJ9zds5X7UPlcW+hI+BjDLn
gCJMy+Ad0nxgB8eTx30zZwCJZ6P80nrJTuRPNP6y7vlCPr5nC2wrPI+lc99G
z31V/ZP8WeR6yuZvgU+LiKJ7xPps8qkqxiw2Ab85+5aKW7WcKjvP86tErIJ6
HK6fD3TF4ifldzE+Un+aF+NdZHc1vKrtO6lHFvdKnC9xmWwfR22slsNFNkVi
UhTfahTkyUawZ/ylem2VfCkVt6K8kmwvKwfHumTdlGp2VTyKYl+lhqa+RfFP
fasKTqlvifpS36KyUt+qEp8q+ZL6lntP3yu8nel7hYTnRvtmGfs3wy+tj9XX
5YvwvSIWVyk2VO7SympOK9ly/lzOn0vquWrG7e8VRKtkDX73YytofT62zHkp
uTXLbG7Z2rQS2LaM1i0TH7A9q8SeZSJnBdlmiftBfcFzywiTxeXlbCnHcymX
tbgE7ysoFuYbsflmvGAIf2+GOU9LZo3nXwQSYrioyMwtLInr6R2A1mFlLaL8
UT4sr2gf0BPGlR42vmTmPJ8ZXzJrgnksI1wXyAY5DsNF941+nt/H2HsR820e
cHD+OZ+WnV6sa2lJto36T+0N55dDuUwv1iGtW0J4Of4lPLdM7JBk23jofND1
YonPLy0j+1hMl7xNNGYhHjh3lJ2Lyyg/l9x7aCfFgdq0QjFeCvMwnp907dIy
j5+x29qJ9prKm+BezuaS4UP1ktti4yP7gPEs4ENjPt5SLPweW+IYkDjT3FW/
F5cJH9ah+IL6v0LqMK7BtlZjfl6Lad3kY2jdcji2JNR6LlPqS76OU5lF/Yn2
HCNnWeht4K/1eTnscU7W8krQc1SsmJ1h/+P44R5D55e5XufLCpMj+L7M9UpY
c/krTvbySgz7cD3lp/bz2HJfPc7eN7nfr2Q87ssMv2Xmg8+VVeQXi8myPxtI
5wieM9L5gOqXcJVwW2H7Ap+FwpzB5yMec+ksRm1O575zOfctYR+5DwxzYuMy
s4X4gDBc5rhiWTZPZJ+x3TxGUp5IeUj3C9+vzM9laqeEY5ijguzlMJZh7qIa
b21cpjlL85r6sbwcl8/rH6+1dJ8yuUxvmI90ndinSD1aIXZIsnH9DOuNr3G0
JlG8w/oR1nUeV4sjwXx5NWInz11sE6tly2EexvOTrl1e4fHD9QTvt3gf8/tO
qvE8DjEf5Loi9W4uT46F32NSrZN7+4pbQ+sH2z9BbvOz0YU893FZ0t7HcUh9
K/UtqS6kvpX6VpgrGMfUt1LfOn99K6z1QWyEmPF/b43V7tA3lpvpewWTv5Kl
7xU8LuG+5D0nrMNh3KR6RvcFrV3hurBW4LhJNVPCisdiZW09W11dy1bXLK2r
54qhVYkM/4p95ms8P12/YviJPPu+aoj95vx4zOrD9qxwu9awfeuUb5X6tcLs
x36srFIfVo2N3L7l1dV8fFU9MS0tr5C42ae9p1iy90fmPoDmt+dfMfKtDv17
zemB3/xMsLTM9wuWuWrw9raurBhaXTXz+h37huO0GsQEEbKX2rxKY7rG8gjz
OVv0/vT3NPbbu38uWvwMH44BxWnV5xjWTfJk3ftgaxiyh+RXsDfWxRzzvOsk
f/A+WEW48lzENvMcc7SC5lws1wj+y0JcloVxu1ZatwwyV2RenEvLK1SP4llB
7/lvWnfoHrV4aN/XI/kSwcvwL1t7kX2knwX3Tcvkjsf9e2NOdn8sE7/RGN4H
1v6VEGeC90rxGPaT109avzD+a4ZCW2N2cCy5bFL3V4V4ReKi98N6IBPXUYxZ
UEtQfwnsWQ3jTmv8OrHZ1y60B9k+DHxbDeW7cd6jVteZzSGOK6sCDkwm/x3G
3/aqdXkdwpvXDz4e8KyiWDnM1mlcV2kd8+NhD+XY8pjyOirlOO41q0xekDuo
jsfOLitMVrCXVhl+OJcwBgiXwF6+X9coHz0v+ZrF7Qzn16n9axIWjC/IDySP
5Hs69+EejX2InfuCPYRyhs87vHj/F+qphL8fo5gHPkXk+RixOPN9HGBO4xSd
L7Q5xIL2iTDH/G+5rhKbWD2mdZLmfrCP2bnP+Sf0BMkHsnY1nMM5dS7nPqm2
4nqF5fEaKNkkxmyV4kDjtx6PDcqloMetrdPYsZob1DGLPetlpO7E8CL2rAf2
BbWK137s8yolXmukWrCySv2TddO10hi2L7Apmg/+rCXVRdEOhmW0BgkxK4rL
Zs99qW95eyQ53s7Ut1LfSn1LwjuMX+pbJD9T34rGJX2vkP2hdlKZ/HcY//S9
AseK5I5Q86L1RchnXEep7KfX9wrJ/iDfWDxXGc5r65VsfX09p0r+e90RHlt3
4/a94sbUs4LnsIwKkbcWzGGdFaSvQvR5ezx5mRX39GvM74psC/cz8LFSQXo4
PhXCu17Rc7YOakz9GWON1RNfE1cd2fsV9W7WrCFZa072uhvH5901p4vqw3JW
14HWkU3reszqqYS4kPhV1on/6xxrEquKw9Fi5GRX4rFYMziuEb9szUI4rVEM
+RzF3ttkYxXGlecOHVsPcFlnuWpzphLwrwW+hnnq10m8FWJjFDvk9yrKF2Vr
xftK92Ql0EX3JtNZobm4ynNzfd3Pofxcr4T+hTr4vse1JoyJj6mfWw9km98m
1/HeWUH70ObPqskznFe0rltMWc6z+udyo4L4KhRruj/DWqvrKscH5WOF78Ww
vq6T/W5rwBqypYIwxPoqDvd1xCfnsucL4mdxqWAseO55/WR9xfvp9geSsW5r
UgXVImR/2Ae8T3wv2v0R7k+af+vCWFj/cD+qOPvDmkn3ttTfwt5G6yiPFY6F
3D+5bl4bpHoY1nm7jvTtShyX8PwQ9k9bP3m+4bG1YI7nk5SvtC6E9T/MZx83
X2NCv0Ks1tdxLGyc+NoifMI8prFdR3264n7T2kHzD9cTnn/p3Hfu5z5eR2Ix
lfY53+O8d9A4ytiEe5710oqv675OIjmXyLkvGhOCeYXZEeHjOfsMPvfJfUuq
7TxOvOYVn/toT2O5GfRdmzuhfxfy3If7Eo+zVK9iZ6noHtzEuY/yVohuX1c5
PigfS577iI8VXAdQzbjEzn2pb8m2SPs99a0Ql9S3whimvoXrUupbfu+EfqS+
5etM+l4R9t1YP5B6QpCL6XuFsHelfKV1Iaz/YT77uPkaE/oVYrW+jmNh48TX
FuET5jGN7Trq0xX3Wz7vSbka5vea3UdE3npWOV7J6Tih43ascjx8VhAv/23e
j6tnJeThvBXQFY7BWpBxPMcn0Kl4C2Rz/TGqFMxXzHwRj5F/nGHj95rPp4r9
jQnt1UqF5p/nQU8rl6xn/BW2FuV1pbIu8K1HY3s8hh/hgecJeR7FEuMlxq1C
11H/cd1e8/tnjZ6JOB6AeWH8Y/ZK+Ub4KjTmxB9h31RQjhDc8O9KdD7AjdtI
9hy3tyLYGMbmeLCuxH5xcVpXczZm9Ldgl1RHYL9HYhOMV4S5wLdQXrinUE9Y
w3VZyCeUh3JuC/Epk3tSDhbkXaVSKeApsc8K9txxFOPjZfaFzTspZqQ+V9uH
IYZSLhx3NTmSq7Ga4myga48H9S4iI5qzVbAQ9ii24fhxhBP7HbWB5TjBpyje
FTQf1O8qeSLFC9st+cp7p1QzeWyL+gjHuay9Yn5E9lCQwxFZONaVKmclglUF
EcKsStzL1U/kV7Q38binc190X23i3BfYFu19nu94UX8+zuTi9dVqUQXXGckX
ppfUhIt37qN8FWpvLPfEHCxB1fpbwJfOfdzn0B/Pc6mc+/h60mdj+chqUgw/
cV2Z3JNysCDvni3nvmqYpL5VFNPUtwr32PHUt1Lf0jJS3xLWlck9KQcL8u7Z
0rfS94oCv1COE3yK4l1B80H9rpInUrzS94pL/ntF1Zou7mt/pjl96lR2KqfT
iPi7Gzsdjms67flOnxZ5JJmnC2WGfKJdp+NzgY4CXTH/TmHbT0f4sc+n/fjJ
UyezUycNnTKE3k+eLJg/ecq9x7A6hXRJMk5iWUwXiV2JGFB8ThM/8VxxnnAs
5VxxvOCD8eckx6sKxXKP5AnyoShHivJO8uGU5D8ey/Mluseq7Zdqec5z1MYr
sAHlbiSPq8WyeL8Vx1aMd1HeFGBq/RTtRe8n2d47eZLvuRjJtgQx2gBWsViD
7FNV8SuBrYrraSpfyvEYriT+p5HMTeTDKW8H8a1wn5wO4ivhJa2PxqcoZnYN
XxvLJxGH0K+g3rDY0TyQ8S3V24rGeH+K8Qq+nWLxi8mJ90ih1hkcXH4hvSLu
RFe8lp0qxF3IE+ZfWYrVqWjOnBLqqmCfs+W0vC6699z6SG5BDIRzWTr3PTXn
vlM8N9l79AwSxF+2/5Qgs7Dvi3Iu3XMfxvBUtRhXs13Kw3Tue1ad+3DunYrx
i3RatCWd+8rSZs59qW+lvpX6lpiHqW+lvpX6VjSP0veKgnwScUjfK8Iemb5X
XOjvFdE6ejrso6dOYRw8TUzPJEqU6FlIk5eADYkSJUqUKFGiRImeekrnvkSJ
EiVK9HSi1LcSJUqU6JlPG631W3bXXhi6ojb7fUV1m6c9nraKVL9JMnKRrufW
NKnnZn0tot8voC3oGaULFDMcL643jCX3MRbH4jwIcRLmCuwoWi/bUeBL1Fe+
Pp6zYcyr5XkJnoJcf+5eoAZCW/cyPsKD9gCRXyfsi03k6gXM10SJEiV6ttNz
tu9+yuhi+5YoUaJEiZ559FT2rUSJEm2eLnZtSJQoUaJEiST6/wFtJUc4
    "], {{0, 0}, {1714, 38}}, {0, 255},
    ColorFunction->RGBColor],
   ImageSize->{1714, 38},
   PlotRange->{{0, 1714}, {0, 38}}],
  Alignment->Left,
  BaseStyle->{"Hyperlink", "DemonstrationHeader"},
  ButtonData->{
    URL["http://demonstrations.wolfram.com"], None},
  ButtonNote->"http://demonstrations.wolfram.com"]], "DemonstrationHeader"],

Cell["Nonuniqueness of Option Pricing Under the Meixner Model", "DemoTitle"],

Cell[BoxData[
 TagBox[
  StyleBox[
   DynamicModuleBox[{$CellContext`a$$ = 
    0.0242, $CellContext`b$$ = -0.19, $CellContext`d$$ = 
    0.434, $CellContext`h$$ = 2, $CellContext`m$$ = 0.0015, $CellContext`r$$ =
     0.012, $CellContext`ss$$ = True, $CellContext`t$$ = 
    0.3, $CellContext`tt$$ = True, $CellContext`v$$ = 120, Typeset`show$$ = 
    True, Typeset`bookmarkList$$ = {
    "\"SP500\"" :> {$CellContext`a$$ = 
       0.0242, $CellContext`b$$ = -0.19, $CellContext`d$$ = 
       0.434, $CellContext`m$$ = 0.0015}, 
     "\"Nikkei\"" :> {$CellContext`a$$ = 0.02982825, $CellContext`b$$ = 
       0.12716244, $CellContext`d$$ = 
       0.57295483, $CellContext`m$$ = -0.00112426}}, Typeset`bookmarkMode$$ = 
    "Menu", Typeset`animator$$, Typeset`animvar$$ = 1, Typeset`name$$ = 
    "\"untitled\"", Typeset`specs$$ = {{
      Hold[
       Style["option type", Bold]], Manipulate`Dump`ThisIsNotAControl}, {{
       Hold[$CellContext`tt$$], True, ""}, {True -> "call", False -> "put"}}, {
      Hold[
       Style[
       "model parameters                                               ", 
        Bold]], Manipulate`Dump`ThisIsNotAControl}, {{
       Hold[$CellContext`m$$], 0.0015, "m (drift)"}, -0.1, 0.1, 0.0001}, {{
       Hold[$CellContext`a$$], 0.0242, "a"}, 0.01, 0.03, 0.0001}, {{
       Hold[$CellContext`b$$], -0.19, "b"}, -3.142, 3.142, 0.001}, {{
       Hold[$CellContext`d$$], 0.434, "d"}, 0.3, 0.6, 0.001}, {
      Hold[
       Style["other parameters", Bold]], Manipulate`Dump`ThisIsNotAControl}, {{
       Hold[$CellContext`t$$], 0.3, "time"}, 0.1, 1, 0.001}, {{
       Hold[$CellContext`r$$], 0.012, "rate of interest"}, 0, 0.2, 0.001}, {
      Hold[
       Style["display", Bold]], Manipulate`Dump`ThisIsNotAControl}, {{
       Hold[$CellContext`h$$], 2, "range of option values"}, 0.2, 10, 
      0.001}, {{
       Hold[$CellContext`v$$], 120, "range of density values"}, 0.1, 150}, {{
       Hold[$CellContext`ss$$], True, "densities"}, {
      True -> "historical", False -> "risk neutral"}}}, Typeset`size$$ = {
    199., {214., 218.}}, Typeset`update$$ = 0, Typeset`initDone$$, 
    Typeset`skipInitDone$$ = False, $CellContext`tt$36301$$ = 
    False, $CellContext`m$36302$$ = 0, $CellContext`a$36303$$ = 
    0, $CellContext`b$36304$$ = 0, $CellContext`d$36305$$ = 
    0, $CellContext`t$36306$$ = 0, $CellContext`r$36307$$ = 
    0, $CellContext`h$36308$$ = 0, $CellContext`v$36309$$ = 
    0, $CellContext`ss$36310$$ = False}, 
    DynamicBox[Manipulate`ManipulateBoxes[
     1, StandardForm, 
      "Variables" :> {$CellContext`a$$ = 
        0.0242, $CellContext`b$$ = -0.19, $CellContext`d$$ = 
        0.434, $CellContext`h$$ = 2, $CellContext`m$$ = 
        0.0015, $CellContext`r$$ = 0.012, $CellContext`ss$$ = 
        True, $CellContext`t$$ = 0.3, $CellContext`tt$$ = 
        True, $CellContext`v$$ = 120}, "ControllerVariables" :> {
        Hold[$CellContext`tt$$, $CellContext`tt$36301$$, False], 
        Hold[$CellContext`m$$, $CellContext`m$36302$$, 0], 
        Hold[$CellContext`a$$, $CellContext`a$36303$$, 0], 
        Hold[$CellContext`b$$, $CellContext`b$36304$$, 0], 
        Hold[$CellContext`d$$, $CellContext`d$36305$$, 0], 
        Hold[$CellContext`t$$, $CellContext`t$36306$$, 0], 
        Hold[$CellContext`r$$, $CellContext`r$36307$$, 0], 
        Hold[$CellContext`h$$, $CellContext`h$36308$$, 0], 
        Hold[$CellContext`v$$, $CellContext`v$36309$$, 0], 
        Hold[$CellContext`ss$$, $CellContext`ss$36310$$, False]}, 
      "OtherVariables" :> {
       Typeset`show$$, Typeset`bookmarkList$$, Typeset`bookmarkMode$$, 
        Typeset`animator$$, Typeset`animvar$$, Typeset`name$$, 
        Typeset`specs$$, Typeset`size$$, Typeset`update$$, Typeset`initDone$$,
         Typeset`skipInitDone$$}, "Body" :> 
      Module[{$CellContext`g1$, $CellContext`g2$, $CellContext`g3$, \
$CellContext`\[Mu]$ = $CellContext`m$$ + ($CellContext`a$$ $CellContext`d$$) 
           Tan[$CellContext`b$$/
             2], $CellContext`\[Sigma]$ = $CellContext`a$$ (
           Sqrt[$CellContext`d$$/2]/
           Cos[$CellContext`b$$/
            2]), $CellContext`th$ = $CellContext`\[Theta][$CellContext`a$$, \
$CellContext`b$$, $CellContext`m$$, $CellContext`d$$, $CellContext`r$$]}, \
$CellContext`g1$ = Quiet[
           Show[
            DiscretePlot[{
              Tooltip[
               $CellContext`MeixnerEsscher[
                
                If[$CellContext`tt$$, "call", 
                 "put"], $CellContext`a$$, $CellContext`b$$, \
$CellContext`m$$, $CellContext`d$$, $CellContext`r$$, 100, $CellContext`k, 
                1 - $CellContext`t$$], "Meixner with Esscher transform"], 
              Tooltip[
               $CellContext`MeixnerDriftCorrected[
                
                If[$CellContext`tt$$, "call", 
                 "put"], $CellContext`a$$, $CellContext`b$$, \
$CellContext`m$$, $CellContext`d$$, $CellContext`r$$, 100, $CellContext`k, 
                1 - $CellContext`t$$], "Meixner with mean-correction"], 
              Tooltip[
               FinancialDerivative[{"European", 
                 If[$CellContext`tt$$, "Call", "Put"]}, {
                "StrikePrice" -> $CellContext`k, "Expiration" -> 
                 1 - $CellContext`t$$}, {
                "InterestRate" -> $CellContext`r$$, 
                 "Volatility" -> $CellContext`\[Sigma]$, "CurrentPrice" -> 
                 100, "Dividend" -> 0}], "Black-Scholes"]}, {$CellContext`k, 
              100 - $CellContext`h$$, 100 + $CellContext`h$$, 0.2}, Joined -> 
             True, Filling -> None, PlotStyle -> {Red, Pink, Green}, 
             AxesLabel -> {"strike price", "option value"}, 
             ImageSize -> {350, 400}], 
            Graphics[{
              Dashing[0.01], 
              Tooltip[
               Line[{{100, -1000}, {100, 1000}}], 
               "current option price"]}]]]; $CellContext`ghist = Quiet[
           Plot[{
             Tooltip[
              PDF[
               
               NormalDistribution[$CellContext`\[Mu]$ $CellContext`t$$, \
$CellContext`\[Sigma]$ Sqrt[$CellContext`t$$]]][$CellContext`x], 
              "Black-Scholes"], 
             Tooltip[
              $CellContext`meixner[$CellContext`x, $CellContext`a$$, \
$CellContext`b$$, $CellContext`m$$ $CellContext`t$$, $CellContext`d$$ \
$CellContext`t$$], "Meixner historical"]}, {$CellContext`x, -0.1, 0.1}, 
            PlotRange -> {0, $CellContext`v$$}, 
            PlotStyle -> {Green, Red}]]; $CellContext`griskn = Quiet[
           Plot[{
             Tooltip[
              PDF[
               
               NormalDistribution[($CellContext`r$$ - \
$CellContext`\[Sigma]$^2/
                 2) $CellContext`t$$, \
$CellContext`\[Sigma]$]][$CellContext`x], "Black-Scholes"], 
             Tooltip[
              $CellContext`meixner[$CellContext`x, $CellContext`a$$, \
$CellContext`a$$ $CellContext`th$ + $CellContext`b$$, $CellContext`m$$ \
$CellContext`t$$, $CellContext`d$$ $CellContext`t$$], "Meixner with Escher"], 
             Tooltip[
              $CellContext`meixner[$CellContext`x, $CellContext`a$$, \
$CellContext`b$$, $CellContext`t$$ ($CellContext`m$$ + $CellContext`r$$ - (
                 2 $CellContext`d$$) (Log[
                   Cos[$CellContext`b$$/2]] - Log[
                  
                  Cos[($CellContext`a$$ + $CellContext`b$$)/
                   2]])), $CellContext`t$$ $CellContext`d$$], 
              "Meixner with drift change"]}, {$CellContext`x, -0.1, 0.1}, 
            PlotRange -> {0, $CellContext`v$$}, 
            PlotStyle -> {Green, Red, Pink}]]; 
        GraphicsGrid[{{$CellContext`g1$}, {
            If[$CellContext`ss$$, $CellContext`ghist, $CellContext`griskn]}}, 
          ImageSize -> Medium]], "Specifications" :> {
        Style[
        "option type", Bold], {{$CellContext`tt$$, True, ""}, {
         True -> "call", False -> "put"}}, 
        Style[
        "model parameters                                               ", 
         Bold], {{$CellContext`m$$, 0.0015, "m (drift)"}, -0.1, 0.1, 0.0001, 
         Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`a$$, 0.0242, "a"}, 0.01, 0.03, 0.0001, 
         Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`b$$, -0.19, "b"}, -3.142, 3.142, 0.001, 
         Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`d$$, 0.434, "d"}, 0.3, 0.6, 0.001, Appearance -> 
         "Labeled", ImageSize -> Tiny}, Delimiter, 
        Style[
        "other parameters", Bold], {{$CellContext`t$$, 0.3, "time"}, 0.1, 1, 
         0.001, Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`r$$, 0.012, "rate of interest"}, 0, 0.2, 0.001,
          Appearance -> "Labeled", ImageSize -> Tiny}, Delimiter, 
        Style[
        "display", Bold], {{$CellContext`h$$, 2, "range of option values"}, 
         0.2, 10, 0.001, Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`v$$, 120, "range of density values"}, 0.1, 150,
          Appearance -> "Labeled", ImageSize -> 
         Tiny}, {{$CellContext`ss$$, True, "densities"}, {
         True -> "historical", False -> "risk neutral"}}}, 
      "Options" :> {
       ControlPlacement -> Left, SynchronousUpdating -> False, TrackedSymbols -> 
        True}, "DefaultOptions" :> {ControllerLinking -> True}],
     ImageSizeCache->{479., {242., 247.}},
     SingleEvaluation->True],
    Deinitialization:>None,
    DynamicModuleValues:>{},
    Initialization:>(({$CellContext`\[Theta] = 
        Function[{$CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r}, ((-1)/$CellContext`a) ($CellContext`b + 
           2 ArcTan[(-Cos[$CellContext`a/2] + 
               Exp[($CellContext`m - $CellContext`r)/(2 $CellContext`d)])/
              Sin[$CellContext`a/2]])], $CellContext`MeixnerEsscher["call", 
          Pattern[$CellContext`a, 
           Blank[]], 
          Pattern[$CellContext`b, 
           Blank[]], 
          Pattern[$CellContext`m, 
           Blank[]], 
          Pattern[$CellContext`d, 
           Blank[]], 
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`s, 
           Blank[]], 
          Pattern[$CellContext`k, 
           Blank[]], 
          Pattern[$CellContext`T, 
           Blank[]]] := 
        Module[{$CellContext`c = 
           Log[$CellContext`k/$CellContext`s], $CellContext`th = \
$CellContext`\[Theta][$CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r]}, $CellContext`s NIntegrate[
             $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`a ($CellContext`th + 
                1) + $CellContext`b, $CellContext`m $CellContext`T, \
$CellContext`d $CellContext`T], {$CellContext`x, $CellContext`c, Infinity}, 
             AccuracyGoal -> 8, MaxRecursion -> 12] - (
           Exp[(-$CellContext`r) $CellContext`T] $CellContext`k) NIntegrate[
            $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`a $CellContext`th + $CellContext`b, $CellContext`m \
$CellContext`T, $CellContext`d $CellContext`T], {$CellContext`x, \
$CellContext`c, Infinity}, AccuracyGoal -> 8, MaxRecursion -> 
            12]], $CellContext`MeixnerEsscher["put", 
          Pattern[$CellContext`a, 
           Blank[]], 
          Pattern[$CellContext`b, 
           Blank[]], 
          Pattern[$CellContext`m, 
           Blank[]], 
          Pattern[$CellContext`d, 
           Blank[]], 
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`s, 
           Blank[]], 
          Pattern[$CellContext`k, 
           Blank[]], 
          Pattern[$CellContext`T, 
           Blank[]]] := $CellContext`MeixnerEsscher[
          "call", $CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r, $CellContext`s, $CellContext`k, \
$CellContext`T] + $CellContext`k 
          Exp[(-$CellContext`r) $CellContext`T] - $CellContext`s, \
$CellContext`meixner = 
        Function[{$CellContext`x, $CellContext`a, $CellContext`b, \
$CellContext`m, $CellContext`d}, (((2 Cos[$CellContext`b/2])^(
              2 $CellContext`d) 
            E^(($CellContext`b ($CellContext`x - \
$CellContext`m))/$CellContext`a)) Abs[
              
              Gamma[$CellContext`d + (
                 I ($CellContext`x - $CellContext`m))/$CellContext`a]]^2)/(((
            2 Pi) $CellContext`a) 
          Gamma[2 $CellContext`d])], $CellContext`MeixnerDriftCorrected[
         "call", 
          Pattern[$CellContext`a, 
           Blank[]], 
          Pattern[$CellContext`b, 
           Blank[]], 
          Pattern[$CellContext`m, 
           Blank[]], 
          Pattern[$CellContext`d, 
           Blank[]], 
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`s, 
           Blank[]], 
          Pattern[$CellContext`k, 
           Blank[]], 
          Pattern[$CellContext`T, 
           Blank[]]] := 
        Exp[(-$CellContext`r) $CellContext`T] 
         NIntegrate[
          Max[$CellContext`s Exp[$CellContext`x] - $CellContext`k, 
             0] $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`b, $CellContext`T ($CellContext`m + $CellContext`r - (
               2 $CellContext`d) (Log[
                 Cos[$CellContext`b/2]] - Log[
                
                Cos[($CellContext`a + $CellContext`b)/
                 2]])), $CellContext`T $CellContext`d], {$CellContext`x, -
            Infinity, Infinity}, AccuracyGoal -> 8, MaxRecursion -> 
           12], $CellContext`MeixnerDriftCorrected["put", 
          Pattern[$CellContext`a, 
           Blank[]], 
          Pattern[$CellContext`b, 
           Blank[]], 
          Pattern[$CellContext`m, 
           Blank[]], 
          Pattern[$CellContext`d, 
           Blank[]], 
          Pattern[$CellContext`r, 
           Blank[]], 
          Pattern[$CellContext`s, 
           Blank[]], 
          Pattern[$CellContext`k, 
           Blank[]], 
          Pattern[$CellContext`T, 
           Blank[]]] := $CellContext`MeixnerDriftCorrected[
          "call", $CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r, $CellContext`s, $CellContext`k, \
$CellContext`T] + $CellContext`k 
          Exp[(-$CellContext`r) $CellContext`T] - $CellContext`s, \
$CellContext`ghist = Graphics[{{{}, {}, 
            Tooltip[{
              Hue[0.67, 0.6, 0.6], 
              RGBColor[0, 1, 0], 
              Line[CompressedData["
1:eJwUV3c81t8XN4sUIVsyI5UVsp7P+SCyqRCSbDKyC0nZW/aej8djy6qEXJIt
hcr2LVmlrCRNv35/3dd53dd5n/e5Z14BW4+LDlQUFBStNBQU/z9Fhpijs7Of
oKMna9cWUKKsRdpHt7T0J+juGwPX0/QpsomWnRfuJz9BpDC7xT7RdNmdz548
ETFPECNOM8PJlS/bc+hVrWfAE+QTJxn7+06VrKNh4pvz5k/Qyw+sU6LufbLl
oweEdjifoFMM+OLNz1Rypyap2y9mNaPsvHTdWyx+crdmPdacQh6jmW/Ge+Im
DvK6Z47P7gY9QtVYqlWTscrZ5Db5gtI7D1FZOXtK/EFaBW5Cp3mtcxPCovUZ
o76+VpBgyhiTcWxESaZfam+zJSqGTyycZzVoQIfHCfxpjTpKem8SEpmU61HT
6fIeocc/lAqEQlKjlOrQ7zd6x73rUpUdRmdEHmvVogARNwWRWSkVvvsDJdl4
LYp9NNQomyCj8la3WSBIoRZVKwhG/3aSVdHqTj2qKlaLtMunHgzWKqicatZh
G9xfizooN1c/0KmpbOc30/zXU4MMcurtmcQvqYRfT/uwT6MGEVZKZz8o+akQ
jofafFSpQe9HVdd7z99S2Zn3+G9QtgYVGPTWPYoMUHG21J1OEq5Bq0+TnHZr
glX0DKnGuGlqUInEcPyUQKQKq5znM4muaiSW0FDN9iVDZWjzKs7cWo307ipz
l3Nlq4TX6rZ/bahG30Slpg0Cc1V2REVbmonVKEKZ+0KnX5HKFPdcvVpoNQIi
t9q3rDKV1PFBSZHAasTvm8Zy/1WFil7ak5r93tWoILFWuVulWqX9UHrFkE01
OtluEmD2oU6FSKFXbKpajTQu2heZCjar7CQO/bFRrEb1orK6ZSYtKrpH9S3c
pauR+QWTH4WtbSrbigas4QLVaC9V8/smZ6eKVt+wx32uaqTFZHhQivxMJd/U
cCiHuRp5xR+n/W36XEXTxyiinrIaEZ5viDJJ9ams37+A9W1WoXfdK37VHUMq
WdUXv8+9r0IHe67ZYmwjKqr9l+q+jVQhgYzA0nyd1yqfFo2vH3xWhdwtaPIX
OCZUUqlMBYUaqpBnkU9Vc9aMisqxy9OKxCr0spdyc2LnnUpSzfhZjZwq5HZh
SKI9YF5lUdkszSilCp2ZZl7I41tQSTQz13cKrUKcmZ36WlPLKvNLkxXegVWo
UW/CsvX7R5Wzfhb7gr2rEME2tufuuc8q8dTTtjEuVejP3TaV8udrKu+Sr6A0
2yr0c4Vj0bB9Q0WWf4anyKIK7ad6kpmlsKUSU2vpX3WxCsU84XLvHfuqIjN4
VfqZWhX6j3Whw9z/u0qk+VzCC6V/8nk9D57oHyrTy1afJmSqUPG5Ar7Y7l8q
Ujf/01wQr0Ii460XY2X/qoTTWJesC1ah0eWuw5VuFISJlHd7P7mrkOLZOAbC
DCXhtICN5T7WKlS35GDs70pNeEuwZTtKXYVy3nz8M/t1H0F8aN5L7FclYlpM
D+b4Ske4a2E3fOZrJfrvArOpAB8D4fXKB3FYrUTTwtmjNf6HCGK37KN0PlQi
SZezS1bUhwlBtIsfTKYrkaIYU9QlR2bCSKoDbjNWibg+cxQlLLMQAuscf9zq
qkRSfXHr0obshGFs2SSstRKhnhNFpsqcBKEXTg2JjZVoSMbrBXaBm+B/ZYUx
p6oS5VWuWTil8RKGPjq7lpZUoqYzTCEZdMcI/P4fe+tyK9Hd7YMzGxP8BL99
LsJtqZXIZCXzkIWOIIFPyHV2NKwS5UzMeSskiBC861cV525XoluOuhiTvSih
F9wyPvpUoocUGyJ+ticIvMOft7ZdK9Hnax7nHsSdJHhauhtS2FcilhNZLZof
ThO6P32pYrCsRFr1Dxij5KUI3AE36DiMKxGP2dXy1AxpQle6R+fpc5VIhc92
5Fy9LGH0a9efOOVK9Lewg6kyS57w7gKn0ieZSsTOswHS1QqE9QduN7XEK1Eq
DebSt65E+Huos4EsUInKr1bnP3QiEA66sa3TcP3j83MKDA/iBJ6B6yftDlei
zuI06AtTJShEspCO7VUgKtNxbcrpcwTNBcd3d3YqEM1712O/OzQJJmqtvDNf
KtBaP82v26NaBPsiJnOlxQpU+Den1IRVl+D91y49a6YCHUxSfdwQpU+4Z9k8
sjNWgTK6W+0PchsR7rccZDQZrEBk3avFzYkXCNU3H0Yyt1SgE8/P1NnOGRNa
XtN3edRXoFbWNAlXZErol7Hae1FegY4Nv446OGhGmEhqUD5VVIEOs0PDL5or
hKW1ff6xmRVIkI/+CeZ1lfBN70rTSmIFqpz53cV1wJpAU/VgQzOyAgXkfSXq
BtgQBJzMrlP7VaC+D7EWpq32BKnu6lIbtwrE9v2/+b1URwImRDmP7CrQqv33
LYYMZ4J+iAkf35UK5JVa1Eff7UKw/K/CIuhiBVq+X5vwRtid4EL4mzGlXYGu
vWl/WPDEgxCQe3FMQbUC7Ukf9Pyu7kXIuPxL95tkBfq23e2U7+1LID00jL4k
WoE437teroCbhEZW0vN6vgpE7Ur4nC/rT3jmtUtxmL0C8dzvTfzPOJDw6qUe
4cahCmTNfo2ZhxRE+O90ccAQTQVqN/iWo3v8LmEt7ttD8d/lqPVZbMS79XsE
Bq0CieVP5eiIqNnbbtpwAjd5y0VjvhzF5QTcl30eQRCjOV9WMlmOOs43mr8t
jyKctc39QDlSjqZ3aWLePYohaHasH7PuK0fCH9bYhjbjCMZ85yzbUTkK0brE
cuVqIsEuKCuL93E52rmjrfkyOIlwT0GVebK0HGmdfmbFeyuVkJiRrn82vxw1
mCRyqginE/K3P8akp5UjE9kHt8nfMgjVF7Ger3Hl6LXajLfVWhahpS6F6mJY
Ocr465xbypxL6GNcxuoCy9Ewo4w6pV0+YdxN+TajdzlqTKAegKVCwrbYwtcB
63K01lvdndlPJFBFKUidMPvn352nVYftSATmxXi3KMNy9Pn136RnfGQCv/r7
8kXNcpQCKim398oIEsVyi+pYOUpt0LipTldJIOzFCBDlypGkzHM5a5Vqgt7V
uasUp8vRkgvHjEVhLeE6V9TbNp5ypNdxvqKdooFAM/Bio5a1HI2TkoZqrzcS
CgKPMBQzlCOwvFhvudZEUDx5RSSVuhxVqbcE/Jf0iPB6uhgifpUhy5iPz/0u
NRM84lfMb30tQ6g9JDpaoYVwgCDpe321DO1S5B2tVWsj4AVt5frTZcg/XHCr
w7mDMG1A3QVjZegnP5eQZG0n4eae9qz0YBl6epZ5yOxgF4G5Lum7UFcZOl3W
GcAW8ZxQbT3OzN5ahrzdKbiucfcQzjPznaJrLEON3G+uGw/3EuY77TV/Vpah
ZC7RAuWSfgKn0FbgXE4Zktt0axx+8oLQOKaQ/iqlDJk/NpHxoXhFMAi/++BZ
bBlqeG16dFlxhPBRtqe/KbQMEdPJc//FjhLCFw8ukAPLENf89hbHtzHCsYxL
f7O8y5CQ8yb5euAbQotmDmecSxna+YNfGuEdJ6yXiep7WJSh57GDD+I7pwix
ZjecbC6WIXClzM/umyEI0z8MuaRThiLO7xXI7swR0JNfuRpqZYgndKornfyO
YOGi9uisUhm6FhucAyvvCd+4Y16dkClDB+9/T2hU/UBIGnz5iUe8DD0OGoqu
bFog9Jy6eoyCuwxZbX/0KFlbJtjMlihuMZch6ZPRe61PPhJ+J3y6tED/z17R
74IY8iohE5O+8ZayDGkuRV3wf/yFILN+K7rvBxmd7flUcmx9nfCisJ3YsklG
NF37XguKbRKcjWifVn8ko9KoYebNG1uE/PqUzaRJMmJtf2H2UOMbQcF2kiFs
hIyi39iqSk7uEEZZ+I/79ZPRBdmLAhsxuwT3LkfcqZOMRg5vrzNY/CTQ+dZY
mD8ho6q7+RGtur8JJcLbvrr1ZPS5coLrms1fAvZG6T6hgozmJV/4dRhQYL7y
fV0C2WQUotA0IDJAhTEtM86xJpORM11Ie6A4DVaZabJLG0NGnupeMqwkWkxD
K49l9x4ZfdjNimpS2I+9250/9cmfjFB/gIj6JzrsdsWJ8zOeZCRVRIp73nIA
Y7fwtBl2JqPFjcYIm+qDmF7rn/QGMzJqmVs6KBZ8GFt2PVdHMiIjfiLV65kH
zFgob9xAhhYZyaeUcyh9Z8GOvhhZiMbJiKrrwL8hegRrvsO5F6jwD/+Guvb+
F2zYJYlrXO5SZDRc336px4oDW5srPXNNjIyGaqOyXh7kwoTwM87qnGTkX6Dy
tbKbF/Pv0LeNZiKjvjIm4QdUx7Ah3NnyxT4yao5KsSp9yI8JdIaasvwtRXde
yphdpRTEbqrmG13+VopEzfl+KTsKYYOdj3XyPpciJk2OhaNLwhi/2ui59x9K
UV1SKwtV2HFsQG2/outoKSJ1RoxG8Ypjx7oEztT1l6LHWiZzH4+ewnzVVU5/
6yhFbwSM377WkMD6u0xFlZpL0eWNnLIEXSmM75yXwN0HpWjhjsojm1hpzOd5
HM9zcin6VfVVkfa9DNZ3jsxGX1CKTsWbGMpekMW8NabpU+NLUYl3n2V3xFms
t/sb9URYKZJWMviqYaCI8Woe/st7uxQllk8JpikoY1494rs23qWon5g1wn+e
gPVoamyRr5eiMN/E0eggwHh6r31etS5FtGUVW4NfcMzzfOCSlFkpknfW2C49
o4Zxaz2YatEsRZG02p2v6TQwj77+13uEUjS8WVnUlKuJPddaGD4nV4qcp/qP
UeppYVz9f/tiTpWi0wd+OYzy6GA3tLm6hoVK0fN33c0Oh/Swrv4zT1l5SlF5
OOHnMSEDjFPH4LEZSym6uuom1idphD3TCauap/jn/876iamqixjHYH6p6C4J
qVdsU7YcNMbcdJsL3dZJSHNZ6ixNlAnWOTiaXb/0T8YDxUJ4L2Psel9Sd2ZJ
yKzrgRHnSzPMdWh/ovIbEvqzQGsyWmSBdegJRt8bIqF0vg3Z6VRLzEX/ctCB
VhLyavkrTfKxxtALr5uGDSQU/bssxYFsgx0xiPdMqyChsBLN2PU1W+z6MNll
soiEuPkbA7oM7LF2g057viwS4hv5lh/U64Cxvpy2srtPQvv33WsfsXDCnA13
zMojSSjFw3Yn48B1jMXopL6MHwkJBM0rW/e6YU6vNM7fciOhouKnL+smbmBt
RtaqbXYkFPKHLSAqyhNjHglUprxCQsIyWifuPfLCHC+ky2leJKEyeRpizk9v
rHXkgWScNgmZPLRv1TDxxQ5fHDjxCieheLLCDbo+P6zl4t5RC0kSon8W7Ov9
2x9jGuPiLDxOQl8YmMtqOwMx+0uyLAtHSf/qzbhTkhyEPRkzOHiCjYQmZsos
GauDMUbj6/tuHCShWqzx+zOXe5jd6zCKRmoSehhTFHw7JQRrNi74+f1nCSq5
19zkOxyK2ZqMrYV8LEEJcp0TxOgI7GLZvd71dyUosS+mNIoqClP/cbro6kQJ
4tDN/V2UHo3J6k77D74sQTpvJhuT1GMx4fzoC4q9JchwVu41C2M8dmRdTrys
vQR9nsyU3NtJwGhVP1CxPSpBVuxyUSIUSdjSAqFpg1SCcvlmzilhKdhb+dV4
q7wSdDXEXX0jIBXrjc5yGEotQbpYuofjQBrWPKWBKcWVoNHfFf7rUhlY+amv
7OWhJUhdU25zqzYTyw4uWmcL/Md/fjp+TSMbi32l3xfm9Q+vw8Xz1vcczNW3
POCadQmKlb0H1PUFmGWPycUXl0vQzblgTXOrIkyPk/qksmEJMuL8FSviV4wR
XOqoKzRLkErujdc7+URMou3qDDtWglxfv2FcmyzB+BgZHobLlSB5fKSYIF6K
MVk3J2ydKkGmc6Z+4klkbIOaFYZ5SlDKYZ3Qi8QK7J1JB4cKawnSF1jZH3yh
Chspc9+oOFCCgv+MzpzgrcGe/eDu56AqQSE+JwboaB5gDbp9xRE/iOhaS2en
T0QdRsz3C/y6QUQDq8nMl7PrsdR1wUs2K0TUOn9vtq69AfNNvUNDGCeis5IW
AcfUHmL2i+KzlcNEZJTE7RlDfISZnJ14yNlDRCvmjazsXM2YZkxEYuRTIkoD
z+qjZU8w+WkZp+0mIkoZe1Z90KAVO376HdhWE1Hc1dAxe6anGMfdBM5XJUT0
cqjjavvndmxXcKW/KoWIdvX0L4mGdGIrvulErlgiMn9XTMFV+Ayb7FG7HRVC
RGtjyOXJcBc2wLlx6Zv/v3tPOiYO5m6sxSX/lJ0nEd3drPxp6NSDVbXp0I44
ERGl0EVyymgvlse4O4tdI6ILfy1n+Yz7sTsNF+9zGxCRuKZlgEfhEHaDhsI5
WoOIXN+MvmNxG8asTGvwHRUiGqpvp7AWf4UZlltw2csSkW7x0fOJp0cw/Of+
rZGTRMRtIrPPBx/FpPQeDoAQEWnmNCf+sBvDBApsS2q4iYh5rNeNO/s1RqX2
1DiGnoiMs+lHLqmMY1upLqe/UxBRwuWXEuTqCezDIsc+h91i5Hzsz2m6M1PY
8xjvx/hyMUoUulwnEjWLNU0fS6qdK0Z+M99qSJf/w0pPv3DmfVuMXFs0eeeK
32GRI6Lcu8+LkddJM6fElnmM+mbvqx9txeh2GymvZuADdo/bKepXUzFa+W9L
tOXjAhZoR97+SypGwcuI9sXlZez7fs0qivxiVFhKpRtZvoL5Vi/aUKUXI5X3
8cOpDJ8w92/CL2kjitGxY11G9w9+wT5lP4/Yf6cYbRT7EBOr1zBHzF6F3q8Y
Jcv17guT3sCso0oqDjoUI659Ib0MB7ew2ZPq1oxXi1F/aL9FzsGvmMWrefbD
JsXorOq5rhXubcyYSzCcVaMY0dM6uJfY7WAjTzuV2AjFyHqpoii98DtmYGuz
yS5XjFoKSU7Gn3cxraoiK26RYvSxtlCxvvUX1m2Is/EeLUYnR/uuiOJ/MLXt
/waPshUj90HbczyTfzFlwjFFAdpiVJqiuc/sOCU0v29fF/xThG6zC7V1H6EC
2UgrsvC3IiT3sOl2DRM1SLzMZxVbLEJ3JZ/r+Z6mhSofwsCJ2SL0WfxsTNWF
fSDGOXvv5JsiJP9sfPpQxH4QtOFdk+guQv6BNYy2vAegkLaNJPW0CIULRrhv
hTAAb+WVKzIPi5DfwUuPV38cBPavOX1ypUUoXjtuvx3LYUjNVLp7Nr8IqYlK
PR76fBgOq0zJKaYXIde3WdVXR5mBPoKrRCWiCD29pWIr3skKkSeemGN3ihDp
TLlo8uARoBo2O4z7FaHm4eBRvw9s8Js96466QxG6bnL8sBXGCQGtZ2U1rhYh
S/vA2d5QLti5Nv5J06QIHWx0bAoa54aNcnYzHY0i1GppMbbZdBTc9R8x6hH+
8eV6GmoFx+DTpkm3vlwReqn5fPXxDX5YUEqXuSBShP78XhYXPiUINv/Jfrx4
tAh9WfD0i+IRgrmw14XGbP/eV5x7p41dGMaHWA+Z0RahfsXiwv9kjkP5vGNU
489CJJ51OOSPsSgUnyRvP/pUiL77h6YbRohB2lPhl08HCpG15hc+YD0Jifvs
VTpbClHR7jzjee9TEG1YUvG8shApMvoOmM2fhtvvBcIHYwtR0+DbIfsgKVjp
p6v3DShEsWwGP0dspcG0YX32qHMhEmMuUdQ1kQGZsKdnPTUKUX7k/JmX1rJQ
5Eqy55ItRJG7weuCt+WA0Tgu+ZlgIXI8LmDPRpKHT8Lmq0coClHc4hX3DmFF
MDuEc7avFaCm6xM91MFK0PPtuIbTbAFKGBIQ+b2iDMSe7YInLQXo7TbpYcx3
DA4/mB60rShAAq85B28b4BCc+WyXIasA3TO4dHXppCpYOCddtPIrQEavMh9+
plOHPqNbd/fbF6A5JdE5Iv05kFe0qq67WIAqv8ZtqnJoAMuBU/uopQrQ4i+C
UfOV83Bvi+VMNV8BEqI8rvMuVQvWpn5cMzlUgEiTZ0RSp7Whv6r3SdmnfGQp
nuWalKcH8mm1S0aT+UhrmcbJlcMASEHprD9785ECJQ/bV5Ih3NO3c9crzUeE
nLDDvXcuwJqcTs631HxEK/M3HLO7CJZ80r0FofmI2/3KuZVLl0Bh/S//5rV8
lHO1aP9HMxMgjy/q5xjkI0f6V4/Nb5jCkY6hQHVCPpK6cDNEKvkybCTlvE7n
zkcapKm70ZQWYBUQQgn0+UjN3qLS1OgKDNk4S6x8z0Mb2+42Ig8soUxGPlrp
TR7iv30iqbbwGhzhOfrwQ1ceSstpfO+fbQ2h1DTz8Q15SDl7fqDEzQasXo8o
/3c/D/0RCPqoJ20HQ23NztHBeShUSkClQcgelEoL06Xd89Avg2QvDwEHYL/p
vh6mk4ce5opPf8OdINzKmPe0Yh7Kf/4zYNjOGbY0lbXfiuYhlQ8H5PnSrsMw
B32JGG0eKhAdCbp3zA1UKDZejnzNRSmlfawjt92hcuXt78D5XGSj6nmJbeUG
RDwhmb5Auajnt21uwQ9P2CqOC7tZm4vO8odZDvR7gXWsd92x/FxkwlDGbF/i
DSpX8APegbmojzVpJtjXFyrVRc/yXM9FfulWsxNufsB5itH++eVc5E85tHnR
8yZs/55+yi73z55tHm1Mjj8ExpaRl4VzkaP0pz/HawOAktPnfvORXNQdBIHH
XwQC45kDNhbbOeiRCB+BSfIOpHW80T65kIMig7TkFr2DgcegWOb3WA6aajhr
utN1F8SuK9AUNOYgzgTQ+Xg+BGp3qL/cKMlBcl311W9pQ0Eu/OUbSM1BjiE+
Hl6DoaBW6Fj23jsH6XPbW0/eCAfLN2k6IjI56GH4rTenj0XDvK31mR2BHOQ1
E3ZTSigGrm+c5O1lzkEc/NW1t6Vj4SZD1xfnzWzE+Am5ed2Ih99ZiW8V32ej
+hGuuaX8BAg7boEOjGQjtdtBa0qTiZCkuplUXZeNWtxar+a3JAH7y7aAO0XZ
KLRS5ZmjazLkW0bbGiRlowXewvx9QilQeeuY7IZHNpJoeU/fU5YKz2v0x89I
ZiMZSPQvYMwEHWWuDppj2Sh/eHzP+U8mjPQtlL9hzEbNM7/DlL5lwdyH24G3
1rKQ9ZWxdnnKXLD3Om+nNZeFmO/orNOz58HqXxY9ruEstC9H7oycXD7sclUe
ba3JQnHKkzZUaYUQXOa3Lz4/CxETgrSlXYqAVk513TIhC0U+luzWPVwMLEYT
HX/dstBc6ssIRg8inIrcZ692Kgv1zmCJA0Gl0MA6qsfKm4UO7U+fVbtIBsXi
fLkFhiz0jvuwtbtkGWi2ye6PXM1EL30yTsxRVsCQNsWG6XQmeuz4aaDqewVc
Gh+cEB3MRP7FDa5KO5VgvWVb2V+ZidwVGK0QYw0s3ZVIzcnJRAFI8Lz+iVpw
P/TztmtsJnJdYvQf1H8AgWLJ+odcMlFEqg/1xlQdpFuhDaMTmahNOWd+PaIR
kuJksns5MtEM/4xYoGETxDaXqmL7MlEXzvghjP8h3GOJTzn5IQOtmX3145p6
BIGwp0QcyUC/w4vWT3Y9Bj837w+cHRnI4N8cHGxqBpceM9l9+Rno0UN+jbGG
FnD4OjgTFJeBaFKnX46iVrDmh4ivARmo64jts/i3bWASKPL2nWkGYv6Uo+kn
iACX2LrVejgD9Uau1SG+Z6B8xYFfZi8dSS85Tr5+9Qzkoyf6yr+kIxKTN5yM
6YKT8+1cGQPpCPsR7OtwqBuOM8k8O/gkHbXzufrUT3YDv0qpS1hZOqI3UDrK
VNMD7BlxrZ7h6Yiq8xfnf9f74HDXX7tl73RkUBE99fxSPzBseB20sklHtCE0
siUaA0ChY3b1318E+f6eolFVG4LVP8J7Irtp6NIyLs546RUsiWeV5S2lIXcW
p1HX1Vfw7jKDEeubNHR2dHt1JHoE3tZvFlE0pKFrM9899MdG4dWcvfatojSk
RWNzuO7eGAwyTGx+SUxDUuES6Q/PvIYOh3a1adc0ZFza3K1f9QZaU6RXL1ik
ocpQWXo5z7fwCJFS+7TSEA9/gpOz8jhUccUtPBRJQw+4Duo5LU5AxovLkUn/
paJPZveHV+JnIPnngMT+4VQUQ8xX04+ZhXhRbPxOWyoK0fvw527CHISECIu5
ZqeiF5oT9SyX30FQbear91GpSCeiujp08R3cnD4QYHYzFRmLAdd5//fgJrfZ
r3EpFYH9biteNQ+OtvbebaqpaHeAmrte9wPY3B/nPiOVirrNDVU+b3wA049P
XfkPpaKg4ZAw0FkE1fzYQ796UpCyV/y1BeUV8HYX8ul6mIKqn5BWfKk+AonQ
NhFHSkFVU4FdxOGPQDf3pYQ3NAUlST57YuW/Cq/4LihhhBTkGbAmJcO2DlTr
Hwv3nUpBR2JSl1T3bYAsCqV9yZ2CKs9MKGlHbEDmtaZX13aT0Uo97HYkbIJV
EYdTSGMyqpHRWAgb+ApJnnVD2sRkRHzqta5vtw3PcG0ZluRkNIk6znBRfAOR
94F/iDeSUe6YsfkBzR34LDCX+vxEMmK+3vurl/YH8G3d/BHPmYyUjtMSD3T+
AKNnTNdM9icj7kKNZeqQn9Bkqyq+tJCEZNijHAKZfsPtElLH/qIkVNUjwi16
fQ+qfQjHXyUmoaG1w5ccj1Pgc+pv47LuJKF5ctTf7zkUuNrC/ssnriShI82M
mvHxlPgBEdcvOuxJKPOKP9OXFGpc5Rv1JVbaJHRcLzFVnJcGn45V9Hq8fB/x
Wk9EpJTT4MTBvP2TxPuomssrhmuQFpfSt5Pl5bqP+tqlhJMU6PC0L2l71TuJ
yLGby6d6hg7fTegZILxORBONqhIO4fQ4Gj5hc+1+IrJ/n+KwNHcANzDaSCDS
JqKjl/Ljnncewl0v3VkW24pHz/hPCP0WYcEpMH9x+tF4ZL3XkFuWxIKnifm4
f6yPR6tlW1l6f1jw9j/OXyu84pG9xEub3BlWnKXceE98Mw6FXf3I8K2RDS9L
MVRjGIlDMu3hGWyS7LjKHZ2I1bo4tLlXXHatmh13vIgzVHvGIRai2UxUDQfe
8vskx+mNWBS5VfF2YIALN1w+bnHoVSwKf+3LPHWZG18YEcj/8iAWXdSwaMSX
uXHGMg6hWo9Y9CfjsYD4IV7c5gK1pOR6DPI5blNHfZMPpyNPaUqvRaO/iwlx
/O8E8PykNzHMw9GoLJGZIVtJEJe5/WposyYaRdcUxNtnCOKWRj0XG9yjkRyH
XfXvC0L4g5/1Vme+RCGZqc1bjpPCuKlhzE25z5HIJV91I1FcDF9VDH/CNhSJ
bP2PWOzLFcPvCd/9/a0qEj2hbNteOXgCr/zhG/rINRIVDw1tbm2fwP+UWCee
XY1Aa6E9Z06+PYmTds+SFT+Fo+r0sBCbWUlcQDDU2aE3HHlsHp1lV5DCC3SH
xJNJ4aiwznXvYqgUnl1g/WDFKhw5SJvt6HBJ44nnYpozx8JQCrX7eeELMvit
pKmBb22hKKXd/HbksiyuI3Znvf7+PTRbwP3zGlEJ773QWz/rdg/NyAxMkqiV
8XO3mX3pde6h9UP3fgU7KOMwXLprTXMPeU8dPbsgroI7r+RR828FI0lxaUXa
NgKufA/EZp4HIcVD5vKbATg+/yDcy9jFHzHX3D8ZM6iOQ2bVos4Jf1RN3hPz
+aOO5wWPmquu3ELdlmefmEqew031+dUkHG+hXTSxnyL1HN7/qZWFzvYmutL9
xDLJXAOvE/na2GruiyJYxqbhvSZ+6BC3WAOnL9qqobELYj6Pu2zjeeXjPkh7
jFUmUvU8LtyVGJ5u4oPaP47z7RSdx7OsxU08LnijBrHKozuWWvjdXJsdQW1P
lCG8/Xu1RxufCY124aLzRJR5LQrFW9q492urp8cSPdA7HRanb0d18EWvnwk/
Ym6gmlVVSQ8fHXyoWlqyJsQN3aa5I2nOpYtH3r7LkbPniq681q1/pKqL4zov
9iLvuCJa7YdVedd18aZl51fWAS6o6ZKO4PfHuniuYJHXES9nFBxZRZFroIcb
b34xp1x3QifyCpg2vfVwxg5ltTU3J/RZl8axJUMPD706ztLn7Ii04s+9zpvR
w12yGJtuW9sjwW3GtSs2+riwk2We85wduvBjTWV/iD4+J1cZbmJph5yaiZEs
Rfr4hTENE0kzWzRItDiCz+jjCox3duYNrdFbUZrSFj0D3PTL+v3Womto7APL
YqmjAa7SvihTX2yFssqFZZfvGuD7rUf880os0cD7c9P2dQb4Z6lenhTSFZT2
PuVpfq8BPkr5tD2q1AKxaw91icwZ4AUl5TQ+ZWZIzlJ7hJfeEA/3LShzLr+M
6DV9OqOPGuIuGmk6VhWmqPV9YxlB2hCXX76bpF1ljEQ0zOuDTA1x3ma/M1B9
CannygvSOBviVDGub2VrLiIONg/hl/6G+Avxy7z8D4xQ3ofzdCezDHHH79nB
J60N0TkD0eInZENcOjviObutPvpLLaoU1WSI/1byOkBlr4taLnGMpHQa4n0z
lkZfHLTRr3cPvKZfGOJpwVoZE07nkZFrjZz1pCF+jV92puu6Bppa/nKOf8EQ
37FjcM5xV0VXtbdOGn43xMMY1q4w/IehbbE/OW17hji3Yffy+3klZBBPpVZP
bYQ3pOT5NC/JI7a+2yf59xvh2m999hI/yaBLQ2f6xQ8Y4R1nMtgHZ04juvHh
968OGuHrLeck/BdEkP+ni+osTEa4cvhSnM4ED6rdON21dtgIlxKJuqn9cj8i
7ihhjixGuETQHRMa4Q1MJLgny5/VCH9gRLVE/sEKrxeT20WOGOEnii9eOf5N
ANyW3hDd/8m/uEjqAV9OwGmRc7jRP9mx/yfb0pYUfJnan/3in/7LCKFYpnVZ
GLrf/WjxH76Cmt5fhVUFSF7NrsxiNsKL//p62y6rwEoOR8LSP34RswZfu71w
GNM+F/zykBH+RNmuZspDDRYb00ovMRjha9m3nNbdz8HcwLK0D50RLrgbJ0Dj
pgkZ2/fMJWiNcFPTomlOFy3gs6G0iKA0wuOamtJPO+tA7nbHxsZPQ7yDpd9Q
zVEP/kz3UB7eMsS3PWfpL9sbwGy5aKLzyr94Le++l5M2gpEVF91fs4Z4LTs1
4FIXoF//5p++UUP8gy/HD2OJS8AR3ZnB2WKI/y0RML122hjMFLv08qoNcc6x
k43XT5nAWaOJNKsCQ1xPGncPFr8MMYNtzCV3/+WTtc5A9AkzqLq5FibqYYjf
u28smipmDnOeDVTrVw3xpi/O78uOX4FssYUzeoqG+NHKZJMRwWugfvZCvsOy
Af5z4/AM4rGGLrMsWsJLA3zpoPkhDrI1XJ99X6L+yABvP/fRo7vFBupE4O9S
iAHu3kQvJ7hgB2GZT2m7mQxws1cXHANu2IPAgU9hxpv6+LnP2Zmvdu0hVmfz
mcioPs4rLP4z+JAjVMl9nctM1seHUnXQtLwz/Bke26Cl08ebH6RsyHQ6g/L1
KZ+1D3o4aXBKIFb3OnwTP90igfTwIGrXcAVrF/Cd+eP5zEcPP+kTp50e4wZV
XTH/xb3RxTVOLF0XveEJI5WTjjeCdXCls7FUlxo9QTOYWlPngg4upSGRG7zr
CYwTy+frhXRwXpubQ29CvUD1hrWzRK82vp21TzI80xs8hPYNatBr4yQ60e13
Hb4wEG167VvQeZxqxSk4hzUAroXGs5YoncMzbAJERY0DYMshX0SA/hx+Yjr2
VWNaAGBuDlpZ4+q40XCN4Au2QOiQMN+47auOFzR97dnjuA13i7aRVa0arhhy
l8mB9w58+3imv0pYFVdI0H2VmXIPQDbwvZSJCk6l81p4ruEe3PvWsw/7oYwP
7bsaIDx2D44KMeh05Svj1+7dEKxnDQGn/k/aaitKeKRPsu9AWgiU0ReO2IYp
4mPm45x/MkKheqrxls9refzGcTsb29xwYBo2DTm0IY0bkfLkr7aHQ/vPVJ6o
YmlcWvAtg9n7cKA95XX4zSVpfPuo9iN90QigCohI22yRwgPYJBkUGyMgZb9t
b8hxSTyc5lcT02AkmDc1CAlOiuOOobKxB9YiYdtqUoHnsjh+nuLGNVrmKBD/
r5ut5+0J/MDvd/S/TKPAK13tqMS0GH7/a4/V0nwUGKwotojvHsdz5lPonv6M
BhP1fN7YECE8yHpo9vHRGFCP5fWn4hbCr87RNjbgMRDbIBnE0iSI80/5Xy2P
jAFfoz2j9c8CeOmIVUMqSyw84+jXMPLixyMNs6IS5WLB6PlWiRI7P+78YsQy
xiwWomTO+usFHMPF+8/tv1sQC0ArQv+Rhw+v6xC3dBGPA9MDQ3tC4Tx4CmYv
7aAfB5dZmRxMF7lxn7b8fdaecXAo6OOmiTY3Lt98uN7kURz4bxN/FnJx4W0P
dmhV1eLhoq3is9Qpdry34NkDDosECJ78QHQcZ8GV3tYd8AhKAIX6vEeH7Vnw
2kOFDj0FCZA5apD/Y4sZTwu6zeP3IQFcpD+Ku3Aw49YWslGjbolwbyNydvUr
Iz6WLDh/4n4i7N4SbI2XZMQ1+w8TQuoTQeOjuLasxyH8tMKXLcmdRFCbMlGz
/MmA/2QjWyXcvQ/3qR54+mD0+A39tCcLxfdBy3zUoyaLDn8fHnpE5fl94Amz
XfLf2Y8vBEg6+NEkwW85rvbYtn34wAoDj7B2EgiP1vEf9KL5F++wPkOLJOha
+e6mvkSNE/h/+t12TYLnI3EOuVbUeN3llVejCUkwsSSCbppR4Rk9zyNDRpNg
4/XerK0HBW40ryxb8yEJWIi3tfR394D+b8P7ie0kOHBHKVaVYw+C5IpVpDiS
oXTqqfUBhz9gS7qzNXclGQbczUTtCD+Bt2O78IB7MhxTrvVOu/sD3ky76ssH
J4OLz+1S955d0GK1KE8oSoaSQ7p3Wmy+g2SovJXKYjJMin+bxIe2YSW/hsF5
JxkCEyUvy0hvA/GJ8JPU/SkwFcmcwpnzFdg3WY6snkgBEeowQY9bW/D72np/
9o0UeGw6JkFntQGPbjve6r6bArVskYLPOtbBI3NWeDMpBTjOL3DwDq3B/PDg
Xa3GFNAz4qE7s/MZ+gjlct+/p8CvOevGndSPcL1JSfTX/lQoFNNWsRhfgQMn
X3DucaSCwrqldOqxFdDj3Pq1TyEVbrAgxN2+BK+2lJ+x+6fCyvKByRqpBfC6
PtzIHZ0KYhk1osuZH4DlnXUpX1YqPP3vcu5J6g9g/CIi+nhzKvDF+D/wX3wP
42UvDeR3U0E80/uORc1/4M9niyvRpcHbv7qHEh7PAWf6tjTGmQYUKZ7Jfn2z
YBHKxaapkAbJCSVMvX+mYc7SbtrEPw2eRHFNnGyYgLtj34bMo9OAqkwnt+/L
OPDrRLdfzUoDFmu+6lWJcbA9W1Ps0JwG2U8V/ZU638AS83cnv900+CEkwG0u
OAZR0THmAXTpcHXM80lI5CiI7fHo3uFMB5vkqvTT6yPg8hmXiFBIhwqn6J7s
F6+AwW7sWIxWOnBj+/YJqL+C6kkH5gSzdOh4pFXmHfAS1npit9P800F5Hy2d
3a0XcJ9wdCkrOh2ofyodawkZAqmmB+N5WelA/Mj1xSZ1ELyLX7eQmtMh+v7f
xrnBfvh2my+kaTcdXlUKFzjG90DGVp13M10GtLtrnWYb6gb56+r2bZwZkHDy
MzOZuRv8TZ3PP1fIgJpmk7WBmi7gevFToU8rAzqlb11goumCFvUE8SGzDJD1
I0xkXHsGv6UaDr32z4A3/Nbnp0Q6Ib/s3N54dAb8GKme10/qAIxvfGM6KwNY
SFf+Lv9FcI/h99iH5gyY1wpiLX77FGiWNHK+7maA64HLIvGrT0D6qdTQhQOZ
MPCw//CVzWawSuP5+4AnE1Iouv0X9x7DY7VNGzcsE+yuSX9klX8EC1wzqQOG
mVDSeMZS6upDOLzZ0y1mkwnxdJ8O/IhrApfCvBOLYZnwutVVK22vATJvRl1R
T8+ET2sc41/UG+C5vndCMTkToor84inv18PR3+c3r/ZnwtrpwW+3FOrgldnX
5reMWcCoPu7QUloFfyTnPsnyZ8FEuzSzV2IliO/v502VzoKHS5laN0IqIOxh
wT1D4yx4nX1Vcya8DOriYxpqHLLATgyyStLIMGPnu8BwKwtalAVdrWpKQZ5F
R6svOwtccBfFW7slYPdRNvB4VRaEmj+8BeIlkNRxrDq8LQsK3yvkv7Qjwqcb
35hU/8uCzfqGLdkvRZA/WDT+RDgbvsToRB0i5cEAMY6eUz4b3rymq5n3y4Wd
gJvKN89ngxiP5KLjpRwwEtMrlHHJhk9pEtyvJbPgzp78SNLtbLjFSu+6eToT
Kt8KUK/HZ0NStajGcfkMoIn47lj1IBvOTOAjtnZpIG05n0XfmQ0PRK7hzVGp
YHXmxYDTaDZkPT0d2dH0r4+8J0oIf8uGEz+utpBE//UtzGAnTykHWBLsa2df
xUMmm6LYL90coLI/k/o1NQ6efxayML+aA7TxMhHv7WLhaO6Pp2z3ciB3OnnV
TCwadLwX1n2Sc2Cf14XKHZ4o+LdsC4wSc+DDc/W+NO5IePWdFJHYnQMS3j+L
j58N/7dn3X/8+W0OhPyl/aFvHAbi5MCPOis5IP/lecVMYCiEGRvp72fIBTe2
7R9P5++BfP2vI/eMciFCmy5aTywIdD5Qxj2yzoVrnFMXDv4KBCs2Osovnrkg
l2b8oGUyACIDjnwxT86FvJgnX/if3IKcKm67pOJcCOaUNaF8chNqZ/kne+pz
geuyJr9Alx+Mq57uPjOaC2tOwT2Z2z7w2eeMsst8LsTqH0g6w+MDFGTF+qKt
XAjkOGmXpeMNYgc08w+x5oHGoiiTyzNP8B+18lu+lAcBVN1aHDxuEE/jsHrU
Pg+g5tbKjQ8uUCTvamPsmwfXMPZXBc3XoT/nln5nWh48/s+lJD7KCeaG7nR9
/5cXPk3H0szuOcLW3zBFiYf/8NpkYzjDHeAfe5HcN3mAzb4rRJV2IJGekTuy
mAf8hQx6b4dsQa03j5luJw8kr1G9gF0bcDlZ8ceXPR8ovE57pV63htavnW8M
LueDWGofvYv5FXgl0qcb4ZQP+QZC1XePWcDC5eHO1lv5MKsyO0371QwOtk3V
iGX90596WaHUYQr8a++ErpXnw1jWt573zSYgy7+cnd6cDyt2vw5/ajMGy/Cv
EVST+XAUv/v53OJF8Hz045fCx3xg6Wc8+4juIoSv7Hl5/MgHyrjhF91yF6BG
76DVDFcByCcM5l82NYRnwSyvWcQLoODwrV9hi/rwto5TR1upAFzHXbxXw/Xg
7xER+UcWBSDXcehHy6Y2sJw/Wf3ZpQAGVavSpp9qwfEAaUGh2wVghNXOl2We
B4NZAmNSbgFEt9U8/+GlAbZM58J7qgrg+OjerrPXObipqvPzd2sBSBxfqjcN
UofCUtOl6zMFIPJx+0Jbgyo0jVtaFn0uAM3ddmqtWRz66O1G3/4ugLIsbY8A
Zhw23D3a1Y8Wgkxd+0dDcQLQFPnJBp4uBLruXIqWXmXgHL1dWUcohD9m3RUG
fkqAy0dnHLUqhGqXJyUSf8/C0W5nQ6obhbBHk3vi1aw8/LykTbd8pxAQPQ+f
z4AcNHkdCKzLL4R9q60mEX1nIJliVSa9phDCHWTplydk4Mb9wdWAp4XAZDOa
I7EtDWI18VfVZwthw/Ycw31tKaBVcWcX+1IIP2gDpKJpJWF+QP/lwT+FMERX
8Ot07Gkw8I3id2UsAmJNWy9lrzi0tX4PuspeBDNqN2we3DkBJ6mdJw35iqBf
8JdsproY0KVopchKFIGFtZOmy08RuDnZvHZcvggeHC/oY/4kDIv8J3S5sCLI
jjwc5LokBM8e0NP81S+CItGCth0qQZD6HmC9YVIEdyP2CXAKCkAh9qlt/moR
MOl7rAzo8kPQiwG/XvciMPGaY6MJPAqfjiiPPvErAo8wwp76fl4wt6ySqL5T
BOTILewImRvkV+OWkxKKIC4kCamwcQJJ5rd6WHoRFN7LusC+wA6sgW5FfvlF
4JnDLBLayQYbdPrmFjVF4MDjTXQtZQUro6cP9R4WwfbDA+cqKlngReZpFnha
BA18nIG7rcxQeZxxUOhFEdgmsstnUBwGzhvBouxviuAlDflYowMjRD1cC6Ob
LYIklWZccu4g2J97qfLlcxH8MjWdMtt/AEbjIPu/7SIwdn1Npf2IDlTHHnwb
+V0E19wk2Rv99gOfbVLto4PF0M6oyLUgSAvxFRQMFUeKoZFNOkmBiQZ+bXg6
5fIWwxqHKi5ATw0Tdy/w3ztVDLscNJxCQpSg2dsZ5C1bDPiB/hQ6NQp4yCgz
aa9SDC/c21JlJ/5iKfksKdp6xfCWauWNDvqFUSyGrikbF8MJvey7YPQT8zj1
VUfCshj2/XqreP/rLqbXOkbN6lYMtbur75D7DtZCdc6a1rcYHkympvxU+4ad
0Glq+367GGKCqXbURLexfZNpfjNxxaCuOy7Eyb2F+fLTjg6nFoOv1RtWLdFN
7IOTn0RnbjF00HASBvENrGPHZLm0qhh+qx768/LUF8z3xpadRlMxRHUeWjoV
uoqdWEp8t9BWDEm3n/mcWP+IpbzpnRQaLoabnHNb1AzLmKa+vWnX22JoSrPf
jHu8iP16TjFm+18xMDx3ObLv1gJm36Q4VLxRDAFJWdm94vMY56m3Wqo/iiFk
qOThyaPvsRcl3t3vKInQ4Z3M0cL3DpNPrWo/xkqE73dsMkSzZrBPB7SUEQ8R
Um/czWv4PIUVhC48thImgr6NQK+/+SS23/tofb4cEbTS0yRu3XyLtX18cpqA
EeHIe9sJZeE3mKeNaeWMJhFu6HY/vrg4hk0Y3S/hMSMCacZHFvJHsPi+k/yt
1kTgZeQo5U15hanifXkW14mgcoz4venUS6xSkjIjO5AIpx21KcVTBzGrsnwW
xTAiPFh5uvzzSz/Gekzp/kQcEXbc3HUVbfqwvoy3DP5pRLh0QTM5YrUHC2L0
iebIJ0Jr/RWF1LhuTCqSifZxKRE0N7EpUfw5tvinKsS0lgjmwsIK3HRdmMGX
hcB0RISMqZCMrhcdGJVDyHfZPiKQb63+WE1B2OOZo76vXxGhkfyoaqf8KeZm
3LLhM0mE+bDHdMvTrRj/kKk76zwR/r47nM8m3oK9Vv/6seETEezOrjpvJTdj
0a33HS9+JULYodVCapbH2GZl37VkmhKgPqLMeM6kCSMLOsxIHSoBz4t+Ogts
jZhFDqX5K7YSqPl9cynrYz3GyFLwxoOvBKwCQr01X9Zhz2KULjKJloCFOdfU
s7gH2E3K8eFayRK47HZgcCqrBjsZ4KNroFACnDJ6JrtdVViac/W5BO0SCNoO
WrnsXo5pvdPqPHWxBMIjmFltV8jYn8uLhCGLEvhVrW23F1iKNbwMaXG1K4ED
/MHyQ0IkzPE831kGtxJIMNxSDnhPxLhRS2OlbwlUcGWaDDQUYy/lL0vp3CmB
LFHm6PSMIkzheNKJmMQSmFic3k0QzMc+558ii2WWwLNPMZdN9XKxYrZ+wb7C
EsDcH/DsT83GTBMcCp3KS2CKXj1xcTsTO0BLxbu/vgSS/wjVGHlmYO1BBVnk
J//4Ll9+gqjTMe9tJTbNZyUwym842VGTik1/8GGMGCsBpsD3Lbx4MkZDz1eT
NF0Ccm0UQhcUkrBTEn26eR9KoGuBQmfwbiJmfMn7U9lqCfCtXmn6VhWPBfnz
xjR+/cfHVMvi9tdYjJTfI4p+lYAHW7ftC+MYbOiZZ88ANQkUKUT2+wxHYbyH
uqnnWUkgddzTgkAbgZ2T8SB+4SGBDaEm+DUKw9wuc6n+ECLBfM0MOzEhFEsL
6vqP5hQJdOyHROLcQ7C2Yvfgw7IkCJphDgu3uoct9HAc5VUhgW+x3V8hFIwd
/NzZKnqOBPV1ecfj/gvCLOXZf2DGJODa8VW66BuAhV/pyNSxJEF/5NvjgYu3
sOp7LvKm9iS4X76VcvvGTex16ZE3Nm4k2H+E/ubWIT/s90C7j7svCSQ+3PyV
+MwHE95wZgkIIoFa/RuHI3HemB4ba314OAnq7mhTmjl6YfnXnNZy00hQFi1/
O7L4BtYTzpxQlkeCRIOJdy9a3bC1itaTjSQSuC0b3Az+6oKxv3QYaK8mwdlW
BdNpzesYts10faCJBBnjnnKqTU6YI1fL/rdtJHD9lbstrOSIJWL25PfPSXA3
MVGDZdwem4tu/rD7mgRORN5ZopEttq/WNpRmlgTcFlYez8VtMImxgwKHF0nw
yS9u4yO7NWa6+wjxfCGBdG9I2l9RKyz4qI2V6DcSZJK7qSnVLDGyGsMfmT8k
eFNwPn8zwAIbdnqYi9GWQh7tuD/1sBl2rIF+0oStFCROZm/MdJlgWuONt2yO
lgKMa72IszXGPH9fZXcXKYWWuQ+ZohyXsCwBuof+p0uh8X3Q9yvvLmAdmg2X
wuVK4U0dX9NKmxG24mq5dZ9QCoqfrvGqXjbEDifvS87VKIX3j8f0XpnqY9bT
FsMNJqVguHywlLNJG4umoHVvv1oK9YYnmGgZtbA6kQcMAw6lcCCha8knVBOb
0DGvfONeCokU6h7PmTQwCk9q7fd+pRB3VmfpRpM6JpZes/z5TinopTszUnuo
YUYtlyN3I0phKP7H8HFMFSumqe5iyiiFB0yS3mfFMWzghKktT0EpjCtVnFGQ
U8G2DCgoRcmlMLYsG3XYWgnj9q0slKktBS3yUnp3uQKmlm2MYY9KgdZW2+j2
obOYS/vfGe32UtBQ+ZjrHS+HpXwov23SUwodDC25+4VlsfnTf5rd3paCdYHq
5I8MacwobOyWyH+lcCjIjDLjshTWPlEhP7dcCiSTMs5hS4l/9XjvW8ZGKXxg
ZmZ9feYUlhNm2mT4oxQy7h5JcJUWx+gmT/nQUZFBLKJVc+uiGHZTglqm8wAZ
uvd7UH9NP45dnHzwQIaXDH7KccpXbwlhHRKRN1aFyaAaTv2mhFkQkwi3PE06
TYaokLYGrm5+LG9S5rOlPBn640O8afiPYQck6avYgAzb/Ilpd97zYv7h/10f
Pk8Go1d8GdmD3NjS5EOxKCMybM06Z0RNc2LPwm3JuzZkqF+NkYyyZcOkphQc
6l3IsNTpQ557zYoVSDIJu/iQ4flDx98JdizYwYjFecEgMkxtKpvmHGTGAqda
i6fDyfBZaW7PNI8JW5FMsU5LIMNt289nWfUPYaYRzsf0M8hA++PGlpwYAyYj
xZbfXkaGxxFNx75f2I8VRaxeuVVHhl0jKQ/FXFqMcbqTW+oJGVp9XgkL0dBg
QVJZkyud//iY2+/cjKXCPkXcyCoeIMPIwMaFY6coMbPpc5ctxshwIDTH/PLw
HqFHioeddYYMZ7iLKPJ8/hBKpntTw7+QgSIkROUm9oPAIl1wkbBDBv2e2JM0
Vt8J9yJ9mXf+kqE2fmycXPSNsDat86p2fxkcHzu/NEW9TbCUFrjvdLgM/qzw
iuhEbBEGIr/r83OVQWJyk1ef4CZBYebFwUmBMqBWTikrblonHIkKjNU5UwYN
KmOJwL9KCJ0x0qZWKYNZMmUNM/tHwoa0KF3buTJoig/7XwtnFg91/8XxQipC
SCgS2VKTbYbk9+0gSUpKlkL2SpRkfag8eERFTyUtdtnmN7/fmGTLSMqep0n2
7GtTsiUhleXv4n/5uXi/zvtcfc7V6fxL6wtyjF6s9TenQ4rRpTLcd6Wrelpu
UGzoUFn6bGJt6zDap0UYf3akw+Tivgu7rYYQHh3Gm3aeDhZBYwYdUwMoUosS
vjF4xbeCHNX41oOmo3kN6sPpUPdJ3Yv7sgs593Yuhd+mQ45nc19Rfgdq0Mp7
te8BHa54rR263diOsJtR134k0UGNT1MkSqwNEb0O+swsOuQFo1+LAS1ISlv7
t3suHeyMLS+FzDehmd7+oPZyOngH6xjyZjYgV+1inbt1dGjreTT05RAHNd6M
nT3USIfR47iOx5b/0P4+18JVnXQ48lG4YrvkW8TU1vNjD9LhyazfoYl9tWjL
LRGtlcYC4bTxI58iqtHNPu6U2g86+Oc7d1iOVyL3W3HeyXw4/IDrKtXSb5BJ
bKBFxQYcZJNy30R0v0Kqd+00Pm/CQc/UKdWP9RIJxO0XFZTFIWuCNmbFYKOx
eIVpdSUcOBt6FG3qXyDOY/4WKwoO81LvMjsEixErcbQgmIaDaJqq3kXvQuSb
nh9QdRCHSemEW923nyOrzEc2I+Y48CZP9mUa5CGdnBBdIRscUr2/2mXIsJAU
w1FKyxGH0VumN5w/kegXafTL5hwOBervyFNtDNTFUu666o2DRbI1N2Gcjsqe
C7xMD8QhjdO2wUMlB4W9aL42GoXDayfUx1zMQK6lxWdE7uKwI0w19UH8U2T8
KnE/9TEODPuvjoMH05Hym1C502kr8/RMRZ3lUtHaKtdVoXQczOx0y4IGktBI
jclgxjMcis9vpFW+S0D/vVWrrHuBg8Dx/ivafY/Rvw3T/4i+xaGd98+S56V4
5NPU7q7TuMK3VnVv48ahE62lB+07cDCZOJf1Pvg+0vqYqhw2sOKf4yDusPMe
2tQVsTZ7BIfGhVWdxPAdNNdzbqR+CoeKltP3mzJiUEe/Wf3kPA6nRvkV3sfe
QklcsZi96xlwSv7n+Z+tN9C1kTmvM6IMaLZ9YxpLiUSOY11HI6QZcHeVdVhp
dgQymCyn0OUZ8E+tZKu6fjhS+J4hzNnJABMNy2+3Pv6N+Gaivk1pMkCj4erq
Wc/riDvn2SixjwHx4lkK47uvInxBK87JjAHooUDb0p4gdHt5s1+kJQPCakMq
Zj0C0EWePycZdgzomRTMVq7xQ8fW9FMbXFd4tZjtaw19kfq6Kokfngy4ytN/
EuvyQRsF6XOSfgxQzTg+ukf2MpoWivmIXWVAjclHM6WSi6hY/GRCVAwDHkk8
Z0oHeqAnm3VDyAcM2BmWdv5c3DkUIr3VvjGJAVXyN4ajWtyRg8yy/mwmAxYO
r99SouOGkNywzBbmih+LSfViu6BtCnWL+wsZMGchWGV42hmtUiL73MoYYDwc
c3GTqiOqVvNLz+UwYFpZTftb1mmUQ7ENb25d2edZncqfLFt0U0Pf9WcPAz7/
WtJy51gjT225AzJcBhzkaR3eI2WFjujwKhpOMABrrn355IYl2q33he/cLAPE
rvCs3iR2Aglj77i3FxnwcdHzZXSgBWo2fEBvFSJArcXxmF2xGZLy+8RolCDA
x9kjSDXHFDlm0ZgcWQIui4tu1i43QVltUay3SgRQYs0b/P8Yo1H+jrxqCgHJ
pZL+8vYHkMbenQVvaASI8/MPPe0yRIEXQorKEAF/ScjJ3AsyQLwcmdJCcwJI
2+Dti6sxZLZ4qSzPmoBTzKP64i166N6e1+XMMwRMaqITih90UbvTxgr8LAG5
4d/UJ6dpSOa+S1XWJQI4ndkzF/WpyLUyvyY9gABqEy2oPVsL4T943yZfJ0A7
tmP9I3VNRLXJ4cTfIaD1lKvdFXUKCon+2XDvIQEXkphnXwyroTclpk2xKQSE
b/jLMrlGFfGPJrTczCZgveAJmYwmZWS+dawtMpcAbqSj5r98Sij+KNYRVkSA
/LFrl93td6Cu63e6rr0iIL1M/m/XFnl0bkC93/89AdsPDB3F9bYhpmj4oE8b
AaGDifTrLVvRtFHz8MVeAoLYcuU+KdJor/+Ozx5cAh5PDyTVP5BEodn+I+4T
BDgtVLRIFUig6vaaUedZArwELwtrzYsjgXWSEw6LBDwdZC4rO4uhx57s71ZC
JHTkxlUJyIigviSBmeMSJDT1uxgZpG5Aiu/t547KkvDL3HtpyFIAeS4x502V
SBjzEurg1VmH8tSXfhtTSPjev2PXamN+NOdssWhAIyHPEL6FBfMhLC59GUMk
FO7/dcirhQe9nTHio5mTILBUyEhsXsaEleP5Na3JlftfLeqCwSJmZctdRzlD
An7+2+DLod9Y4k0dwZ1nSejq6ZO+XDSPDbKjhZQukeAVGFWbXziHqY51iMgH
kNBnssWHp3cG85ZRE5O9ToIIi69MbtcP7HcoZ7PEHRKMZpP/XkeZwgzyZKVF
H5Iw8P1MvfCLCSxq0HurUAoJF056dbuZjWEcsTey67NJOFWTGVcu8hUTMxbd
viaXhBSLV6sUeb9gpwJcFVYXkWBl6KH7dTsXS80pUFwsI2FIM3Nz7tlhbNd6
m52zHBLOmkv5/rEdwEq85ikTPSTUeE4Pz0V3Y8YNiVrccRKM43jzuJSPWKMG
0u1dWMlKtfmrIlowhwf9+m0bmNCpmGPrcKER87fpClPZxoR7X8WuHdZ+h8VK
t9UEqzPBxD9Loym6FpO6ajmisJcJGhu1xiPCqrGsng8CHAMmlAeddfKiV2Jl
af9ZbLNkwtRpMzTTX46NK73prPRnwj9Gq4feyhZhsswit/OPV/gB3oGFViZG
CGlHbUxnQpafc8FRbQLTuZyHs3EmYHSNbo8GOnZMi5wQLGXCgKtx7IfsTCy0
JD0or4cJazfrypSXJmJ91TExv+RzwSZ4rKE94SbmqbyelaGWC38trHvy9HgU
Nhcd1XhEOxcUK5/U66BITPhIuESqcS7UUj6lZmSFYdAUmGZ0PhfU8iesXUIC
sfRel4IYZi4ovFa8V+3mjrnM6XbL6rJgfMrB28HTAHNeUyWnDSyQ/TDfENuP
MOdNx9xND7GA6vhoxxeKPuas5T7ha8sC/xOHFnqv62DO3veW64JY4G0Wr5Jb
vQdz/Dyyw7eEBX0ltNMGdBnMrj3hYq3eM4gLM88ZdpnX39m9GKq7LQ94owtE
Tp/J0++v4kpE6jyHMqFKYjZ8nf6OYL+uwsP5wH2Hedg72O3r7SkeuGBWAJVO
5v7Wys/0rA+HjVc6F0KxqYm0HN/XvQfcl/XS3YtAaXFnRb6myt7yI4pFLm7F
IKPJ55Es7KI7p/+BVhf0AgwS1p45MBmqk9WlPp8XXAKIU2ISyHlK83S9nKgR
WgLu4Z+KLdek0jRGWVheRAk8bIuzjzueQCv7RQl/FlMCsil9F2yX7tNapXYL
sFJKINOnKTRHJYLGZ6sqQ1aUQGQTRT/HyZXm3rLdIHs9G4xEVssWuyjQ1Oyd
hxSF2WBzxOo679A22tRQWmSWGBsWNDN+PJqSpl2b3lafuZUNhW6Itu+IGC1e
VNYyg8IGFU2jMfYuHlq1hbR72gk2LCrKCwQ0D1JvfzzFL2fDhtU6+5tODvVS
jzs9wVPt2CA5cfM+CHVSe7wlJ1Lc2HClbH8gNaGJOnNHIjA5gA2X6m4bztlW
UEslrKVkQlayr89IhtAralhKfGlSKBt4fm8W7LAqoW7IFV9OjGZD59bxn1Ii
z6nN1JNPt8SyoTvK2nfpLpP6pCzuQOI9Noyr5RiljdCpjsbNXOmHbEh+8bOr
jCeL+v//XPDYnCu05nU69X+6t6wG
               "]]}, "Black-Scholes"], 
            Tooltip[{
              Hue[0.9060679774997897, 0.6, 0.6], 
              RGBColor[1, 0, 0], 
              Line[CompressedData["
1:eJwtm3c41+/3xyNllcqeZWeUTeb7vBJl74QQEpJEyN4ze2XvvfdObrIlyYgo
CdEge4vv53ddv7/u63Gd+9znnOdfz/PHzWL2TOsR/qlTp16dPnXq/06OwUsh
ycnNiLtphJ/+1x7OIP6XTfyrZpR6Id5/kWEfF2nYoRkV04yS7akW6NX3cTvL
dgyBL5tRb+NPDtSwj+s5P1xh59qMlPISQs6HHeAs1CPH7+g3IxNm3dAghSNc
Co1Fi+zdZvRSIXBXyu8IN/RNJlNGsxnxXvhYZtl6hBOzW7ESVmxGu/fc2jmE
/uEIY1SOLks0Iybb5Kp7bMe4ohESth3aZrTR+0q+mewUfEmZI1yn/K/+5nCM
L/8puPiwZfnPxWbkYp1JH6FxClw2Hzd8J2pGb5dSz9vFnQJFyn7F93tNSGXl
7G9HRjz4fTfYLm+yCeUV9o7tS+HDtc+n27SSmlDhQ+0nvPUEIPOym3w3rgmF
z9uakc8TgJpEsGVqVBMK5u1MeHDpDNgnk1xaCGpCn1JPVASenYEG/UvmTk5N
SObrBfcu/rMAU5dJkrSa0LVXz6nCuglBI3TWWFqtCd3UY0PyB4RgJplTO6vY
hKSXPq878RNBQAqHEffNJkT+O5hcKpUI+gyuVbXwN6Eryeb5Ti7EoDUtofv1
XBP67lXAlKlECg/DDkt8iZqQz4eb5MLBpOAo9eaEg6AJTYx85VbrIoWEVKzY
9rARvU+O8r2MnYPp+3eOTn41oqWvsgWKuPNg/kUnh7W3EVHwNnl8v3sBnL8+
+2vp24jGVYNTG/9dgqEGHiFdz0aUGetyRMpGDpzRP5zkXBtR926KRIUCOYzJ
3v/HbN+ILmmoTMzEk4NQ0e1zUyaN6FH4izF8QQpYfs7Eo4I1op6AJNJlF0q4
pTL5VFK6EakYvxp8mksJKRxx1VzijWjPlFhBYYgSFCeJJM4INCKCdAV9Eg4q
KJDZutN2pRGRJdUUTXyiAlOid48EThqQwdZVbVkVGmj6Hlh8+bABPcj9GFbi
QQMXX2Mr53YbkE1604JzOQ20PW1w/PW3ATlU3leWv0gLjKPZ/jkzDWjn8sW0
t1O08CndJZuyrQH5sE93kwTQg7Iw59c9jwZkZHN+QJPvMtg58UQfujQg5Sdv
wr8/uQwJjXy3jh0bUNY2Q9Jq8WWYlbpRfPppAxp6QZwRevUKOMopOJEZNaB6
Oa5mG0pmSLtrfZ5dpgHZ0ckvmrOyQEeibTunRAP6eXIQZizPAoufnztwizag
yDCZU1lWLCBg7P6Z73oD8i9SKDyqZIFui/B8CaYGhPe51/m6LCv8da6QUf9X
j9z+nPXedmQDipaaNc39esRDoKBbl8YG4kcNuTrb9ei41exzVxcb+PkgYoOV
elTobhvylYodaF4Oj5t/rUfv5lMNT7WyA5ay8dTtTT3Kp7jFXEjLCTGtYhn5
nvXoEeHhSjYtN8QvsndoutajQ97seT0Nbki4SLHwz7EeOT4eVA0P4YYU81Vu
XZt6VLMrPmdzwA0554rqz96vR5/DtBVFFnigzpDuvaV4PeL8/chxZvgaNAQR
rlGI1KMk4YHQHxevQ1PVNnk7fz0iPu0z6K55HVoJRvRor9ajDzpvZgzGrkN3
WehCH1U9uj95W5LwOx98Ojo85N6sQ7cO5MWywwRgkvP35U9/61CrlPEfmyoB
mNKYvOn3uw4dDsj9Cx0XgJm8uuCp73WovZWbuYNZEJZUnlKEDdehk1k9Rp7X
grCXNsOzXF6HqB68NU45JQz0Mh36FVZ1aF/GobtiVBTMooue5JnXIemn5rvn
8cSgZD7KM8WkDhWXFl4e5BMDqVDj7CC9OuTpRW9nFSYGhhOHP40V6lDScpD9
DcUbkGkv5nKBqw7945XmX5oQh59dTKFn2OuQ3YGeYSKpBAjQnkk7vFKHIgiO
R2tBAtrbRtESTR16wdhyQ7RYAuZI7QnbCesQl1CImoOvJLAXlCbYLdUi898Y
c+UdabDZjy2ymK9F/dr0znF+0lCn4tZi+K0W+SfxaG2+kQb5TYUZhYlaxHqF
uIxbTAYssEUOlt5atKMRTBp5DQfFU8z1HwtqUZSD+QI5HQZ8FxJGhSxq0WiX
gJ6CjizoKFneHTGtRb1GlxPfeMqCa6D4hL1RLTK906UeUygLXYdTU1U6tWjB
+CD+3pEs6P+8Msd3qxa9NX5T7lxyCwI6itd4mP/rx26yZ4hOHoqP3J4PMPzX
v7zc3CtFeRi6obL1mKYW5ZwNwBtwlQe6ir+7RWS1iLa0X8JzWh4qUoRPOP/V
IFUe2wTevNvw2eHNebapGuSJS1iLUlaA44rIqLfjNUjm0Js6x08B2H8/uGT2
sQb9xZMhE2pRAFsTfKrsvhpUf2hz/IFHEQhU7zBeaaxBTbmF8uzkSsDH+ZGH
Ib4GETtYxEkeKEPA5MIdCrUa1MrRRBrOqAHOHifivYo1KL4hktId0wBrZnoe
d/ka9EancKXFXAM0rNTPzUvXoF/vX6zxV2gA017zcA1vDTpNmVB3Wl4TGmii
9LWIa9A5PrH6Qz8tKH5drHT2zH/53e1+mmVakPagS6rlVA1yq35tSfBJC/wK
95lY96pR4ABNfwCPNqjfMJ9bX6xGIqUl4YST2vBTV+JJTFc1mkq8WzUpfxem
D7QN5durkTR/TLCl010YyrBV3X9djcJksrJN8+9C3WIuv2ltNVpJu/U89awu
+L4g2xLI+Y/jXYawIV2gT5j3GPauRoepmIyIgx6ojEdEXpCqRoOxp1OVGQwh
MCfb9vyNamSOoxon1jWEtmf1aqTC1cjL5N/BrRhDECT5SkbIW41kN5auCxAb
ATVcizqmr0YSAYaFZ06MYLZoIGrloAqtukgyDeKZAN2LmWd/dqrQmizvRWU2
E9C6taH+a6MKlcgJ916UN4Hur3QXf/yuQj2jjd+evzSBEvLH0V+mqhD7B86E
HCpTcPIgjHnXUoVi47fVpaTNoEKRwb6/oQptRZcr2JmZwU9qfs3emiqkskRM
txNiBgbVupc6S6qQXqL7zs4nM8AW82NaUqpQq3vP6uyLh0CiIRdb7FaF1Jfx
b2z3mEMGm29csGQVUvQcU7Ett4S6Sa95PrEqlBvLv2Q2bwkDER7CnwSrEMGU
YdsonRXs7jqPsnNXIfKl8DK+ECvQGLSleEtThfg8Fb7/sn4MZ383ce7/qkR7
//SSfRWfgJBOXc+d75Uo6FvZWG/wE3jQVmmRMFmJ+MIzGtN7nkBTbEGBcG8l
Yvgu3/BP3gaeSMVz2uZVItLfJJR1yk9hOPwZ57xxJXo+m/hVwPEZHO1Y9wjq
VqI3BXjbVK3PgNvUwsJHtRI9dv6VooFvB36iRgVM0pUoMYWMc1LZDkRnlDj1
6CrR3Lkglr9zdpDCz8n5frQChSlgLb9YnsOjkS8cjQoVKFO8op/rlyNcjhrI
TcYq0PTM2otfVE7wSbmJxUO8AlH8yiAjveUECt1xTDe5KhBz3xstxwwnuNak
RPWOsAL5W6au7Oi/gK30JoJvPeXIBY+r3WfBGcoNCvw62sqRklPypSYaF7Cg
iT+V11COmARQgLGyC0xGPzuyKihHJA238o9qXaDVn3NrI7Ac3f7MyJgc6goB
j+Pnz8qXo7ftSQkiau4gw+ln+ku6HLUkt0SPh7jDztyzb+9EylFV4xDBTqc7
WBkqT0ezlyMxLdrOZikPUFHHH6UnKEeDP/GOnwh6AoWo3Vu+zjLEIlRN7C3m
DTmnVLJ1b/7HG5yBZyZ9YSdy8J+pRBmK/hDuUv/PF5SZVA2eCpahxrZ1mgY2
P9iSUKMIYClDRtlP6Mvs/OC2g0ZgNV4Zok8799aLzB9+/9B5fO5tKXp/X/WJ
iUEA4BzHu2laSpGs7Ldxu8AAiMPXZWWrKUXCpNW5X6sCQPrKvWmJnFLUsnQz
5gNRIETq6ata+pWi0UV/Ad43gSD0zkjwrWwpOqNfbOQuHgxB+jMR7yVLETfN
sV3d42CYXjL+PSlUiu4erBreSw2GAAKT3FXWUiT2QP3BzEkwfJIxo2I6XYqu
5HxZIBkKAbcqi33nzhJ0rYE8utY7FDpfPeu4LleCwjo/nXsEkTCy2fkvTKoE
zT4vYL8VGAmzmrSSv4VKkNNoA2P3u0g4Pt9RU8BSgtx4tYZbDKJAPIg878pJ
MXpSwhukgkVD2Yv6oEstxUhhiW+1+0UMtIwRdz6rLkaBeSdEIpkx0C9kfPK+
qBh19WpL4/XFwOLfsy6hicWIo8zIr5U+Flgs9R6fdipGajTjpMNdsZBw71B5
m78Yfen+Gou7Fg959eoh2leL0Y6bzTWy+/FQS5HXVX25GMV/bRBVCY2H4Q8q
Mrbni9GM5UYHze94IFXI4Fv6XYTwTj11J6l8BT7iNy99zi9C7Ne4LtxVT4TH
dMGfWhmKUMEQg0L/egoQDLxfq6AoQh/KWkosrqVChhslaTZpEaJTSPgaaJkK
Y9PZEHhYiLpdB9XUvqUCltFapDpdiPqUTgS5xtOAlm3DbSalEDEzn6+/MJ0B
taPir4ZjCxFXSfye/uVMUAvwrnwbWohoNaJaJcwyIeDHuYUCt0JkGkRJh/5k
wmrhVdVnBoVoxcQi4rR/FvRcM7pyir4QuYxFKT0sywbTr7kSG5cKUVCRaR7h
aDYcRfzWXiAuRN9u/WTBP8gGoVXnkL79ArRDt5t2pJAD6dWx69GfC1BCeEsY
058ccBTr62RJLkBZhBNYN5YHbJiw1S3aAkRKVfix60YhuLSrmoVcKEDNPjl7
l58VwiBmZfj+bAH69GVs7qSgEF7cTNe4t52PTG6IKNynLYIBWUKJJyP5SEbr
H0kGXjE8l58mjgvPR7/ViTvCV0ugt3v79KR/PiJqY+rb4y8FxtsXjxnd89GQ
aJ86vn0p9NyW3yh4nI/IqEmptrZKgV6hcqrldj6ile7o8yIoh7dK/qVzp/JR
x50z4tm3KoHmXXr+1b08VNiVeqEoshJslJsybVbzEO2cGoflVCVQq6zE7XzN
Qy5cq6UkklVgrXrPg+R1HpoTpsUTnqwCcg1eVSGnPHSd9gGZ/NUaMLs7+tf3
Vy5SlP5G+ZamHrQKfXpXZ3PRcGCLxAfFeri1fz3LaDIX1XbsCuh61AN7eoim
RG8uus1k+vDTXD0sLsjUreXlInkVDba39Q3wxLHI9YFJLpq6ri9q7tgEhj13
td7fy0VXtc/czK9oAhXa07xS6rmI0jxkxPFXE/C1Gn2hxuWie83jfN0mzbB2
mgKGGHLR3VZvMW3dFnCM8ySQmchB+u+JSxyNW8H8B8/XkqEclLI7262e0wp3
b0zW0/bkIBMrmuGPi60gNi1kuVWXg+R6rht+tH8De6w/+0tjc5C9tgjh36g2
8KzRiqJXy0Fq0VtqVM7tEPTxKv1eVzZiZUp5e4G5E06/6B3eb81GihLVqzTK
neBDbxl8WJeNlDM/4we86AS3hwVbx3nZiD0pJC9sqBOebrN/OBOYjXSyKWcc
/LtAh441gEI+G6lsJDaG4PXAxzcdklQy2ej4VCvhbeEeUDMzXacWzUZrvd4v
nR/1gEJpljE9RzbqPiCOk3rXA1IyVyRYzmQj9bS7LpZpvcBqyviXrzsLXaDf
FdHV7YfMM615Am+y0OYneZK5qH5gLLl/X6g+Cymlqols9/cD9WZKn2h+Fipb
dUMNMADEgXS50oFZaCN6H29Q8B2sFVHrKclnoWnBAHsnwffg/p0l4F1oJnoU
6JyQOTYMP/uJqh1dM9EfCrP80ONh0K1Z/cpklYmyy93k5rg+gpD/mxt28pnI
QYZqctrrI/xm1/9DeSoTRWmYJdIJjICBVbSWsVMG2qX9Iz9eNAp9Gs7ehOYZ
aOh3wwnD1CiISRiXVWlloO1nKd7zpGNATnLt7GmBDKT3ScziwG4M+kt7mwt/
p6PeWLqBZzfHQXz1mHn9QTq6QnmWq/foExRM/FBNUUtHn+efFA2ITQBl+6Db
LZl0pBS4e9PSfgLWolPGXtGno3EHRvfnPyegUEgsRHI8DVEap97Em5kE6hdP
V/2V0hB7LkVD3M8p2DqafkMtmopqvO0EjF5+A7fQwoIl9lTE9YCoonfsG+DR
OkQ1UaaiX0HPCF0uzgKZMImpwVYKqpBPlu0wmgWux+IEGbUpKHnLf33zaBYM
x+OVOIRSECVuBO+d2hzMmZkI77CkoJ8kLx3+us3B4zVext5LKf/5H3Mjv8I5
eEHauWK1noyKnsU+P4U/D9E316PLqpLRBXmChy6t89BVrjohzJ+MuExDuNwU
foCSFF07wZVk1JlI9hLn8QM+9i0UjZMlI5+vGpEhVT9gZt7dzflvEiqkNrSo
pV+EPboSptflSSgg8e+TyO1FuBZ01lz2WhIKddlobun5Ca+M0ZoGdyJqZmF4
TTK/DNFhQsm9NImoiny4+63ACoQ25d/EnU1EP2To8e57r4APeXgs73wCEq/e
FLlx5S9Y9+iJnE1PQA8M2v/9fbwKGN+G8+uLCejlftsDPJp1kLr/iFno5BXq
imZwjpFfB7GQyb6ilVeIl/nIscRxHXjn2ugSBl6hVN/Dq15j60CdEPbaLuAV
IqmM2J9J2YA//9hPOPbiEXHIkzFBuS1Y5EkqTFuMR4fO6eyCHlswe49Ug2I8
Hg3O0eVN1m3Bp+r1rFM18f/tvwWU3Fzb0P6oTXb6STwK2jeYu0CzAwnv7wVF
f4tD9q4RW5S0exBzMMBHOBSHZAokN+ru70H4VdyEZ2scSu/t32LP2gNfX3au
J8lxaJOaxdqHdx9sRNf75bXj0Lcsch1nlQO4mR56/rAnFkF02lXmliN4/pTN
obM+Fllfb8mvIPkHeTKtk2F5segNIeHpG4b/gGhmJZfRLxb1fTFQuYV/DMOX
NSVxMrEooo92o8LgBIyzaCx9a2MQKa1kKjUzHhZtVzWomBODTL44M5Bp4mFv
MUUh8pgYlJ7heDHHDw/j+O72L8c2BnWl454XLeFhyywzcV3c/7F33Gn7ZnzM
PTevnTArGo2uCKSwexFgZQ4ynMOR0egwyTGPpIUAm7n1KSzJMxpRfiGIbNgh
wGQXCO9x349GMokXSW2en8FIOJ6sKFFHo9XH76/kO5zFBFQfijDSRaHByRBf
mSwiLH4l/qRsJxLFbz2nI/lNhO1F9AzIjEWi+hObwVERYgwNcZs+iIpEGDtJ
o+17YkxNYy0i50wkWpvkcBUnJcWeaHsucW2Eo7SpbW3yN+exUzgXHuKRcPT6
n9ylWHIyLJ7L4emv6nAUO22/wfeYDGv7Z7VZbB+OUO4B1QjdBYy8SOeEZz0M
RYSsSGXJXcRajnhprq+FojLLIrfokUuY+hKnwfnhUJS6XSP7gJAcW/jIkr5S
GYpK3LfOLUqTY2SFNGwVz0KRqIbz4tUScsxU8zQ//+pL1N2jujQeQYERFUzd
FvwbgnIiRP999aDC0qPHX14aCkFXeaZSUBsVJuQ+PLheHoLilC0lYvGoMUON
Hq2apyGoqdLajSGUGqs8qDYWXglGK71D8pKFNJjcj7JsivfBiD/sXNiVdRps
8kPhwmZZMLrMrqBOL02L4eenW9fZBKOgKcJA83FaTFf95QvR5SCkq7ip9Y2K
HvsjEdBMNRiEwiJo/E4/psd82L2PtkuD0K5KUKrVG3qsZN/Rr+FJEOoqoM0/
b82A/cs1ibzxJxAJL4+EOYwyYnl7NwokfgegLy+vydQsX8FYWP2sHvUGICLD
M66EAsxYhvIgT0xeAOq7NEfbYM2MJWeYVP40DkDRropOPPPMWKTcy6bEUX/E
EVdFSfmdBSO1HXXrrPJHz6eDGazYWLGQRCaZ1Qh/RJHrc3bFghXz+13dcVvB
Hyl8SCfKX2fFnKOnBrZb/RA7Kff3JGp2bKuZPYIlxQ89EhTfk3nIjj2ft1VX
dfZD0jnj5BrV7JiN2OmxPEE/dNH9iuNXTQ7M5AvvV+0CX6SUMfw0OZ8TU+Ly
XK2O8kEnznfsDbO4sV7N3uqvNj4oc02P04iIB5Nzv+RIrOSDiu4HGDg858Fg
KH/PhMAHTT3u7KVS5cWsfqadZt7wQnzBpd8Q03XMTEowxLnMCzkVWvHtJl7H
jCK7z32w8ELSc+xfmyn5MC2Rv1Re056I0i3tBzs1PyblA1xfujzQxtxqxq10
AUxsdLRM2NsDHXWObQT+EMAEOK0EwyQ8UEHHoJ0evyDGPhgtKVnhjq7GhhRN
9gpiZLRzKkmJbsikMCnc/7wwRvTkxcdVTTfkOmaX5fdQGDvdRqJ755wbignd
5LJ7LYztPRR+sOPjina4mqtV7EWwucoAex1rF3S5bVMhfUcUg8TSH0rcLmh+
Knu1QVcMS/Ma0b/50xltfz8OXWwSw3RVmWX5LJzROm/dnzb/G1j/79fkRGYv
UFKj3MNlEQmMc2Qu6Jj5BarQ1rulXCiB+TUTH259c0KSv9yzxRklMemQe/Pf
jZwQEy1VLT6ZFFbFsVn7Wt8R/fvKWnGbQgY7f56eq4bWEfX98rxMnCaDWW9h
aUUTDqiO/hJavorD2DsjA17ddUBPJP33rRQBSzLhuftM8zlKDemm75zCsO07
mv2PLj5HVhLHBx+u3cS0+F1kDD/YIyHhX6RdPjexc8fdHIqq9mhnPsUtmk8W
80413WFVtEMdAlE0xLm3sC9+IdZ0RHbINWKuMe2MHPZ8zPjNlchniHc/5Iuz
tRz2w/4gYv+lLZJ6n9YpKiWPDZYJ8pf72qDPVzgTWA9uY0Hu3jQpJ0/QpMjI
Szm7Oxim9P4kyPMJ0rjPb3Xu1x2sbslq2MTVGs3PVQU3zilgqaxZ9pT2Vmgh
nSDac1cJ01lf0cdbtURqg6fER/2VMbJ2Kdm/NpYoXYC56AKFCuZnNEHeZ2WB
fHmvCihJqmLWSWR17ibmKM5nenOgVB0TJ/PcmVM3QYwpHpXEoVqY7spq1Ous
B+j6SxI+hQUtTLrth1B1tjE66tDuDABtjNDko0tariFqGUxYyd/TxjJyiwgc
CvVQaYP0evfzu1iAY0ahVdE91Jb3Re7myF3MWj5eybhYF3m9WyGeENTFxJa8
oxVLdRCp7DmHijVd7D3PPUbmSg2kt0CFjiz1MIvdZC9eE3UUh9t6rd6phwkm
B3ZRm6mikQy/HkEmfazvi6HGyiNF1BoTulD1Th+L91JImLS8g74IOLYNXzHA
HjCLfOl8LI/G10bfBdobYDsPSa1Snt5EJVsW6cXn7mP+pH/vk37DoUJg6Iu/
ex+jV+9e+j4niWyrP42Rpd7HamLTHJoWxVBPMd+9iS/3McVPDieRv4UQ/nqv
ZiW9IdYunED97st1ZH2y26KvY4ittsjxuSxwoJIrwafTXhpiUgGLYUqTDChz
vSQd12KICXAEv1D8QIgeCF/3O79oiPF5eN4lYF/DPaFKqZ48Z4RVauAvFuxT
gEK0fKUjnxHGna11n3ObBXrD9zdblIywQ7q8W64r3HB9mV831NQIs+g/oFrc
EIBHN7886n1uhH0IZAu9sCoCGUV7zYZeRpi4rMqx+B9xCKe+wycVYIRlHzs+
N1uShkvb+BcN/uPAr2qb3fYYaAzHiTf+d79Z6mH51DNZOBytoLrnYIT9TXa2
XH0qB59TGzLkzIww1r0wFgKb21DpGH4jRtkI09XNmqa1VoB5WitfHX4jLKyu
7tV1KyVoYCqiLztvhLWT96vLWqjAudA5tdf/zbtl95X4nrkaZO/1NpX8p0f8
0t53UUEN4J4onij8T68K6tOACWiCqkNeyoK2IdYnfz5NiV8L3Kwj5xPoDLF5
R5p9HT7t//SZPb03dR87zmXRfXBdB5x73onKJd3HaEd5ax9fuwtPhQsoWjTv
YyqC2FMvnnug7xX1l6PFALMwURoI4daDvqBfclmPDTCfKJ2rcVz64Lby/VCZ
2gCrW7H6Xsh5H5gGNplkrfQxppKYux9ZH8Bs+l9htH0PO1i7+AUxmIDw0trl
soh72OI5/fM0BSbgJ+jonMZ+D2uT+/Wsu8UUDCY67sVp6GJP64hFWRcewreH
JKkGhTqY3rCmhautOfzQFug7ktHB5JaTE4f3zKFlj4L93rg2xsjOc+B13gIW
o+i6e85qY4NxSmhazAoEejgqR5w1sabK2DWhDitgnhzyiaXRxPLeTbGEKj8G
2sYS/OkmDczj9JMAcRNriPUdE5I4pYHxOoQpvnppA4FLLKmit1Ux6qhRt2WK
p9CSfnhPPksFwy9lKLuV8RQI6s66f/injE3NlZJt1NhC4q9n/1Q7lTB57sXH
V23t4Lea5uuHzgqY5I1QfO1aOwgkirTvW76DCcjzpXrt2cEFl7F+u0d3MEbT
F4PjfvaQDrOO+ia3sa2ks/wBic/hWjaFP767HPa7oKS38stzoPX924FPLIfN
1qmZTLM4gOfuRfHR5FvY4HBCjFCZAyjeyq/M75TF8oiubs22O0LBzP18XbGb
WAr1u/BzZ53gA80vuyufMSya/RmHuLITZNrzqkp5YZgH1qgbNe4Eibg7jiYZ
gGm73GmW+f0Cwkb/uaxRymAKQX80H/M7w3O9xLP+HtIYLj7qd7yjMzwS8Pw4
uSSF8VRNMCwfO8MFEjZRy35JDP+npVcKhSswTL08bVIvjiWYul69quMK68E3
TqVi4hj3dOhwbbwr3Je8L+MydAPTGCpnfU/lBsoC7L/G1sWwjLrNnhMad3AO
i/iudlcUE+I7Yxeu5w63H65mDm+KYN2F1HR0ye5gG56q+yJeBFtOkXgiRO8B
Hb7sNDvTwpiEr/eFR4yeQHXZ+qaunxA2eBDdtG7oCR1eWw8DBIQwE8ccU690
T9Av8o+zmxXEgiy7axMve0H1t8fuuvKC2Jgqqd4AszcY7fn8EmAVwMQjlIcT
Y33geJDSNBGuYfhKY+wzNT4wKPjzg/UALzZ41siVfdQHhM9EWsXf48Ue+Niy
VlP4grPli5MqFx4syCHGcSDeF9a9Pwe9GuPCNATo+y/W+wILjcWVdDsujG4l
h+neuC94XtXXiCXjwsos6nrmqfwgk32tmkbjKjaqP0H7L8EPPimbfjb+yYGl
UZs8vdXoB7srU2rZsRyYxejPjpcTfkDLxmrqiePADlQOrKlp/cE/0Mrrawo7
xowxveFP9gdc4dB3hUdsmC3nQ1Oz1ABo+J7V8UWCBdPISxMzagsAjQ36zvAt
ZkyQ9ROp3vcAGFy1l4yoYsa2mBQbVK8GQuEP2W6Ta8yYKxU/qURtIOx7hJSe
e3QZM4izmhX+FAiezS/xP68wYdKXcur59gPhfp+m/bgLE3Z8jsqEHYLAlHSb
/PorRiyA4LDuwrsgeGPVU0G2SI9Z+ImEkvwNAgvnqvSL3vTYnVO2D85cCgai
/bCcJTp6jORolvhQNxiu3B4ZW9ahw6I2e4wX54KBzuq7iOI3GixlLpbozUEI
EM1+Dq+TocI8TAa/NjK9hK3oFyvDq5SY0cyZ2hrsJaQcdTJI51JizFMuRkVB
L4F26f2FhfOUWP5H45o48lAo91572rtOjgWpJwVHioYC8bW3rAXl5JjV+4+G
L/VCYfeH50G2NTnG0y9H6J0RCp4WnX+nli5hVe08htY8YTBx7s/Jm78XsVic
ueAj1TCof6W4slZzEXNoTT9rYhcGQ8GMCzQuFzGxpovVdxvCwPbaaij/mYtY
a+XOmZuy4fCBVMuOSocM6814W0ljEAH4amTL70VJMclPVSTPPCKgrZDlidsU
CVZxPvNRT0YEbBLfUw3wIcHiPdwZnOYjoCRJeShxmBgzMRAJHrGJBJEo+j46
HyLsgKrAOMI7CpyCy7cHaM5itqrxzQvZUfC1gNmu8sMZ7HuAH6V0VxQUedZO
pYWcwRZc+R85EURDASPlT59/BNjAT1IGdsVoED3F5b27cRpL6OkK8h2JBlyo
5Np1YnxMY05KpHw+GkR2Pmm1fsDDiI9rvk9uRUPt6Ctd6kQ8zEM0W1qAJgYo
27UNmLnwMLM8z42Z+zFAdtdJU1T7FMbvJ2Ys/SMGVk4l1ta8+gc/08tJrXZi
4IfVEpGrxD/IaWZvjiOMhbvDvuQeM0dAvU5O+Yc7Foy2kwg5rh3B0YPV/mTb
WCj+3hXlM34AfTJForu7sWBHhv8x2nAPHtdJXj0kjAM9vCZ3Qpo9IOF9T3tC
EwfKEyrDuiO7oEK7cXhWPA7OLPvmOyjvwvCG1FtqlziY7B+dvHtnByYKP6iJ
7cVBRdxsxoOHW+By2QyTJIqHH+L21VQ8W0D7aksQRxsPC5fG2NzWN8HAj47q
tng8zL+m3pTz24QZw4fTd13iIatYtiG3dAMWL+1aOu3FQ4929r8yhnUIDnmp
70r0CiZt1+/dXl4DrhMGZU/aV/CQoP3Q5s0aWC9jfIHir4D4c953A9M1+NsT
uhXv8gpocjhGLjxYhW33y751e69AWV/e+2HvMiRsVD1vIkqAzGgCk0KXZRB7
fMu8lTYBYmfZYz7yLIOLrtWdLvEE2JHNfvQ+5g8cCdScH3NJAK8I5zRK699A
sCifsrmXAMH42ZpRN3+C4BuBQU2SRLAaIjmyP1gC43iG40qGRBBREdEVqluC
Rtl1UxtcImzcvGqB8SyBdWYa9w//RFDR2baVZV6EYb3Npk9kSWBk/XfdX3AB
/vHP/BZhToJ7lua393bmgYewnzFOMAmmfJVZmd/Mg399ho+6ThJ8G97m81We
BzFyJYW+5CSw2NUoULSbg/R3WRPN7MkQzrTiSj05CwM5YcS0YskweZblTlvh
LOy4vpB6cScZLA6EuPacZ0GDSyVTyDoZPIN1eujpZ4EgcNeitDIZqgie+oz0
z4A1Tm0nTTIFbn+JLbrP+QUSqSS4DpVTIFLhtqDqp2noWmYz0DdKAZoBtWfX
g6eBKXX/DZVPCvgvL4lX/JmC4d28wMjuFOiL+eNsgj6DWPUhpY9GKkhq5B+x
Rk2A0jxeWINJKhyEM1VQa06AMRUR3opdKlA0LNPUU0xAkCvlin5MKvh/XNP4
nfIJJm5e7xYeSQWGbA5tvOpxcBkxdlrSToNChmMvlYNRCCd49IfJPA1YPa9v
kvWMQpbYE1MdxzSQ4pWseBA7Cv0pzqod8Wmgsq2VlH9tFOgfRnOkjqfBQuVJ
caLlCLze7BhXu5cOZKe3I3q3h2GYo0850DIdLKQu/GnqH4aFe0Mdr53T4WbE
6lWWjGE41zpVzpWUDocOc8caCsNgGLAZiP85Ha4xvzChlPsAx5QcYg0GGYAX
qUWVOToImFhIApNxJsSImuHCAvuAqdtKHd82E1yr/gWN3umDA21FoiXPTBi+
IW3ZStIHdfYkblXpmbC+Yc38OLYXuMrDjW59zQSWlbtzJ0U9QBSrECvClwUb
krkP36x3wYvPTX85xbJg5GDtrcqbLvjBzK1Mh8uCW4SjqQ9fdsHbSmKCY9Us
sKwWJWVl6wKP9wNOvU+zgMZtdafFsBPWiFT1Dcqz4PHsgaHQUgcYa7ypV6nP
gsrik5mElg54n3idHN5kwd1DvamnkR1Qwkn2ju19Frwl63KzvdEB5nIfpFeW
s6A698xgcmQ7THprMvtcy4bJ66VL0tlt0L5zdym/NBuchmzqtMVbwNF246F8
XTZ4iF66QLvRDNyLkbMLrdlQruwcnV7WDLHjvZ/ZhrJhXn/3xTxbM5jXSQxm
r2VDIqENxszQBITPmarTRXOAGztgSudpgNZfzddlcDlAKfErz3u1HuxMdUu+
3M4By83kd6fr62FSIyqXQS8HXvBQf/l1sx5K+PESkt1ywM+0yeLIrA7UVhbc
XqEcGPRiedLTXgP4j3x3RfpyYCMFke1F1kDjFybHseEcCBe7zFxtVAPMg7pP
KeZygNqBLaf2qBrWS/oexBDkgklGQdlHrBrircrkIhRzQco47LZzeyVMzzuQ
BY7mQtTvC0Ovf5QAAfHl8ujpXAhDy6ZRuSVwja9POW0+F8rKXHDEZiXg4cL4
snYzF3STjph/zRYD4/nu03MUecChHVXJu1gEhmLU+zidPCj3o7x8/3whBNxv
T1QyzINBkrduo2MFUOZjLaZrngdqFHTKn9MK4GigzeGpYx6khR6lB/MVQPoD
y7+p8Xmg9CsDFPTyYSakaX5vLA/intpO8HXlwtkKMz+Cr3nQ8xtxf4nLBb7R
cywXf+SB5N3rf/DMc8GLydT46nYeULoor1WfyYUrNcSf71LlwyN/Nw5/tRww
mTYYqrmbD1pKaeIrW1kwd/1fk82nfFhuf/SAjiEdNPxHnTm+5cNG3vSdZ0Np
0DZZLDazlA8OOn71sX5pkOKvW6e+nw+uNeH6EiupoPW5slKIsQBurl8s63+X
Am8DzAr2TAvgjwQwcpclgcCU+KNq6wIgiWYxN3ySBBn8F9itHQqgl+MikuZN
Arep19nTAQVwdWxZ619ZIggJUKW3FRaAaX9SrHJTAuRO98YFrBRABeXblOTl
eCAXzNCS2SkAzaGdinf18eAT5Hhp57gAJhJx2VHe8WAoyBJlebEQaM/gb/VQ
xgNlsFuoknAhuF/oONcvHwcBQtd9L7oWQqJcjcGn9hgwfxlrm0ZQBFKmjlnP
2SLhdvgL9Y5zRZDgVlVPPRUBXFEGAouURVDZRotnFxMBf+JZN/g5imC5LeGK
FH4EPM+qceqUL4JmeZM3+Mth4NM44vE7qAjWl4s3vs28BLOWBqMLUUXwLv6s
LWnWS5B7k4ITSSyCH0eMFR9NXwJhp9kpr8Ii0L4dZse1FAKRQxv+l/qKIHiS
w298LxhSf5CHiRMXAz7bbe6/YkHg8XPnidGlYqgkkFSlxQsC4z9TKn50xUA4
tFLT8y4QWNdzyAa5iyEv/TZTqVkgFB0JxT5QKgbrAjLaZwn/+WgK7eSgsGLQ
sfXXHKX0h5GbcYVj50vAsMmrnOORD9A6LBQPU5XArxjXaT2cDxjniZYNMpXA
n0oHwl80PvD77GRV1/USCJCzyZNI8obTg4wtdaolwHLwcsvB3gtEdAsG4yNK
wHVp3OaKnAe4Be8ORb8qARpzyDbA84D2JoWP4eklkJXs4CmK3EGV4c94QHkJ
9CuQsnVJu4PFLP83x/clYO5KWcoAbpBo3byuc74UGnpDGhweuMBMKsmWBlUp
sBbT1h5yuAD7+/s7KkylMFSdN3huxRmq+I8P5K6XgjaNC0+3hzP0bckSiKqW
wnBd6LknOS/gwGuQmiqiFETVCHVczziBYdw3qfFzZXDKJK+kgPU5/NwyNPai
KoM8iuAs+y17cNSd8rl6uQw8fJQza3vsIZxuvNuVvwweFlZ+S7Sxh9bMAfXL
WmVwuf/TjfY3dsBUVv/QMrEM7PYf+7H8soWS88JBF7PKgG/71phfii2IPasq
ai4qg1e3N6FCxRbUhEpXSFvKQEj+keD92qfg1ZTlXPWlDL6rTdwc/2+vn+kK
C9tnKYc/18e0k/WtwZqTuCKHpxze8r6jqaa2hp3goGFl4XJon/Xxdhx7DGTK
vlQZcuVwZz//zq7mY4CPLzJlLcshqb2I5o2OFWR9Na0NKyuHMlJewmlnCzDd
uTHNdKMCJpNbf7zlfggmZzqvCEMFPJj7gbkdmYEJpZq5wp0KWMSdLkj/8B8L
ma88v1cBdsTFnuzO/7Ft9EmvcwVcPmlzpX5nCsaLP9meN1WAknrfjbpAEzDe
drAKbq+AoaTXso3G/zHBSVlaXwU4u45w04ibgBErlVjvZAUQ3yVgHpt4AIbG
NxUY9/+rJ/EqMaTSGAw+Jdv0SFTCzwYVSzZvQzD4wV49fbMS6sqKHx5J/cdb
ldtripWgFn7rvNP+fdAn7/FiMKgEYtd6G3hxH/TUNqLt3CoBt1x7+4KzAej2
KNXTv66EjzkK4sbxesA9/c/rxuUqGNB5espT5C4MuulXJ7FWQVrm1yPvYx2w
pa+f3+esgrCPBsnn+3WgTt9GoZW/CpRTjmk6H+gANjl16ebNKvg+MNxmF6cN
uuONeUrmVcB+33imglwL9h0pJkqtqsD29afLrxc0IY3yGfH5p1UwqKZ2TaZR
E+a0OW0/OFXB3oWklXQjTXg6En9DJ7gKKGpOP6+u1ICAD/YDRiVVkP25lV15
WA2uPnt/1FZRBc/PMCae81ODATJufubaKkB/ydQTRNTgotps3NzrKpg6y+V9
kKoKqYNqRpbvq4BrnCNmyEEFavp51+zWqmDsF1vaobwSfOv8QRUgVg1v8y2e
UVjdhrqD3clhyWrIHV5I0Re4DaGCJGlMUA3y3ENWvPvyIJLJx9p4pxoqj188
sQmXhxA3Z77fetUgPO+ogmuWAwFB4jsa7tWQRpoad8xzC85YMZCke1cDgcLg
gsmhLExlXH//y78aiIYIDSUHZSHgnJa2f3g1RFK/P6f2TBYml1IeNKRXQyfR
rNpky03wzbjmwtheDf48S24+Fth/+uKkHndVg3bkUNSQDAbXzmke1/dVQ8CJ
r64fFQafXJ0C1D9Ww5nAtu3r4QA8d9ui/eaqAcej+qzmHg5GSDWKfxLUgGQO
ZfiXS9LA5uowVadYA3tazxqfnxWHmqDwikbVGrA9522/NnQDsPh8vxbNGjj4
PH9nNfEGGFdO8LTr14D/4VjME94bkPJDyv3d4//eO07jw+mJAbkWAePcyxrw
VeDD0+wTgewHTGsLETXAUHcjRi9JBASeinUtxdRA54hb/AcrEVALsbJZSa4B
qSWHeUJSEXjZNti6V1wDzxFXVaCOMJzifWV0YaAGSs7OE8wcCEKUeIUg+VAN
zB3kJlp+FITLt3vPUI3853v+dT7ULBIEadP9cvqpGgjQ1OKUvScIzolGxxy/
a8DH+EjSp1kA/p7mzJQmqQVO4aY2KyZ++PqlYfaxUi0w3CRPoF/hgUj8RblO
tVp4dSrZfrmYBzAuqmJG7VrAMz3z18KSB/IcHOw/3K+FHKlBdvUFbrAhEcAX
fVoL7Umnttp+cMHhjWK2U9G1cCjX2NF65iqUGU0G68fXwon72Sn9QU4w9idc
rkmqhY5d9fGgOE54O/So7lF2LRjOurwLZeOE0Ees8u9qaqFf/fsXCiUOoItL
tUgYr4WX2184TirZYKBpYGD1cy2YyZYM7XqxgcfMPp/iTC30JWNyT9TYYJZb
b/dwsRYW3c3evvnLCkXtlCGme7XQVXFpZVWEFW78jSi+xlAHCal/Xr/8xAx3
FX2W35rUgQi+j9ndIUZol28wHTGvg5/j0+8dwxjhmuzyp+9WddBZIKoroMgI
BFJ6Hafs60CJ6vHZFz0MUHNNIAHnWwftbUFplH30cPHiLLRk1wGfnOmFZ4u0
4HGOur4/vw66DKMTSsto4SeRCs/n4jpw9f0yZutACwiviXKvug6qpG69DMCn
BdvNqF+ib+tASNVpa4CTBgY/QVz1XB3IxDKztQVRgfioE1HHYh2Uxz9mntSh
grwPpZ7Dv+sg79tTMws2KnDvo7Fa3aiD4IETx+kOSuBpWZW+froeHuPT5ZAQ
UEJIeuZiEVs9RNyvc0lNI4db5icSWeb1EJV98cM6zUWY3f0DqVb1ED7fT/F5
8QJ4hU3KJ9jUA1XtIKNTxgVoqanWDHesB/Ilqq2UCxdACM/8sUtAPRDVPOh2
3D8PrBl9SRp59bB2lUmW/TcptAvWZygX1UOdExnXRAkpGHdn590uqwedjM8q
9DakkLLsViVdVw/bVyZ5VdZI4JLU9T6urnrYvFgxInlCDKcmY3ZPLfwX/3ij
W1CMCDKeeP07XPov/+TJkfYJIUifWJ/e/VMPukspzJt9hODCKXdhZbMeol95
teQaEcKa4w7n59MNwJ6mEFEZfha+XbqvW83WACctzxIDTp2BNmX2etOHDYB3
qSRQTBwfvHc5lWstGyBb7l6xFyk+YLnc3wlsGuD8mRky0W948PaA73yRYwPY
r14w+hmMB93FEo/+BjZAh9DbPuWZUzBIqE7lXtQArpt+xQrSJ7iIWs3SwbIG
qIn9d6ts9Rin9kDn5uXqBjDwIUsbzD3GDTfoP+1obgBHXhppabJj3Ogj827C
dw1QdG9eIv/PEW6q09UpfqUBeld+2TL2HuBSn3mQLq43QAJfkYNb4AHOkME7
+8ZOAzByjRK7yR3gZp4HvJ86bgDyI4/Ke137uO8sURwsFxvBZ2KZ3uzdHu6n
d954uVAj7F/wDni8vYPbkfog2uvcCCOmDn6llZs4+7bJL0Pu/8VvezVW+W3i
lrE5/0/ejSAVV3yFSXcT911+++OP4Ebolfg7evV4AzeozmBLkNQIKn1Rqn+0
NnA5Dy0LbjY1gnZIgtEjsnUc06KdqmJrIzQz9Y0+X1rDJVm5bWm0N8KRikfC
5/Y1XMTTCFmTvkYQDvcZrHRcw7k41854TTbC5/eh3z62r+JUw06oW/caQZnq
tEhv5Aqu7zxxW+dRI3QSPOrQUl7ByUaTP3p3qgm835Z/dSFawYm/4qidImoC
o2q+G1EByzjWTGX1fdomuHZpR7XN/w9uryYxWEyiCcoPLYVO0n7h8qb496pc
m2Dx8et6W6FFnLXZsxQBryaYcylTPdj/gRP4XSFd5dcE5wldiKjf/sC17l/3
rQxrgtI3a2x72j9wY7TXSCrSm4CvZvE/87aAI7jHxVja0QTGtqe/Fv+Zww3M
WLbx9DSBB9H1W7Gv53DRFoUmJQNNMPgi13A7bA7H+IIzv3i0CWx6qTs5+eZw
Iq/Y+Yp+NMEZ0rZ2SpfvOPNRZiyfuBnilPoD6VlmcTz3TebYyZpBNOvbT9m1
b7i1ucyAPPJmKBQpqGPJ/Ibz2Ljcn8vQDF+p9TsUT2Zw8ZeYtHKuN8MHUiNP
kv6vuC51OvNMzWYQ7ng58cpnGhc6oXf2im4zEO7rYZ2S0ziNB0lFGQbNwPYh
Pjpnewr3xZZmJf1hM/ieNvrw7OkUbiuC6kWaUzPw2vQzUD76jGuhukvL6NYM
6On+Vib7Z5xPenxLqlczHOT82f+wMIk7V05xkhLcDOQ/Vw6pLCdxIyLa2fTh
zQBcS2+4uCdxSa2xt1Kim6Fc94Ho5z8TOGO5kR90r5pBkpb2A0flBO7//0+C
Ud/M4TmHCdz/AEO621s=
               "]]}, "Meixner historical"]}}, {
          AspectRatio -> GoldenRatio^(-1), Axes -> True, AxesOrigin -> {0, 0},
            PlotRange -> {{-0.1, 0.1}, {0, 120}}, PlotRangeClipping -> True, 
           PlotRangePadding -> {
             Scaled[0.02], Automatic}}], 
        Attributes[PlotRange] = {ReadProtected}, $CellContext`griskn = 
        Graphics[{{{}, {}, 
            Tooltip[{
              Hue[0.67, 0.6, 0.6], 
              RGBColor[0, 1, 0], 
              Line[CompressedData["
1:eJwUV3c8V98bJ7IiRZRZyogioyS597mUskk2icyM7D2yE4rsvX3svUdOQ5GQ
ZIvKjL7KSony8/vrvt6v55z3ec77/Zxzz8Nzx0HTYh8ZGVnMfjKy/3/5eg6H
p6Q0o2il8OsmGT4yBvGLdvEJzSh/2odNj9JP5rHR8xvRT5rRPbfYJ+p+/jKb
/zlyhD7ci7eJa9kNBsi8ZuivcPRqRm3XKLcYA0NkLNUfD13Xb0adHX8k1c0f
yxQN0J3aPNaMlr5/+qKVki3zMXWaevVIM5pSaBtatMuROWTW8t+3Q80ocdQg
YVYpV8Zz/W7DF5pmlHYivZPldL6M4pE3ir2/m9A/cy5BNo8imSXtB475o03o
IvvU/pV/1TLc3Le1swab0D6dO6IHp2tkNOclpVP7mxCLSWe6VH+tTIv7PEVM
VxOKntIxHHlXLxOZJJ/k09SEKDeeVjbZtcg8u83l617XhIIni4aimlplNgR+
mjhVNaGtGSkKxyNPZYya8oWsippQBqZh7reLZM6OUbRrJjehXj0e5yu3Xso4
pdAdng1rQjkrspszvZ0yDfqHzd3c9tarElfYxXtl/rAda6Qyb0JPN00ePtt4
LwPj3HTJmk2ovby4/DbtsMwd6dzaz4pN6GZ46YqK9ahMSCrfLUHZJnRjpq3k
CfWEDOlPEZWzVBOS/WzsNbc8KdNlcLaq5VwTanp8UEvvyWeZpZZKfQqBJnRI
+cZ+Rt1pGQYOCQoV7ibkha6pJanMyoj6NJTFszShKP3Mhwvu8zKaE5d0Jumb
0MD4/jceE19lXC8/3eWj3FufhnZCLeCbTGIaUXxvuxHdqulIOWT3XaZp+6Vm
41ojkhPmeU/1YUVmwvD6zu5iI2IglSoLpa3J/GvtLlD40ohKa49GTsduyJzg
VFN/MtqIaL+eusKENmXEehjzLww2Iv0357fuL/2SkfN9/3vsXSP6EH7di51v
S8b8o1buyc5G9Dpl5OBC97aMWxTrr9cvGhGpkZGm5eJfmTCZUWXb9ka0qMgV
stPwT6Y43fBnbX0j6tnle3jlNxnWosKlpFfdiAJ1jP6ZDZNjPTtTmTtljSi2
7GFmPdqHfTe6oyCfvzf/Xc/umQZKbJeeN2MxqxF5H/aSDerYjx16Orf6KK0R
7XiQG9t/psLEue6mDcc2ooO9AlEtV2ixK71CK96PG9GAdCbf4yg6TMvvv6vH
IxrR+epSn/G5A5jHpMN3q8BGpNl+30Sg9yDW1yAkruPXiEakrr2fP3EI44+Z
c7vq1YhyXOe/zs8cwgblDP+ecNrjU3s3/jCUCTvLySrLaN+IKph2blJZMGPB
P/tD/lo3okOVrHYzakcw8aJr9OMmjaiS42JLyRVW7GEguUaXUSN6etvYPVn9
KPbZoC2uQW9PbzNao+9Wx7BoBnGOOI1GxN2CFDifsWPz8/8ZB6o0ovvcwyRB
ck4Mf1aY66DQiE7nSTnT3eDC/nPmElIhGtGL98cPkx06gV1RGbWXlmlETyJz
O+X6T2CpfHHVp6Ua0ZuaARaTFB5McZTm0n7RRvROq4Os+/opLLv6pe/6mUb0
UX2Gek2YF/sd4f/si0AjapswnC3l5sNI2Mb19uONiKbKpO0ljwD2j7Uysoyj
EQV0iU3wXziNaa/cfZd6tBEdGGKM5dcWxCjzPul4MDail78cCIWnZzBD39RU
iwONKKSJaiKbShir0daeukndiPC6wnmK2yKYKc1bC9HdBhQwmx05kCWKNX0J
LebebkA3R+sVSszFsEOtxDL9rwbk0Cy/5CkujrXbN7gufm9ARWtv6lOXJDDW
605NI0sNiPVCmeabofOY/YmzO6/mG1BemMUJ0tsLGOeHnODcqQYk2Hf3ht7Y
RcylzKgzZrwBUbJ5GoqvSWHdoUcP3B9uQGopi0YdR6UxL6lHsYZ9DWiKqXbI
IFIG6z+sMKzY3YAu8x9uix/HsNPf9rFLvd7DfRVUa1KADWd45hxpb0C5OvOO
C0yymLCHxNy+lgaUJlTdOzUui4VofD+9Wt+AhNIW9UdK5TAJCvOq3vIGtL01
OGxtcxWL+Mi90VrcgOxC7t2f0JPHpuvHLpYUNKDzIxFCFJrXsBhrdRSW0YC+
vTvz28BSAfsqS0fhltKAFgxbhR8FKWLA8eqaWUIDCu38SOZVqoR975Xug0cN
aB/PnOtzPlVMvvDnYZGHDeiDnvWIuqcalh5Qpc0ZuscHbrPbY+qYsgT/5G/f
BvTcpfZ7ueUNzNFNKGbbswFdrMj+K35WE0tsFLnyz7UBHfUsEND5o4l9vnyx
mMK+AeFHQm/+rNbC9vtfNqK624DOXeZvlU7XxoSeASOtRQMq6467XR2jg7le
VXA7eKsBscwae/5M0cNSwlROH9bfi49PmFVV6mPtXRoTzNoN6Kqe8SeP9wYY
jaq+LJtqAxrUHrlMXL6FpWvbMPBiDegjxzL5c0NT7HnSvWf8l/b8nCibzue+
g82PObsIXmhAIdOJB1cX72Cixj5jIsINSNvsNptEmjmmnX0/SkywAY0cwWi+
BVpg3tPBcJ6vAXF2q9RGO1tiryyjCi5xNSAnU2btGy7W2FJRjJ4MWwOqFaAr
1Qy5ix36Fn8AWBoQYeozTptjgxk4ZDhdZWhAUgoHHZN37bDvHhWY+t96tOb/
hOqcqBPG3FKzcmOrHu22WYjR/XDCpHYa8rR+1qOd8y1naBucsaAARGuwXI9+
n9Wy+nDLFSt88bLNaLEeZSWyndcDN6yHssvh9lw9ulyxJe4q5I4dfdg/ZD5Z
j6hPFMgdOu6JybwdDLcaq0f1sxtgI+iF3WEYu2wzVI+UVIuyGcEbK3vyJceh
tx595GkQP/XYFyNS1+y9n9YjhS7fh8uzAZjFx80Tfs31qNZ8gsUhMxCL4N7+
cL++HqlEZLx6cTsIG8ylkA4tr0eNcycDz20HY1uz1MsPiutR1A2uuN9DIRi3
AH12REE94s76zL7RHIpZlx6hismoR36XjskcyHqAPVo+1hybUo+Wk0zP/swO
x2rOcdklJNSjVyaZTyrKH2I7tXwDqY/qUbV436zhYiT2pE0ys8CvHjV8ER/M
9onB4ud5n9/wqkef7j2hPYo/wRIPMc/+da1HIY3uVw1pY7FU8x+COnZ7espv
f5xujcPSH0+q7LOuR4O3b09u58VjmU1vHSrM6tHQc6mIx4kJWC59UT2V4d7+
PNkvkWckYfmSiaM1OvXo+spCwFR1MkYyCdk21qxH+kkmLqIfUrDSOhPZRsV6
9MVyJNIWS8cqptTMzeTr0Xmvg28CHmRgVTTYA0bZemRL0rA0+5yJ1Rmx9VpJ
1aNeNh7XlM/ZWEMY9Qrz+XoUF28XL1uQgzVV/WR6dq4eHbbeZqxzzsXaKAf0
jgnUo4hLFcceCOZj7SLPfDpO1iPTe3Tfm5kLsGd6FZmO3PXoPwk9eiMaEvaq
LGK2i6UeaePKQq+ZirCuYU9qt8P16GswzIQJFmPdZFZCPAz16Ffx9VdFKiVY
n9YVRy/KemQod5ILbynDhne2twXX65D2x/S5fJ5qbJR/iXv4ex1Kftvj2zFf
jY1rjMoGLdWh5eOCqYl1NdhUft2D8S91qOeGxsCIbR32uS+3JGyyDnX5Nu87
olOPTf+O6RUfq0NhxIZMhlIDtqBizxzZX4dmAjDHO1pN2JK7oeTFnj3+7U/2
MTbN2H/ZivoznXWojo55/kdUC7aywZd1GdWhvO1ed9Pfbdjv9Cmh/8rr0HUd
7lkW7Dn253WPanJxHfoy1sf3g+wFtrPS4ni1oA5ZET1R6r0vMDL5pIb09Dp0
c/WDMXdgB7bPIXRMIbkOkW99/qV59xVGmeKysxFXhz5JyVukGb7GaJfV5VQj
69BSyJzoKZMujP4obrEVVodMZvtmlF3eYAdlz4YXBNUh4TOuboax3RhTAk3f
X686dPm1I8elzR6MHXuuX2Fdh0KkV+glxd9jd2KKbPPN65BbRPfj9bn3WMlM
tF+qSR3KCDHKnMkewC5HGOeE6dWh7WgG1fvCg1jIpHytr1YdOhEUufhydxDr
ERV+5axRh8rDWq/ajw9hRiPbX40V6tBDFYcA2ZIRLF9o5o/W1TqUlnlcmDt7
FFv266ZXJupQ+Lirw8usMcyfN0X0olQdknqS+Gn16QSW5STpyXh6T5+Oru/t
xGfsawdXxH7eOtS7aaIX9/UzJnpsf/r28Tpkv0BDokv6gj1r/4AWju6Nh47Q
bzQzGA1T6/tJ5j0/TsOFzz0z2A2L3JkPjHXIWDlW4nHyLDZ9wIn6GXUdCkjy
l1BSmMeEbuuxNVDUIZ68nUdbZxcw5xo4U7Zbi8Jmb50oYP+KUegfVE/+VYt4
fW1O6DAtYbyk0kTHhVr07/wx0QK/75jdVmyR5Uwt+rHK7UWq+4HVqXi3GH2q
3ft/8JDP+6xg8usKUwojtYhyr5kQG1jFHl8TXcE/1KJRqUt/rB6sYcMpR/dd
eFeLLnJvxpZeWccsiXk+ns5atCPaQes4sIFVxPVePPqyFsmOI76ggp/Yr/k6
RQZUi4YCWkQ6Ajax8EfB9lsNtWh6156H7cZvrHj8RP17Ui3qljd29rqzg60J
03R25tai0mL3QZuAv5h04I/Rp5m1qGD9PJgW/8O6Bdp3ihNrUbqMjeT+aDKc
yafgYHZsLYqZX5pUu0COG/ZFnUh8XIvU2d1atr+Q4/+5Gl4NCqtFxS/MqD3U
KfDzXXI6nkG1KOPx09OdhyhxXw4h63v+e/m5kx/wH6PEGV78jjRwr0UzPdvm
eBAVLsKY+EHcshbp+6uedL1Eh2spWWkPmO7htzV+GVoHcK9QqRGnW7VoIrrB
3MOHHu/YHh+v0qpFIsk8SbzfD+KLkmVGGhq1aIszdMmH6xB+0Nlv6odyLVpf
0Ft92n0I1/96fFrkyp6+l0ReLEgz4f6nVs368FqkKq45ZP6PCc83fjFnL12L
uKLz2ebeMOPfB80Xy8RqkUJRKvllbxY85HnxitCJWjTGPBZNq8SGF+94O3dz
1KLcq+d69XTZ8b6LKht3j9aioIMa9hkOHDhbxfdfRQdrkbey5Zk3L7hwfBF5
KdDVIraofNv0f9y4Oe+T7YX9tSjuFPdg5qkTeEWqxC7/3xqkF/uRxyeABx8c
ogx8/bsG6bBRSMVcOolvHRreZ7lRg+I0epSO/zmJX33gSVXwrQa5jDMpfIzl
xcdcnjKcGq9B9WcqI/rPnMb/VTyOfjFUg665tKAcQUGcd+n24Tvva1Dbj6aH
2WJC+D2TfSw5XTVIovtX9QvTs3h82odEoqMGCdPxjD2NEMabh/OPfUY16FnT
ZedEJIJTql7nPN5YgwTZ5NhuF4riguHHMttrahC0Z/yg0BbD1V4uHjeuqEH9
lC/PxdKK4ymXok5lFNSgQ0mSNgHhErgI/3shjvgatC9U++L7OUlcyzS3rCW6
BumerqCZGriIe6W7iBhE1qDJxnE7hTdSeAcTq3hKUA3KT179VfJBGl9UXaiV
8q9BqubonuXXy/jBh00XRr1qUO65LX0qGgzX3zW4dNRpj0+xtSrvLuD+0mdb
G+xq0BLt8WJZHQLPd/sro2O9t7+wj4xU/wj8+7csIuF2Dbplc/pVmKkcHjI6
e51ZrQaZ2XtWdtyXxz18d6U6FWvQMl10GrPuNdzmBLuQj3wNSr8S8yZN8jqu
Ya1OPyNTg4ankyCeURG/Qm/zN1GqBjl3xc4U0yrhklUh35XO16Bzh9XqrzAo
41y/m/trztSgrNByX0dxVfxQ+uBzS4EaZLy/jvyFlhpOSfyoYT9Vg6RLEg6y
BKnjSw94E4LYa9B3Jt3P1bsaeMPRaH1N2hrEMXKT27frJl7cWqxEtX/PT119
4k2kFp5+u+NyC1kNsgoKfOigo40HFW5xnfxdjWiCutHkPl3cTfkI4/B6NaoY
W9iRnNPFrX+IkEX8qEYZ52SE6fv1cPWL5tOr89Xo8kd6FZtnBrjchP+Hgulq
5LQSrpL62hCXvJ/SoT9VjcwMghLjh41wzs4+0vOhalQS9aZUl+U2/lXnku2T
jmo00Ss460B/B5/4c9NI/lk1WrHoi6Fru4P3Zd5T3WqtRp6D1owCzmZ43Xze
OdPaaiTPcXt6ZM0cL4xoP8FSWY3Oe3a3LD21wFNFxg6/KdnLL+9OrG+MJR7o
fnBDNLca+e72aUioWuOu7IJzsxnVqF++XWfx4l3cuv3KcHJKNTrdiXUQZ2xw
NSqvJrIn1YjjW2Upk7Adzp4449t/vxoxLuqWq9x0xBmk/9mH+FQj2yrptnc/
HHGyqWO3pTyqEWIXKqOJdcLn+dRks+9VozcSwVb2X53xsTfW4lo2e/txvqxF
leGC99gHn6KxrEa3Wu4Hn9NzxWvrm/Y73qpGDOtDJ0/OuOEk/Q+bp/SrEcsA
p7t1rTue+nd5YUSrGsnWmfyUivTAA+RPdYNKNdJTGbKO0PTCVYYePWa8XI0O
GZ18uXbdDw/NzbnHcLEaXTp99HSqoj/e7lCvdkCiGrGfFRz9fPM+LkY3eZD6
zJ6fz+7UNDwPwG1GVr5TClSjFrkn7/K1AvH8fMp3+05Vo47L/8i9/gvEWeFs
9D/2amS6lH/L40wwrk5POOywVqP8Z3FpmwPBePjYTfU/THv+B0iepQoIwbdd
fBg36apR0Z8HXtHfQvHPRd3Ry3+qkDvbKYoKhoc4m/uUw7fNKnSqkKKCduEh
rnllTX1xrQp9uvtjProzAn81yXZobqkKyQ/kFtFkReH/SoRXpuerkC39Xy73
xEe4lKds/+fpKsRXglgpEx/jJUx3Yz6OV6GzDx0drunG4LOffB3Hh6tQU2wg
QTsbg3OVx2iMDlSh8KmhC1ZuT/CY602HBrur0J+lyw6RpFjczZf6yduWKlRq
V546ci0Br1DkcHrTUIXE77sE9O0k4F9Zz93orKlCkh47ZyqaEnGDap3DL0uq
0OtPRsMLcsl4vL/N6jNSFep66xhYcDgF71X2f9+eW4WEO0dMmBdScGK+4ElL
ahWi0HpxZpSUhnvVNjs1JVYha+lVu6wn6XhNQO+NhtgqFLnoTvoVnIHzcfw8
XBNRhZ5MK42rBWThdBpXY4u9q9B/X9mldX7k4Fe49JwL3ffiLa8/BIbl4r5L
tpoFzlUoZOgYbfDJPPxHSBxTjk0VogxxeJt9Nx8/rVm4lmm5p0fN/UAGlgL8
zvHWgfQ7e/luOEquvCrAB5unY5MNqlDh65h7r6QKcYYHm86JOlUoc1eenWm7
EL+mRXczXrMKcdVSCD58WYQ3fxdjjlGqQiQ638lmqxI881Rg3APpKjTt8yaw
f18FXjfqPyMiWYWG3I6muRyuxLsf+UoMi+3ly+hyv/RIFf7rl8cHXsEqdElf
XJbhcjV+sNztVA/vXr7m9U7vhqpx3jsuLi4nqlDEnxrOYbcaXKPnHvOLo1VI
xqtiwex1LW4ZaGd2l7kKzajncCh41OF+kja1hxirkLOvIs0ZkXq8JNvi5m2q
KiSkf228saIBp1pq4t9arETcCnLPB8lacHGtutfXv1SigrtKNZELLfjt9krL
xNFKFOofxEox3Io3xZJIEp2VSINVneri26f43E7OtaD2StQoczPWe6AdZ7LK
mO+vr0QHeLuro6YRbns5nv9efiVaWzkjzcP4HE8uiH7dllaJfn7yMIKC53gH
Y6TlgbhKNPvmkc8t4gXOPRtIKgqsRNqJ0dUQ9hLvj3LgnzGuROhYT4KD9mt8
Z9PmtZhOJZL8/WBM71gnLmhqaRmgWom+nT7rXv2lEw+6cIvEJVOJ3JkWDULC
3+CVWXrX7CQq0eRd41A7y278I63WfItQJeqP+jmXpfwWvzClxK/HVole6vpT
jJztxe8oXHtNOlSJNoNeV+gI9uGPa2Qtf1JXoidF58PZRN7hX8OkSLGbFciM
1nW9pagfTz3Hz9/7oQLZ8VmTl1N8wDtTeF5zvK1A7WGWMEH6gG9QcFnavKhA
ydq0oKU+iKuOMpOoqyvQq7dil95XDeHecozXdIoq0NqhqVfCNsM4qYxuPj+r
Ag1MWSqHCY7gZIHk/HKPK9D6RJDBt5ZR/Oy3nVcxoRUoyFA6wvDRGK6v/dvi
k28F+mrAeyTachyvEfxR4GtbgRYcs+GYyEfcYuAjX6NCBZL/1eG5feAzzh3d
nZdCVKD/pt9sykR8xoeVm3h8pSqQ4LyjA07/BVd4Fccle7oC5ZukT//gmMbP
NimxvKWuQLFS24dw+1l8zlUqrny3HIXf2igupZ/DM8X4D8f8KkdRecksb6vm
8EOl5AzaC+Wo6UBYeBH1Ar6R0UT56XU5YhzEVwfWF/FyA1LQ8/Zy1KKXxtLe
toRbHo0ny28oR5FX+1rDIr/hozEOO9akctQou3zd4PIy3hbMv7EWWo6O7XN5
5uG6grsRR5yH/MrRz6MfhAbWVnCRv+QrjW7lKOz9u4xB11U8233ym69FOaKi
NbWVDlnDQ+7Gz1DJl6NqQ8V90R82cIw/yHRRphy9P5PrKeT8E9+cdvj09nw5
Msovj9Vk2cStjZQnYnjL0fIRbPTN3V+4ivq+D+yU5Yieqeg0g/offD/9isbf
7TJkWTub+4xlG2/vmuz7tF6G1lKYL7BPb+Oics3d+TNlSEKeydE46i/OfMHx
hcjLMnTW4sq3qQQy6Fm9RRxuLUOvH1QtsTKRQ0iFcvt6TRlSpSge7XtCDpsC
Ai1NuWXoroXj8vH0fTDOPlUtF1SGqqQpmo98ooS4kbfn+LzL0PuRnE4W7/2g
Et9cTu1chlppTtXasFFBO0NCcY9pGRI0iLV+YEENuWQqOTqyZSjorED0H0k6
2Hzc89f0UhmKnp6NENqgA2UuVQN7sTJkwJJf4dNwADYuqTGH8JShCU+xFDpl
BrjmohFaTV6GBnOYa+YMD0Eq+fsvbVulCCScG3/1H4If0TfwrtVS1BrwZUdE
8TAkl2n+mvpSik56pEebXGGCpTmtu/Qv9sarTCMJ0yOAuw69OtqyF1/b0uxf
PQJx+3ROnqopRfk/IkOuhbGAzHHdiUu5pajsWloZbysrPNbTV7UKKkW9L6d4
H+mywfT8WLGzdyny9tJpGKFlh4tuBlT+zqXIpu/gleFn7PD5iSGKv1OKknXO
37yLcYL421tiL+RK0Qdz7iVL1+MQpj/1qFe6FCkGCB2cFzgBEwvGS6PipcjC
1jbSPfkEhFCa5P04WYq0jra98w7igWHsDgsXRSmqWtUMP+t7CoR6pp1Ob5eg
F2Gr1gv7eOG+gVmfxHoJii0nRI8/4oXTHuYPlGZKkLV5MYtxGR94V1luebws
QaH/+Dnzjp2GPnxBO7i1BI0r6ua9fXoaTvVa1TyuLUHt5Ov6olaC0LNobVuQ
V4IqlcgHj3UKAfcp28mB4BKUKEhl6twuDM7V3y5N+ZQgXpcDdSHhItAJdomL
LiVI+fHsYJPuOXA0slcnMy9BO6NfWCmCReFlgsNz4aslKG7bR+S7pjgMrL/8
G3m5BP0cv7t/dVQcPt84Jr0kXoLemYxspd+RgH8Mz2tIPHvzN+U4NQPPg1QY
U/7x3WJ00IjmPtkPSbg2a/nZb7MYtc6nBx1NuAjacq2cH5eLEeYemVsKUuD8
zywh+WMxSj1Bev889xKUudeHHW4pRsuuuhP0+TLQMkj70qG6GHnzp63ec8Lg
jbjxbm9RMRrZpUdqV3GY/07lGZFUjHCPjFHWbQAeK727FG7FaJHa5L7zqCyI
viorMLUrRif3pT/m05UD/BT5NDIrRsbqN0zFx+TA6FOxga9mMeI1imuuXLgC
ibrbyj/PFSM9r4yvNaLXIL9ePfymQDHKiJC3Lum5BrXM+R3V3MVIP7XtYoPd
deh/p4LdY9jjVw4pd25WgAMKmSILS0Uokuucl2e4MrCT1mzkp4uQ7Ff7HWoF
FThNeb0wb6wIfV9KnomkV4Vrz34cN+kqQnJls77L+WoQICV7eKygCMWppqlr
HbgBjxMTVC9mFCExtYsFtQE3IGNj8WFCfBGaVI+2Zt66AS1Vsfs0g4vQqzN6
L7nXNWHj9Ox6t0kR+rsuYxl2UBv2PZASFdQrQqC9vU2dqQ2H56LsHqgXofs8
TNZCYjogknNh7gpehF4+/ldXckcX7rI9GG7jKEK8nO0tp37qA2V370oFcxGq
HP7eo59sAJneRw7kHChC040D92+BIQxO5EDodiEyq//76FSKERCZbUWqE4XI
4DajD4f/bZhQo3gJHwqRK7Fpw8pjAu67ipNibwvRu0n3x6ahJlBmMnKYtbUQ
qdxNi1rVMoVjp9a8p1ILEdblTmt12AxqP0gl9McWIttMR4OVMDNQC7lf+SKi
EEWNGCQI7JpByBz9LMm7EAVGLzaO/zKHH4UCqg4GhcjlSHAbGb0VROjdszLV
LETc6w/c8pOtgJe2PvCmUiEqo9brdjltDQY2cg0XpQuRZ+Xy8fEbd+H12VvH
ydgLEaH7xKql1xZMJ/MurR0uROxAKi13s4OdR0s3Z2kLkftPZ+w2jz2I//AI
79oiIXazmgeqIfcgozp2NWaMhKQMK9jUnzqC1J2xA8HvSUhym9XSnMcJBphO
8Lu9IaEjU9VExQMnoHEtN9BvJiGLNLnrBw2dwVWy6yVPCgmdiXDK0+R2BcaF
g1PMT0jocS3jyq0EVyhJ0v69/yEJ/RlLJyNndIPPv6fPLnmS0Pq3A1FX6dxB
pfVvQo0eCWWRf72tdNITThES1leOkVAwK+Nz7zlf8HymeieckYQKpVp4udP8
oIewNuqlIiHp8dLANS1/cJfN0ND9WYCUrEQCI4buQ7cc9SXbgQL00rDndWRY
IBx/ySNR9aYAzQjxDDusB4LrFRnhn88KUNv66dd9d4KA+6oTz/3KAnTk2+Qx
CcVgcJafoI2LKkChDKsDnJKh0PnqJ8VocAGS9qh0v9UUCpzXDv3j9ClA7y+/
DI7EwuD1Nfk10t0CtC3tbv5d4wGwK1SOt1wrQJKDjiUJGQ/BoevN4C5WgFY+
qtJSXYqADoXZvqsXCtBikUnH15EIuKfI9rLvVAF6dlL0jeqJKHihFFw6TbbH
d9b5ev7kYzj6NqNA4Hc+ciGZBdUmRoOdclOW3Y981JVx3H9BMAZYVZbjNifz
EZWBrSQsx4CNqq4vXWs+KrvS7Mz4OBZQr5O7ek0+GikOTdrcjoUjalGO8cX5
6Fd4XbGMXRy0qz03507OR8EOnMMsWvHApHFGVdwtH0WVfuU2kEsEq3756x52
+Yi+epUhoSMR2jRMZNvM8tG92uNcCYpJYHkj4cI1zXx0PIFEx2mUDC2au1wG
5/bWj9nXMpyfCne0P3wPXMxD26Q1KdOBLNAsDOj88TkPqfp9eq8slw1XtoSz
b43mIe+v/OhCRjbwZoTfuNSZh560hh9I1suB+VmsbiU/D3l5vb7xeD4XhiW/
RRmn5yFX/TxpVvU86AxPtuiJy0PdlU189c15UHR2nbUoKA89G5rZNE7IB1vX
Iq/bJnmoU/r9Dx8rEhi91tbs1d2Lq2oqDH4hgcoxijOX1fOQn6RncYJxIYi0
3frIiuehk7T5BfdvF8EKBTP0ceShoo06hnMBJeAa50eJjeSihSKVx2HXK8F8
TmiypC8XrT4ms9hargTti6P1x17nIoHWeeNe5SqQnBC32qjLRdQuQQ81/lTB
75Nf35TG5qIArrd3imxr4KtrQi5bRC56FPzX2KKnBsZey/k8CMxFl6ldPTdE
aqHFJuOsmWMuuvs9P6hoqxb8ajSj2dVyUTn3pfdKpHq4R0lmHS6fi4zE8Xfe
rA1grFNObMrkIlOq44vt4Q1A/KFe23sLoqXvTNUkl0bYJ/dU6yFtLnrlz3Z9
zawZwt4LsP/uyEGnfu52DzQ8BQr3zv6tthzEIrC26C3XDgHsVg+263IQdmBw
3LO/HbzNSBv/8nNQz0WT7JR1BPY/ed/tD81BxNe79xrOPIellI5Qar8cpLgf
PEx8noMlbi5D65aDwlharhn0PAeTB3nF9BY5KOuqTquG8wvQYjsZwiyfg8rS
1HoH+17C+6fPpVmwHMT6RcYjXLAD1O6YrrJeyEH5u/td60I7QKE025idLwcd
5/d8HyH3Ci5jxy/x7M9BlEjmQXffazhpyvld5FU2qrUIfZ4o2Q1Z+9vyRZ9m
o9yjLi9cSruBs8TQULw+G3W+8BHlP/kWWNdTuy4UZCNiP9N3XpYeoA1ly5MJ
zUaMR1joZZn6IEywWR/3y0bCJjeOBST2wb4+vUOEWzY6oe6f/IbzHeywJvtd
schGV/VuLL492g8rRax6SvLZqDDQ8ozrxfdgr9pwUAXLRhplmkMngt7D0qr2
K9UL2ajGtD/yR+97mJVOEL/Bl42+PsWxfXcHYKSHmUFv/17+0y9Krcs/gM8X
npC3EVlILPgTY4vzMHx9Q1Pt6pWFFk1451zGhkGn5sckl3UW+qBB9f6d7AiI
Bz+96CifhdJvf3ILOToKS7z6346QZaGCVyGfA0fGQI+BONb+PRPR726t/ac8
Dq9/8stbTWYixtbjxadfjEPu643M5pZMJOisbyxUNwEG1jGaxm6ZqPrxLKKs
nIQuDY/71OaZSPZlv2Gu+BRIXjIuq9LMRP7y7RNyTVPARHeWikI0E73mrn5F
evMJ3pR2NhcuZaCkqzZ54/u+gNSPfydWb2egHbu2VB/XGSCNzKmmqmUgMY+u
1T+dM3DkWY/3FSwDBWuyl9VyzsJKTOpgAnsGkr7AfPPzm1koFJcMlx5KR+4N
7DefSMwDq7v9j2CldCTPWHfvxfVFCDHW4hS+lI40N9O6S6oWYe3aZcVhgXSU
f3XjOD3HEvQdpc07vT8dGSRcy1faWILQ5nydXpSGeBIKhc81/wcbOxNPWS+k
oV01CreLCivgHVFIWuBNQ3n2HBvHQleA/JhLdNORNGTLEuf09MUKHJSgMzXY
SEXelTTkusQqnL4rRZlZm4qe6kmK7ZNfA6OheCU+8VTEfotv7LvbBkzfMZHY
5ElF+sEmNxfRBtxdOcPZeTgV/XZIVH5N9xPcD7xctl5NQTPaG3Pn8n5CjOxq
TFlVCgqTP/1ge2oTOspVRyTOpSBCoeuoYsgWKF1me0Z5PAUpyvRKWExuwfuu
2aKhgynI9fFNh9CLf2Bqxsfb43syujlPvTT+/Q/8Zivhai1PRv/Sp16w2uzA
2TAqc7mzyYiuCGba4nchwRitaAgmoRXzx4L8FhRETKR4SufRJEQyP7xwp5iC
iGgqkMWpkhAH+9zJO98piACmqNgzM4no7szVrnJvSsLmtd55qoxEZHu5LyUn
fT9BiKx5tB5KRFQp59mkqGmIy4YWJ8R3E9D6KpRd06MhJMNHu4qWE9BSwuNr
IiU0xJnpdrbE7gTEybnD/FiDlmBNjGx1DElA4puctxoK6Yhvf3l3+X7HI88K
0tpwAAMxL5RcmD4fj1QDCTj2mYH4rHtAg3koHtn/kl24ThwkhqtXs8lq4pHh
m0l9DwpG4plFu9yEbTwS2BAbS1c6RCT26obFfIpDTbe2lcvXDxOyGREM269j
UTUNn+l/JBbC2f6Uy8v6WCTAOT1pOcdC5GNto5H5schMruiDOS8rQTO1nMcZ
FIs67r2s/S+PlejnviGNY7FoqOZBiGTxUcI4+6hVYO0TJJwsJrXTw0b45OU/
o86OQcepJx4w+nATZS4Yf//jGFQ2lBEY1s1NTF0Zjkz2i0E3hGeOhLMfJ+Rm
qXUFDWPQK/r37GfajhN0fLbLSqwxaJDn27nfQScIUVWz85xs0Si0n7+zboyH
sL3pt3B6LQqN208O2LbwEmS4pxDtQBSKFWW75bzAS8SfdrFfrI5CR8W/ydUc
4SPa/1qvFztFoZHuNzqTDnwEU5HWrtBqJMKYZevHT/MTLTtnjgqvRCCJzAeA
FQgQNKTxa2Lfw9E9fE0g7ZUQkf/7IunSUgj6+0qfDusUJaYrQ5y0bDzRMMtV
5eFaKQKSSueUBD336qNP8V+/FJHuP6Av+9UD0f8JrTj6XYrQUT0hJ2LpgfYl
UqZxnr5EvFlqZaK54440br4IM0m7RFTxrde26ruiuMlazMhfmrifZrp5UtER
rfxbmPQWlyE+BoXbsNE4oh0l6pBeFRnCedD46fHHDmhOq2yOzEqGmHP682jr
4T2UECX0ljpNhugpEztXHmiH5ji7Wx+QY0TayWynI07WaKF9WniqEyOkDvpt
TquboMMLZJN7LypCZ/lHdGv2bdQxLPbVSRkImfY58eocY9Sz1T6gZAIEtcl7
z/Q8I/SLYjLW5eFeO5FXROlSqIc8ZOUpEsaA6BXS5TxRqYHKkquFjaUIwvJX
iv8ZE3VkDzT+t2UJQiwltIP1jiqibWGjuq5EEF0fjTSWLRSRkmPxv05Dgtg0
O2Cdai+L8npp3aL8CEKU74G74jtqdFit9+Lv1r3j5eunTcm7gntW5FRef0kQ
lRr75klbzEBtnZvp3U0Q22z5V7yWBYE2rudqxChB5Pxzdb6zIAOyNJ4hKusE
ETqptv7KiYDRJs+Q2i2CaL5sVj7uIAfntOj7d3YJ4uTvSB5Ku2tQqeeILtDL
EhuOk7S65mrAPqqoh52SJeIXfn+5IKYB64ff0NaeliUqWCmAEL0Bab70++hE
ZIkZ16NbWiI3gVckWMNQSpZQESPs/YV0IX+NVzVcWZawNFHqDhfUA2REHNuv
IUsERGsJxJ3Wh2ZwV7ujJUvULVt/KeQ3hKN+VGlPjWQJrpIn2u9P3oZHDnXi
P21liT8rhz4iDhPYus8v8NRBlpin12c4SjKBGuE33LddZIn2q4sOr1pMwUlU
qUnUW5YoMRHL4ZS/A9YRy2dN/GSJRF+vAZd3dyD+vqrS3QBZwr6O9sLJWTP4
bzftHE2YLKHXf8PS6545yEmJDmSEyxJX/0tJ6v9tDkMUfQP0kbKEKM10l0Cw
BWwwy/NoP5IlOHmF/vgzWMIQn0WFe7QsQUM4nxlOsgTW0n+2Tk/29DNsMRI+
aQXMVjMq8nGyxGePfY9DyqxAnHzh6lq8LNETp4QmJK1hf9QnBc9EWaKpMnZF
/Lk14OQktZEkWSL/7ThPhPJdcKphVWVMkSViFk7e/DJ0FzIqDsucSJUlfCls
Q6RMbMCB0+cIXZosYX28tj56yQauPLzc37OHtS5vz8+72sLoWcLGOn2vAHWv
HMN3baGJx2fq4x4+4xKpmPDQDq7EzggKZcgSrNEfvP9jtgfncTcljT28r5Sj
7EqmPWCZEqC+h7+/NptMPX0PsgdP0Qjs4fHp0oNrNfdAq1OTNLLH9/rfOihi
DsBPPcBhuodr2GWcsjsdYFOryfblXj7qHHLvt087gul9ntR/e/nLC87fFbjn
CKwXRMqY9rD0xYh9N2sdof8tRdFu8p7e8iJp/r8d4dDO2/hXe3rw3xyQKMGc
wO9Jnbf5nl6cpu49Q0F7feqhH3c+7unJ5MBuQd7lBG9Uq3SF9/Sm8Wv/e5bB
GUjkoua6//cjmepcSJIzvDuivSm5598SqaSz8qMzHC13SfovYs+fOjWTCR4X
SNuRfeCz539Pf+IT8TIXcO2bjecLliVeTEkLGa+6QLOR+DCxVz9N/029eCi5
1weLnSi/sFdf+TQCG5+fuYJ/T419mbsskcr6Noqeyg2KZhqDRPbqM4bXgU9K
2Q2ukXOGROzVry/RqBM95AZnlv3K+61kCWc1wx8t7O7wVruAptVsz0+j3Qfz
t91hrsO34f7eBXLT83oztuQOaREcPsk6soRC2Lcbd895wLJfTc9/N2QJPD56
Kd7VA5oEE+c5VGUJoaoRjv/+eYAk+aV1uit7fn618k9l9gL3IvdTosJ758HU
S0BAywvss63pXgrIEoITEf218V7wR+KBl+RJWUKjr/xkL4s31KYkOSBWWSKz
bv317lEfiHtqY3jrH0GIi+x3jNLzAXkW8+O/fxHEq0JWNrYUHzC8p+bjukoQ
/6VeshVn9wWxBZ5oplmCuBR4n9GC0w8Gd37qfO0kiJ4/MU2rRn5g8eoMVfwz
gjBxzTX1z/ADYTUUerKZIMKsXtUmcfvDgYayjK/FBDGoekCv+8R9SI3onOeK
IAipR8r9SbEBcCq4xVxLniD2KQ3yTtUEgGhX/5KszB4/1S0v3g8BsDxw4wSL
BEHcDrh3spo5EAQehpvZn9jjd3ni2h0fCKwuX4eG1oH4oD9y7G9iEBAnxddi
NIC4x29meictBM6uG+PCXzFCIz9d8lZ7CGj/uW4m34cRYieHD+h9CQEN7wEL
0TqM2OBSbFAVCIWuwau+gfcxwovl3IFLtaGQPBlmxHMEI0Iot+sY34ZBTnvc
8bkLMkTqdCzN0z/h4Dp/cOjPbWmiM/NF5VGDR+D+acYnx1mSkB6uonPwfQQu
Y+Euh25KEhUMWRavMx9B3Mo5Hh8JSSLe14fDbeYR9Ns/nJLfuECYGJx/MGD3
GCTIlb2euV0g/rCQjB/dj4Z6wS6bDs/zROLrjrDAgRhIozhyvyxInOjCii78
+hULKtkVeQP3hYm7ddIC29RxQHdb4zavkjBBd6b32O7ROLjy0fVG9hFhQuXY
2jaVVBysuGb1Hys5S/SvXX7B6hkHgfv2J7KNnCFGCt+pSf6OA4fgcnJ0SYiY
P/zLyu13PDy+fk/fmFeAeBD+UN+LJgEeBps2d27wE6d3OZT9jiUAI09EqNUr
fsLmP0IkVCoBNNV8HJSt+Pfum4iNeM8EaBlzCiot5yN++nAH1v1OgO6HN5v+
XeUlKOflU9d/JwKNVmuiYBYPIfZUtOcGXRLkqYi+MnThIYzjOf5VciSBUsdn
psHrPESj3KqpHZ4EdP/l6iatniBsstIF54KT4Iz1HwEbhRNEv9560/DBZDgt
3H4wmoqb+Htuaun8iWRQ3bFbftbIRQhRv+GME0uG7uPHSffvchHB9ZkB6lrJ
8GU+Uzmvj5OQZFJS6EpJ3usb6MQDsjiIjLfZI828KXBrv+umrSEb0Z0bSXtM
MgWK3CXoDFjYiE0v98vu11Mg6cFFloF3xwiN0ypZ4jYp8LcraNn42jGCMvSX
ZWllCrzgnmWauXSUsMHVNtOlU+HZrdzP16VZCMnq7SMBGmkg8PmrZVrGYUJp
hjyywSQNajrpR5JsDxPGLDTky45p0KZ6IJVM+jAR5nVkWf9JGpyj4lVkGT1E
jMgKv5IYSIMLAVG3cbZDhOeAsdvCzXS4KWXHq2jMQERRWnzjMk+H1i9fFAyp
GYhsSVtTLdd0EO4PLJCspifepHqoPo9PB878qP+uUtMT7GYxfGlD6RDg0pWf
20ZHtK4/H1LTzYC/f39SuSvTEP18XcqhVhlgSh72PIOMhpjV7Xve6pEBUSqO
dX4N1AR923j56eQMKJtl/GTKS00YhayH7hvLgDNn7puk01AR/47wSTYYZILB
vMnM51UKYq+hSOQyzoL37fRlb4GM4Hplrb7vXhZoyeUlfaIjI/7cVKRZ8MuC
3NufccryXahzovOuysiCComFpMmpf3C6POrWlcksUGKSV49V/ws0sQqx50Wy
oYvH7uU5sz/gPtb0nV8yGygSAr6co/sDcycEldnwbHAm8184U7MFLyppKf+p
ZoMI1/sAxv1b4Nvb7dZpnw1sRV7MKg2/YIVGVd+gPBvu6WTpjF39CcYaT+tV
6rOhQvmCLOnPBvQmCTPB02yY+qwtoF69ASX8B9+e6t2bf6BNSJhnA8yvvpNZ
/i8bGg2Tbs/SrcPo/RsnAs7mwMqsLXkK5Spc63zu63w+B5jy9lHKda5A/UHx
MXOZHKBRyjhQHLECsRlMsYoqOUDdYrhdzLwCKq0fKJjtciDhBJlMpNF3eLap
vVBQmgO17DOMbTTfwPXempl8XQ6Q42IbxWlLIDj/+PNsWw5sclNvsYguQexQ
59ipvhygPHahSPfWIpjXXerJWckB2Z+8jAffLAC1M1d1xoVcsHWUq3jxZRba
FpuFMTwX6oLw1tKIWXA01Sn5eC0X5i+aqn44PwujGtF5HHq5IBLSwv0uagZK
zpEnpnjngpDgo0Um5WlQW571TkC5IAkjHcbbn2CfReCv8125cKDXMDLP6RM0
fuRyHezPhbc6HKw/F6fgRI+OPfN0LsidueCc/3kSVku6bj+hzANT3x7dwLkJ
IJ20+CjKkAdB1C+WPG0nwCCVXL+fJQ+6bNbqldbH4cVDaU1GgTzgf7L6ypxm
HOKty64+UsyDj6SEyp7ro6DwWeH5Wc08eDv9L+DHxAj81Z3DegzyIPCKef5T
pxGwvM598YBdHlAhMX/53GGQ4o8RfPg4D4yW/k3dZR2CiRmXg6Ef8uAnMyel
5bUBoKTlLo+ZyAPOL9RnlX+/h7MiXcrpM3mw3enOZVT6Hnw9OR/WrufB8MWj
K6tH3gMnwyuKaeZ8+DP7jJb62zu4Ku6Qu8yRD4KnD75uNnkHdrpsslun8iEs
wN40fLQP2nLs/Q+dz4ekCeu3Rn29YCTJuoVr5UP2pFLx8YG3EGL4LEnJKB+u
b9458l33LZQF2EjqmOcDz83nzjmfumGnu93F3jUfUqll19I33kDGbavvafH5
cCgoVfH8+S6YCm+a+T2YD3MNrf7hlK+AquJOEOVkPvgk6VO3FXSAyAd6nkNz
+cAYMM7qqtAB/lymxgI/82GotuqvYexLOF5DO6bNUgCLYVwDbhdfgMJIrYcp
VwF8UvCjkpp9Do47t1jt+Qpgt/N7h1bsc3h2reZmyIUCMLdZo4lYewYmEwZ9
NdoFMBRMEmoKQRBOtt++/VYBGO2mnB1aa4cqvsoD3RYF0MYj/p+BWTuQOVIo
fnErALWV4Rxf5aeQQ1n2kjGxAFL0D2+dvNgK08J/m+yGC0DOrt6iwLURNII/
ePB9KoD6OFYR2p0GaB8tlpxaKAC0SXWOFNoAqcE6depbBcDJdsrdMqseNMcq
K8U5SVBoHJxH/l8tPBMJu/eNlwQXHlB1nwup3atzI+F8YRL0RdY1qnPXAt05
2lIWIIELhUj0Fb0aeBFyh/TblAQ3qdxtjk1Xgei4lEW1DQk8Tt8SXA2vgsxz
jLw2LiTQSsTofcWqwHu8NWcihATmKOocC2MliIuyZLQXkoB+niAFPSqDvInO
uJBlEuSnkWVcOVoETGKZmtgmCZ532Hc3xBdCQJjr4c1/JDA+JSzRfKQQjMR4
oq0OFULmcsN1bG8fRx54RyhJFEJdgakPtUI+BH3UUKSQKQTmQ+/ON43mwYqY
AE3b1UJQ6pOYzrLNg56PH0KFdQqB7IKV+LekXAgRFw485FUIT5qdLIxoc2Dt
AQXxJrAQ6rnW1CpKssFkcuxfYEQhrDoNBi7u3aMy4WG+62mFsGHvUv1DIgs2
Jj95DLcXQvE37S3y6HQwfxh7L52yCPb1JQfh00lwLcpd/Tl9EZxtzt49YZYE
p6MNROePFIH8t9cj3vOJ8C3+5No5viJwPHqmz2ojAZyza9xeyhcBRWAd368z
8aCVl6jzVbUICrP4Q81QHEiSvC8y6BTB2wl14TWtONgqldvSsSyCU/krO2ph
sRDQOOC7FFYE8VMlm9tkT+BOS8Mtxugi6BkXG7iXHwNXn6bi55OKIMmsQblZ
MQaoX94h8y8sgjh3uGghEQ2P+9aCD3cVQZ66xc3U9ChIm2OKlKIthmuqP2ke
U4WD79dN21uHi4Hu5q/86YAHYPxtXCWIrRh4PnTGrf4Ng5OruQd7BIvhxHOO
YVqyMCjaEY+9rVQMIlbct5+dDIGIXVaXEM1iaOPuNw2qDga7fds3iw2Kgbh8
Ui5NLhjO0bxkWbcphpQUgc95tkHQwHwzJSyyGPAIXr+JkQBIZr3oXRpXDEG1
yfNcngHgzcZh2J9WDEfic56ZsAcAdnyGk72sGKpTuEUD3vhDh5BLdnlPMQSq
MWXWHPeFAdm4wkGGEqgY3b0n6+ABx1xmi/tZSqBuYn/Ux0V3MM6/UNbDVQIC
tmbeV63cYYlqtKpDuAT+3hWelLNxA4oezpY61RKgtrTmDYh2AaW/9m1V2iXg
aD16h+q4C8SIoPayWyUQX1f3/UeVM3A+MX2Zb18Cn+oG09smnOC8Dqkn/lEJ
TJZ3Km8qO4L3g199MQklUDiaW5w57gDPmhTeR2WUQP7+8nOmPA6gyvFtKKS8
BAL9JJQ7WuzB8vO5T669JdAW85n6PbstlB0O/OI4VAIdydESAz42sCY3MGM3
WQLSFPs2r32+C/4Frl/Nl0vg+amc9Cu11pBk07yqxVAKx9tLC0j3LWEqjW5D
g6UUrI3EFW//sQDeXsNNFa5SoNiUbKP0tICqc//+XBUuhdf/JlNGfcyha0OO
8oJqKRis8IlS5d+Bg/zxVGLapVAeWSMYev4OaOnO0QjfKoXey7XWfp2m8KX5
AQOffSlwCb0/VrBhAn/8e1hZHpWCyHUSw9SgMRBVXGyHE0pBYv9/Z4vYjSHs
yz0OhoxSoGr+K5ZlfguYrh4+sb+8FPq0jelaKI3gDK2O4M+eUpijyhC85qIP
ztKFZ1YHS4FXMNTt6KgeNNn+Fl7+WAokDeYdO0IPrvalis/9Vwo85zW49Th0
wSju0+Uh+jI4EuQVf+a3FnzdMDL2ZymD8bfnWVXttMBVZzxAgLsMCoYZBRdm
bkIU29Arr3NlQDt0+YT4pCa0ZXWrc2uWQd/TPonfPzVAgVzBudOgDAQGr/ZU
BmvA4J1X8Y5mZdAueTla/ogG/Mf3bOyFaxmwaHP4RvmoAVdZvZlVUhlYJwvK
J5soQwmDRNih7DJwydKVvUpSAkmHqqLmojJYDlC9X7KiCGripcsHWspgSfEQ
nXicAvg3ZXtUfSyD7rFqbQH6a0DHzp2qP1cGqMslPtVVHhJ90tr2fS+DUwu0
myufr0IFnkiuvVsGkT33B+c7rsBUR2TkFk852JbzX3ZplAUbftqKXKFy8H7Y
2eEhIwubD8L6lSXKIcCKOamsg4CDyoEsmVfLQcvgglJFGwC8d8+SsyoH1mm6
Bom7MtAjvvH8m0M5tHA9dDqYexn04p1m4z3LwXD6NyfPZ2lw1LUTXHhYDq5D
fTN3bS/t/ddNayPLyuH9Jda7LK2ScBY+DZ2vL4fyl6MCkuyS0JRt9HvyaTlc
9xXyTfG7AP1mupjou3IA7VtxLRrngWxJpXNwtRzErzEeecQnDlHK3Yt+f/bG
s7VpzOaJwbHy6/QCFBUg+FCgsZZPDEQd5W54HakA7fXtdRMJUTDdvDjBdbEC
Xl6rv3dp8SyY7H95XAIq4Kvx2xQ7/j18RM1c4XoF1AzmHYi0PgMm4ubLzroV
wBqpznV4WxBM7sXsdnpUQPCtv3ocOgJg4sdxdfJ+BTRsTjH6NfKDSRQpfO1B
BWhUcfxY5OSH2yVth7mSKyBcS34lYJ0XjOe/nnJuqoA8JRpjqt6TYPzTxfrB
swro1Dnmc1xlD1PulqV37eXPu+/Fwz4euHWSRbJztAJuajxE/z6eACNjWQXO
rQpoe2WWfl+GG4zse6LEyCvh87FGMmtbLjDy1X1/jbYSKjWSqtqzOMEw1d7A
ia0SvmY5JQgf4wCD4RS715cq4U3MXIzv1WNgMMdbPSFbCdL+K94yaUfBYKPy
54piJfyvhSsN58LpokRZQkISUYjKTpbEzBWJyL4URUKWLJEtsmRLCSFKskfI
9tsXKbLln7IVRSkRlYRKlpLe34f34zwz9557zn3mmXu+DNddDWX/RVFwEuqM
lXBuAM/Wo1nVzC1w3PJHZlBUA7x9maRcFSQMx11iBpMTGsD7d6T2t09CcNyf
W/xOagPYumhr9LkLwbFUqbsd+Q2g8iW/XshjMzh2mlHFHzTAm7mD37VFN4Hj
4OCKalsDdGt1uz/QFQDHj27YuLsBqDO9F2U8+MFhXcSTc28a4JlTmPm/zo1g
j+8Ot/9h4SdlXvjVw83yI1s3fWMnQOiZjBOpktygUH+SuLSeABKttLipIC5Q
ePjpF58AAcLKTAbD5TbA3jd/Y3WkWGujRh9SKwc8i3Ii5skQoG3R+lXEHg4I
FKdOrMgTwILtRlFn9jqgOPmbNqkS4Lxy2suYUHY4tvIkSlKTAB8sTI0qv7LB
7zzZutj9BPB/if+98WIDg9cjmw8eJIDvSzORyf41PBGhfajMmADrnTb167z/
iy9vzQ7nMCPA5By2af65irsdj7zpsCWAgPhd1zvqf7DjIL3czJMA5ASdaMk/
S3glVPhVjQ8BGv+ZZJfqL+ECkXM8/AEE4PwyafUmcRGP28kH9oYRQJxL3KxL
5hdO/hlfohZFAHau7bUKUQt4z43RgaxYAvyK5vteMvQTBwzk6NinECCwtjps
X9EPLHh+3pd6jQCLblOhXDw/MGnz0QLRTALUf9fqcr3wHS9bc7AP5xFAtTyR
sdlzHif1Bj91uU8AGcrCgT2vZ/Duc89XH9UTYGje2ENg7it+KrBXdSeZAN3r
v2cJ8X/FgpZjN8YfEMD2136hEpcvmPxNr9OohRV/4H116/XP2DH91nJ5OwFy
z55o1ur6hO88s3Txfk4AylahNCvzKYz971/v6mfNmQIqpPzcSTy2cUPr3iEW
nqutdNzkRyxv/lB+5h0BfvMrU8/mTmDSf4rzQfMEOPH83MdA9Q/YwTdFZmCB
ALR137Iky8fwMveE/b4VAsjx/uBRlxjDyDSf+YudCAeiTe6xKb3DY59+fXXc
QIQvntuEljRGcUKKjRSDlwgnK/pTKQff4q5O7sQoYSLE3U45eDNsBPt5eVLf
bCWC54MtBSb5w1hgQ8sn/e1EOJZ0dNdIx2tsbxxx9N8u1vm8V2M9aq/w+7bJ
LUnaRHDk2HT/kvVLTPm99LrvABHupS3ZdlS/wKnqvAWSQASz7W7Z+7lfYM1i
FRm6CRG4+EcK+F72Y54hg0mOo6x4XTY56YP9+B2fXZW1NRFov0l13aQ+fCUq
QmX6OBFc3KnKtYd7sQvx6ndtFyLMpIee+GjUgzU+36EknibCvDuHie6R5/it
Q8sBybNE6Hv2nxv4dWM1dR4T64tEmGWeXTLb0IXX+0jwFsYRYZvzyfdf0BM8
UqT8/EsiEbT6m/LeXezESXy2dolpRIhu5E7i5O3ATkaeon2ZRLizNDA45NSO
VaLCh7fnEiFIfUz2YEMbfv0p/xStkAgLtmL/VM624jqpOhmOMiIsk+LPuvY+
xgkOzZNW94hgrzp7MUb3MVZqm/D7Uk+Eci0pypxEC44vUrqwvYUIW0drLK0U
m1j3Bev5trP2Lx9oKtR/gJX4bNaoXUSQ/bqxP8+hEQ9FhiVZ9RNhzGH9hrJC
Bq4hpJgUDBLBSf2Fvt4zOr706Tbvl2EWnomD8i12OlZweJSZME4EfpFp85Y4
Kv53rc+ud4oIjF+zfPJdFPyydVx0+1ciVO1Pz40TpeBYNa5C6k8Wf/fuGat2
Eh7YaF39mZME0lt4zBJOEXClobu/Fg8J5HH4IbWKBhwdGaqawE8Cp9FwlJ1T
j+U/5VElREmgttXDui+9Fv+RrLngI06CxMxcmuStGtxn/1CPKkWCtZkXbxKr
7uOo1g+PLXeTQLnaISJnvApbrfxMuqNIgo+LNqstvFV4l9oG08+qJNg96A68
BypxT6FCT/x+EiwJlMxurKvAspEhI5QjJDgaZeD09l0ZJl1Oq6dbkIC7GLYM
HyrDBjkVCY02JPBdnZ0vaCjFrg2vFFqcSHDvW2THp+wS/K1pfq3VhQQjRsxD
ezaW4OinPC86TrN84ZEzrcabinH+pN7Fbl8SFJQ8Erq6rRDv/Wlv1RNAglOJ
RX+dFAowgy1Qtj+Ylc87p77c8A4ekijpHookseZoqwctV25jIVvO7eNXSUD0
7H0nfeYmLj0lOf8xnQTh6FVLa00uVgvQbv+URQIpwZgx3eUcbHnFx//bbRLc
5p859qv0Bh7NjTeYLyRBlAvTdHwtG/vfzRf5WUqCVd6buYtu2fjqo2dNy9Uk
ONPhdXphXxYWezaZ+aeOBE2CIWczyzPxveE1zzUiCT546A0wtmXi9gU1fs5G
EqTkivgZyGRgNsVcl01PSXBF8cqk3ulUfH1/vbpQDwkSeE2dXyRexVKHn6zf
MsDit9v4XUzdFax/eqVOfIQEPlxttUpbUnB3oFCC5DsSTJheDe2wvYydoxUd
d46TQDNBVjn/ZjKOuOWyJjdNArbvPgPqakl4Q0X4wJ5ZVj8tuqtykxNxDun6
PcUfJHg+qaQcMZaASc8fW6r/JsH+L+YpnPfi8SyHfLE+LxmilH1dc17F4pjN
EAICZNCTbkuU74/BfDuOmxgKkUHQh+vcgRfRWOFA6pyJOBlu+zuMDM1FYabJ
3TYzlu83ahRUfcsThU0dmm5ZyJDBpufWi5OKkdgraBbsFMgwcd/V5H1iBP4V
wyXiqEIGvs8y1gGN4Tjp2s7PxzXIcN+M8C9jKQyX3bPNdD1ABtEb0hOMpFA8
+pY25mtGhh2bv8WpTwbjjHVTh9osySDGIx4ngoOxwZ4t1dvtyPCwf33tdEEQ
Lg8JCe49QYY1DRVu/CoQO94uG9zjRob8vuBCdVoA5m7u103wJMMZt4v9kcX+
2J9XbZ1WABkOXknuy79+FkupnfLKCCaDBhHut+f64j6HjKefwsgwSy3imyz3
wZqlM9n5sWSovqOIu9964T861bJsmWQYnm3+yF/jgWtdXqc45ZDB/quvBWPe
Hbsmcs2Q8sjgnCu4IoXccWvPGcqZUjJEL5tvV/vihkMXcsSaK8hw8dZeXW9T
Nywv3h4tdp8MOwut4j85n8KpZ2SMu0lkuHvvME+EoAvWv2ZTvYtOhj8GUt93
/TmBZwmX+GMfkCEmrNZyZs4Z266+G1RrJ0N/4Bb9E4vH8bYbd7xuDpLBw2p7
WlCAA37KePp0bpgMkjaeyleL7XH0uxWVI+/I8NFlpFF12A6P7T2+9GeKhed7
RETE3RZnW6WccPhKhpbXElk9BBt8KIzWXD/H4iNwV0Nwgw2uahG5cnqZDAIK
DxLCLlth5ymjmcZVMgwtHLjt4WCJ+fhCrEXYKXB7wGJvnqoFDjrWL/aEhwIT
KQX9OpzmWGc2vVpJggLObfESz2VN8Gfhh/yXd1DAZS0ux8rwMM7XnQl+L0sB
R4zVdXyN8VqS2YFsJQokD/RtZus1woT7kUVf1SigYyFtYsFvhN37qtYZa1HA
G+20e2VriDsluLqXEAUWn1wbzf1hgC8c1Fa1MaRAjFH6QbOjBljB+8yN+4cp
gK8tHwg/DjiD1HbCxYoCvdGErpd/9LHDkUszrW4USKzPidHo2I9bjGmnBzwp
sEC+UxMwpoOVDGeGPvhQwAeOJjdx6GBOveOP2YIpIOCkZxF1WgsH6WRoC4ZR
4CGEEk7f0cRv9rXX7IikQJRhbbzF232YpKR2E8dT4LqZb6veeQ0stddro2Uy
BbQvvuDt6lTHqXIFl1yusupv3W/tL62OT0tx+0VnsfhpuTSb96liQcExaCxl
4Rcq/m72U8TRfKLU/yooMKT/5YOhnwL+zH1UYbiaxY90/u+PkL24mZ0hskyk
QNUaYSKneDdWWPt2lYtGgW2cqeXTj+Xxzd+y/0QbKbBpT6Cj1owcDvx5/YtW
KwX493Csph/bhUfmOlyNOykgYpSuIZIniw/P/Hlh/5QCFy7n0+Ley2DJSe9H
IQOsfs+pCgomSONnQ3CDOE6BwjG3C7d2SOH9L8K4H09RYIPYYetD6yRxeW9N
TN80BWo0eKdN5yTwxa6tPnM/KFAZW8U5ObUNT7VbjK4tUqDcwOrk03kxbPs4
0VbgDwU2lovMlHGIYYXGOX1lDipIcPV4TBuK4ps0OZI+FxUuMiJKHwVuwevI
J3Yf3UiF7kzDbOsyETxc82SznzAV1l15uZKzQxhfKSyeqpKlwkjS5phIP0G8
cHvwBGM3FXIvqEisL9iE3W5u7H+iSAWxITlipb8A1rke8WBqHxWeH4o1WVbh
w2XX6tQWdahANj12+e2OjVjgykTFen0qXNe9GP5QnBdPXbLK3HWICoQRsedc
ytzYNiZ5vaYpFZI8vH1bjbjww8gHUUZHqRAfbDMt4bEB55zffcbdngpbI3iW
Ahs5sZHnP90STyq0o9Ta5DZ2PLb0Fe74UCG051KNlzg7jr322vimPxUCdcaa
z0ew4UYS0SYtlAoW/BY/j19eQ8cPFx1LuUAF95Jhk3fuf9HicKpLQjQVShMW
b/KbrSINdk/fC0lUCP9+R21K+zfqy7E+F3KFCjG1dYuDeisocA8KC0yjwgT3
gZDVI8vovpVovGcOFe4kj5sXXlpEMkVdedblLDxGknCR5U/Uok4tMq+iQueH
0emCnB/ItaO0/HAtFZRfXuCI+vAd5c9EEfQpVOiz8aMNZMyj/Ze8aToMKlT8
1YquGZ1DQ8L2TRpNVLjW9j30WvUs2qyn3LWnnQp2DiYXd3nMoPqebT2yXVTo
Nbz8hs/6KzrqvuGl1DMqCKb+TVY2mUZXrr5/L/KSCp7Cg38LbT8jttdZS2wf
qcAdFyJU/PIjKvKL/fvnExVa+MN4cng+Iv1/ZzmWvlJBzqb22Y7DE+iC/KFN
335SgdOYJ/zDyw9ItFFty+clKjydWkzJlP+AKBaSEhN/WP0Iv5zZFTuG5kMX
5Yc5aDAll+HXnPgOZXBPKL3kokF7A2rJOT6KlAp6NXo30sDF32y6ev9b5NNW
hTuEabB8/NqjWbER9H7zCUeiLA1ixXUHVKyGUHSFycna3TTQC1zN1wgZROK6
mu6VijQI8SfQrhS/RI5u/IGF+2hQrp197cemF2jh50pIng4NSL//qw2yG0DZ
KVORN/Ro0H/k+sMtRf2op745+aoRDbIDza90mvQhf8Paa0kmrPyax0rKjvYi
3qG8rDhzGqSrJ39jF+1Bh/8GF4bZ0cAoPUntWXc3emS+i3ragwav9tuQmuhP
UNySvDnZmwYV0Z8U4+mdyODu3g+c/jToHtRIm3zcgVp/q/BXhdLgUtxCwauF
NpR4T/3uygUabPNL/Z2zvQ0dstXUNY+hweZed0Mbi1bUUa17ZjaZBjJcIwq2
XS3osoP+H0ilgabko7eTm1vQYXbIysqgAaEjtUyp8xHqOn7ooeYtGoTqA1lG
uwk947LacrGKBpa3vLnmSHSUTrapeVZLA9XnYUWPG2jI8pT9QSkiDQpUtgaF
06moj+YU8JhJg+J9Kt3Nk2SU5X6SQ/gRDewK60yjN5KRrcCp256tLD0yLdPO
HiChF2c8O7i6aeDEMfncmURAOZu9Tzj10oBLLzzE/FcDsn/o+/3+Cxoon12b
986tR0Mi5yQt39JgQp+/opK9Fo20RYblfKMBR3zAWk9kJbpzLnrj1HcaPH+g
cn0h7B46KRFXqrNIg0//Uh7Jx1Sgd+eTno+ssfi50iRH799FxVIpHkocdHAS
iTNP7CtDbk+vrsRw0YFlo4mR/0rRB+nrctKCdLi3apbeHVGCyp5nPTgvQofD
5VZlQ5eKkXtkjk27GB2oPrLqT6SL0Me+2zHe0nQ4FmfzUCrzDqqILhBmytHB
UD033fRkPvLaU1zNq0AH+zrxmCqt2+hzXPlgnQYd3qka/R7kv4WqFSv9/mnT
QdjVi3Br40109lU1u40eHdz+2btGiOSiGZUG5QUjOiTVVH4hG99AdSPENmNT
OjBiBpkqAdko8DLF6dZROkwacbBzFGWhuVFm8gEHOhyfd+6UE89EhKtNEmlO
dMg0qlTz+y8DBWk1E0dd6OBgPO9hGJiOfqS1j17yosPRb+GHgj+mIvL+JyED
Z+nwRCAkIoVyFYV+/I9n1zk6LByqIfZnXUGLer1aTyLocD5KpLEz+DIKfvT6
bc9FVj2h050bk5LRjMF44lAcHbK+n/y3VpyEPhj/6p9MoQNHWsaM188EdLJr
7cK3a3QQ2zHN3KmQgIbMuHf+uk6HKlvPPCHfePTMSiKQM48OefU6zcWrcchk
YNcWvgI6bGvztlmujEWt9ipNwiV0SLNIXH/odAyiOx3kla2iw8mvm1Uv/olC
ZR7e9w4y6BA5saeeqyUcSU4FWRxposNqXOujgGdhKM8nasG6hQ5my3ffvBkP
RekB6YZuXXTQPC+gr6kUgrjnb37xfkaHIwrqJGfX8yjhfEnmuT46SCpFmrLf
DkYXIsjvYl/TYXpejxEkH4R+rDQlX35LB1L9Gy/574EoILpTKWOMDvmjNrf7
7wYg9/jhqMLPdOg13TnHpeGHLK79E21apkP5RrH5hXEv1MXP86htlQ4GutsU
4esZZJgpdKabjQENUVmTw3890f5cOfIINwPey3p62ht4INJWVedxPgYcc3xU
5XPOHSnn72efFmRA5frPW7QrTyOZYnOrFTEGMN15eLJU3VChtMMimyQDbBVc
VifWXJFYuWshtzQDvF9InT5T54L4q4O/bt3LgAi+lMtY8wRaJt1K0dZlgNqV
evGOYUcUolWqghEDrp5bPtrz3gHN0u8PGh9kgPCCrJfLvD2aaHoo63CEAdIT
yMBO1Q65wpOnJy0Y8JXTTfnzSVv0+nFfsKcNA3of6q+53rBBPZ0TzSFODKi7
sLojeps1OnLkm9dFFwZs2prE/NBnidq7F/kTT7P4BskJdMVYIGYfz8lsXwYo
7RZQFlpnjjTthDnyAxjw4ONs6pHXR1D94Pb7pcEsPNGzXrsemKLyEdVlQiQD
Xu/+e6Cu/DA6634uXy2WAaHEp/M/042R2nS9PiGBAT4LvfJBSYdQ04pyfMM1
BpwCod95Nw1RQnyArGomA6LqzY7tIB5Epjx1HfU5DEgVpgpmDBmgl2JKvPWF
DMi06bGASxjll/jVKpcx4O2LrvuFGxBy21NjWXePAVUtmb9Wi/TQjI7CjdoG
BqxsvRHjtU4XkZp9tZQoDNg31HRqtFsHXTCpflXDYED4jo5c5XJtxHlsz/aa
xwzQKbi+nBuriZ6+836k0MmA8Z4byW5x+1CmV6Xb/acM0Kq19PVJ00Dbw+Ur
ql8wwDkleGiqSw2N/z1jsvc1A14NkNRvzKqiquSKL1VvGdD53owv8ZQK0szd
pVI1yYqf3RkgHqWIfm/37Ns9zYB5xQCr39IKqKX87vnKWQbY+cnpho7sQUcp
MvR7Syz9AvNPbI2SR0L67k7yqwwYWZny7jolh163lf6pYGPC7ZUSUxm7Xcjz
xU6DCh4mVBRVHUNuMkjhhNv4LgEmLOnNy3VdkEbz48VJ5UJM8KwMtcso2Imi
f0j9d1eCCZSx6CPOXFLIMMrVT3YnE9TbB6kb07Yj7nVF/Hd3McEq/eZfDVkJ
1nshaVumzASngoFZ92Qx5Hz75IK0BhPYRrWedlhuRTulC26WajMhYkPAV5vd
oqhWTeJNCTDh2RPqfxwcIug8wzlm5yEmhKL/dvVwCqP9Bvk7SkyZ8D5nVYNX
WAi1W23zLLZhAp9QLCXCVhClvjq+YYcjE+w0PkaJrt+ErE/lVRU5M0Hg296f
lZH86G3g1m+FHkw4Pz+6V6aAF5UtOl6X9GGCpo5FmqYpD/KJvale6M+E4qG8
eI713GghfUt4QRgT0NYettK69ahxi4PY9igmzD1/OD5zixNdKsxpvBPLhGu3
uCXnrnMgvjrhf/kpTPC9+5U/5B47GtC0KxVPY+mdZStJb2NDeU3ZRvmZTAha
S/1y9vU/fddDA5PbcpnQL9nj1YbX9P//3zFkTFWE+jNX9f8H9gNCJw==
               "]]}, "Black-Scholes"], 
            Tooltip[{
              Hue[0.9060679774997897, 0.6, 0.6], 
              RGBColor[1, 0, 0], 
              Line[CompressedData["
1:eJwtW3c80N/3lplS2bLKFhVRZOR93lbZm+xQoZKVzOy9svfee++RSzISPkQl
KyukiIyU4tvv9fr9dV/P67nnnvucP859zh+X3cJO6z4hAQFBAhEBwf+t3INU
ISkpLei1rG89m7sGZhj/xSY+oQXVxMY2p1dqYM+NuzSjYlqQb7SweOeiBrb3
zZ45MPQfFjhBR6qhifWeGqm0d2tBcNDw9PUVLcxS/fm7Wwb/zot1JLhAp4Ol
Mli2yui2IHtXZjYeXR1s+JNUlpRmC7LhGwjbTNDBRO3Xra8qtqBrz8K9dxh1
MbIYlT/nxFuQYhbZI8JLeljx2xOce2dbEJvDjReZ7vrYdOoC2RZtC7qkPxFZ
2K+PUd5t/faVsgXlpIvGFzEYYK7bDxrnj7eg2dLIlznNBpgi7WvFof1m5GJd
YTpCaoSt6Qbb5080o+dqIt9JP5hg587d0c0ab0Ydr8VeCoiaYlrLohKpI82I
qu9zelCiKdbqvEwU3d+MaMmMyt4Z3sHCk+STPJqbEeXayG1BNzPs0keiDq3k
ZqT10UfL4IoFJhXaQ/0zrhllaw7aKNpZYGriwVZpUf/yWX1+QVNlgTmknKBa
CmpGkTQdKzJCd7FGA6p7T582IyP9O5Nm+D0MJs+dSNZqRoUNogyPIiwxjbA5
0xtqzWhD/li+26QlZiGRWzen2Iz6OGu2E/mssIBUbhM+6WbE7T2UQfHGCus3
vFTdKtiMzmcNyagxP8C0psT1ZiiaUZB0clDxziPsbvhBqe/xZjTsTDvipmuD
OUm+OOImbkbrudmMaU02WGIaXmJ70ISk9fqPPnk/xqaMbv05+tKEGs9JLe2x
2WH3pnVyOfqakOk7HrMPOg7Y0wj6n70vm5CQ1zfepWgHLOjGhPKjjibE2hBm
3zXkgJWkG+3WNTQhpaCRpX1FR2zD2EJBPr8J3fjgLVCh8gRzmbHbsPJtQseV
p1WnPZ9iw438wnqeTSjPu47pXvdTjCf681M5tyZ0Dqe4PUTujI3LGP1lc2hC
9xVkUtVTnDHh4psUk2ZN6LJfM7rf7YJ9c2TlV8Gb0ACnlmvETXdMVmXiscSN
JjS/k7idlOaOpXLH1VwQa0IU4q2qTVvumOLEcXGSK02IJVapEnI8sEKpnVsd
55sQz5f79NOnPDHz42/uXzlqRMXVf+8oUvpgzfOBJecOGlGXZYyxqpwPRtmG
r1P8bERXlYHvt6sP1vG40enLRiNSsvs0rLfkg7GM5fjnzjYiu0+bzIbdvtj7
DNcc2o5GRHei3Dsq3x+77HL1M2FrI+IsCVkTWvLHAjQ2Lmw1NKIq0djdXK4A
7CrRveqhikYk4KXtclAUgEVbq6OgjEZUTnt5drQ5EFO+yjOz/6wRLVLFx0SR
hGD2T/mjD1wb0fXjdG7zmiFYYpOA7KFTI1r/nPyYJysEm5O8XkL0uBHpPIgt
SrgRijnJKTw9bdKIRCN5ysz8w7B03YenuKQa0Xf/Z4sBspFYV5JtJ494I6K3
3/cNzY7Elj86PuETaUT+V2X9Gg8jsSumHh8FLjciR6ci7+SO51iPZUSBOGsj
8ghpcX3CE41tuFRKqf9tQGkuKlYJYzEYTWvtpuavBsTzke/aTYpYTOxPY57O
bgNaVY5oK5OPxfx8ELnhegOiijl1PLM1FmMIHXl3b6YBhe4mJZhVxGF46o/H
7i8a0BpdlotXcwJ2f3qPzbOlAfk+WJdM/ZuAhZ07GPNuaEBuZpt2sbKJ2Hgu
kURgRQPKolS7xvk2EbMuoyWNzmhAQ6E8PnS/k7CYdtHMAs8GtPCmSu69SyoW
v8zVpenWgNgGyfkUxlKxREqapb9ODei5Az60J5iGpd77zqdn04BGFb0SmNfT
sFyK4gZSowZEHs8nfuScgdUbMw5ZiTWgMAfKFzmW2VhjENkmzbUGdN1Pu047
Kxtrrt6l7hRsQOlsxfwDE9lYO/Fb/bO8DahImk/rjFoO1lMettRP14BWRDQi
bsnkYu//HBzwbdcj/rTXMvva+dgEz9q59xv1KGhnvPdWaj42qTEh7bdWj6qu
BnOFz+djs/n1wZPz9ehjfVDLb8cCbEXlMU34SD0yeMewPZ1TiO2nz/J/q6hH
kYIcbGPCJdjv3kHV5JJ6lF/brHs8rAT7s9lqL1dQj8p2VoVsFkowAvmkxvT0
ekTINm4xkliKka+ry6iG1yP2CnFX39PlGJNUl0GldT3KSJjcsZWqwiyiix/l
36tHIqri/ga5VVjpYpRnqlk9iq+n85YnrsYkw0xzgvTrkUBQXPUDm2rM+MPB
qqlCPbJRu9/ULFeDZTmIup65UI/EVbMorRjqsNVXrGEkXPWI9arpFRbdOuzK
WZL0g/P16G7IK/2UuDqss2MMrTD80+N3fG+Xuh5bOOlA1klWj0rjnqT6Mjdg
XIVlifYrdYjRapVIUa8Js/kVW2y5WIck5BYiXuY0YfUq7q3Gn+rQuR/dq1c2
mjD5bYVZhQ916HhzceJ+aDNmiS9zs/fVoeyNHLfIoRasZJKtYbSwDm1SVJJ1
BLdjPy4f7+vLrUNLCVZPqJbaMQnf7xMvMutQ/F+dqGjpF9gAb8efksQ61LfV
wcVO0IF9czKS8wuqQ8HGhXm/whEmcCZxTNiyDumox5NSOXRhOkpWum/N65Cc
StUxtcouzC1Q7IODSR2aqhApt/jWhb06mJys1qlDthO2ROcfvcQMVs8vCMjW
obMmxzvEn3RjAV0lm/xsdait+ZvMYHUPVvLH3XGA+Z++o2507G8PNnxdZecB
Qx0y+u/FlKxSL8ZYufGz+HQdumBm/uHPSi9WmXr1iOdvLQo+z05fcaUf+/jk
xSnOyVpUnnP39vPfA9hh5fOol+9q0RcZvgcPDN5gXGt3qCxGa5E7s/vZuJY3
mK0ZIV1Ofy2y0bJZXPIcxIhVb7Gcb6pFgi8+TZIxDGMCPKP8zPG1yFQ14cTH
vhFMxzy3vDWqFh1G3jy+RDiKuaU/ETAM/4dL190QNoq9oqYXTvGrRSyX/NW2
m0cxgyNDcQaHWrTK/o0xt+ktFjCxdItGrRalFMTMT86NYy7PjsT6FP/l5yu3
JuF7hz1kY+L3kK9Frile0vyO7zANa3WKxRu1KG+QIs6e7D3Gut8yUnuxFsn2
G5JoYR+wRoYoAy3yWhQuh53Mn/uIlbSVKJGS1KJLXUaRvBKTWPqdV5KtBLWI
rvP16Hz8JOZX9IuVY78GEU3ezzipNoWpX7+3sLVcgx6JJT6q/G8aW9UTfxTz
qgaN039eZDoxh0391jaW76xBF1SEo3Kk57DhTFvVX201qFLJkf+L2xxWv5wn
aF5Xg7gZVzt6vs1hvs6nd67k1qAz6buqBNPzGFPi4rMR7xpUbn838PfCInZK
4vBxgEcNYvXenJ7jXcIIZs/eEXOpQRnaE+ONj5ewZW416WzbGiSXAz3YnyWs
rqGZxN6kBjlzvaJk5V7GVN5FPj8jWYNqnvt4CpSsYoG5ObanrtegXRqtb6v7
q1iHXYPayas1qHR0gb1Q8QsmdGLmNNnFGvT0XheT6MYXjB4uRR0y1aA5gRCJ
k3Jfsbnigaj139Vog+2tVhH3BsboPGv3da8avccUlYWDNzAt2R/qX35UowtL
T3l+f9nAemYYKT+vVaMxMYI2jbrvWCn1g+jpyWq0i8Uv9pZuYk+fkcW8aa1G
d4LmtClsf2CViswOrxurkfNGxIPWkh/YKr2gZl9tNfJ+YBbFv/wDM6zRo+ou
rUbZR90HhubbGL5cENOaWo2I2382yprvYCc05GJL3KtRDuO5hfDQPUyWVd+x
yLkaFZHPoMS3e9iztUdaBY7V6LoviXEUy0/se0Acdc7DasQuQ0ygV/cTG29Z
iE02/KdnOtkn+ts+lsnpGxcsUY0U+O9qpEQfYPUTXosCotWoUSigIG3rABuI
fHb1vVA1qv5K9XlH+w/286fLGBdfNRosyZFCLH8xjUFbmpcM1aiGN3v0BjrE
SNeaeX59qUIfOHrVhXiOgbBOfe+t+Sq0VPFrNNXiGNzpqLJMnKhCl10unZvM
OgbNsYWFV/uqUPumwrFlFkJ4JBnPY5tfhUgp8L4QdiIYibDjWTStQiI1j/8M
3SaBP3sPe4X0qtB7v1O/KPNIgM/c0tJHtQpdaCtLM/1OAn4iJoWsN6pQ4/2w
pgvhpCAyq8Sjz1iFGM81eS7+Rwapgjw8Q2OV6HC69YpHzAnoS2HvZX5TicwZ
W2Xkvp+AHSJWy4cvK1GmwVlCQ7WToDpBU0hWU4nuUVhweVFSAIHvMR6Z55Xo
TqfnqkDBKbj/dpq7SaES9bMH76mGUcK5qIG8FLwSOQ/cdZ3opIT3ys3sz8T+
YeXcNoZ9SlDoiWOVvlCJJs7I7b+wpoJLzUp0b8gqkXqv3IV1LWrYyWgm/tRb
gcK+HmulVKWFCsNCv66OCkTAcX6QJpoWLBniCfIbK1AeTIntjtHCRLTdH+vC
CrTwbeaVqSkdtPvz7PwIrEDqFe9l2LzoIeBB/CKpfAUyoJ/wZ/52FqR4/My/
3KhAhJTk9s4YI+wt2H16c60C9ZRE/VyIYQRrY+WpaK4KJFcpL3gkyQQq6oRj
TMQVqHEpW6ksgxloROxfCnSXI4WAbLFrqedgcMsEp2orR84zpPQOR+cgoFK5
Y7u2HLXyqLce3j8Pe7y8rc255ejRwS3CKGY2mGSarZHxK0dMFmxjuztskEug
kqMnXY5+ahfa/RzggL3ng3/NxcsRZbTl/C8yTlBmVTV8LFSOlFkMg7vlOWFH
XI0mgL0cOfy0qWvs5oSbTzQCa46Vo5sbO/KWr7lg7bPOA4qXZUjOZddH95AH
MKd3PQytZehDvJcHlSIvxBHqcXDWlqE3V8+MdMXzwo3zt6fEc8uQnmYSJ4Xg
BXiub6Bq5VeGFo/ET+Ta8YHwGxOhlzJl6Ezqtco3nJcgyGA2ckjiX3wpwVVT
70swtWK6NiFchhhj30SwTF+CAGKzvO8cZUi+0AQupVyG91IWdKxEZcjQ4+Yv
Ug5BcK+2/OXSXYoEhPRDLogLwTC2ouvfVopOH56auekgBJxDVrXP60qR7mKc
KGupEAx+sX5UkFeKbsuWeR+wCsM5zkczb/1LkSSB7tzL01ehO8Gu67JcKcrQ
e3HURi8Cb7e7/4ZLlqJXLDnqj81FYE7zrMSacCm6wfzi24UKETg81VVbyF6K
Kk8+OTN8SxTEgqjzzx+VoNVr4YeSYdeh3LkhiKq1BJGTWR+I3JKA1nHybrua
EhS+rVb/KF8CXgubHg0Vl6BChSHtDUJJWN4gdQ1LKkHSt/ap1rslgd1K/wHR
0xJ07OWL+dt6UpB4+0B5V7AE3WR6+KjcDIf8BvUQbd4StH1R9NtkKg51NPmv
as6VINKXZKkf3+Ew8p+KlO2pEkRhRSenrSYNJxUyBVbWitFy5af8CEUZ8BGT
pvpYUIyIP7i4LT6Sg+eJCarXM4rRf15RjyPr5SBj50toQnwxynjA/knyUA5a
q2MJtfyL0RNLT4KGeHnYubC0PWBWjO6ktmb7Dd+EB4zB79uZi5GTIr3FKTdF
IB4Y2qykKUZLXMex1iFFyHSnPZlzshgF8F/r8eNUgvGpHAg8KEJEto6zT98q
AZ7ZXqw6VYTGssl0NDAVOMv5w302tQiVJ3v539VUh7oxsYSR2CJ05pT/VkmL
OqgFeFe9DCtCJtyWQkVUGhDwmWKp0L0IaXDtbJt7asD3Il5VO8Mi5Hs+LumJ
iSb0XjI5T8BUhGy27raLy2iD+Uye+A+qIhRaLSD11E8b/kSuaS+RFyH+pPzX
Id3aIPzdJaT/VyGyaHsaLKugAxk1sVvRHwvRMZ4cbUNjXXAS7e9mTylEUf+5
6/fU3IYzK6dnaWIKEefjm1c3CfShNEl3nyS0EP2qGFzh1tSHuf2FS2uuhWhd
R/xc544+qLT9TajVL0S+bRri9IqGwIlftZY9W/jPz7j7FvGZgGunqkXImULU
peKtHxxnAoO4tfEQaSEq4U1n+XpoAs7SGRq3dwsQZTba1Zk0hQEZMvFHbwtQ
PVWSAL+WGTjKT5HHRRSgUv7kJEF5C+jr2SWa8C9AXn/89oqCLYDlJuUhi0cB
EjAR86N9YwG9N+V/FD4oQCvr/EYTOneBSaFqsvVmAcq3Gyx2cLoHL5X8yxYI
ChDxS0kqtRVLYHiTUcC7n4+k9H+rjUpYgY1yc5bN93xkeG+NLyTKCuhV1uP2
ZvJRdG94fe4Na3ioevvZibZ8RBYpMURR+ACoNS6qCj/NR0dWJR//ttiA1Yj8
LRebfDT2kzfhgOMxtGuYSbffzUdZ1+9f8Ix8DJaaCSI3tfLR0KBYCoeVLbRq
HbEaCuajp/FvzYfo7cFCd2zD90seao6sUNEjdQStIp++73N5iNqqLpDvliPI
/rqcbTKRh9pKzwWuhjgCV0aIpnhfHvpbYeR2/cwTWF6Sqt/Mz0Np2h/dPXid
4JFTsdsdszx0o+K152SoMxj36moN3c5DtwZ4Pp+bcgaVs0QXJdXz0K8axdHw
yy4g0G4yTY/lIa2oTdvNdy6wSUQDw8x56OdHkgkzETdwivMklvqQizwC5/N+
Cj+De5/5Z0qHcxE5odepb8nPQPf6RMPZ3lz0edeyVZfAE0SnhK126nPRieCa
nMwxT9jnWH1dFpuLOmRVovIivMGzViuKSS0XlWibBI4X+oItMYF1iHwu6i7g
bni37AumehX43o1cNFtxleolrx/gv8l+jF7MRXr79bQPy/2AUOaFTih5LsLb
LmUZdvlD0Cgv0/6rHCTFdiRKyhoERM59I7/ac5AD03OeI6sg8GGyCj6oz0Et
HtNTv+qCwP1u4c5hfg7yMB1pI1QPhse7XP+RBOag0MBwxv6YENBh5Aigkc9B
VglnPTxUw2H0RZcEnVQOUiUdstEpDQc1C/MtepEcZEqWN/74eAQolGWbMnHn
IIPzBTVP+iNAUuq8ODvJv3jy4VEl/efAYc6yIdCTjaQ/4y1lM9GQRdKef+VF
NuJ4FcYjyhADLKVGRsIN2ajLReYoWDMG6LdT+0UKspHO50qCyP4YIA9kzLsR
mI3slTMmH3XGwmYxvb6SfDaayf3uyjIZD49VG0+rSGWj759E9rzYE2BtS7dH
VSQbVXLEbX18kABLEgnCmtzZSEuNUir4bwJ8GKQ5pU+SjUy4tr9xCCWBxzx7
wJuwLMS1EbFYPJgCq6+P1zi5ZSFGwwa36UupoFf7fYbVOgvtk4aKeT5PBWH/
F9ft5bOQKk3CYxa9NFjjMvhKS5CF2L5Rqzv+TAf9U/jZjo1MxOuXLVB1NwN6
d3nkrWYyUaDKEEnIaAbk9u5ktrRmIuX08Nc8tZlgaB2tZfo0Ez1Lo5Zdkc2G
fg0Xb7J7mehi8deLIz7ZICpuWl6tlYnG5nVjczqygfrEJVKiK5koua2DmUIq
B16X9bUUrWWg9wRel6zkc0Hs+yHb1p0MZOHCRZUdnA+FHz6rpqplIJF5crHp
8Xyg7Rx0l5XKQNL1dj9xzgLYjE4dT2DKQCVOxcmJ3QVQJCwaIvEuHY0nn/+1
R10EtMysDYvd6UgoQev3wYMi8CMiXoioTUfe5kE3NF4Wgen4qOSnqHTUmH9b
/8C5GOidH3/3V0pHLr+l3X5slkCAqQ7LZfF0FJQn6UWmXQo/bkoqvudNR3sv
rpclNZbCMAN53gWSdHR/oJ5X2q8MAlvy9YZQGrIY/txx91IF7PyZekEvkoaa
+y6vDVhXg3tYUeEKVxoiS/HZ+JNbDcfOPolqpk1DMnGm+oSz1XD66glzw51U
9KdWYSBOrwYuPBAjzqxLRZ1kDe/4tWrB+F28ErdwKiqt1nRmd66HBQuzq3vs
qairZYmDEdXDg82LLH1UqWjj+vGPzOQN4Hyye916KwUpPFDCtLIbIFp6K7q8
OgWFcBo/3p1qhFcVqh+uCqagURKF+3PhLaAkydhJfD4F1elu9AattMBo/1Lx
u9Mp6P1fNy1vuVaYXfRwd9lIRgmWYdc9CNtgn7GUta0iGd2U0/hxJaodLgWR
3pO5lIwyrxcmOWwiqKV5q0LDkowks/x0loQ6QTwnQ2TpZDLaIcXiLW064Wb7
NbKgr0lIiuupwp/FTjD7YVH6ujQJscoZrgzMdEGCKdrU4EtCRO/WTjIcdUN0
uHBKH0MSws9nR2+rvoKw5gJpjDQJXZe5l0+V+Qp8qCNiLy4mIoXmO395ZXrg
Ya/+NdKMRFS+OeFmkNoL97ffTD8LT0QuoYsTM9u9YMYGgdtuiYj5cPfOqFof
6Lpzv5/TS0Rtptll58j7ARf44dJGmYh8WnW+kES/Bkmj+2zCRwkoTvWJR+Pu
axANmegvXk9A7a84XpwwGYCLCx2MiQMJyH89/1PrlTdAnxjeZh+Q8O+9H/96
fH0Qvv7lOuLej0cy1I1L3GYjsMyfXJS+HI+Msk0yv+WMwNztkxo07+KR8WWS
kN6lEXhfs5VNUBuPGo/2Cfsej0Ln/Q6ZqUfxqChy/2Zg5FtoixX6qmkYj7gD
JpPtJt5CI8qP61eIR7SumlUJXGNQxhi+1MAdj3gly1TLOscgceh2UPSnOMRK
8fB6xvF3EPN7QIBsOA4pFYUtkpi+gwhe7INnexyieGbz+GP9O/D15brwKCUO
VdzoHJ+0fA82Iluv5bXj0Cah13HCmQ8gnRF26qA3FsUktpNfPDsFjo85n3Q3
xCLfsB/93oFTkC/VPhGeH4vWsOng/J0pOD67nsfiF4t86J+zeE9Mw8g5TQlM
KhZRP8CsHzTNAuH3L1mkl2KRAvXvycvXPsE15EfyH1Ms+stp8O543SdIulM/
cmc/Bk2a3fCNN5oD02wGK9+6GDQ3qdZJ93geou2rBxVzYxDpgyAG0/p5eIkr
ClPHxKDMWOzL5J954J53/5trG4NmObHkkJgF+MY+G/eKLwZln7w8pz+wCB55
+Z1k2dEoRfUybuS9DOVPpHhGnkcjg8p4hbfTyzAr+z482TMamQxRzC1LroDM
EtltPqNo1CM0ckh2tAInuB+tK9FHIw2/HJbTqV/gxi6RNg1JNFLvZCjVIVmD
qTBxh6aVKMR87Xu7h+Ma5L5JJ/uYG4VkQ1TvRmt9hSuqd6+xMEYhxS+5/vP8
6xC/Hn9UvvccKXUPI7HCddiP7B2QGn+ONGcfdCLODUDDfOZ3op6jK7aHMyHc
30FNYzMyl+Q5Mjkj8DUvdxMeaXuuXPgRgTpM59QvEWwDAebKT/42AlXQ1Plk
qWxD/IUnj7/URKAXrj/z76RuQ8df6+0ShwgUeCKMdE58B6iLdY74t8KR7VvR
mJTQXSiKVZc5ORqOPkgmzFyc34UbnkqBX6vDkag4q7y0xB5YauEny+3D0c03
Sbo0W3vQ+uciw+XNMPS6udVE0HEf1Fd4DE+NhCHGYhXN+vf7sDTKnrFeFYZ6
HO/V/7nxC04XMXBW2oUhT6Vc24PTv8Fck0hQ8Hso+rHDltrw+gCOF07eFNoI
QWv8b/X+5h5BRvS7UKrhEPQum+vFJVoCXNhjZHCrIgT1drRPU+oT4MYavVq1
j0PQ8APNufhFArzqd43p1fVgpOOqO3LrBCEu97k8h2YoGM2rPbhofpsQn/iv
aGm7PBi94n/zZaWAECcsyHhYbxOMkv0GXI1vEeF66qHOIt+CUD3R1vKrdGL8
q3hAC91gEGIqnOG/uEeM+3B5/9ktC0LZtcpd0pokeOkvJ7/GR0GI5vufewUU
pPjfPLPn178GovTVYG3DFDI8f/96ofhaAJI6FXtqh+Ykzs7hZ32/LwAReV0z
zUo6iWcqD/LH5Af8879ssyznKPCUTLOqVdMAFK/3+9L7q6fw53KhzUlj/khA
nThfN+AMftJ2zL272h/dCNG6o0lJiYcksUp9j/RH9wRoJwTNKHG/tZqumwr+
yDvWJUWahAp3iZ4c2G33Q5q3qZtJLanxnRauSPZUPxTMoDcl1k2NOy7aqqu6
+KEOwmHBIA4a3EaUaDxfyA9l74tblK3Q4GbTF2e0C33RqxP+d/si6fAZEucs
b39fpGge3OXylw43FOw0LzPzRSm7qle67OhxXT+dZUJmX1RVpt1lZcyAK13w
/F4T5YMooo+yz+sz4n2afTUzNj5oSzTrXfUsIy7nQeVEruSDWs0/9XlYM+Ew
XLBvRuyDBubHB5iDmHHr1XQith9eSL/CQUD8GytuISkU4lLuhfrIOB0Vos7h
Js97KP6z9ELONbWTd0TP41rXNui8pjyRvanroygFNlzSBy5Mv3qGNNwHFy53
sOOiY2PlV72foWWCZqZYdg78Co+1ULj4MySnp1vvHcyBcw1GS0hUeiDb8IpE
OSNO/PTZBZXkJHekffbuy2Yubvz4I+fR75ruqE/2ekxRJjdO1HFC7xaFOxKT
3yweZObB9+9evbPn44ZcI/Ktz7Hx4gtVAQ46D12RYSYuPKrNh0NS2WclPleU
2sEsLD3Hh6d7vTWQXnVBPSmE38GeH9dTZZMRsHRBS3NUGdppF/HXa23Uxy2c
0fUXwvSrbAI4z9uFoEM2Z5R3QLk3PSiA+7WQH+x8eopO3tTuVPIUxG+E3F6c
N3mKyNhZu086X8Grubfr2gycEKVveXwFoTB+6hTThdqzTmgxSo/cw0YYf7iD
pxd/eIKctFbazn4Uxrm6nwck6D5Bdsad22fbruLJZvy6dpqOaLlPnTwlXwTf
vaX5+j6lI/JOclnQ4BXFtQRdpYz/c0ATuSZbURWiOMVhD7eiqgPC+x/tkvdc
x73TzPc4FO3Rt/HLHR84JPBpv5CHjMftUS/Xa4WqVxK447jpi/PP7ZAT3TWq
1YeS+GeH35G/Qm3R4c/x/R+vbuCD5UKCFb42SCL9XkJDLeBBHt4MqUePUFcm
ScJjKRzHlYaOgjwfofP/8Rjz5eN4/Yr1iJnbQyR1gvzMhJs0nsaR7UDrYI0S
xF9ll96SxXW21g2OfbdCY7ppixkvZfHTnZIyGzZWiFKvXawUl8P9TD5Q91tb
otyBPw6SN+Xxh8mn6z3M7qGvaoPfZFxv4VxWxunWs3cRm/d/tSSnFPBZkdIA
XeO7aHT1gh5LgQKuOSavK6hvgaaL+MJlPiniYqc99xbUzdCdiXu337qr4Hrr
36Pasu8g+cqfNPw8qviNjs/CNTmmaMf3RdGDcVWczGzUNT3PGJFUC/tKiavj
mXnFxE+K9FHxzSJiFUpNfIj/NgtblQZKcFy5HcCig1v+TPG6aKaOJO/aMfV4
6eBCKYGv6C1UUfUk49mkOR28f9pYY/2+ImK+4Gd7NlcX37t70jr1sTRqXrrv
L05/G/c/uWF08hOGAir9qrtsb+NM6j0r8wsSaFv5vt3fV7dxxfdPjp6vCSO+
lQiWyAf6eOfVRPo305eRHOvlerMmffx7q5yA6xI3oiJe5lo9ZoBf4Q52VvyP
DPF6UzuwRRjgAs88dYm5NjFUxcVs+sYAr9IgXC78RQPcGVE3HpIa4nw5WkY8
u+yQ/GjgNo2UIX7AmC/rts4HRGOqJJfsDHHL17/pln9cgaRf3XfC0w3x/wI5
w858vwZQM37/VI8hLiajcij2VQxuyfaqx60a4jmHTo4WKzfAo8LsAxGZER44
o7bd44AD/uOlvTKbEd4iebdi0k4GnlzkeWJ8zQjfSHGx+v5YDoRezVwRlDXC
OfbD2YltbkIDu9Rhl4oRrqeXPXX2oQLE7dznZdQ0wsPr6xMuWyvBhp/xO0zD
CO+kfq0uY6kCvtZ0izJKRviO/Qz57Xtq4LvjnScBRnj8yv68iJAG1Hx8n4IL
GuGV9ESAX9GEW3Ht3E5MRni//Kl0JUEtOEM2wfWLwAhfdGL4pSOgDQwDfeE/
Fwzxwzx2vTuXdeBkud5+aqchfnbsYt2DS7oQM7iAUaca4sKEopROF/XAKWFh
5/m/eqkI4Y+9+G/Ds2vmv+Wk/9XPTGkghE8fkOMV4odnDHGfKB3euAsGcNX2
wQWRSQO8ft16vojHCNbO6NzPtDTAh1meYLXcxpDU3t9eccEAX1X2TGvnMoEG
o6Qvcqv6OGtpjO4oxx3gfmlu88VMH/+9STmNmM2A2LrzszatPr5MYXCKodAM
WhO7Oad6buMdcl/selrNQartOzXOdRt/XE8uwrF0F95nOT0ZHtfFB+OU0JSo
NcwJrFm5C2jjzVWxm8Jd1tA68cL8xZQWnv9mkj1M+QE0+2vnDIZq4c+IHgWI
mT2ER+vXpNNWNfGLT8IVE0Jt4NhkQ2p8rQYuz7f8gNfWHuReD6t0H6rgEtfD
CLXr7EGt/vPfS54q+BV5gTSvfXtwNT3FTX+ojLOYOw++83MAhcqvxPpkyvhO
MqlgQJIj7Mqpe/0RVcTXCkv7qqYdoS+eQXuoXwGfq1czm2J/As653Wxrxgr4
4EhijHD5EwjcmWhZCL+F5x/n3ZnrdAIJ8cS0F0Q38VT6NxEUpE/B+r4t0adC
eTyay45bTPkpPCzsbvqjLI8/w5v0ot49hRynjCtE6XK4tuutFqk1Z9hZVzJg
1JLFCVetvFJp3ID79ZX9rFPSeKK5Gy+vjhvQWVBe4RjBcb6psJG6eDdQv0Ji
9iEOxzWGKziG6Nwh984xZnQOxzPrt3uPGDxgLZQvI8Efw4UFSOwj9D3gSFhX
XpcJw3uK6BkZUzygJ/F3H02dFP4tVfyRMNMzKFIX3zddu4GL+3qfuc/iCRcl
3T//tJXEB39HN28Ze8I+MWbkTCuJmznlmntleMIz1r3ojDYJPMiqpy7pnBdI
On+bQacl8HHVk/oDbN6Ar8hd1+kTw8UilUeSYn1ga4TT2sFdFCdUGuearfUB
69r/ztiLiuKDpCZuXGM+8Dja1T1xWwS/42PLUUPjC2601ku4gwge9CTGaSDe
F6Y/622YuV3DNa4wvaZs8AUmS2KLLalrOON6Luvtd76wwSnN7050DS+3rO9d
pPODuV37pjsxV/Exgw9n/yb6Aavt/ueNJmE8nd7ssWyTHxBjKRca/IVxy7HV
rtAPfmD05cZPFQ1h/LfK74f0Z/2BzXCeZO6rEM6Gs74QTPGH11X2KuyXhHBb
nrvmFmkB8KnhpXFimiCukZ8uatIRACmGgvuLMoK4EMf7k/rzASB/tZ0t4asA
vsOq2KjKGwj8fqeDiKUFcDc6wZPidYHAGy72WevgEh5AfFB/5k0QcE4b/qIt
5sct/a6FndgIgunMcAFvC378FoHtHRKqYKieyxn9wsqPn/gzR36gFww/2Z1j
y5P48KjtXtPlhWB4t/3y493EC3jqQuzxF79DQHZucn60nQd/ZjY408QaCtf9
1z35A3lwk1mSulo8FEIPlT1xNR6cbdLVpDgoFILG7aiSFrjxglHT2jjqMDBK
SK+Po+HGqzv5jR/yh0N4iBGDQDwnHovdE7qvGg7/kQ+trVly4k/aM0jN7MPh
Q1xsk6gEJy7aTFmj2xgOQ0HXGx0WOPD2qj0SaZkIMIkuNhER58D7Ml9WMRhG
gviNW3ZMh2y4xPvqE3bPIuGy41Ntu49seOWprPu9mZHQmOxgKtDAhsc/82B+
uhgJKHPNfukxG25meC34rc1z6Oje/E3efx7/TVdoGukdBWfMooWKullxW9X4
lqWcKCj/IjpzJYgVnw/wo73xKgpYmsprzRVZ8SU3wftPiaPhIU+BbtUoCz6w
epKZSzEavJQSsNYvzHhi76sg37fR8Fok/06lCBOusSB5rWIxGkSe+RbnHmPC
yQ9r5yd2/vHyDpksw4z4M5GcG1cYYmD3j79tqjUjbpHv+WPWKAYK2HJMIvPO
4oJ+oqY3PsfAyPGnN5cFGfB+qWKRnz9jwX5FseJuMi3+oF6C94AsDs6+Ei8o
daLFT1wcOnvEEAe1mgp0oEmLq5z9cUAqFgc6RyubKidp8ZEfki/pXePg72k2
pc9+NPiHov/URPfjgPgSTe9tb2rc9ZwFLnE8Hh5oZxfTmVHjZxN2hLCz8RBe
JZZDK02NG/ox0t0Ui4fx6IGzY0TU+Kzx3Sld13iIVFnygwgqfJnqp9XT/Xhw
aDfOUiimxINDQg3cjieAmndX1EAEJX7hiFnZ82wCnDZ5WuTvQIk//IYLBIol
QFD+IkOKJCW+0Ru2E++aAPIiop/888/gux7nfOv3//FvVS2EqE/jxMvyqdv7
ibAUprR98epJXOjFlUHNE0mQO9F6y4n4JG4az3xYxZwE+sXD/czvT+BNMlvm
NlgSsHuvhga4n8AfZqXzffZPAlEpBum8PnJ8RH+7+f3pZNilqu7RcDyO/xWc
XbvGlgwUg0nZbIrHcX6y1yxxQsnwJfnqhDTbcdy/IdNHXefffuN6+af/keGi
1EoK/SnJ8CE07meYEBme8Sb7QwtXCuxIHjs5QkSKD+SGk58VTYG7UpezTT6R
4HtuzpLOt1KgTl9YVKiNBNe4oJIl/DAF5LPZ3xc9IcGJA39allWlQIxtiFXX
CjH+EFPbS5dIhU2y+Jbz00S4aM0BrY9GGoSyMtyo3DqGKy0eC280S4M4SjXC
/vfHcFO648fW7dMg0l+g+Uz7MTzIjXbdICYNJP9yefIGH8M/SF/uufo2DdBY
vKXt+WO461vTpyva6dD9W9mW4t983Lbd9U7tdga8InIsjRv+CyPc/cqBVhlQ
oLlJ8Cv3LyzdHu5qc8kAeNzwu8DlL1C0T1ZcSM6Aijs2NePsf8E4YDuQ8GMG
RC/sWTi7/YFDWm7RRsNMCJCsC9IXOQBcNCSR1TQLbCdPP8Gn94G1x1qd0DYL
il56PNFv2Yff2orHVzyzoKPv3ofCxH2odzjhXp2RBZcv2Ml+1tyHCxURJrIz
WXDtqp7A7MBPOB6rEHtNIBsiLlft2PbuweZxVQPDimwIW7VQKp7fAVONFw0q
DdlQTvOXffbVDgwlXaaGF9kwR0GVCMU7UMpz+g3nUDaQ7EXxBtjtwD25/26s
f8uGMxI20ycJdmDCW5PN51IOTCimj72/sA2de7orBWU5QHWfI9Y3aQucbH/c
la/PgfCJZ1MZnlvAt/x8bqk9B1j+oy5cvLsFse/6PnIO58DVv7rxa1e24F69
+GDOZg7olu4MzgxuApkja02GSC4EgqshM8UmqK0vuSegXBDZ5++QUFkHwvu+
P6/154KB68ZaH/s6NE2zOo2P5AKNRlVU0s9vwDao95hmIRc+Wkg8+ZP3DbZK
++/EEOeBze0TV0eOvkK8dblcpGIe6ElQ72DdazC1+OR04FgeBH1Ni73jvArE
5OcqoqfywHE5IrtLdxUuCfQrpy/mwaTDhomWyCo8c2UJrdvOg4lV0a7DnRVg
OdVDtECTDzHwn5SH8woYi9L/wnTyIeVLnXqP7zLMhjQv7o/nQ8DFgeL+piUg
rbTwI57JB5OzWh4e6UsgMEbBTvk5H/oDrjXq+C6BF6u5Ke9uPjiMa7i5KS/B
+Vryj7p0BcBr/HsicH4RzKYMh2t1C4DkB4+FK+0iLFz+22zzvgB4Jl8TK8fP
g4b/mAv3pwLY9HlE6+QxDx0TJaKzK//43FuPX1rMQ6q/Xr36rwJY3ZI8Piw0
D1ofq6qEWQohffWNQeroHLwMsCjcNy8ELEXUa5xhDvKm+uIC1gthaHFZIdl9
BqiFMrWk9grBg5OWx1xzBnyCnKj2DgvBiKJyy/LCDBgLsUdZURZBWKDXCO+H
aaANdg9TuloE3Ln7152uT0OA8GVfSrcisFR9xLtMOAX3QmNt04mLoe0iZ+bL
lxNwM8JZvYuiGNYS3nC9yJ2AC1GGV5Zpi+HtGdFbi34T8DWe44cgdzHonLlo
XiM7AY7ZtU+75YthbC6TQq3vA/g0vX22FlQMh3QLGdrv30PaZ+pwMfISiJFd
3dylegfPVvcemVCVQIgmyd73vXEw/Tqp4sdYArnPnxqenh4Hjq3c04N8JdAp
OmLfVDgOxX+EY+8olcCcbJFQg9Q4NNJopwSFl4BjX9gvYccxeCsdVzR+qhRY
f31aWt4ehbNPlkpG6ErBVtJ/w3tmFEzzRcoHWUvh9CHPddG+UVgjnah+dbkU
7qoHLf5KHQWiQZbWetVSGO51UvgoOwrX9AoH4yNLgWcki+h96ggkPWzZ0jlV
Btmh4h98W4ZhNu3EjgZdGRA7vjGxixsGriGjPRXWMjA/tcvy/PEwVAse/pa7
XAbjaTfETDmGoX9HhlhEtQwu/zbNlH4+BL+9BunpIsugo9Rcdtp2EIzjPkm+
oyiH59lbr8s1B2B1x9jUi64ceNj/+IcKDICT3qQP77lyADkOyqSTAxDB+K7H
TbAcnL2lfGV7X0N71oD6Oa1y6KSzo5yUeg2s5Q13rZLKQbbDILFLpB9mX4WH
/2KvgMcsDpoVN3v/+QTyylz+Cth1dlhk5+uFveCgEeWrFUCorMuJTvbCaWVf
uky5CviUOtblONoDMOqcJWNVAW/n69maTXsge8a8Lrz8H/9tHIX6vALzvetT
rNcrgdokoW7w00swI+k+fxUqIVFzVzmu/x+mVbuncKsSOvaYvFxq/mHhe+uO
tytBofAbVbL/P2wbfdTnUgkqLYp1InwvwXR5ldOxuRLOBv2x6XLrAsP3KTa9
4lUgFFxJyiTYCYafuWqmpKuA9LaFiTLzP7xTtbupWAVcPUSvEsg6wYC614vZ
sAqSaaLd1joR6Kv9iLZ3rwL6X0vRjTwI9HqVGpjaqiBHrtFd/eAF8E399bp+
rhqGhRgevOttg0F3g5pkjmqopv28JZjbBrZMDYu/eKohY4bMrN2zDeoNbBTa
Bavhsnne6AORNsAnJqmkpauBXCnB8kxRK+i9a8pXulcNlXN1EYpxLRDwn8OA
SWk1nA798qYqsgl47Yb+dFRWw7rZ77Ae2yYYOM0nyFZXDXfIUhlINJqAUm0u
bqGtGva7lisJaJogbVDNxGqoGlzoxbwWUxuh9vXFTfvNarDS4PzFXdsAn7o/
0wWI1gCL9f1p9r91UP/758SIRA1kK9UoeC/WQZjQiXRWqIHzfDGBh6/r4FqW
AEfTrRrY8lJvNk+qgxB3F4E1/Zp/8x0hUePVOrgiRH5Lw6MGpEslTto51oJv
5iVXls4aOMqqzNwjrfmnD5N88KoGCH5paIhvVcMlCs3Dhv4aSMeK/ZOnquG9
29MA9dEaiJL9MV5WXQ38uh3Rfgs1UPhQaYfduBrentQoWSWuhZXWwhE9+yrg
dHsyWa9YCxnnjtLsyCqgNiiiskm1FhZs3GIJPpcDHl/g16pZC38rGh63vSwH
06oP/J0GtbDsxk5Q6VUOqZ8lPd48qIUWx8BFn/0yoNYiZlkIrYUpjpqf1dul
QHAxweTMQC2ICZxSXyAtgSixSiHq4Vq4avRtXu1LMZy72UdC97YWqC0CZD+9
KYYb5r8qmCZrgd1DtvNhTDG4JJkccq/VwoHxnQHec8WwQcSTdeNE3b9+el+A
FiuCmenGuQdKdbB7a2wpJrEAnhMuy3Wr1YFDf08VoUcB4BfoSli066Cbqtcj
6U4B5D954vCfUR0Q+j/VvcRXADYnrhCKPK4D+uhvY39f5MPB9RJOgug6aFAd
3KffyAPGuDTLxHd1IJyfNrpsmQsDzQMD3z/WQdoh04iXei48m/0loDhbB5Jt
CVIiYrkwx6f/82D5H0+/9/IPeS4Ud9KGmO/XQYXKFtWPyhy4vhFZcom5HrLL
PypqH2aDrqLPt5dm9XCqJyJr+G4WdMo3mr+9Vw+x+UnFRVgWXJL59n7euh7W
dSClgjELiCX1uwgc6kF5ulMLRjKh9tKVRMy3Hqq7M887QSZQUs5Ba049lP1Y
H97mzoDB9xBXs1APqZO7H2ep0kBs7OnxruV6SC7jodnYSoX8/8o8R9bqwfi4
UCfn21Tw6Gew/v6jHrKO8TYfi0sF/tbvNy4TNUBqFc1fP/pUCMnIWi7mbICa
E8yhjv98rey9I/Hsew1w/9Gt2WHDJJj7+RXSrBuAholubxaSwCt8Qj7RpgEO
795oPc2dBK21NZoRTg1ga3WxavB7Iggfu/fANaAB9rmW+DuCEoEjsz9ZI78B
vJxa/+i1JgDBRMxPgqUGyIl7OHn/ejxkPvL6e7DSAP5DymTcbPFw4+gh0c+v
DeCid+h49G9OceWRO7O+3QBCsloBJFNxsOm0x/ORqBF2zn8k0faJg09URno1
nI1wdZYaffgvFjqUuRrM7zaCj8J2S41vDHj/5FGus2qER3hsx+qjGMDz+OaJ
bRrh5qKHkaReDLz8LXCq2KkRahpt/hO+GAM9JeL3NwIb4aBw6KXl+2gYJFOn
8yhuhD9BriGvhKJhstvtafx6IzBpheVO70VCmt2zk8tbjXCR80CoYjQSjJm9
c67vNULs76aa8vJImHUMGJo8/HefWp3o63cjYZ49ipudsgk+2kmD89sIWPXO
f1ch/K+P0V88fa8lHPYk/xPpc2kC5dIMVeeiUHDomJge9mgC1/aD8bHQUPiG
L/i/924Ce3b5Czo2oTAvvzv6ObgJbnuRRbQLhcKgOrMtcXIT6OXa9/B2hEDu
XatC6eYmoDAri5SbCQbV8CP69v0mSOCImgm8GgT9p8g7uv80gdt26sR3xiCQ
iaa+/4agGZT1vva5EASBWAJ33eTxZjjG5b0zNxQIHFnK6r/ONoPlyz+FtA8D
Yb82KVhUvBlukfKfWCwKgPxJwf1qt2ZYMgugExLzh4cWdqlXvJqhilj3evB5
f7iyVnmj2q8ZYjMpPf6S+kP7r8u+VeHNEC+x8kLxvR+Mn710ojKjGXIRYYKx
sx8Q377AUtbVDCbmtyxutfvCvTE2vIC8BbIRlxezqQ/wG5ktcJ1uASupGAde
RR/YXMgKyKduAfo0m3S1az7w7Me513nMLcD8tuz4xgkfiKdi1cq93AKaW+RV
k47e8Eqd8V6WZgvI060mZ4p6QdgHfdLzei1gXXvX988ZL9C4k1ycadgC/JPR
gRFfPGHalmE9424L3P3+ZkI6wxN2Iumc05+2wPTTlwG/ST2hlU73LIt7C0Rl
aHAszD8Dn4z41jSvFqj4zTL+q/0ZUFTQHKUGt0BhCZ9L85Nn8Paadg5TRAuI
N6etmao/g+T2WNnU6BbAwiqdr118BqZybz8zJrRAKYHajBjZM/j//5OwEd0y
92jRA/4HSxoceg==
               "]]}, "Meixner with Escher"], 
            Tooltip[{
              Hue[0.14213595499957954`, 0.6, 0.6], 
              RGBColor[1, 0.5, 0.5], 
              Line[CompressedData["
1:eJwtm3VQ18/XxUFBUjolpKWkJUQ+9y2CEtKNgHRIKiBIt3Q30t2dogtKCago
CgiCCIqKlIBIKc/3N/P8tfOac+fM7s7O7Lmzs5zW7rp2p/Dw8HJO4+H9b+Qd
p47OyelG37f197KFN3Cm6T9c0jO60T3Rfw4nThu4RLN+naSUbuSytqy5XLmB
21vzYImM6UYf3jREXODdxA2dnWjweNCNpuX7z3+i2cLZayW+v2HSjbw+ufYS
c/zC5TLa9ygadKPrd6x0VhR/4V59UihU0OlGZOWvRMjsf+GkPdYdJVW70aVB
QoqL9b9wRCk3j9nlutEek0D9Z9w2ruotKfceUze6GKDzM91jB/cxd4noF103
On51oieSvYOjsulZ+0nVjQYY/BFT3w7Od8ep4zNxN2qgML28TLWLU6V7ofpy
vwsdLIjftOrYxa0aPPQom+lCBAXH73Kp93DCH04/1c3uQqXHfseMFAc4hZhB
mj9pXSiA8j11qPIBTlPuoUNeUhdq6KXA2QUe4O7mkFJ/iepCjBfe85duHOA6
TKhtvb27kN3fiU3a6UMczLKTZut2IUItvZ6hvmOcduyixRXNLuR7gzvIAe8v
zvpySeuiahc6EUlvzcD+4iJyec0FrnahzTQL+8Jnf3EjpsJNPaJdKJo+9mLc
y3843Tk5w3nyLhSr3rC0E4wHNnFHNaHEXagwQ5YwsAwPvOSfnPASdCEytWo3
oxd4kJmHVbsddaLb339snKLDh7lbN45PfnQiI5pPP1Xq8cH2o34J13AnqikW
D5HdOgU+8+4bDqGdiK1S1QieEMKrDkEJw8BOVHUXF6+wSgh8yV+9lR50ImVu
C70cxjPwTvHWX467nejbDfcqF88zIFF1nXzWshPFtn29nC1KBGv32ARvYp1I
iKplsaOHGK7dnHG9fKUTpf4RSlpfJ4Zc3rRmftlOVCRyazKRkwRUZ4jlCMU6
0T0KvDy6WBKoUNi98fR8J9LPZz513ZIUrIjH7MROOlCywq+rZ7nIoetzZDX7
UQd6Yef318SMHKgeY+vkfzqQ0SERL0cWOTx17fD6sdGBQjsaW1kpzgLrZHF4
yUIHonp0xLuDTwFT+b7FdE87UMpsac4JHhWoS/LN7wd0IJFDhuv1l2jAw1sw
+ci3AwVPSy10mtJAZqfItX9eHcj4XLAURQgNLMrLVJ927UDuOuzxRWM04KWk
4k1h3oEURs0VXe1p4ZHBnbM8Ch0Ir7Pkx6VaOujPcuvjk+tArKejrqm8p4OV
D/c8BS51IAmqD+1NJ3QgZuH/QeRiB5pI1K+JMqCHQfv4cjm2DnQccDvFlJAB
NnwaFLT+tqOHPxhFlO8zAm1Py5bOQTt6+jnOirKCEWSPO0r1f7cjBrc5L/kp
RggLQSSm6+1o1z/apleGCRhjJt7bzrejb2OTMz4nTIDlbrv6PWlHY6ep3RNL
zkFKr3RBeWA76hk5FrdWYIf0FZ5+nQftyNaRikQnhB0yqWi//PVqRweTBgvv
nrNDru2mgKFLO9K8P/yk6OZ5KCGvaj9zqx2lirrd6JTggDYz5pcOsu1oWo5U
Ps6UEzqiiLZopdqRx9O4C8chnNDV9JumT7QddUmy9zyr5IRegrfGTBfa0Ypl
0aTeHicM1sV+GaFvRy+Iz9/Iy+KCqeOjI4GdNoR71u3u8ZMbZvhW2ac22pCD
SmZ+DiMPzGrPXA1bbUNrtm03eJV4YKGs7eHs5zZ0ZkL1oUMBD3y76UobN9GG
Wn0dLJuMeGH/0YLgWn0bYiizij6/wAfnFPpNGhzbkIyC8aTSVUGwTq5yLrNt
Q3tLL6xrfAShZjkpMNeyDX14zGga2iAI8rEWxVHGbSj/w+Tlh2xCYDZ99N1C
pQ3FdSxqnMUXhsK70r6U/P/53Vxtm1+4CN8H2GIJedqQcrz8m5esIiDGRPjo
6Hwb2r2SexFuiUDf00n0jbENcQaXfKv+IAJLZHeJ+oja0Nj5tconH0WBp6I2
0+NbK8qrYGN1+ScGLgepVfbLrUhDo8WqiVMc2m769Zh9akWCe3E6OGVxUN5R
WVCZbkX7GhH5cgniYI+t8HIOt6L0I5uLiEMCqmc52t9UtKIomhfP0g0lQYQy
c1LC/r96p2A+/lPSoK/mYPDWqhXN39SM6ZeUhgeRstN3zVvRnACjz5idNAwc
zc426beiS2/ijqTGpMHk+/klkWutiGv8q7V/ngxE9FdvCXK0otsnQy7PdeWg
+tjv3ihLK7Ia6LRZjpODVzI3d50YW1GC4iF75KAcMDds/KmiaEXWon9idC9f
hoZcyRO+vy3oaTe7hbSgPHzwfHKWe7YF7T07FyPFowD/GhKTnr1vQf1TtNyn
7BWAZ/U2tfWbFiTddMrOrkoB3CxP0RePtKDNtQlsWwQHBBo3WM93tiDcPEeV
+jUAEb43gizpLegxnggf2yAGETNfbtBqtiDKzeaHbzSugU/AieywagsSOmXc
2eJ7De5wnBP0V25BqEvo007pNdB21CJfvtKCigk4AnKOrgHbfvdEi1ALGqfu
Z45tVIIOxiQTXZIWpMcZtj4ieB2qH1ernSFsQa1aykm0Ztfh0e0B+R68FsSf
41IxnnAdwioP2Lj2m5HWtBF74vZ10JKxXfq10owKG5/T3em/Ad8N5ZxTBppR
e1hap4u3Kswd6pkp9zWjX5x1r5gaVOFVgZvGweNmRJlnRKn0TRXaVkpFrVqb
EbcsXTLrLTUIvU+xK1bSjFjJQ1t/q6jDuczlgIng/3TnL666OA24+T4hkVK+
Gd2uSly5Oa4NkSXFbmdlmtGf4JaXsKkNT93bNckkm9Hy9jpRAI0OiJPOUxAJ
NaMBRv8vb010gAGEk/6da0YeDKxJZGs6sFg1mrR+2IR6TtaKZM7rAfP9Bfef
e02o+7JUANkNPdC9tq31Y7sJ/QwXOC3prgeD88xUX1ebkIv3r7ngPj2ooXFK
/jjbhKgHV8N5HPTBO4AoZaynCb0r6WZQGDSABlWWuy86mtDXaD7lkm0D+M4g
qjPc0oS4lJ9t23MYgmmzIfXzmiaURKBxQB1oCNhKeUpPbhO69z1en1DeCEi1
lVKr/ZrQydhFZtZRYyjgDk17eLkJkf4yiFKUN4O2maBlEekm9K3Bll/J3wxG
EwIkp8Sb0Fjeu2szj83gzx+fSR6BJsRLgC49wZmD9rgb7TPGJnT2T9p8oboF
nFnt4jv40YiWhGVGQ65agoR+29CNz43oM16hkaO9Jdx+2mifOdOIijoO/Mvi
LKErtaJCcrgRKeTM5rFNW4KzfDqfW1kjipk0Zxe4ZwUT8e58yxaNCOvJijDt
tobjvTtD4oaNaFn6fcjPZWsQsLK3D9FoRKGh+zILFDYQdsm8gu1KI9J+qWy3
ZmcDlxbU+IyZG1FihD/DIJMt5Iry8b2cbED+vz+9kEu1A7u3H3k7VRoQKbOW
lNycI7AnjZbmYA3Im65nkZXKCabUuzgDZBvQTx7GG/eUnUBlMI3tKn8DsmNx
5rrf7ATCXWr0Y0QNSDWxsflv4h3Yze8i+DRUjxKMaFy3LF2g3rQirP9pPdru
sylyzHcBe8Z0vLKOetSq30NrM+sCM8nux44V9SjU/uvFZQNX6A3n292OrEck
vJrLonpuEOGUvnxGuR55L7dV4El5gAJfmNWPK/VI/V0uT7qhB+wtuX8ak6pH
PC/ccPceeICjmfpcMk89yv2K946qzwNuap2aPEdQj/rv93X/0L4LtJc8nok8
r0NCNxdmi0LvQQnezWLDq3VI5PFbFwEeb9hLHP9rJVeHLE0lyCK1vUGdTcPU
VbwOMRVdmMYFesOunCZtBGcdOv6wyzMx7Q3XPbUjm/HrkOoIn3RIyn1Y/arv
RP6sFpW40JK8YfQFnNf7QcaeWmSbVxZ8T80X0k4ZcnG31CL8b+k1wYG+cOW8
0ZxcSS2SJkb9i198IdHYRMMhrBYZFykvT3c9AIkxc/FnirVoT9JWzOO+P0SZ
LCS8vFyL7nzQccU1+cPcN4vVGYlaFPHh/OeHq/4QQWBZuslVi5RSvHKTLQNg
SsGanu10LeJj86PO0g0Evyb7A5/nNYg75eC1q1YwPM9w77+oVIMo58adLs+G
wtud53/j5GtQzlGr/oXTYbCow3R5VaIG8dZEG3gKh8G/s/0tFZw1iEDbnU04
JAxko2jKzp9UIz3V3Y9ywuFQd789irqnGq3vfCbNzIqAnnckz92bqxG1JJ/V
0lAEvJCwOHlZVY2eNqksPtqLgJWNM76xWdWIVTbd3dIoEjgdjJ1Oe1cjXabu
Qxx7FGQaHan/Fq1GQvth3urPHkJZu1a03oVqxKwYoni4/xBaacsGmtmrUdM4
3VN+sWiYeH1Twe1sNQrrGw0lKYoGMpUCkW+rVaguAHEfR8ZAiOxV6g/lVQg3
eWf9qXMcODE/nOplqUJrw2VbglVJQDD6cquBtgoZx/C0uKwlQYEfHVkxWRV6
GnXyu5gpGd7NFUPkUSX65SSJb2aRDFhBb5XGXCUab/916LqeDEzc234LuZXo
/MK9kNJzqdA6KZsxkVqJFgyXWvuvpoJmRHDjs9hKRPwpfuySUypEfCX/UuFX
ieLeLtVwdafCZuUFDXfTSjTprV3CY54GQ8Lm5/HOVaLsKw1s/h3pYDVfKrdN
XYmu9A1XGSynw3HCqt4XkkrU2Ty5l0qVARKbPtEjBxWIN+KDgZxLBuQ3p/5K
/lCBDERMv2nwZ4KX9MhzzpwK1MlmeMemLQu4MUnHa0wVqMJNw4CVOw98+zSs
oykrUPqsxyGnTR6MY45mL89UoEzqPPv+0jy4fzVf2+h3ORqMWgya5HsEo4pE
cs5vyxGR+LUNN6l8uKc8R5IWX46+/9aK/uxWCMODv0/PhJejA1lGHoXuQmC9
TvWP1b8cXSbJPeY9VQRD15W3K5zK0fR0ALuyZhGcU2mc7blejrZoSHXmV4vg
mVp47RJeOVr0632vKF0CjGP55Rf2y1DrryNKH6sScFHvKnTZLEPdO1svaRNK
gOHmetrefBniphb5Evu1BO5oGAWQPi5DRC9+3I/PKwUabSENCe8yRJ6g/+8l
azlYG0xuhP4oRSITrlGOAVWgWxkyvLlYijjSCZuH2qvg2sHFIvOZUuTntiTQ
sFkFPPnROnLDpaih5qE2u101rHxRaNsqK0WzP82lqw1rwNmr6sFty1L0IVeb
stSgDsyGDHRfGpUiZWKj01ey6+Am02khea1S1MVNSew9VwciveYfGXClKJfy
4P5Lm3rYOk0Lr1hKkfebIwmlgAbwSgskUJguQWw17SEf7ZvA9qvgfM2rkv/u
24TB2IQmMJCZaWcaKkF7lP3OmW1NID0n4bDbVoLKRiaCX5xuhn2u7y9qU0vQ
aQmbga6KZghs0U06p1mCyLUiH6edtEDUmwvn9geKkUjzLfxIgg44fX944qC3
GCVq99qrXOqAkHMOD4/ailHJqMUjP/sO8LOp2P1XVozoSo3jRUc7wPU3z2vC
yGIkRTeXtZ/ZCfrMXBG0ysWIL+ltw/71bnjzpP8yvUIxUo91GuEP7gZNa6tf
DJeK0fUlCYkPnd2gUltkcY63GOUZKnYiwR6QVzgvx0lYjCoFOz0HGR4DlxXr
hshgESIN4uV/SfwECgl7y8SeFKE3WheFs1SfAGvNrVsS7UUoG1Gt/o59Agw7
uSOXyovQfMLxeR/Kp0ASyVx6JbIIHaZfoWo6j2CrisFYTbkIsSyL3OZq7AP/
z5wRY7GF6Kzl0WaE6HP4/oK42etBIbJU5ik1s3gOhi2b82yOheid/aFxTcJz
kAh/IuOhXIgoJYMr69afwyqPyU86vEIksDYV4946AKaOyboW3gXIhh1/kNJo
CEa0fYKJbAsQdaZkxGLCEEjLWdQ16RYgjsRHGlcGh4CGVPjMabECNF94ezD3
0jC8qB3urlzNRz/3zuWyso2A7OY/jl+389ELvKsm8cSjUDH9VSNXMx/53X/b
+lxlFOj6xv2uKeQjnZob3IUxo7CVnPsu41w+el0Ryq16dgwqJaSjL79/hA5j
L/zKZR0Hhvuum+Fqj1C2Yc23CbNXsHs894ThUh5isPRt7O96A36xlRXfePLQ
Deci8zNLbwCfyTOpiy4PTbOdo2wkewsUkqRWpru5aIhxNVDM8i3wO8kSFLTm
ojTsSJKKYhLM3qer8Urkoso0uufiQe9gydpSco8zFzHjmY5LNbwDpy0h1mHq
XNRyQVSifuEd3Cd7vu74KweR+9hNnbr6HpKv/kqua8pBAbtqKTZkUzBQrzEt
KZqDXrPPjzJ0TYOaPHMfwfkcJOjbXkC4NQ1vRr5UvafIQVsW+p5B/DOwsOzv
57ORjXzuZIzR5s3APnMN2+P6bJTGWf/+d9QHEI46Y6sonI1e8zGKrvrNQYYF
2tIWyEL315VMWT99guQ4iZxhxiy05bwYsMy0CLFd5VdxZ7IQiX5FR7XiIoTQ
xKcKLWcindB05sSsRbgzZCx1Jj8TPWu1XZ67/hkwkW2fx1SZaHvqtNpA7xLI
37LjkDjJQL/Zopleri+BdPTMSNV6BrImFC0wP78MQktPmTNHM9Bec54Qa8Qy
MGTGPfaIyEBlH6dPKeh/gZ9/eU5499ORBPl8YQLVCqwIZlc+WklHiprJUh/V
VmDRiEyb9n066phRD38VuQJTzb+K8FrSkdPhAW/F3xXos3uqOOecjkytMuZN
fn+DzJdGUcmf0tDPIV+L+jOrkHI4KkL0Kg01/mAxF7+5CvEXcNOBvWloArvS
7p+6CqGhPPzOOWlo4GaCkCvnT3C59OuFsl4aujcgKEiiugZX82PPHg2log7d
JMyzfwPuuXJ7Pm9PRU4nPm1naTehTKF3Jq4sFREpx71PttsE4oX1UtawVFSu
vaPZcGYLJth1LuMUUhEB4+NwkbYtsChidAhtTUHDj4qazC9sQ7JH07hqSQrq
HdYk4DfehmeYqgRNSgqyKZCSCInZBt7Pfn9L3FKQcW+B7uf1bVjjXEgbEEhB
pyw583Of7IB/aVkfUVEyGu+Kairy+w11ngp8E4nJiEeDvkW0/TcsXJuKyw5M
RsTJX1tctn6D4hciI4FbycjZ0WzywHEPSHmd19UYktE16jq3Eus/IKZhI8XK
nITMkxXVbvkdQPp6+kndXiIyDSHP3uw7gP2EoVGFd4lo9eDTiCnxIaBXAla3
kxJRecf3kP6cQ9DU3kooIUxEiQaa1TzDR+CsF/iNfzse0TTRjFBo/QM8nK8g
ydt4RNGYeW6w4B+k83u6/miOR9FpW8c2m//g6V/Hneq78Shk16HRIe0EaKr0
TwR/xSEm+o1sd088rOdYiPHiViwSPR98B/cJH9P6xmd6diIWMbQxM3JTnsK+
vOHMX2+MRU8CM2Ky4BRGUcnI3eAeiya7TYpkSk5hVjqnRUU3Y1Dx79DoBLfT
GHHF7HXxjWhUVTX824uXEMtPfh9D/SoaFRarWOjfJsQk/CfGf9VHo3teKhzf
cggxM+0h3RbXaNRdbb0jRn0GazxstpBcf4jM255fKCImwgy1Yu5fWotCETY3
zB3YSLCfchHd9ONR6CPeOYoXNiRYCE/w8e/aKPRTnwKR15JgNQdeYR3OUUi8
/FrjjSuk2N9Sy0SZn5GIp2qEd8OJDCvbl6mQW41ANFVVeiq/z2KcXGGOdsMR
iPxumNukLgVWoD4umFIWgS4etOY3N1NgOQWWjd8tIhCXedb9IE9KLFEppitr
MhydtA68xo+gwsjcJv2eN4Uj26+BlI5dVFh0FpvCZkI4ihxgf5y8ToWFrTb3
X1cJR2XXLlPKmFJjPsmzo797w1A8/pNVeQUabLebJ4EzNwwZSP3VYPalwe4t
u2lp+IShotvsyVOtNJiL9Ol3ZeJhiFri+RGeCC1m+VFoXq8iFJGpExbEX6TD
1PgDN5uTQlBq2Oz1eHMGbFhnuHneJQTt+J29GlHFgCn5U3uRqIWgHL1umupd
Bgxele9bEoSg0EOUkZzMiDl+f3SaYzsIjVT62YdNM2HW8uLRPnVBKJ5QPSxO
mBkzTxwkf20fhFTDHq3thDFjulIb9EFzgSiUbezTP8lzmHwI8H8cCECfNHFe
45UsmPTkZJ1kcADC0wlkLiBmxcT4HMXj5AJQLxbFT+7MivGMJ1++3OCPaLWr
Rz5JsWEUTEs3s7P80Af57mtW8+zYUmPEXf07vqhBjWPtijInBlm1X9UEfNFo
DWVfTAgn9ijorcnV7z5IK5lF5m0vJ2aowaEoYu+DAgZ7j+7IcmEvVh/TEFvf
Rzl9i5MGV7gxvrdLUf847qN175tzTCHcWFg3ydHuJ2+k06G/RzDIjV2JNlr+
bO6NAn7T7d7V5cGaeHdaH5t4oeqedrVbAbzY2bPn+FuY/uOhSWauUV7szi72
qGraE5EZ6merMvNhPM8TIzIMPNGBhyX+7GM+LNtS0MBd5x5CPc9/fKPhx4Lz
rPa4VD2QFqGzeweVEPYxLPoOM7EHopJNn6j3FcLuvbN4cj7RHa1+IFspWBLC
vt49TDiIcUP7MR8ECnqFsfE6cdH6UBekz0I+7xkrgkX5BzPmnjijmu+RYTmn
RTFM7eVJVKAzOpXI/Z0zWBRr++Y4YfngDur+J6U3hhPD8riK7tLddUTdjyNe
fbkpjun/WjfB33RA9eSqbAtp4hhFn7zihosDIp0YlFL7KI6FmU/TjDjao8al
pu3CuxLYnWyKNn9LW0Tahb+n3yiJyVIE7i1pWaIqdpqjuyHSmOH6ZtLjotuo
rQRXmfpZGrvy9KtEc7EFquJjlhxWksGILN/4Pio1QxvydnvF1LJYQWkVgWel
MXqwMWldNySHRXgVVDpWGSE2mZRvf+QuY3eU09Usqg0R3FAZG2+8jEl/C05W
rdVHWy/fpOiXymMvBY1YORq1UUuhqiSqVcDs/+QECVlqoYDAOGrpSzhMPCdy
gMFaA+nGDigP9OOwkY9m2ut2qujjrQYG7y+A7dmQOea6XkV3O34ciQlcxcLJ
Nm6RfcIhiq85F+z8r2LntAa/fV66jAh7dMh9X1/FVKc8TxJXJdDUplusfaAi
Jsb78L7qayL0OOmVWNmva5hIQKABAc8WjqGy8R2pvhLWqH1qpeKAFpY6bYJr
u5SwI+ayaw/WBWCfkfZkJFoZK/7ndc/62xUoFyajbFa+gUXOa+4M3sXgTrkc
D8/jG1i3vE39rLsijF65zyUgqYJx7cdxErhcB05noZ8UQqrYrsc8iZGtJnzX
fvpEQl4dS/+2//mSuDaQzWW4cgypYw0MpwET04Hg0/xvP+jdxJa9GA/0RfQg
lotjsdtHA/vvCLgGCRqBVOZPUc7PWhhbTYrBG67bMIjqappydLHDLaqPiMUS
fHFDz98d6WIr5CZnGSss4dxMPz77bT3sqdIP98EeK3DewJdq5dfHXNtILnF9
sYF3zBzFMgMGmPGEjv0DN1vgSMi2+i5kiCmt5WRN7NvC4JzDdlyaIcbKI3gY
dNYefG9cmB63MsLG09TQnLQjqEXbxmvvGGNdjalbEv2OsPrDwuC1nglWNjbL
GavuBNGNav78LSZYwGnnCFnLO/AkieeQz8EUczzf2p60egeqFoQP+Z6YYvry
RysrXs6wc6f7aSflLUzIM041I8YF3km0y16pvoUxJE36rdG6QmxHRk7s5i3s
VC1L3bUCV2Dc8E/lEDfDNoZs5nP53aBu0EKm2dUMm12qpdhucQOcsqTuTpkZ
NvRvB1QV3MHvZFa4ZMoMazl35W7RsDtUKvoZBp0yx7RYFN8c8XsAld5tS01+
c0xZYMXpgpsH5P7LS/x0wxy7LBN7Sq/VA1oKYnzPWJljYsoieUH7HiC8WJ5R
6GmO8em9laxRuAtajfGtScHmGKvV/fH3YXehWOqG7kCEOUbjfs4Of+QuzG62
f5EMN8eIA5/+FT57D/RGgnfm/cyxf7HWmca69+BvZCnnmLM5tpt9RjQi6x6g
l5E0Zw3NsdWKmuHGj/dAmZ5O4qmcObbYpmk5x+kJ27kalviM5tjUs+39Mw6e
IHxJNAx/wwwbn8hMkajzhLM2WYdbT82wZwuXBS1+eYIvoSwFSawZ1rW28CxG
2gvYUimkY7TMsIbDsFvt/l7AcHDetoPSDCsjvrC72OcFcsgENzt6C8tlGIsn
P+MNHo+C9BRDb2HJPO68surekMW9pgGSt7AArNMw6b03BPPK2CrHmWJ6vje6
FVbvg7F30/2XdCaYStRPHSdRH7j9/R0/XbMxhktPWk338oHqJcrvcerGmGDT
NMvaPx8wuVwyAgFG2KnvDkG5tA9gPPHCabN3Blim1YMLF/QfAMOwjPKxhwEm
MBc70Zr+AAbYhebHzhpg2q/quV7S+0Ew0cW1NBV9rKBtZ+iE0R88VzdMbYZ0
MQkRQo94Y3+w1k9pF3XUxQYrGZiZc/yBqq6ChZlMF1vLlXOWOBcAEoOsJLH6
OphcaDClHWsgLBnu3hjc0MLGD5O7fpkFAh0B3uHNG1qYpVeJVVB+IDDYhAUO
l2hiUQ6DrVnsQZB55ttWm7UG9k6DzHiUIxj8mEIi3p5RxxyHWfGNrIJB3+5O
up2PGnaEidQsFwfDYS8Jy96qKkadyx8URB0CZLdbevdmVTDZBPWJrNQQKFIz
ykqZv46dUnvHs9ASAvc2Gz5L2V3Hxs+YP+CZDIGN3A+PEzaVsdshblzNtKFg
J5r2U4xcGYvyTPEaTQ+F3n9yY8s21zBtsXMvqNpDIShLXWr+RBFjXi9hM3of
Cow+qS78BYpYnX3b0DJ9GFR1Fm6EfL6KTZpMM/3NDIPPP6izpkIx7BGDpeu1
zjCo6BudORTBMPvJ7/0x02FAv9mlx9wL2OHNwzsMTOFQZ794OS0ch3FgbE9E
c8Kh6O5g28SVK9jqcTn1/e5wsKpqeO3WKo+1dYvY934IhwxW6WuXLspjNyQx
StVzERDeR82wKnAZc+OzsbLOiwDDUI6pd8qymHbZI2nzpxFQeyo5jX1UBhPn
miIz/hwBt98sajjryGC7bKodGhcioRivc7rLURp7QC9KJtcaCVNVpprbnVKY
aZrjouRUJOzK/e1j05XCrlCXtIscRAJxmR1V84Yk9o+c3pIHoqBeaGZyTEQS
iyA4aqMci4KrlcyzdC/EMfswqVjSjSh4qVge8NRLHLuB53abkPohJPTl3DDg
EsdIjxdJjgwfQjvJsRJ9uBiWtDNksbL0EL6WFjKdahXBPO7iSX0mjAbFukUL
ez4RTHdTjuQjfzTQOJZzf3l0EaP7Wdf6xi0aiEt35mdShbHcpVTiJ4fREPLz
Hn5YkSAWYDk+38kWA2sv70ZGCwpi5guErS1YDISFXBSi7hTAOGZ9zauiYuC9
+W97h2l+rPyNRUsaTSwoJdYO+0hewKK0sh8mXoqFJeL0b3Ov+TDHl2/MYoxj
oWKwnFzdjQ8TfKFEFFwQC6SCec8Ymnmxpj5BszuCcRDn8X2AQoMHS8XZittp
xIFIhpyw5z435tmbf8bSIw58tpLuRpRzY9JdVM0GHXEgFH1QHEHAjfU27hFe
VYyHhOCsprV3nNhwwbNGRtMEYNCxfeTlfh67PNVE6h6QAGzpsJf2mx1rOFto
N1SQADHODamrgexYeoA/i/dyAhR9kV8gy2DDLE2lHr51SYSlHaPUd3Ms2GQK
15JAUiLcikh2tLrHgl1/QaUQ2pwIedW61KOkLNhF2fVt0b1EuBAvGnHm6jns
kL7CIiE4CVKWrdPOP2PC3DTSu78UJwEpTc3jAHsm7HNEGN2VgSTAp/qg50zO
hH15IGrnTZAM1DaLS3NmjNjodzIWHtVkeOS9eyRCyYBlDg1Ehb5NBi6V79Im
rbSY9pK8VP1yMvT6FJnoudJiJP9aPs/sJkP851vz7vy0WMCl4itijCnwudO9
4qCYBrMuC9xeuJUCg5btdT3F1Bhr324hqWsKGM3c0Ba3pcbezzlrSAelgKV0
2fOiC9SYCq1pVUJRCuy9Fwg0aqbCRMOkLa58TQEe4gsmWoWU2Pf8ejLHvRR4
9Xlw95UEJVbSzdOdRpQKW7jbK4fDFBjDLxq6nwKpEPOuvEb2z1ns+Pbmixy3
VKBgV2H1dyTHRhSqLv35kwr4RW/sGJNJMKe2yxeOiNKgtciMrwsjwUiFXjKd
MKYBpduVcY9tYuwm0/bRGdk0oCecHGU0IcYmtuWfMfimgZies+1zCSJsuvK1
pvR+GsSHEQ2R0BFivuzW2GXidCgkPOmReUeAMWXsiuOY0oHo6odqXAYBZhrG
TH9dNh2cbw7yjTITYAtmNnMGvunQ3pE+Hih8Gluh/uPgvZ8O7lof1zq98bGH
0TEmD4gzgI9RX4lAER/jP2FRD2TKgOTQu48PKfCxO2uYSKRsBmRr4kg/1uD9
lw9id9N9M6Cj9eVFk3cn8NufPbRtPwNM0iry6Uj/QuZ2070u4kyodVDNHGg/
Bmmna7a9TJlwncAFP8z6GHwNHW8MyP6nZ1v/oUdHcCzWcvadbybUP3DTkY84
BIIV5dyd/UyI05Cl8JLfB/EnYuM6pFkwNoATidz6AxbpLP8aWbIgcsTkQlrF
H+hU/GXlgsuCnUTurkz6P3Cn8JHA1/AssMvIuj397zdMGO90TVFkw+X20kqV
ox34K7qwKsWRDbT2e2YPn+6AINEL1jTxbKjTmz9OCNuB8PaCEC39bLj18WHW
N/IdkKZRUxnJyQbDnQvEwYLbkD9WNN3NkwMXzLdLDqK2YLQkjoRJOgfcyZnu
+hpswd6D+/L3b+TAzfdt8Zk8W6DNf7NQ4k4O5NUQ9GnFbAJB5B/72sYcUM5P
Thli3IA7OM29R5dz4WMcv91vp5+QRS/Hf6SeC4E0G7c3mX7CwBq3qYn5f0zX
/Pv7yCqw5R08oQ/JhZTxWdmXQqsw8acsMnEwFzg5lVePj7+DdPMRXYh2HsxS
9VLJjq6A2jJ+XIdlHpiK/vhMFb8CFvTE+OseeeAuopaXr7kCUQ/o1k1S8kDT
iv3wxfuvMH314qDk2zz4c9zwQGLtC/i+tfD+pvcIDFsJh/1kliGewO4nm+0j
GJwXUc85vQxF0s5W+l6PoCR+e0B9Ygle5Ppo9Kc/As6kV+F2zktwziaZN+/9
I4jZvPZVvuozPN7pf69plA+WhefDCOQXYYJ3RD3SIR88tst6cigX4YvRq/7H
PvlwS8tIQffFJyDvna3nz84HEdUFYyuOT2AWsRN56kM+FJ266+PzYR7+0fFK
d5gWQGTz7XAR7zmguSFUt3anAJq21L4aC88B3wNxLm7/AnCz4H+q8WUWNOcV
KJLzCmAmriUgwXAWCssNV5w+FsDrUWV7XqUPgElHZ7JZFMJz/e/ME1engW3Q
UevU/95lri08HCOchkM9VeJvgYVQqCDT4zg6BW13Sf2a8v9j90yZUIMp4K+P
N782XwhaHiGmB/feA3GqSqqUSBH8UEgcSHgxCfc/dG3wSRfBGwVTq5nMSfjK
IaDOjCuCglBmnRrbSXjWSELwT6MIjOu5ZRfwJyHg5aj3sGsRzBFTRporvoUt
Yg0T0/oicFnSFwyfnQAL7SftN9uLoE91qiSncQJeZl2kgSdFoPVjKoMzcgJq
+CjGuF8WgbXD35MQ8QmwVXp9ZX2tCC7EcoZ2sb+GmWAdjhDhYuDxdwogfDIO
fXsG38priyF73jfPMGoEvNy2bZTbiiH0AC/S5toICKwkLn7pLYYv1Z9vX8Qf
gdT3wx+4XxXDNJ6A/GbQMNi2yY0XbxXDp87sy1thQ0B0j605/1IJ2Ip3MXHV
DkDvj+6LCrgSGItbOk/kOQAeVoY1H6+XgLeWjlKM/ADMaCeVshiXgK5uc5/5
q+dQI4qfmeNXAjo9gT0MR89Ac/2LXwYqgaDXYXf13PvhlF3oH6mRErg3q3OE
w/qh8yOb17uJEmATE3Kup+4HjnFDV9qlElhhQExnO/rgV83I7RSCUuB4/9eu
kaAP0h3rlBJUS0En1UQoy+MJzC17UkROlgIrrYfg+cUuICBhr0+eK4VOHapm
gpIuEBYZUX+0XAoMDzkNYmy7IMCXNaZ1pxSsPEpsnH52AuvZwdNLtGVwxLiR
bYTXCWbSDAc4/TKQ4akrSFVuh4hbfVlqZmWQV5e2V0/VDnUhd6QNbcsg0YGI
WftjGxyPPvV09SqDjG5yGW7vNsi/7bCRl14GXdY8xwt1rbAQ3bW8/64M/h5F
NsdItsCZBuswgvkyaG3hD/Y80wIik+ScVF/LIGG/sOD1h2YIYrOyuPC7DDZk
7gnNhjbD+RaSDwb05XBP/Xcm03QTWM6ZvmoxKAcXfO0fsYKNsHTxb5fLVDlM
tRkIprXUgHb4pA/vp3K4OnKj0cm5Bp7OVEsvfCuHnJXZdXzeGsgNN2zTOiiH
C3fxL7jnVoPuh8ZGCdYKSJvhGTqVWAXPIqwr9q0qYO5rIdLLrACxWVm75jsV
EBT8562+aQUUiFLy3PGsgEf81AH77BXgN/u4eC6iAujkZiM4aspBQow+/2ll
BfhURuOeD5dB6dxwWsR6BTjSimd9Zi8FGvECXYW9Cmg4oviouFYCIVFe1Hv/
KuDBPF2XcE8JmIlzJjlQVcKkeK5eulEJ0D30i1WTrIRUteuTsdnFECFxMZTq
QSUMnX+08Um8CGxjUt0eEVRB2KUp9/h7eXA9/r5WP3kVsLtSqTKI5gF/kqnY
Cl3Vf3l1bFplLRd+pnNti/JWgTJ5mHmxYy7cK2rxfq5cBcz1Mr9/OeZASOfb
gNWoKthhikttiMoC654Oc8qkKpBM9cQ/rZEFSk9ycVJZVWDEXij8jTYLiJ5b
4wVVVgFHQSiBSWkmJL7aDqceqQJVhpiSxyMZkPeVJk6WpBqumXInaQmnQ8D3
PWdz6mqIWl2VOj5MA4ufszfDmKuhIjHNjns0Dbh+lVCMC1TDinBq8kenNKg6
lki9rVYNsSFCczMNqdBBq5cTFVcNCS/lsw40UuDt1bTKd2droKd8P+lrSwIw
eX6pnqCvge8NTYXELglgUXapbpytBqxx+0rTvAmwemamaeBiDbScZ+ryyIuH
0+OsPW0aNfDLcuaffWIcSBlWjKcn1MC6cQMLQWoM+D388yo5owa6eLfOcBvE
QF+Xypv4/BpQHPu+844pBjRYfr6PqK8BcY4m8bXiaLBfFP3k9bIGBidnsvp7
HkLWne5f+mdrganU9OwCYRQs5JHuatPXwqIIy7W4N5HA8/LW3k22WrCI2Q/o
yI+EJtF/h0oXa6FHJu9imEwkjOwqElzSqAWW6IzAlx4RcBg0zkCfUAvj9inC
lw7CwCztk/x78jqwyS6gWTIJge+7ZhZB9HUQy4MLWxcNAS/D2ZAL7HXQ+sX7
j92ZEIhnfj/4QLQOyHgm1iWcgqG3cFSLXbcOcviesc0IBQFbXbuNQ9Z/9TZP
4ium/KHmrGQUVdF//hdxF82T/EHavamqu6oOFDan0sdV/EFTonadrKcOosNJ
+F498YOgriKfpo91QBFqYMPf9AAWBuLiDjjrIRp/6n11mw/c4SNpKBGsB65X
v8dpfX1g72HUhLpkPbRlt7qdu+IDFOqh9AVK9VDdX6P2Z/A+wJv7hYoO9TBc
ohH0fNEbiuatWuPq6qE/b5xWX9wLrPZk5thkGkCj1tUxReouWBI+Py8JDWDo
rEJQQ/Yf02naqtxogDF+xU2eZQ+wlLBdv2fUAAYCyn8U0v5jt+STYZ8GOCZ4
YDW06Q4WK9+573U1QG3/FVmnMlew+O3p+LCvAaTOxTWftfiPCU7qHo00gBjP
6w1TJlcw56KXHp5pgJD7Cjo/El3AzOKqCutBA5zl3XhXHe4MplM5LkNyjRC5
o6ToEOsEpl95mueuNsILg3ThRY3/eLfx95ZqI6TGSOKtUjuBCc1QEItpIzBk
fPtRk+cIxprbyR5+jXBzY0+0t90BDIfU2s89boQf6seuh6fsQWDub5AMexME
EZOSeR9Yw7ifSXM2VxO8GtODLyPW4HauffmArwnCIi7sTGRbQ5uJi0qvaBNw
znb0sl22Bmxmlvrq1Sa42FU+ahVmBYbvO8vUbJvAs96BLorfEg68aKdrHZug
zTfJ2PvfbXhE505y1rUJiGffJrbW3YYlPT63195NUNplb19Bdhtc36bL6D9s
AvpeQVvBSXOIeH131LymCTrYXBuXom7BBfeXx08bmkBpsuRvKXYLRikERDla
m8DkDJfAuSNToNJcTFt63AQXSIWfsd0zhbxxTXOHl03wj0e5ScvRBFpeCG15
bDUBOQ+z3pynEXx6/pU+QroZHJo+PTE71oO2wz8zE5ebwW5Sg8l1VA9ixUkf
sUEzcDL5KB1l64FUoQhX541m2Kzxp4uX0YNoPx+RVeNmUKQyMTL30wUxcZIb
2v7NMJv3oqqDXgcIHVlI84P/4/DCWbqf2jBbcPHlj/BmwHnj31zo04YIcl29
8PhmmCuJaGhw1YaZb7m3O/L/82soL9XO1oLQAmFf1r5mOA54qqIgo/Hf/uLk
nQaawZfL7bXrxk0QJtf51z7y33wCxS4bVNyEqQfeEVpvmqE4ciz0KtNNEDR4
mhy21Ay/maauWRCow1sy7ervBC0gRbQTInisAtwPPGfbVFug4q75i30LZWiJ
im/o1GgBOQflMNuLyoCll4f16LQAWds/FqVjJbBonBbsM2mBf9xZjaZ5SpD7
Vd5/zKkFCPhu0I0sXAMaXQLWpZgWoMR/hvofKELxbbatLwktYDPv92FLUxHE
XKUHvqW0gGdt55dwHkXQjHZ0Wc9pgdu8YzxvJ65CzNPx3v3qFtjoO2Dcu3gV
8IQyzClHW0BlJJRfYgcgSbZBnOZVC5gp4UC+GoD9+jAh/dsWMF4UHNq6DXDF
6qD+3GwLMOluvzV9jQOfLPN/vKv/rXdFI/CkXQE2TvMVXiFthZ4Kphz5YnmY
/9ix6KTWCo7JvqwdX2Ug8dSK0nPNVoitMTReqJYBjJ++mlWvFdqkTD3y3WSg
zNPz7utbreBvFiE/eyANLqRipy65tsIvHLMiL6M0HMlUc+Mlt0KV6gNs0FkK
6sxnHpqkt4KGOK69UVYKLMKJ1lqyWwHvrPSLc2ek4Nkruza74lZ4RDjQ5Voi
CbF2XMpjLa0wm2r+ZnlRApjT8uwz37fCGaag0wRe4jDaNTq6+aEV7B53Wtir
iEPAwsF/rUIrHHG+c5JmE4dFAeM/RyutAGG7l1lGxKCqjy7aar8Vqon0qWe5
xEBmI6FamKUNDKy2GZOmLoKBasjaM8s2qF82r30QJgB9yh1Wb23boGXYXoHi
hgAIK65NfXZsAxdiWXIRcgEgkDfux7vbBubslFdJs/mhRVgsExfaBr+dN6eo
Oy4AFdUi9BS3QVje8WsNUj4IIGdof1HeBoxODpWnpnnhO/FNwQ/VbeBTVpQi
WsYLCL+Lbr+5DeaH+C+tAy+47ST9uPSsDbz+rTh+COCB8SlIa15qAxPlHM04
Mm6QnfQm7l9pAw/sE07xExeUva4NnFhtgzPO88iylQv8RxgdN7f/03OoKyfM
uECwZ/PKxdPtYBdxbt2qjROi8wtXqrjbofqabWKINwdcsz2RK7JtB2cvHrIs
T1ZY/PMT8hzbgeauo9R7CVYIiptRznRpB1F716TKbRboaWnWifdqh5Wjx9Gn
vVhAAt/WyTfiP52Bes8z8BxwFYxka5e1w67jozWWGiboE28vUK9qh8DLL0ZP
32MCi8Hisut17eAfx7TqfJkJctf8mq60tYPstQLdrnFGoJa/OMI/0A4l4pvC
XH8YAG8m5Q/el3YoaM0LU7amhwLnoL9H39ohoLLtTZ04PVw5uXP6z8//cvUt
V55wfHrw5VOiXN9ph5wHSbO+JXSw5bXH9+F0B4j7q0q4/qCFT9S3DJu5O2D4
ZyFbRSwNPFXnabey6QCqW7vBQnRUEPyHT73VoQM8y2XvSXygBKxU4DOBSwfo
6DWVvomlhGeHImervDrgRYFkvd4WBQxWy9ltRHYAU6u9osTAWRgn0qL3r+oA
dNjQMpxABgmtOrXjdR2Ab+r3i0CNDDRv619lb+6AUOG5kh9nyGCiw8S1v7sD
6hLPfi4JI4VJO9tBorEOYCNzv14VSgKzzx94p693gNM77FblIyLIcw8gW/nV
AfF9ugbF1kRgxhJcLLPXAeZ/ElMFBYhg4V7Ey9l/HbCc7Kr+tfMMfOZM4uWk
6oTS3Mjq93OE8D247H29RCd84HDKDbhCAHvyry8N+3TCxTTqw1vG+HD36czH
V/7/9TWbbKbFYviwhi2FTwV3wpp8BLciCT58Vv795uvDTjBSKq5IfYwH41os
bgTZnWC8ED9kzIMHJTYOFVe7OqHkZlJ4Otk/HNuKh4ZqbyfEx8XYvhr6i8t2
9NvV7uuEJukt24qwv7gE1wRFy5FOqCAdoBY6Psb5+rQuBM10Akfk8s7tvSOc
RtwJQ+9+J8QaVDGonjnEjZwlefr8uBN+Kqi09o0e4BSTaezG8Lpg+msDQ3/S
AU42g7d1lrgLUtX9lY1YDnBchepaB0xdYJrZ4Nwpu4/bb8l6KC3XBT01pEJX
4/ZwZbOi+00PuuCxhf3o+4c7uDvW7rliQV0Q1NIfTm64gxNbbbjSFNYFherT
9c94dnC9BxdDG+O6QN7HR7bq+TbuHZMwaUN+F8RHH7FeItrGERjxs9b2d8GG
vr6MStkWbnTB4angUBckddrfWn6whUu2r7SsGe2CJ9JMm6taWzjW+3zl1ZNd
kKgrxnL/cBMnlcEjUvW1C6Jq1bvDujdwtpMcWDlJN/Bl0Sfim6/hBG9ZLvFQ
dEN44YHPON0abmupMKKMphsY3Xy2tF7+xAVss78oZemGB68qBR9gP3Hp1Gy6
JRe7QdfD/xyX6CpuQIvZtlCnGzw4L5TcEP6Oi502PnPesBvuDlp7D298w2nf
zq4qMO0GC7tGsy/N33Af3RjX8226gWK85fym3DfcbgL9/Ufe3UC9Nm/FprOC
66E3YGL164Z0E55SU6YVXEh+ek9eUDcEKfNP8C9+xZHX057kPuyGM0LVXPfu
fsW9ldIrPhffDcXrDC6rl7/isntTr+Umd8Pufaof6wRfcRZKb78yZ3RDk3ur
lP/rL7j//38JV/61rSfnfsH9H+DqvLk=
               "]]}, "Meixner with drift change"]}}, {
          AspectRatio -> GoldenRatio^(-1), Axes -> True, AxesOrigin -> {0, 0},
            PlotRange -> {{-0.1, 0.1}, {0, 120}}, PlotRangeClipping -> True, 
           PlotRangePadding -> {
             Scaled[0.02], Automatic}}]}; Typeset`initDone$$ = True); 
     ReleaseHold[{{
         HoldComplete[$CellContext`meixner = 
           Function[{$CellContext`x, $CellContext`a, $CellContext`b, \
$CellContext`m, $CellContext`d}, (2 Cos[$CellContext`b/2])^(2 $CellContext`d) 
             E^($CellContext`b ($CellContext`x - \
$CellContext`m)/$CellContext`a) Abs[
                
                Gamma[$CellContext`d + 
                 I ($CellContext`x - $CellContext`m)/$CellContext`a]]^2/(2 
             Pi $CellContext`a Gamma[2 $CellContext`d])]; Null], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`\[Theta] = 
           Function[{$CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r}, ((-1)/$CellContext`a) ($CellContext`b + 
              2 ArcTan[(-Cos[$CellContext`a/2] + 
                  Exp[($CellContext`m - $CellContext`r)/(2 $CellContext`d)])/
                 Sin[$CellContext`a/2]])]; Null], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`MeixnerEsscher["call", 
            Pattern[$CellContext`a, 
             Blank[]], 
            Pattern[$CellContext`b, 
             Blank[]], 
            Pattern[$CellContext`m, 
             Blank[]], 
            Pattern[$CellContext`d, 
             Blank[]], 
            Pattern[$CellContext`r, 
             Blank[]], 
            Pattern[$CellContext`s, 
             Blank[]], 
            Pattern[$CellContext`k, 
             Blank[]], 
            Pattern[$CellContext`T, 
             Blank[]]] := 
          Module[{$CellContext`c = 
             Log[$CellContext`k/$CellContext`s], $CellContext`th = \
$CellContext`\[Theta][$CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r]}, $CellContext`s NIntegrate[
               $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`a ($CellContext`th + 
                  1) + $CellContext`b, $CellContext`m $CellContext`T, \
$CellContext`d $CellContext`T], {$CellContext`x, $CellContext`c, Infinity}, 
               AccuracyGoal -> 8, MaxRecursion -> 12] - 
            Exp[(-$CellContext`r) $CellContext`T] $CellContext`k NIntegrate[
              $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`a $CellContext`th + $CellContext`b, $CellContext`m \
$CellContext`T, $CellContext`d $CellContext`T], {$CellContext`x, \
$CellContext`c, Infinity}, AccuracyGoal -> 8, MaxRecursion -> 12]]], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`MeixnerEsscher["put", 
            Pattern[$CellContext`a, 
             Blank[]], 
            Pattern[$CellContext`b, 
             Blank[]], 
            Pattern[$CellContext`m, 
             Blank[]], 
            Pattern[$CellContext`d, 
             Blank[]], 
            Pattern[$CellContext`r, 
             Blank[]], 
            Pattern[$CellContext`s, 
             Blank[]], 
            Pattern[$CellContext`k, 
             Blank[]], 
            Pattern[$CellContext`T, 
             Blank[]]] := $CellContext`MeixnerEsscher[
            "call", $CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r, $CellContext`s, $CellContext`k, \
$CellContext`T] + $CellContext`k 
            Exp[(-$CellContext`r) $CellContext`T] - $CellContext`s], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`MeixnerDriftCorrected["call", 
            Pattern[$CellContext`a, 
             Blank[]], 
            Pattern[$CellContext`b, 
             Blank[]], 
            Pattern[$CellContext`m, 
             Blank[]], 
            Pattern[$CellContext`d, 
             Blank[]], 
            Pattern[$CellContext`r, 
             Blank[]], 
            Pattern[$CellContext`s, 
             Blank[]], 
            Pattern[$CellContext`k, 
             Blank[]], 
            Pattern[$CellContext`T, 
             Blank[]]] := 
          Exp[(-$CellContext`r) $CellContext`T] 
           NIntegrate[
            Max[$CellContext`s Exp[$CellContext`x] - $CellContext`k, 
               0] $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`b, $CellContext`T ($CellContext`m + $CellContext`r - 
                2 $CellContext`d (Log[
                   Cos[$CellContext`b/2]] - Log[
                  
                  Cos[($CellContext`a + $CellContext`b)/
                   2]])), $CellContext`T $CellContext`d], {$CellContext`x, -
              Infinity, Infinity}, AccuracyGoal -> 8, MaxRecursion -> 12]], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`MeixnerDriftCorrected["put", 
            Pattern[$CellContext`a, 
             Blank[]], 
            Pattern[$CellContext`b, 
             Blank[]], 
            Pattern[$CellContext`m, 
             Blank[]], 
            Pattern[$CellContext`d, 
             Blank[]], 
            Pattern[$CellContext`r, 
             Blank[]], 
            Pattern[$CellContext`s, 
             Blank[]], 
            Pattern[$CellContext`k, 
             Blank[]], 
            Pattern[$CellContext`T, 
             Blank[]]] := $CellContext`MeixnerDriftCorrected[
            "call", $CellContext`a, $CellContext`b, $CellContext`m, \
$CellContext`d, $CellContext`r, $CellContext`s, $CellContext`k, \
$CellContext`T] + $CellContext`k 
            Exp[(-$CellContext`r) $CellContext`T] - $CellContext`s], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`mx[
            PatternTest[
             Pattern[$CellContext`a, 
              Blank[]], NumericQ], 
            PatternTest[
             Pattern[$CellContext`b, 
              Blank[]], NumericQ], 
            PatternTest[
             Pattern[$CellContext`m, 
              Blank[]], NumericQ], 
            PatternTest[
             Pattern[$CellContext`d, 
              Blank[]], NumericQ], 
            PatternTest[
             Pattern[$CellContext`t, 
              Blank[]], NumericQ]] := ProbabilityDistribution[
            $CellContext`meixner[$CellContext`x, $CellContext`a, \
$CellContext`b, $CellContext`m $CellContext`t, $CellContext`d \
$CellContext`t], {$CellContext`x, -Infinity, Infinity}]], 
         HoldComplete[Null], 
         HoldComplete[$CellContext`meixnerMean[
            Pattern[$CellContext`a, 
             Blank[]], 
            Pattern[$CellContext`b, 
             Blank[]], 
            Pattern[$CellContext`d, 
             Blank[]], 
            Pattern[$CellContext`m, 
             Blank[]]] := $CellContext`m + $CellContext`a $CellContext`d 
            Tan[$CellContext`b/2]]}}]; Typeset`initDone$$ = True),
    SynchronousInitialization->True,
    UnsavedVariables:>{Typeset`initDone$$},
    UntrackedVariables:>{Typeset`size$$}], "Manipulate",
   Deployed->True,
   StripOnInput->False],
  Manipulate`InterpretManipulate[1]]], "Output",
 CellID->8793728],

Cell["\<\
In the classical Black\[Dash]Scholes model of asset prices, every option has \
a unique \"fair\" price; that is, for every price of the underlying asset, \
there is a unique option price that does not allow arbitrage opportunities. \
This is no longer true when the Black\[Dash]Scholes model is replaced by a \
more realistic model, for example, one in which discontinuous jumps in asset \
price can occur. This Demonstration shows this for the case where the asset \
price is modeled by a Meixner process. \
\>", "ManipulateCaption",
 CellID->3037421],

Cell["\<\
There are two plots. In the upper one, the red and pink colored curves show \
two different models of arbitrage-free option prices based on the same \
Meixner process describing the underlying asset price. The values shown in \
red are obtained by means of the Esscher transform applied to the underlying \
asset process. The pink line shows prices obtained by a change of drift of \
the underlying process (this is the same method as is used to obtain option \
prices in the Black\[Dash]Scholes model). The green line shows the Black\
\[Dash]Scholes price for the same variance (volatility). In the lower plot, \
the user can choose to view the density of the Meixner process model of the \
(logarithm of) the underlying asset price versus the Black\[Dash]Scholes \
(normal) density with the same mean and variance or the \"risk-neutral\" \
densities of the two Meixner process models used versus the risk-neutral \
normal density. \
\>", "ManipulateCaption",
 CellID->1363251758],

Cell["", "ManipulateCaption",
 CellID->442121567],

Cell["THINGS TO TRY", "ManipulateCaption",
 CellFrame->{{0, 0}, {1, 0}},
 CellFrameColor->RGBColor[0.87, 0.87, 0.87],
 FontFamily->"Helvetica",
 FontSize->12,
 FontWeight->"Bold",
 FontColor->RGBColor[0.597406, 0, 0.0527047],
 CellTags->"ControlSuggestions"],

Cell[TextData[{
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Resize Images",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox["Resize Images",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   "\"Click inside an image to reveal its orange resize frame.\\nDrag any of \
the orange resize handles to resize the image.\"",
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]],
 StyleBox["\[NonBreakingSpace]\[FilledVerySmallSquare]\[NonBreakingSpace]",
  FontColor->RGBColor[0.928786, 0.43122, 0.104662]],
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Slider Zoom",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox["Slider Zoom",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   RowBox[{"\"Hold down the \"", 
     FrameBox[
     "Alt", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], 
     "\" key while moving a slider to make fine adjustments in the slider \
value.\\nHold \"", 
     FrameBox[
     "Ctrl", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" and/or \"", 
     FrameBox[
     "Shift", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" at the same time as \"", 
     FrameBox[
     "Alt", Background -> GrayLevel[0.9], FrameMargins -> 2, FrameStyle -> 
      GrayLevel[0.9]], "\" to make ever finer adjustments.\""}],
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]],
 StyleBox["\[NonBreakingSpace]\[FilledVerySmallSquare]\[NonBreakingSpace]",
  FontColor->RGBColor[0.928786, 0.43122, 0.104662]],
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Gamepad Controls",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox["Gamepad Controls",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   "\"Control this Demonstration with a gamepad or other\\nhuman interface \
device connected to your computer.\"",
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]],
 StyleBox["\[NonBreakingSpace]\[FilledVerySmallSquare]\[NonBreakingSpace]",
  FontColor->RGBColor[0.928786, 0.43122, 0.104662]],
 Cell[BoxData[
  TooltipBox[
   PaneSelectorBox[{False->Cell[TextData[StyleBox["Automatic Animation",
     FontFamily->"Verdana"]]], True->Cell[TextData[StyleBox[
    "Automatic Animation",
     FontFamily->"Verdana",
     FontColor->GrayLevel[0.5]]]]}, Dynamic[
     CurrentValue["MouseOver"]]],
   RowBox[{"\"Animate a slider in this Demonstration by clicking the\"", 
     AdjustmentBox[
      Cell[
       GraphicsData[
       "CompressedBitmap", 
        "eJzzTSzJSM1NLMlMTlRwL0osyMhMLlZwyy8CCjEzMjAwcIKwAgOI/R/IhBKc\n\
/4EAyGAG0f+nTZsGwgysIJIRKsWKLAXGIHFmEpUgLADxWUAkI24jZs+eTaEt\n\
IG+wQKRmzJgBlYf5lhEA30OqWA=="], "Graphics", ImageSize -> {9, 9}, ImageMargins -> 
       0, CellBaseline -> Baseline], BoxBaselineShift -> 0.1839080459770115, 
      BoxMargins -> {{0., 0.}, {-0.1839080459770115, 0.1839080459770115}}], 
     "\"button\\nnext to the slider, and then clicking the play button that \
appears.\\nAnimate all controls by selecting \"", 
     StyleBox["Autorun", FontWeight -> "Bold"], "\" from the\"", 
     AdjustmentBox[
      Cell[
       GraphicsData[
       "CompressedBitmap", 
        "eJyNULENwyAQfEySIlMwTVJlCGRFsosokeNtqBmDBagoaZjAI1C8/8GUUUC6\n\
57h7cQ8PvU7Pl17nUav7oj/TPH7V7b2QJAUAXBkKmCPRowxICy64bRvGGNF7\n\
X8CctGoDSN4xhIDGGDhzFXwUh3/ClBKrDQPmnGXtI6u0OOd+tZBVUqy1xSaH\n\
UqiK6pPe4XdEdAz6563tx/gejuORGMxJaz8mdpJn7hc="], "Graphics", 
       ImageSize -> {10, 10}, ImageMargins -> 0, CellBaseline -> Baseline], 
      BoxBaselineShift -> 0.1839080459770115, 
      BoxMargins -> {{0., 0.}, {-0.1839080459770115, 0.1839080459770115}}], 
     "\"menu.\""}],
   TooltipStyle->{
    FontFamily -> "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.35], 
     Background -> GrayLevel[0.98]}]]]
}], "ManipulateCaption",
 CellMargins->{{Inherited, Inherited}, {0, 0}},
 Deployed->True,
 FontFamily->"Verdana",
 CellTags->"ControlSuggestions"],

Cell["DETAILS", "DetailsSection"],

Cell["\<\
The Black\[Dash]Scholes model and other one-dimensional diffusion models are \
examples of complete markets: any option can be perfectly replicated by a \
self-financing strategy involving the underlying asset and cash. This means \
that in such models, the price of the underlying parameters and knowledge of \
the relevant parameters (interest rate and volatility) uniquely determines \
the \"fair\" (i.e., arbitrage-free) price of every option. In probabilistic \
terms, the problem of option pricing reduces to the problem of finding a new \
probability measure on the space of all possible events, which is equivalent \
to the real-world measure (in the sense that the sets of impossible events \
under both measures are the same) but under which the price process is a \
martingale. In diffusion-based models, there is only one such measure, known \
as the \"equivalent martingale measure\". \
\>", "DetailNotes",
 CellID->383586068],

Cell["\<\
However, models that allow jumps (e.g., models obtained by replacing the \
Wiener process by another L\[EAcute]vy process) are incomplete: there are \
infinitely many martingale measures equivalent to the historical (real-world) \
measure. A choice of any of these measures will give a consistent \
(arbitrage-free) system of prices for all options sold in the market. Such a \
measure can be given by specifying the corresponding probability density \
function, which can then be used to compute prices of options (as \
expectations with respect to the new measure). Two of the most popular are \
obtained by means of the so-called Esscher transform (well-known in actuarial \
mathematics) and by \"mean correction\", a method analogous to the one used \
in Black\[Dash]Scholes pricing. In this Demonstration, we compare the prices \
obtained by applying both of these methods to models based on the Meixner \
process (an infinite-activity L\[EAcute]vy process) and display both the \
historical and equivalent risk-neutral densities. We also compare the prices \
and the densities with the corresponding Black\[Dash]Scholes price and \
density. For certain values of the parameters, it may be difficult to \
distinguish the graphs of prices or densities of different models. In such \
cases, you can obtain a clearer view by adjusting either the option price \
range slider or the range of the graph of densities. This is particularly \
useful when we want to compare the tails of the distributions (the Meixner \
densities are both more peaked and have thicker tails than the normal \
density). \
\>", "DetailNotes",
 CellID->1796446233],

Cell["\<\
The starting parameters of the Meixner process are obtained by fitting the \
Meixner distribution to the returns of the S&P 500 index. 
One of the bookmarks contains parameters obtained by fitting the Meixner \
distribution to the returns of the Nikkei index. \
\>", "DetailNotes",
 CellID->1167846943],

Cell["Reference", "DetailNotes",
 CellID->905775284],

Cell[TextData[{
 "[1] W. Schoutens, ",
 StyleBox["L\[EAcute]vy Processes in Finance: Pricing Financial Derivatives",
  FontSlant->"Italic"],
 ", New York:",
 StyleBox[" ",
  FontSlant->"Italic"],
 "John Wiley & Sons, 2003",
 StyleBox[". ",
  FontSlant->"Italic"]
}], "DetailNotes",
 CellID->15943128],

Cell["RELATED LINKS", "RelatedLinksSection"],

Cell[TextData[{
 ButtonBox["The Meixner Process",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/TheMeixnerProcess/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/TheMeixnerProcess/"],
 " (",
 ButtonBox["Wolfram Demonstrations Project",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
 ")"
}], "RelatedLinks",
 CellID->1703391291],

Cell[TextData[{
 ButtonBox["Fitting the Meixner Distribution to S&P 500 Returns",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/\
FittingTheMeixnerDistributionToSP500Returns/"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/\
FittingTheMeixnerDistributionToSP500Returns/"],
 " (",
 ButtonBox["Wolfram Demonstrations Project",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
 ")"
}], "RelatedLinks",
 CellID->792929680],

Cell[BoxData[
 ButtonBox[
  PaneSelectorBox[{False->Cell[BoxData[
    GraphicsBox[RasterBox[CompressedData["
1:eJztmjlPZFcQhZH8H5z7LzmYFGkSyAwZkEEGZEDEkrBEbAEgAjCLxS6xCbEP
Bnu8SAYaRoIEhPDnPqJcvm/p17THyJp3pGnVPbdu1bl1T7dGo/nm/Xffvv+q
qqrqa/78wJ+/4ufn56enp4eHh7u7u9vb25ubm0KhcFNEoQiCT0Wwa4wA88kh
WCYhKS39eKAtCUFCSUmW4AN/96T6sY30qa1gUCk6NdiUK8Q+ij9riFZOR5YZ
xu5yFsNgG8zzXMTV1dX5+fmHHDnKBLbBPHLR2dnZW8vJ8X8F5pGLbJkjRxbI
LfZpv0U5crwauYuEpaWlmZkZPt9ayN/Y39+fKeKthZSGXPRj+WhoaHjnwHJi
YsJ2mUBra2t1dTVbzc3NvI5tQZKsWLu+Znd3t+LZ2Vl2fZBSFlIyCIaHhwnI
hEdSTU0Ny46ODl/cgyLKEYitbFI7JOkIu6ps12HLKtNOaXV1dTYcApaQlOWs
dEbBlkkik0t5wYgRjwCrAK9H4dOrKtmRg/39/cr0j5gdctG5A+R5BiCyra3t
+xcQo5PAdhkgd5+cnCRG/8HBATzL6iKISdYDaUunenp6FMe6yMpyWZVlJkxA
cyZTw9cAdZCnJNDYoy7iOGfZ3dzcZMkn70KLlHbwkLwL+lGrL4U0+wloi7Mw
UrW1tUUsQxKwRQJzi87WzhIzHJacYnRaqiNLElCi7uJVWfniM3bkOpxCIQl2
hRQEJom6KCP8iwvIQwwBYvw8dUHNpK0IlsvLywMDA3omzSeoqev7IKksdShi
VqS+BmiBQHIgGHBWlvZQl5RbeN538TySKO6Ho++al8QQ7O4GGvk6wWzlBLus
hoPUgMc2sUOI7Wh12GVEfpgZIRddFMHyIjMaGxvp6JmVlRWUbG9vS1JsMgqn
pqZYjoyMcFNI+Spa04pEg6Ds4eGhfrEp3viCqMKoYIBaZHtGXSBTbqFXFgmj
dgHvY19BRTyCHOaDH6I64YN2vlHA2zJLR4HnYIwEdO/s7IzNSYJ3UVmIfRTd
SPPncY3XD6ZsBi/z6MfTDy2Li6JlFVOcUvoq2QD9NHxyFBznp4MjtJCrU9pl
dJHePRiat7rMH+REfRLs6q0F5JmLPM/FbQglO14UXcor8NXWcwTfrJKQi34q
H0jq7e0NSBTOzc0RyM8iEQa/uroK09LSAkOO/tqpBJLJUU34o6Mj4sHBQSWQ
7DOjZXd2duDVF2iAqmDVVCQqGFDBfsrwj9VJauevCaipduItn5saTzKl0Ikk
ekkSoJ0G4uELxqqVP+2yVDZe8qgPaUMo2VFqAWkMgSNJ3ZMgF/1cPuQizzAl
LsIn8ejoKHFtba0eqL29HZIlvJIhqaC4vQjVJJ80/SaInJ+fJ1ZmbFlVUEHx
6nJ8fMxS8+STU4FguwhYW1uLbiW1I0aVYj268WRaQTX1d1E7SWKLINqXpvAp
k9dlNSi7rB8CxyUjY0cYLMS4KIUtU1onQS76WD5Q1dfX55muri502nJ3d3do
aIgcRIpZWFg4OTlRDEmCZSpHJGmcGhsbs1MMJ6WsMD093VcE+UbSjjqQnIoK
FijujxCTmd7OX8TEG28aiHUWbVGpbFkRD8hA0sfItOmoCjZDX1kD9LdI71g5
KnER5l94gb4Iwbj+FQQuejWSXATPN1HPwWd9fT3LyttVAr6P/GjoeyRbRn2V
jsBFnxty0S/lo6mp6Z0Dw8dCr6hTEnJR5XUQzGyj/Pr6OuLtIqSdnp5W3q5C
IFX/mKZ/LRwfHy/3OBf5TNqikIt+/eKxsbGxuLi4t7f31kL+gcUiMib/Z54B
QevcRTkqh1z0W44cFcBc9HuOHK+Cuejq6kqmSsnMnZYjgFxh/2P28fHx/v6+
UChcXl7+EQf46+vrpN0cXyAwA4bBNpgHC/0JwypFcA==
      "], {{0, 0}, {194, 22}}, {0, 255},
      ColorFunction->RGBColor],
     ImageSize->{194, 22},
     PlotRange->{{0, 194}, {0, 22}}]]], True->Cell[BoxData[
    GraphicsBox[RasterBox[CompressedData["
1:eJztmjtPLEcQhZH8H5z7LzlwinQjiCwIIYQQyICMRwRkPCIQCRgIeCa8At6S
vetrW2aXlTYAhD/PEeW63TOzu4wxsj1HYlVdXV11qvrMLEJ88+n7bz991dXV
9TU/m/z8ab+8vDw/Pz8+PjabzUaj8fDwUK/XHxLUE2A0XmEeofHPwnPLQhBQ
pFBqLT+crELaCgaVw9OOZGVOvRR/1hBnbtlpyxmm7nIWwSAbxPOSoFarVSqV
H0uU6BDIBvFIRR/NpcS/G6WKShRHqaISxVGqSNjd3d3Y2ODzo4n8hYuLi40E
H02kNaSinzrHwMDAdw4sV1dXbffy8nJkZKS7u5utoaGhvb0928JJsGzt+pxT
U1OyNzc32fVGTlqcooGxuLiIQSR+KPX09LAcHx/3yT1IohgB29JmlYOSjrCr
zNYOW5aZcgrr6+uz4WCwxElazopnDLaMEpE05QlDRn4IWAb8uhQ+PauWFTk4
NzenSH+J7UMqqjjgrLQBSI6Ojv7wCmx4YtguA6T3tbU1bPhfXV3hZ9mdAJtg
XZC2dGp6elp2qoosLc0qLTNhApozkRq+BqiDXCWGxh6riOOcZff4+Jgln9wL
JXLK4cfJvcAftnooxNlPQFucxTMxMcHWyckJtgSJwRYBzC2erZ3FZjgsOcXo
tFRFlgTARNXlV2bFy99mRdrhFAwJsBZyEIgkVlGb8DcuQA8yGJDx81SDmslo
Apb7+/vcvq5J8wlyqn1vZKUlD0lMiuTXAM0QCA4IAykwcKpKThfe76t4P5RI
7oejZ81TYgjWu4FCPk8wWynBmtVwoBr4kU3qEFIrWh52GZEfZpuQiqoJWFbb
xuDgIBW95+DgACanp6eilBoszbBcWloaHh7GKV3FOS1JbARpr6+v9cYm+eAr
YoYxYQBbaHuPquDM6UK3LCcelQv83vYZlMQjiNHrOuaJPyjnCwV+W7ZTUeA6
GCMG1Xl5psZkwauoI6ReijrS/Llc8+uFKZnhl3j08vRDa0dFcVrZJCeVHiUb
oJ+GD47B8fn5eY5QQqrOKdeminTvwdC81CX+ICbWSbCruxagZyryfhq3IbSs
WE1Uyi3waOs6gierJd5DRdUv9QwxPd14EHw1uSD92qkAgjVwtayL407jV1Bq
Wk3Ars8GSAbLpiSpKiKDvcr0vWNbqeWquSqyeDo1v34DhCeUqGXKpJwG4pGv
Ij2Jpk/K6RmUX/TIj9OG0LKi2ALCGAJHsqpnQSr6uXNAcmZmxnvOzs5ohE/s
5eVl3Ut/f7+ebpws8SsYJxlk60tNOYnXs2Ontra2sBWZmlYZlFB+Vbm5uWGp
efLJqYCwNQKYf7yVVQ4bVrLJaY3gJ9ISqqjvReVEiS099XFR/DmTV7MalDXr
h8Bx0WizIh4kxLhINTk5mVM6C1LR584hFXkPBHp7e22JnBYWFog5PDyUZ3t7
+/b2VjZOAixSMXISxik6slMMJyetsL6+PpOAeHNSjjw4ORUTFkjuj2ATmV/O
N2LkzW8csHUWbjFVtiyJB86A0udo2lRUBpuhz6wB+i7yKxZHERWNjY1tvwKb
3oNx/S0IVPRmZKkIP0+iroNPnmKWxcsVAc8jLw09R5JlrKt8BCp6b0hFv3QO
vagNDB8JvSFPS+zs7JC/eB4Iz87Oxv6joyN9YQmE3d3dFS9XEFDVH9P018KV
lZVOj9PIO3GL8WYV/ceAlpDr+fn5RxP5AjsJPppFa5QqKlEcUtGvJUoUgKno
txIl3gRTUa1Wk6hyIkullQggVdh/zD49PTWbzXq9fn9//3sa8BOctVvifwjE
gGCQDeJBQn8AEYN5ZQ==
      "], {{0, 0}, {194, 22}}, {0, 255},
      ColorFunction->RGBColor],
     ImageSize->{194, 22},
     PlotRange->{{0, 194}, {0, 22}}]]]}, Dynamic[
    CurrentValue["MouseOver"]]],
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/versions/source.jsp?id=\
NonuniquenessOfOptionPricingUnderTheMeixnerModel&version=0011"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel-source.nb"]], \
"DemoSourceNotebookSection",
 CellFrame->{{0, 0}, {1, 1}},
 ShowCellBracket->False,
 CellMargins->{{48, 48}, {28, 28}},
 CellGroupingRules->{"SectionGrouping", 25},
 CellFrameMargins->{{48, 48}, {6, 8}},
 CellFrameColor->RGBColor[0.87, 0.87, 0.87]],

Cell["PERMANENT CITATION", "CitationSection"],

Cell[TextData[{
 "\[NonBreakingSpace]",
 ButtonBox["Andrzej Kozlowski",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/author.html?author=Andrzej+\
Kozlowski"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/author.html?author=Andrzej+Kozlowski"]
}], "Author",
 FontColor->GrayLevel[0.6]],

Cell[TextData[{
 "\"",
 ButtonBox["Nonuniqueness of Option Pricing Under the Meixner Model",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/"],
 "\"",
 "\[ParagraphSeparator]\[NonBreakingSpace]",
 ButtonBox["http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/"], None},
  ButtonNote->
   "http://demonstrations.wolfram.com/\
NonuniquenessOfOptionPricingUnderTheMeixnerModel/"],
 "\[ParagraphSeparator]\[NonBreakingSpace]",
 ButtonBox["Wolfram Demonstrations Project",
  BaseStyle->"SiteLink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
 "\[ParagraphSeparator]\[NonBreakingSpace]",
 "Published: ",
 "August 16, 2012"
}], "Citations"],

Cell[TextData[{
 "\[Copyright] ",
 StyleBox[ButtonBox["Wolfram Demonstrations Project & Contributors",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/"], None},
  ButtonNote->"http://demonstrations.wolfram.com/"],
  FontColor->GrayLevel[0.6]],
 "\[ThickSpace]\[ThickSpace]\[ThickSpace]|\[ThickSpace]\[ThickSpace]\
\[ThickSpace]",
 StyleBox[ButtonBox["Terms of Use",
  BaseStyle->"Hyperlink",
  ButtonData->{
    URL["http://demonstrations.wolfram.com/termsofuse.html"], None},
  ButtonNote->"http://demonstrations.wolfram.com/termsofuse.html"],
  FontColor->GrayLevel[0.6]]
}], "Text",
 CellFrame->{{0, 0}, {0, 0.5}},
 CellMargins->{{48, 48}, {20, 50}},
 CellFrameColor->GrayLevel[0.45098],
 FontFamily->"Verdana",
 FontSize->9,
 FontColor->GrayLevel[0.6],
 CellTags->"Copyright"]
},
Editable->False,
Saveable->False,
ScreenStyleEnvironment->"Working",
CellInsertionPointCell->None,
CellGrouping->Manual,
WindowSize->{632, 453},
WindowMargins->{{0, Automatic}, {Automatic, 0}},
WindowElements->{
 "StatusArea", "MemoryMonitor", "MagnificationPopUp", "VerticalScrollBar", 
  "MenuBar"},
WindowTitle->"Nonuniqueness of Option Pricing Under the Meixner Model",
DockedCells->{},
CellContext->Notebook,
FrontEndVersion->"8.0 for Microsoft Windows (32-bit) (February 23, 2011)",
StyleDefinitions->Notebook[{
   Cell[
    CellGroupData[{
      Cell[
      "Demonstration Styles", "Title", 
       CellChangeTimes -> {
        3.3509184553711*^9, {3.36928902713192*^9, 3.36928902738193*^9}, {
         3.3754479092466917`*^9, 3.3754479095123196`*^9}, {
         3.375558447161495*^9, 3.375558447395873*^9}, {3.37572892702972*^9, 
         3.375728927639103*^9}}], 
      Cell[
       StyleData[StyleDefinitions -> "Default.nb"]], 
      Cell[
       CellGroupData[{
         Cell[
         "Style Environment Names", "Section", 
          CellChangeTimes -> {{3.369277974278112*^9, 3.369277974396138*^9}}], 
         Cell[
          StyleData[All, "Working"], ShowCellBracket -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Notebook Options", "Section", 
          CellChangeTimes -> {{3.374865264950812*^9, 3.374865265419568*^9}}], 
         Cell[
         "  The options defined for the style below will be used at the \
Notebook level.  ", "Text"], 
         Cell[
          StyleData["Notebook"], Editable -> True, 
          PageHeaders -> {{None, None, None}, {None, None, None}}, 
          PageFooters -> {{None, None, None}, {None, None, None}}, 
          PageHeaderLines -> {False, False}, 
          PageFooterLines -> {False, False}, 
          PrintingOptions -> {
           "FacingPages" -> False, "FirstPageFooter" -> False, 
            "RestPagesFooter" -> False}, CellFrameLabelMargins -> 6, 
          DefaultNewInlineCellStyle -> "InlineMath", DefaultInlineFormatType -> 
          "DefaultTextInlineFormatType", ShowStringCharacters -> True, 
          CacheGraphics -> False, StyleMenuListing -> None, 
          DemonstrationSite`Private`CreateCellID -> True, 
          DemonstrationSite`Private`TrackCellChangeTimes -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Input/Output", "Section", 
          CellChangeTimes -> {{3.3756313297791014`*^9, 
           3.3756313299509783`*^9}}], 
         Cell[
         "The cells in this section define styles used for input and output \
to the kernel.  Be careful when modifying, renaming, or removing these \
styles, because the front end associates special meanings with these style \
names.    ", "Text"], 
         Cell[
          StyleData["Input"], CellMargins -> {{48, 4}, {6, 4}}], 
         Cell[
          StyleData["Output"], CellMargins -> {{48, 4}, {6, 4}}], 
         Cell[
          StyleData["DemonstrationHeader"], Deletable -> False, 
          CellFrame -> {{0, 0}, {0, 0}}, ShowCellBracket -> False, 
          CellMargins -> {{0, 0}, {30, 0}}, 
          CellGroupingRules -> {"SectionGrouping", 20}, 
          CellHorizontalScrolling -> True, 
          CellFrameMargins -> {{0, 0}, {0, 0}}, CellFrameColor -> 
          RGBColor[0, 0, 0], StyleMenuListing -> None, Background -> 
          RGBColor[0, 0, 0]], 
         Cell[
          StyleData["ShowSource"], CellFrame -> {{0, 0}, {0, 1}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
          CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
          RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
          "Helvetica", FontSize -> 10, FontWeight -> "Bold", FontSlant -> 
          "Plain", FontColor -> RGBColor[1, 0.42, 0]]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Basic Styles", "Section", 
          CellChangeTimes -> {{3.34971724802035*^9, 3.34971724966638*^9}, {
           3.35091840608065*^9, 3.35091840781999*^9}, {3.35091845122987*^9, 
           3.35091845356607*^9}, {3.35686681885432*^9, 3.35686681945788*^9}, {
           3.375657418186455*^9, 3.375657418452083*^9}}], 
         Cell[
          StyleData["Hyperlink"], StyleMenuListing -> None, FontColor -> 
          GrayLevel[0]], 
         Cell[
          StyleData["SiteLink"], StyleMenuListing -> None, 
          ButtonStyleMenuListing -> Automatic, FontColor -> 
          GrayLevel[0.45098], 
          ButtonBoxOptions -> {
           Active -> True, Appearance -> {Automatic, None}, 
            ButtonFunction :> (FrontEndExecute[{
               NotebookLocate[#2]}]& ), ButtonNote -> ButtonData}], 
         Cell[
          StyleData["Link"], FontColor -> GrayLevel[0.45098]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoNotes"], CellFrame -> True, 
             CellMargins -> {{0, 0}, {0, 0}}, 
             CellFrameMargins -> {{48, 48}, {4, 4}}, CellFrameColor -> 
             GrayLevel[0.99], StyleMenuListing -> None, FontFamily -> 
             "Verdana", FontSize -> 10, FontColor -> GrayLevel[0.45098], 
             DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
            Cell[
             StyleData["DemoNotes", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, FontSize -> 9]}, Open]], 
         Cell[
          StyleData["SnapshotsSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, ShowGroupOpener -> True, 
          CellMargins -> {{48, 48}, {10, 30}}, 
          PrivateCellOptions -> {"DefaultCellGroupOpen" -> False}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], DefaultNewCellStyle -> 
          "SnapshotCaption", StyleMenuListing -> None, FontFamily -> 
          "Verdana", FontSize -> 12, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "SnapshotCaption", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["SnapshotOutput"], ShowCellBracket -> False, 
             CellMargins -> {{48, 10}, {5, 7}}, Evaluatable -> True, 
             CellGroupingRules -> "InputGrouping", PageBreakWithin -> False, 
             GroupPageBreakWithin -> False, DefaultFormatType -> 
             DefaultInputFormatType, ShowAutoStyles -> True, 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, 
             AutoItalicWords -> {}, LanguageCategory -> "Mathematica", 
             FormatType -> InputForm, NumberMarks -> True, 
             LinebreakAdjustments -> {0.85, 2, 10, 0, 1}, CounterIncrements -> 
             "Input", MenuSortingValue -> 1500, MenuCommandKey -> "9", 
             DemonstrationSite`Private`StripStyleOnPaste -> True], 
            Cell[
             StyleData["SnapshotOuput", "Printout"], 
             CellMargins -> {{39, 0}, {4, 6}}, 
             LinebreakAdjustments -> {0.85, 2, 10, 1, 1}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoTitle"], Deletable -> False, ShowCellBracket -> 
             False, CellMargins -> {{48, 48}, {22, 10}}, 
             CellGroupingRules -> {"SectionGrouping", 20}, StyleMenuListing -> 
             None, FontFamily -> "Verdana", FontSize -> 20, FontWeight -> 
             "Bold", FontColor -> RGBColor[0.597406, 0, 0.0527047], 
             Background -> GrayLevel[1]], 
            Cell[
             StyleData["DemoName", "Printout"], 
             CellMargins -> {{24, 8}, {8, 27}}, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, FontSize -> 
             16]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DetailsSection"], CellFrame -> {{0, 0}, {1, 0}}, 
             ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
             CellGroupingRules -> {"SectionGrouping", 25}, 
             CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
             RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
             "Helvetica", FontSize -> 12, FontWeight -> "Bold", FontColor -> 
             RGBColor[0.597406, 0, 0.0527047]], 
            Cell[
             StyleData["DetailsSection", "Printout"], 
             CellMargins -> {{12, 0}, {0, 16}}, PageBreakBelow -> False, 
             FontSize -> 12]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoSection"], CellFrame -> {{0, 0}, {1, 0}}, 
             ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 28}}, 
             CellGroupingRules -> {"SectionGrouping", 30}, 
             CellFrameMargins -> {{48, 48}, {6, 8}}, CellFrameColor -> 
             RGBColor[0.87, 0.87, 0.87], StyleMenuListing -> None, FontFamily -> 
             "Helvetica", FontSize -> 12, FontWeight -> "Bold", FontColor -> 
             RGBColor[0.597406, 0, 0.0527047]], 
            Cell[
             StyleData["DemoSection", "Printout"], 
             CellMargins -> {{12, 0}, {0, 16}}, PageBreakBelow -> False, 
             FontSize -> 12]}, Open]], 
         Cell[
          StyleData["ManipulateSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12], 
         Cell[
          StyleData["ManipulateCaptionSection"], 
          CellFrame -> {{0, 0}, {0, 2}}, ShowCellBracket -> False, 
          CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], DefaultNewCellStyle -> 
          "ManipulateCaption", StyleMenuListing -> None, FontFamily -> 
          "Verdana", FontSize -> 12, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData["ManipulateCaption"], ShowCellBracket -> False, 
          CellMargins -> {{48, 48}, {10, 16}}, StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12, FontColor -> GrayLevel[0], 
          DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
         Cell[
          StyleData[
          "SeeAlsoSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, DefaultNewCellStyle -> "SeeAlso"], 
         Cell[
          StyleData["SeeAlso", StyleDefinitions -> StyleData["DemoNotes"]], 
          CellDingbat -> 
          Cell["\[FilledSmallSquare]", FontColor -> 
            RGBColor[0.928786, 0.43122, 0.104662]], ShowCellBracket -> False, 
          FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "RelatedLinksSection", StyleDefinitions -> 
           StyleData["DemoSection"]], ShowCellBracket -> False, 
          DefaultNewCellStyle -> "RelatedLinks"], 
         Cell[
          StyleData[
          "RelatedLinks", StyleDefinitions -> StyleData["DemoNotes"], 
           FontColor -> RGBColor[0.928786, 0.43122, 0.104662]], 
          ShowCellBracket -> False, FontColor -> GrayLevel[0.45098]], 
         Cell[
          StyleData[
          "CategoriesSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, DefaultNewCellStyle -> "Categories"], 
         Cell[
          StyleData["Categories", StyleDefinitions -> StyleData["DemoNotes"]],
           ShowCellBracket -> False], 
         Cell[
          StyleData[
          "AuthorSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {4, 18}}, 
          CellElementSpacings -> {"CellMinHeight" -> 3}, 
          CellFrameMargins -> {{48, 48}, {6, 3}}, DefaultNewCellStyle -> 
          "Author", FontSize -> 1, FontColor -> GrayLevel[1]], 
         Cell[
          StyleData[
          "Author", StyleDefinitions -> StyleData["DemoNotes"], FontColor -> 
           GrayLevel[0.64]], ShowCellBracket -> False], 
         Cell[
          StyleData[
          "DetailNotes", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False, FontColor -> GrayLevel[0]], 
         Cell[
          StyleData[
          "CitationSection", StyleDefinitions -> StyleData["DemoSection"]], 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {8, 14}}, 
          DefaultNewCellStyle -> "Categories"], 
         Cell[
          StyleData["Citations", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False, ParagraphSpacing -> {0, 6}], 
         Cell[
          StyleData[
          "RevisionSection", StyleDefinitions -> StyleData["DemoSection"]], 
          DefaultNewCellStyle -> "RevisionNotes"], 
         Cell[
          StyleData[
          "RevisionNotes", StyleDefinitions -> StyleData["DemoNotes"]], 
          ShowCellBracket -> False]}, Closed]], 
      Cell[
       CellGroupData[{
         Cell[
         "Specific Styles", "Section", 
          CellChangeTimes -> {{3.34971724802035*^9, 3.34971724966638*^9}, {
           3.35091840608065*^9, 3.35091840781999*^9}, {3.35091845122987*^9, 
           3.35091845356607*^9}, {3.36230868322317*^9, 3.36230868335672*^9}, {
           3.36928857618576*^9, 3.36928857640452*^9}, {3.3737586217185173`*^9,
            3.373758622077897*^9}}], 
         Cell[
          StyleData["InitializationSection"], CellFrame -> {{0, 0}, {0, 2}}, 
          ShowCellBracket -> False, CellMargins -> {{48, 48}, {10, 30}}, 
          CellGroupingRules -> {"SectionGrouping", 30}, 
          CellFrameMargins -> {{8, 8}, {8, 2}}, CellFrameColor -> 
          RGBColor[0.870588, 0.521569, 0.121569], StyleMenuListing -> None, 
          FontFamily -> "Verdana", FontSize -> 12, FontColor -> 
          GrayLevel[0.45098]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["AnchorBar"], ShowCellBracket -> False, 
             CellMargins -> {{48, 44}, {3, 6}}, StyleMenuListing -> None, 
             FontFamily -> "Verdana", FontSize -> 9, FontColor -> 
             GrayLevel[0.5]], 
            Cell[
             StyleData["AnchorBar", "Presentation"], FontSize -> 18], 
            Cell[
             StyleData["AnchorBar", "SlideShow"], StyleMenuListing -> None], 
            Cell[
             StyleData["AnchorBar", "Printout"], FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["AnchorLink"], StyleMenuListing -> None, 
             ButtonStyleMenuListing -> Automatic, FontColor -> 
             RGBColor[0.5, 0.5, 0.5], 
             ButtonBoxOptions -> {
              Active -> True, ButtonFunction :> (FrontEndExecute[{
                  FrontEnd`NotebookLocate[#2]}]& ), ButtonNote -> 
               ButtonData}], 
            Cell[
             StyleData["AnchorLink", "Printout"], 
             FontVariations -> {"Underline" -> False}, FontColor -> 
             GrayLevel[0]]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["GamePadStatus"], ShowCellBracket -> False, 
             CellMargins -> {{48, 48}, {5, 5}}, StyleMenuListing -> None, 
             FontFamily -> "Verdana", FontSize -> 10], 
            Cell[
             StyleData["GamePadStatus", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["DemoInstruction"], CellMargins -> {{48, 48}, {5, 5}}, 
             CellFrameLabelMargins -> 2, MenuSortingValue -> 800, 
             MenuCommandKey -> "8", StyleMenuListing -> None, FontFamily -> 
             "Verdana", FontSize -> 11, Background -> RGBColor[1, 0.85, 0.5], 
             DemonstrationSite`Private`ReturnCreatesNewCell -> True], 
            Cell[
             StyleData["DemoInstruction", "Printout"], 
             CellMargins -> {{24, 0}, {0, 10}}, Hyphenation -> True, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, 
             LineSpacing -> {1., 2, 2.}, FontSize -> 9]}, Open]], 
         Cell[
          StyleData[
          "ImplementationSection", StyleDefinitions -> 
           StyleData["DemoSection"]], Deletable -> True, DefaultNewCellStyle -> 
          "ImplementationNotes"], 
         Cell[
          StyleData[
          "ImplementationNotes", StyleDefinitions -> StyleData["DemoNotes"]]], 
         Cell[
          StyleData[
          "StatusSection", StyleDefinitions -> StyleData["DemoSection"]], 
          DefaultNewCellStyle -> "StatusNotes"], 
         Cell[
          StyleData[
          "StatusNotes", StyleDefinitions -> StyleData["DemoNotes"]]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["SectionGloss"], StyleMenuListing -> None, FontSize -> 
             0.85 Inherited, FontWeight -> "Plain", FontColor -> 
             GrayLevel[0.6]], 
            Cell[
             StyleData["SectionGloss", "Printout"]]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineFormula"], 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, LanguageCategory -> 
             "Formula", AutoSpacing -> True, ScriptLevel -> 1, 
             AutoMultiplicationSymbol -> False, SingleLetterItalics -> False, 
             SpanMaxSize -> 1, StyleMenuListing -> None, FontFamily -> 
             "Courier", FontSize -> 1.05 Inherited, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             FractionBoxOptions -> {BaseStyle -> {SpanMaxSize -> Automatic}}, 
             GridBoxOptions -> {
              GridBoxItemSize -> {
                "Columns" -> {{Automatic}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{1.}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["InlineFormula", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineOutput"], CellHorizontalScrolling -> True, 
             "TwoByteSyntaxCharacterAutoReplacement" -> True, 
             HyphenationOptions -> {
              "HyphenationCharacter" -> "\[Continuation]"}, LanguageCategory -> 
             None, AutoMultiplicationSymbol -> False, StyleMenuListing -> 
             None, FontFamily -> "Courier", FontSize -> 1.05 Inherited], 
            Cell[
             StyleData["InlineOutput", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["InlineMath"], DefaultFormatType -> 
             "DefaultTextFormatType", DefaultInlineFormatType -> 
             "TraditionalForm", LanguageCategory -> "Formula", AutoSpacing -> 
             True, ScriptLevel -> 1, AutoMultiplicationSymbol -> False, 
             SingleLetterItalics -> True, SpanMaxSize -> DirectedInfinity[1], 
             StyleMenuListing -> None, FontFamily -> "Times", FontSize -> 
             1.05 Inherited, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             GridBoxOptions -> {
              GridBoxItemSize -> {
                "Columns" -> {{Automatic}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{1.}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["InlineMath", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["TableBase"], CellMargins -> {{48, 48}, {4, 4}}, 
             SpanMaxSize -> 1, StyleMenuListing -> None, FontFamily -> 
             "Courier", FontSize -> 11, 
             ButtonBoxOptions -> {Appearance -> {Automatic, None}}, 
             GridBoxOptions -> {
              GridBoxAlignment -> {
                "Columns" -> {{Left}}, "ColumnsIndexed" -> {}, 
                 "Rows" -> {{Baseline}}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData["TableBase", "Printout"], 
             CellMargins -> {{2, 0}, {0, 8}}, FontSize -> 9]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "1ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.04], {
                    Scaled[0.966]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.126], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "1ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.078], {
                    Scaled[0.922]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "2ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.05], 
                   Scaled[0.41], {
                    Scaled[0.565]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.14], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "2ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.079], 
                   Scaled[0.363], {
                    Scaled[0.558]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}},
                  "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData[
             "3ColumnTableMod", StyleDefinitions -> StyleData["TableBase"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.04], 
                   Scaled[0.266], 
                   Scaled[0.26], {
                    Scaled[0.44]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}}, 
                 "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], 
                   Offset[0.14], {
                    Offset[0.77]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.4]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}], 
            Cell[
             StyleData[
             "3ColumnTableMod", "Printout", StyleDefinitions -> 
              StyleData["TableBase", "Printout"]], 
             GridBoxOptions -> {GridBoxItemSize -> {"Columns" -> {
                   Scaled[0.08], 
                   Scaled[0.25], 
                   Scaled[0.25], {
                    Scaled[0.42]}}, "ColumnsIndexed" -> {}, "Rows" -> {{1.}}, 
                 "RowsIndexed" -> {}}, GridBoxSpacings -> {"Columns" -> {
                   Offset[0.28], {
                    Offset[0.56]}, 
                   Offset[0.28]}, "ColumnsIndexed" -> {}, "Rows" -> {
                   Offset[0.2], {
                    Offset[0.56]}, 
                   Offset[0.2]}, "RowsIndexed" -> {}}}]}, Open]], 
         Cell[
          CellGroupData[{
            Cell[
             StyleData["TableText"], Deletable -> False, StyleMenuListing -> 
             None, FontFamily -> "Verdana", FontSize -> 0.952 Inherited], 
            Cell[
             StyleData["TableText", "Printout"], 
             CellMargins -> {{24, 0}, {0, 8}}, Hyphenation -> True, 
             HyphenationOptions -> {"HyphenationCharacter" -> "-"}, 
             LineSpacing -> {1., 2, 2.}]}, Open]], 
         Cell[
          StyleData["Continuation"], FontColor -> GrayLevel[1]]}, Closed]]}, 
     Open]]}, Visible -> False, FrontEndVersion -> 
  "8.0 for Microsoft Windows (32-bit) (February 23, 2011)", StyleDefinitions -> 
  "Default.nb"]
]
(* End of Notebook Content *)

(* Internal cache information *)
(*CellTagsOutline
CellTagsIndex->{
 "ControlSuggestions"->{
  Cell[173353, 2990, 258, 7, 70, "ManipulateCaption",
   CellTags->"ControlSuggestions"],
  Cell[173614, 2999, 4440, 96, 70, "ManipulateCaption",
   CellTags->"ControlSuggestions"]},
 "Copyright"->{
  Cell[188845, 3341, 818, 23, 70, "Text",
   CellTags->"Copyright"]}
 }
*)
(*CellTagsIndex
CellTagsIndex->{
 {"ControlSuggestions", 215554, 3910},
 {"Copyright", 215753, 3915}
 }
*)
(*NotebookFileOutline
Notebook[{
Cell[1304, 31, 34328, 567, 70, "DemonstrationHeader"],
Cell[35635, 600, 76, 0, 70, "DemoTitle"],
Cell[35714, 602, 136025, 2355, 70, "Output",
 CellID->8793728],
Cell[171742, 2959, 562, 9, 70, "ManipulateCaption",
 CellID->3037421],
Cell[172307, 2970, 991, 15, 70, "ManipulateCaption",
 CellID->1363251758],
Cell[173301, 2987, 49, 1, 70, "ManipulateCaption",
 CellID->442121567],
Cell[173353, 2990, 258, 7, 70, "ManipulateCaption",
 CellTags->"ControlSuggestions"],
Cell[173614, 2999, 4440, 96, 70, "ManipulateCaption",
 CellTags->"ControlSuggestions"],
Cell[178057, 3097, 33, 0, 70, "DetailsSection"],
Cell[178093, 3099, 949, 14, 70, "DetailNotes",
 CellID->383586068],
Cell[179045, 3115, 1650, 24, 70, "DetailNotes",
 CellID->1796446233],
Cell[180698, 3141, 312, 6, 70, "DetailNotes",
 CellID->1167846943],
Cell[181013, 3149, 52, 1, 70, "DetailNotes",
 CellID->905775284],
Cell[181068, 3152, 300, 11, 70, "DetailNotes",
 CellID->15943128],
Cell[181371, 3165, 44, 0, 70, "RelatedLinksSection"],
Cell[181418, 3167, 480, 14, 70, "RelatedLinks",
 CellID->1703391291],
Cell[181901, 3183, 571, 17, 70, "RelatedLinks",
 CellID->792929680],
Cell[182475, 3202, 4887, 91, 70, "DemoSourceNotebookSection",
 CellGroupingRules->{"SectionGrouping", 25}],
Cell[187365, 3295, 45, 0, 70, "CitationSection"],
Cell[187413, 3297, 339, 10, 70, "Author"],
Cell[187755, 3309, 1087, 30, 70, "Citations"],
Cell[188845, 3341, 818, 23, 70, "Text",
 CellTags->"Copyright"]
}
]
*)

(* End of internal cache information *)

(* NotebookSignature ZSUSKz8UHq6fwumLmVyYrrl4 *)
