clear all
close all
clc

x = linspace(0,2*pi,100);
for i = 1:100
    y(i) = sin(x(i));
end;
figure(1)
subplot(4,2,1);
plot(y,'b-');
title('plot(y,''b-'');');
subplot(4,2,2);
plot(y,'g-');
title('plot(y,''g-'');');
subplot(4,2,3);
plot(y,'r-');
title('plot(y,''r-'');');
subplot(4,2,4);
plot(y,'c-');
title('plot(y,''c-'');');
subplot(4,2,5);
plot(y,'m-');
title('plot(y,''m-'');');
subplot(4,2,6);
plot(y,'y-');
title('plot(y,''y-'');');
subplot(4,2,7);
plot(y,'k-');
title('plot(y,''k-'');');
subplot(4,2,8);
plot(y,'w-');
title('plot(y,''w-'');');
