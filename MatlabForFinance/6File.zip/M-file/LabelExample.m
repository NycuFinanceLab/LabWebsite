clear all
close all
clc

x = linspace(0,2*pi,50);
y = zeros(1,50);
for i = 1:50
    y(i) = sin(x(i));
end;
figure(1)
subplot(4,1,1);
plot(x,y,'b.');
title('plot(y,''b.'');');
subplot(4,1,2);
plot(x,y,'bo');
title('plot(y,''bo'');');
subplot(4,1,3);
plot(x,y,'bx');
title('plot(y,''bx'');');
subplot(4,1,4);
plot(x,y,'b+');
title('plot(y,''b+'');');

figure(2)
subplot(4,1,1);
plot(x,y,'b*');
title('plot(y,''b*'');');
subplot(4,1,2);
plot(x,y,'bs');
title('plot(y,''bs'');');
subplot(4,1,3);
plot(x,y,'bd');
title('plot(y,''bd'');');
subplot(4,1,4);
plot(x,y,'bv');
title('plot(y,''bv'');');

figure(3)
subplot(5,1,1);
plot(x,y,'b^');
title('plot(y,''b^'');');
subplot(5,1,2);
plot(x,y,'b<');
title('plot(y,''b<'');');
subplot(5,1,3);
plot(x,y,'b>');
title('plot(y,''b>'');');
subplot(5,1,4);
plot(x,y,'bp');
title('plot(y,''bp'');');
subplot(5,1,5);
plot(x,y,'bh');
title('plot(y,''bh'');');