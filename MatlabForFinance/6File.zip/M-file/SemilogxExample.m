clear all
close all
clc

x = linspace(0,8*pi);
semilogx(x,sin(x));