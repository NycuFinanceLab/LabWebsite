clear all
close all
clc

x = 51.5;
y = [50.9,50.6,50.5,50.3,50.6,51.5,51.5,51.1,50.6,51.5];


figure(1)
subplot(3,1,1)
plot(x,'ro-');
subplot(3,1,2)
plot(y,'ro-');
subplot(3,1,3)
plot(y,'ro-');