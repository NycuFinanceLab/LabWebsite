clear all
close all
clc
x = linspace(0,2*pi,50);
y = zeros(1,50);
for i = 1:50
    y(i) = sin(x(i));
end;
figure(1)
subplot(4,1,1);
plot(x,y,'b-');
title('plot(y,''b-'');');
subplot(4,1,2);
plot(x,y,'b:');
title('plot(y,''b:'');');
subplot(4,1,3);
plot(x,y,'b-.');
title('plot(y,''b-.'');');
subplot(4,1,4);
plot(x,y,'b--');
title('plot(y,''b--'');');