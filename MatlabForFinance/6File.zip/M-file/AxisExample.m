clear all
close all
clc

x = linspace(0,2*pi,100);
y = cos(x);
z = sin(x);
figure(1)
subplot(2,3,1)
plot(x,y,'g-',x,z,'ro');
axis([0,2*pi,-1,1])
title('axis([0,2*pi,-1,1])')
subplot(2,3,2)
plot(x,y,'g-',x,z,'ro');
axis('auto')
title('axis(''auto'')')
subplot(2,3,3)
plot(x,y,'g-',x,z,'ro');
axis('ij')
title('axis(''ij'')')
subplot(2,3,4)
plot(x,y,'g-',x,z,'ro');
axis('square')
title('axis(''square'')')
subplot(2,3,5)
plot(x,y,'g-',x,z,'ro');
axis('equal')
title('axis(''equal'')')
subplot(2,3,6)
plot(x,y,'g-',x,z,'ro');
axis off
title('axis off')