clear all
close all
clc

x = linspace(0,2*pi,20);
y = cos(x);
L = linspace(0.1,0.1,20);
U = L;
[theta , r] = cart2pol(x,y);

figure(1)
subplot(3,3,1)
bar(x,y);
axis([0,6,-1,1]);
title('bar(x,y)');
subplot(3,3,2)
compass(x,y)
axis on
axis([0,6,-1,1]);
title('compass(x,y)');
subplot(3,3,3)
errorbar(x,y,L,U);
axis([0,6,-1,1]);
title('errorbar(x,y,L,U)')
subplot(3,3,4)
feather(x,y)
axis([0,25,-1,1]);
title('feather(x,y)');
subplot(3,3,5)
hist(y);
title('hist(y)');
subplot(3,3,6)
stairs(x,y);
title('stairs(x,y)');
axis([0,6.5,-1,1]);
subplot(3,3,7)
stem(x,y);
title('stem(x,y)');
axis([0,6.5,-1,1]);
subplot(3,3,8)
polar(theta,r);
title('polar(theta,r)');
subplot(3,3,9)
rose(theta);
title('rose(theta)');