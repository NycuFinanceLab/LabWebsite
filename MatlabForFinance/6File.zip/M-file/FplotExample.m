clear all
close all
clc

fplot('sin(1/x)', [0.02 0.2]);