function ans1 = func3(v1, vector2)
% This is a function output max(in,avg(vector))
ave=func1(vector2); 
ans1 = max(v1,ave);
disp(['the value1 is ', num2str(v1)])
disp(['the ave of vector2 is ',num2str(ave)])
fprintf('max is  %d' , ans1)
