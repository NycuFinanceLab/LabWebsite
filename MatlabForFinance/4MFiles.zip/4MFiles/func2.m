function [ave1, ave2] = func2(vector1, vector2)
% Func2 is a function for 2 inputs and outputs
%
% You can enter one input or two input
if nargin == 1,		% �u���@�ӿ�J�ܼ�
	ave1 = sum(vector1)/length(vector1);
end

if nargout == 2,		% ����ӿ�X�ܼ�
	ave1 = sum(vector1)/length(vector1);
	ave2 = sum(vector2)/length(vector2);
end
